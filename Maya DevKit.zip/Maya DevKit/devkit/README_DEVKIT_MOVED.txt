The Autodesk Maya 2017 Developer Kit is available online on Autodesk Exchange at https://apps.exchange.autodesk.com/MAYA/en/Home/Index
Refer to the "Setting up your build environment" section of the Maya Developer Help for information on how to install and set up the Maya Developer Kit. 
You can find the Developer Help at: http://www.autodesk.com/maya-help-2017-enu/?contextId=BUILD_ENVIRONMENT