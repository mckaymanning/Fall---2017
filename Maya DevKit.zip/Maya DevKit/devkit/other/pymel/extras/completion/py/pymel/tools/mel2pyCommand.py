"""
Symbolic link it to an easier-to-type name (ie, 'mel2py') in a directory on your path
"""

class Options(dict):
    """
    Wrap of a dictionary object to get options parsed from OptionParser into a dict.
    """
    
    
    
    def __setattr__(self, name, value):
        pass
    
    
    __dict__ = None
    
    __weakref__ = None



def main():
    pass



