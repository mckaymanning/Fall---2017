from sets import Set

def resetTypeCurve(attributeName, curveName):
    pass


def getMObjectFromName(nodeName):
    pass


def setCurveAttr(myRamp, pos, val):
    pass


def getFalloffCurveAttr(thisNode, attr):
    """
    # curve utilities
    """

    pass


def splitTypeMaterials(extrudeNode, meshShape, typeNode):
    """
    #assign materials to the type tool
    """

    pass


def resetAllManipulations(nodeName):
    """
    #resets all manipulations.
    """

    pass


def joinTypeMaterials(meshShape, typeNode):
    pass


def getShaderFromArray(GrpMessageConections):
    """
    #given a list of nodes, find the shading engine, and it's material
    """

    pass


def getShadingGroupsFromObject(mesh):
    """
    #get the shaders attached to an object
    """

    pass


def getVectorShadingGroups(mesh, extrudeNode):
    """
    #given the group nodes, get the associated materials
    """

    pass


def getShaderFromObject(mesh):
    """
    #get the shader attribute attached to an object
    #this and the next function are VERY similar, but they go about their task in different ways - which only work in different situations.
    """

    pass


def setCurvePreset(attributeName, valueString):
    pass


def flipTypeManipulator():
    pass


def checkTypeManipButton():
    """
    #check if the manipulator is loaded and make sure the manip button background is correct (run from AE replacement)
    """

    pass


def setShellAnimateKeys(typeNode):
    """
    #sets keys for TRS on the animaiton attributes
    """

    pass


def particlesToTypePivotPoints():
    pass


def toggleTypeManipButton(typeNode):
    """
    #this function is used to toggle the colour of the manipulator button (dark background when the manip is selected)
    """

    pass


def getCurrentCtxName():
    pass



