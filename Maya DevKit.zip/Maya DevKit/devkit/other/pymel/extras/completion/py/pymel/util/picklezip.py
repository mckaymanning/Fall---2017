def _loads(filename):
    """
    Load a compressed pickle from disk to an upicklable string
    """

    pass


def dump(object, filename, protocol=-1):
    """
    Save an compressed pickle to disk.
    """

    pass


def load(filename):
    """
    Load a compressed pickle from disk
    """

    pass



