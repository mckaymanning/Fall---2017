def disown_MPxRepresentation(*args, **kwargs):
    pass


def MPxTransform_rotateQuaternionZ_set(*args, **kwargs):
    pass


def MPxCacheFormat_writeHeader(*args, **kwargs):
    pass


def MPxTransform_drawOverride_get(*args, **kwargs):
    pass


def MPxContext_deleteManipulators(*args, **kwargs):
    pass


def MPxBlendShape_inputTargetItem_set(*args, **kwargs):
    pass


def MPxTransform_overrideVisibility_set(*args, **kwargs):
    pass


def MPxRenderPassImpl_perLightPassContributionSupported(*args, **kwargs):
    pass


def MFnPlugin_registerRenderPassImpl(*args, **kwargs):
    pass


def MPxTransform_minTransZLimitEnable_set(*args, **kwargs):
    pass


def MPxGeometryIterator_point(*args, **kwargs):
    pass


def MPxTransform_maxRotLimitEnable_get(*args, **kwargs):
    pass


def MPxSurfaceShape_nodeBoundingBoxSize_get(*args, **kwargs):
    pass


def MPxImagePlane_colorGainR_set(*args, **kwargs):
    pass


def MPxTransform_overrideTexturing_get(*args, **kwargs):
    pass


def MPxTransform_minRotLimitEnable_set(*args, **kwargs):
    pass


def MPxTransformationMatrix_asMatrix(*args, **kwargs):
    pass


def MPxSurfaceShape_objectColor_set(*args, **kwargs):
    pass


def MPx3dModelView_drawInterrupt(*args, **kwargs):
    pass


def delete_MPxMultiPolyTweakUVCommand(*args, **kwargs):
    pass


def MPxSurfaceShape_objectGroupColor_set(*args, **kwargs):
    pass


def MPxTransform__dirtyScale(*args, **kwargs):
    pass


def MPxBlendShape_className(*args, **kwargs):
    pass


def MPx3dModelView_viewToObjectSpace(*args, **kwargs):
    pass


def MPxTransform_type(*args, **kwargs):
    pass


def MPxTransform_nodeBoundingBoxSizeX_get(*args, **kwargs):
    pass


def MPxContextCommand_doQueryFlags(*args, **kwargs):
    pass


def MPxAssembly_getRepType(*args, **kwargs):
    pass


def MPxCommand_setUndoable(*args, **kwargs):
    pass


def MPxManipulatorNode_xColor(*args, **kwargs):
    pass


def MPxEmitterNode_mMinDistance_get(*args, **kwargs):
    pass


def MPxMayaAsciiFilter_writesSetAttr(*args, **kwargs):
    pass


def MPxIkSolverNode_hasUniqueSolution(*args, **kwargs):
    pass


def MPxTransform_minTransLimitEnable_set(*args, **kwargs):
    pass


def MPxSurfaceShape_hasActiveComponents(*args, **kwargs):
    pass


def SWIG_PyInstanceMethod_New(*args, **kwargs):
    pass


def MPxTransform_scalePivotTranslate_get(*args, **kwargs):
    pass


def MPxCacheFormat_writeDoubleVectorArray(*args, **kwargs):
    pass


def delete_MPxSurfaceShapeUI(*args, **kwargs):
    pass


def MPxFluidEmitterNode_turbulence(*args, **kwargs):
    pass


def MPxTransform_nodeBoundingBoxMaxZ_get(*args, **kwargs):
    pass


def MPxLocatorNode_localScale_get(*args, **kwargs):
    pass


def MPxLocatorNode_objectGroupColor_get(*args, **kwargs):
    pass


def MFnPlugin_unregisterMaterialInfo(*args, **kwargs):
    pass


def MPxIkSolverNode_funcValueTolerance(*args, **kwargs):
    pass


def MPxImageFile_load(*args, **kwargs):
    pass


def MPxTransform_minScaleZLimit_get(*args, **kwargs):
    pass


def MPxTransform_getScalePivotTranslation(*args, **kwargs):
    pass


def new_MPxGeometryFilter(*args, **kwargs):
    pass


def MPxLocatorNode_intermediateObject_get(*args, **kwargs):
    pass


def MPxTransform_nodeBoundingBoxMax_set(*args, **kwargs):
    pass


def delete_MPx3dModelView(*args, **kwargs):
    pass


def MaterialInputData_specular_set(*args, **kwargs):
    pass


def MPxLocatorNode_useObjectColor_get(*args, **kwargs):
    pass


def MPxNode_state_get(*args, **kwargs):
    pass


def MPxControlCommand_appendSyntax(*args, **kwargs):
    pass


def MPxGlBuffer_closeFbo(*args, **kwargs):
    pass


def MPxTransform_selectHandleX_set(*args, **kwargs):
    pass


def MPxFluidEmitterNode_mFluidColorG_get(*args, **kwargs):
    pass


def MPxTransform_inverseMatrix_set(*args, **kwargs):
    pass


def MPxGeometryFilter_groupId_get(*args, **kwargs):
    pass


def MPxTransform_className(*args, **kwargs):
    pass


def MPxIkSolverNode_create(*args, **kwargs):
    pass


def MPxTransform_maxTransZLimitEnable_set(*args, **kwargs):
    pass


def MPx3dModelView_viewToWorld(*args, **kwargs):
    pass


def MPxSurfaceShape_center_set(*args, **kwargs):
    pass


def MPxImagePlane_useFrameExtension_set(*args, **kwargs):
    pass


def MPxImagePlane_height_set(*args, **kwargs):
    pass


def MPxCacheFormat_readDescription(*args, **kwargs):
    pass


def MPxSurfaceShapeUI_swiginit(*args, **kwargs):
    pass


def MPxHwShaderNode_outColorG_set(*args, **kwargs):
    pass


def MPxFileTranslator_filter(*args, **kwargs):
    pass


def MPxTransform_resetTransformation(*args, **kwargs):
    pass


def MPxEmitterNode_evalEmission2dTexture(*args, **kwargs):
    pass


def MPxCommand_undoIt(*args, **kwargs):
    pass


def MPxTransform_displayLocalAxis_set(*args, **kwargs):
    pass


def MPxHardwareShader_render(*args, **kwargs):
    pass


def MPxMidiInputDevice_doMovementEvents(*args, **kwargs):
    pass


def MPxFluidEmitterNode_mFluidColorR_get(*args, **kwargs):
    pass


def MPxManipContainer_draw(*args, **kwargs):
    pass


def MPxTransform_getShear(*args, **kwargs):
    pass


def MPxTransform_clearLimits(*args, **kwargs):
    pass


def MPxMotionPathNode_positionMarkerTime_set(*args, **kwargs):
    pass


def MPxBlendShape_swigregister(*args, **kwargs):
    pass


def MPxSurfaceShape_deleteComponents(*args, **kwargs):
    pass


def MPxLocatorNode_type(*args, **kwargs):
    pass


def MPxObjectSet_memberWireframeColor_get(*args, **kwargs):
    pass


def MPxTransform_geometry_get(*args, **kwargs):
    pass


def MPxTransform_ghosting_set(*args, **kwargs):
    pass


def disown_MPxSpringNode(*args, **kwargs):
    pass


def new_MPxBlendShape(*args, **kwargs):
    pass


def MPxFileTranslator_canBeOpened(*args, **kwargs):
    pass


def disown_MPxRenderPassImpl(*args, **kwargs):
    pass


def delete_MPxNode(*args, **kwargs):
    pass


def MPxLocatorNode_nodeBoundingBoxMaxY_get(*args, **kwargs):
    pass


def MPx3dModelView_setTextureDisplayEnabled(*args, **kwargs):
    pass


def MPxSurfaceShape_boundingBoxCenterZ_set(*args, **kwargs):
    pass


def delete_MPxUIControl(*args, **kwargs):
    pass


def MPxImagePlane_coverageOriginY_get(*args, **kwargs):
    pass


def MPxUITableControl_allowSelection(*args, **kwargs):
    pass


def MPxTransform_overrideLevelOfDetail_set(*args, **kwargs):
    pass


def MPxSelectionContext_newToolCommand(*args, **kwargs):
    pass


def MPxHwShaderNode_outColorG_get(*args, **kwargs):
    pass


def MPx3dModelView_setDisplayHUD(*args, **kwargs):
    pass


def MPxTransform_checkAndSetRotateOrientation(*args, **kwargs):
    pass


def MPxMotionPathNode_yCoordinate_set(*args, **kwargs):
    pass


def MPxCameraSet_camera_get(*args, **kwargs):
    pass


def MPxTransform_transMinusRotatePivot_set(*args, **kwargs):
    pass


def MPxNode_className(*args, **kwargs):
    pass


def MPxLocatorNode_inverseMatrix_set(*args, **kwargs):
    pass


def new_MPxFluidEmitterNode(*args, **kwargs):
    pass


def MPxSkinCluster_swiginit(*args, **kwargs):
    pass


def MFnPlugin_deregisterCommand(*args, **kwargs):
    pass


def MPxCommand_currentStringResult(*args, **kwargs):
    pass


def MPxManipContainer_addRotateManip(*args, **kwargs):
    pass


def MPxCacheFormat_swiginit(*args, **kwargs):
    pass


def MPx3dModelView_className(*args, **kwargs):
    pass


def MPxMotionPathNode_upAxis_get(*args, **kwargs):
    pass


def MPx3dModelView_setViewSelectedSet(*args, **kwargs):
    pass


def MPxAnimCurveInterpolator_initialize(*args, **kwargs):
    pass


def MPxIkSolverNode_setSingleChainOnly(*args, **kwargs):
    pass


def MPxSurfaceShape_vertexOffsetDirection(*args, **kwargs):
    pass


def MPx3dModelView_setDisplayStyle(*args, **kwargs):
    pass


def MPxTransform_rotatePivot_set(*args, **kwargs):
    pass


def MPxObjectSet_partition_set(*args, **kwargs):
    pass


def MPxCacheFormat_endWriteChunk(*args, **kwargs):
    pass


def MPxTransformationMatrix_scaleTo(*args, **kwargs):
    pass


def new_MPxAssembly(*args, **kwargs):
    pass


def MPxHwShaderNode_outMatteOpacityB_set(*args, **kwargs):
    pass


def MPxSpringNode_type(*args, **kwargs):
    pass


def MPx3dModelView_isTextureDisplayEnabled(*args, **kwargs):
    pass


def MPxBlendShape_inputPointsTarget_get(*args, **kwargs):
    pass


def MPxFileResolver_getURIResolversByScheme(*args, **kwargs):
    pass


def MFnPlugin_registerAttributePatternFactory(*args, **kwargs):
    pass


def MPxFileTranslator_defaultExtension(*args, **kwargs):
    pass


def MPxGeometryIterator_hasNormals(*args, **kwargs):
    pass


def MPxTransform_maxRotYLimitEnable_get(*args, **kwargs):
    pass


def MPxSurfaceShape_nodeBoundingBoxMinX_get(*args, **kwargs):
    pass


def MPxMotionPathNode_zCoordinate_set(*args, **kwargs):
    pass


def MPxImagePlane_colorGainB_set(*args, **kwargs):
    pass


def MPxTransform_shearBy(*args, **kwargs):
    pass


def MPxLocatorNode_nodeBoundingBoxMaxZ_get(*args, **kwargs):
    pass


def MPxMayaAsciiFilterOutput_swigregister(*args, **kwargs):
    pass


def MPxEmitterNode_mOwnerPosData_set(*args, **kwargs):
    pass


def MPxMotionPathNode_position(*args, **kwargs):
    pass


def MPxCameraSet_type(*args, **kwargs):
    pass


def MPxTransform_checkAndSetShear(*args, **kwargs):
    pass


def MPxFieldNode_mUseMaxDistance_get(*args, **kwargs):
    pass


def MPxTransform_treatAsTransform(*args, **kwargs):
    pass


def MPxNode_isPassiveOutput(*args, **kwargs):
    pass


def MPxTransformationMatrix_copyValues(*args, **kwargs):
    pass


def MPxFieldNode_mOwnerVelData_set(*args, **kwargs):
    pass


def MPxDragAndDropBehavior_connectAttrToNode(*args, **kwargs):
    pass


def MPxCommand_displayInfo(*args, **kwargs):
    pass


def MPxLocatorNode_localPositionY_set(*args, **kwargs):
    pass


def MPxEmitterNode_mCurrentTime_get(*args, **kwargs):
    pass


def MPx3dModelView_setFogMode(*args, **kwargs):
    pass


def MPxConstraint_enableRestPosition_set(*args, **kwargs):
    pass


def MPxIkSolverNode_setMaxIterations(*args, **kwargs):
    pass


def MPxEditData__dataValue_get(*args, **kwargs):
    pass


def MPxSurfaceShape_evalNodeAffectsDrawDb(*args, **kwargs):
    pass


def MPx3dModelView_isBackgroundGradient(*args, **kwargs):
    pass


def MPxHardwareShader_outColorR_get(*args, **kwargs):
    pass


def MPxHwShaderNode_invertTexCoords(*args, **kwargs):
    pass


def MPxSurfaceShapeUI_select(*args, **kwargs):
    pass


def disown_MPxCameraSet(*args, **kwargs):
    pass


def MPxHwShaderNode_currentShadingEngine(*args, **kwargs):
    pass


def MPxGeometryData_copy(*args, **kwargs):
    pass


def MPxTransform_rotate_set(*args, **kwargs):
    pass


def MPxNode_setInternalValueInContext(*args, **kwargs):
    pass


def MPxSurfaceShape_objectGroups_set(*args, **kwargs):
    pass


def MPxTransform_rotationInterpolation_set(*args, **kwargs):
    pass


def MPxTransform_maxScaleLimit_set(*args, **kwargs):
    pass


def MPxLocatorNode_colorRGB(*args, **kwargs):
    pass


def MPx3dModelView_setCurrentCameraSetCamera(*args, **kwargs):
    pass


def MPxHwShaderNode_swigregister(*args, **kwargs):
    pass


def disown_MPxManipContainer(*args, **kwargs):
    pass


def MPxHwShaderNode_provideFaceIDs(*args, **kwargs):
    pass


def MPxLocatorNode_instObjGroups_get(*args, **kwargs):
    pass


def MPx3dModelView_preMultipleDraw(*args, **kwargs):
    pass


def MaterialInputData_hasTransparency_set(*args, **kwargs):
    pass


def MPxLocatorNode_objectColor_set(*args, **kwargs):
    pass


def MPxData_readBinary(*args, **kwargs):
    pass


def MPxDragAndDropBehavior_connectNodeToNode(*args, **kwargs):
    pass


def MPxFluidEmitterNode_mEmitFluidColor_get(*args, **kwargs):
    pass


def MPxTransform_identification_set(*args, **kwargs):
    pass


def MPxUIControl_className(*args, **kwargs):
    pass


def MPxNode_frozen_get(*args, **kwargs):
    pass


def MPxTransformationMatrix_asTransformationMatrix(*args, **kwargs):
    pass


def MPxAssembly_inactivateRep(*args, **kwargs):
    pass


def disown_MPxObjectSet(*args, **kwargs):
    pass


def MPxImagePlane_displayOnlyIfCurrent_get(*args, **kwargs):
    pass


def MPxMayaAsciiFilter_writePreConnectAttrsBlock(*args, **kwargs):
    pass


def MPxTransform_worldInverseMatrix_set(*args, **kwargs):
    pass


def MPxGeometryFilter_outputGeom_set(*args, **kwargs):
    pass


def MPxFluidEmitterNode_fluidEmitColor(*args, **kwargs):
    pass


def MPxSkinCluster_weights_get(*args, **kwargs):
    pass


def MPxConstraintCommand_undoIt(*args, **kwargs):
    pass


def MPxImagePlane_colorOffsetR_get(*args, **kwargs):
    pass


def MPxLocatorNode_boundingBoxCenterY_get(*args, **kwargs):
    pass


def MPxCameraSet_active_set(*args, **kwargs):
    pass


def MPxLocatorNode_objectGrpCompList_get(*args, **kwargs):
    pass


def MPxTransform_overrideDisplayType_get(*args, **kwargs):
    pass


def delete_MPxTexContext(*args, **kwargs):
    pass


def MPxManipulatorNode_prevColor(*args, **kwargs):
    pass


def MPx3dModelView_refresh(*args, **kwargs):
    pass


def MPxManipulatorNode_doPress(*args, **kwargs):
    pass


def MPxMotionPathNode_bankThreshold_set(*args, **kwargs):
    pass


def MPxTransform_scaleX_get(*args, **kwargs):
    pass


def MPxTransform_minScaleZLimitEnable_set(*args, **kwargs):
    pass


def delete_MPxHardwareShader(*args, **kwargs):
    pass


def disown_MPxMidiInputDevice(*args, **kwargs):
    pass


def MPxTransform_rotateQuaternion_get(*args, **kwargs):
    pass


def MPxMaterialInformation_fInstance_set(*args, **kwargs):
    pass


def MPxToolCommand_cancel(*args, **kwargs):
    pass


def MPxConstraintCommand_getObjectAttributesArray(*args, **kwargs):
    pass


def MPx3dModelView_customDraw(*args, **kwargs):
    pass


def MPx3dModelView_setFogEnd(*args, **kwargs):
    pass


def MPxHwShaderNode_supportsBatching(*args, **kwargs):
    pass


def MPxManipulatorNode_lineColor(*args, **kwargs):
    pass


def MPxSurfaceShape_geometryIteratorSetup(*args, **kwargs):
    pass


def MPxAssembly_addConnectAttrEdit(*args, **kwargs):
    pass


def MPxGeometryFilter_accessoryAttribute(*args, **kwargs):
    pass


def MPxObjectSet_isLayer_get(*args, **kwargs):
    pass


def MPxMaterialInformation_swiginit(*args, **kwargs):
    pass


def MPxTransform_objectGroups_set(*args, **kwargs):
    pass


def MPxDeformerNode_className(*args, **kwargs):
    pass


def MPxTransform_overrideShading_get(*args, **kwargs):
    pass


def MPxParticleAttributeMapperNode_outValuePP_get(*args, **kwargs):
    pass


def new_MPxGeometryData(*args, **kwargs):
    pass


def new_MPxFileResolver(*args, **kwargs):
    pass


def MPxSurfaceShape_worldInverseMatrix_get(*args, **kwargs):
    pass


def MPxSelectionContext_processNumericalInput(*args, **kwargs):
    pass


def MPxUITableControl_isSelected(*args, **kwargs):
    pass


def MPxManipulatorNode_glFirstHandle(*args, **kwargs):
    pass


def MPx3dModelView_setDrawAdornments(*args, **kwargs):
    pass


def MPxLocatorNode_nodeBoundingBoxSizeX_get(*args, **kwargs):
    pass


def delete_MPxPolyTweakUVCommand(*args, **kwargs):
    pass


def MPxComponentShape_componentToPlugs(*args, **kwargs):
    pass


def MPxLocatorNode_localPosition_get(*args, **kwargs):
    pass


def MPxTransformationMatrix_baseTransformationMatrixId_get(*args, **kwargs):
    pass


def delete_MPxCommand(*args, **kwargs):
    pass


def MPxContext_stringClassName(*args, **kwargs):
    pass


def MPxFieldNode_mInputForce_set(*args, **kwargs):
    pass


def MFnPlugin_registerFileTranslator(*args, **kwargs):
    pass


def new_MPxLocatorNode(*args, **kwargs):
    pass


def MPxManipContainer_addMPxManipulatorNode(*args, **kwargs):
    pass


def MPxMotionPathNode_upTwist_get(*args, **kwargs):
    pass


def MPxEmitterNode_mRandStateY_get(*args, **kwargs):
    pass


def MPxMotionPathNode_worldUpType_set(*args, **kwargs):
    pass


def MPx3dModelView_setObjectsToView(*args, **kwargs):
    pass


def new_MPxAnimCurveInterpolator(*args, **kwargs):
    pass


def MPxImagePlane_squeezeCorrection_get(*args, **kwargs):
    pass


def MPx3dModelView_preMultipleDrawPass(*args, **kwargs):
    pass


def MFnPlugin_registerURIFileResolver(*args, **kwargs):
    pass


def MPxObjectSet_usedByNodes_set(*args, **kwargs):
    pass


def MPxCacheFormat_writeTime(*args, **kwargs):
    pass


def MPxMotionPathNode_orientMatrix_get(*args, **kwargs):
    pass


def MPxEmitterNode_mStartTime_set(*args, **kwargs):
    pass


def MPxFluidEmitterNode_swigregister(*args, **kwargs):
    pass


def MPxGeometryData_typeId(*args, **kwargs):
    pass


def MPxTransform_translateZ_set(*args, **kwargs):
    pass


def MPxConstraintCommand_constraintTypeId(*args, **kwargs):
    pass


def MPxContextCommand_swigregister(*args, **kwargs):
    pass


def MPxGeometryIterator_maxPoints(*args, **kwargs):
    pass


def MPxTransform_maxRotZLimitEnable_set(*args, **kwargs):
    pass


def MPxSurfaceShape_nodeBoundingBoxMinY_set(*args, **kwargs):
    pass


def MPxTransform_displayScalePivot_set(*args, **kwargs):
    pass


def MPxHardwareShader_outColorB_set(*args, **kwargs):
    pass


def MPxLocatorNode_worldMatrix_get(*args, **kwargs):
    pass


def MPxImagePlane_depth_set(*args, **kwargs):
    pass


def MPxMultiPolyTweakUVCommand_swiginit(*args, **kwargs):
    pass


def disown_MPxComponentShape(*args, **kwargs):
    pass


def MPxFieldNode_mMaxDistance_set(*args, **kwargs):
    pass


def MPxCommand_isUndoable(*args, **kwargs):
    pass


def MPxTransformationMatrix___eq__(*args, **kwargs):
    pass


def MFnPlugin_removeMenuItem(*args, **kwargs):
    pass


def MPxFieldNode_mOwnerPosData_get(*args, **kwargs):
    pass


def MPxAssembly_setRepName(*args, **kwargs):
    pass


def MPxTransform_rotatePivot_get(*args, **kwargs):
    pass


def new_MPxMultiPolyTweakUVCommand(*args, **kwargs):
    pass


def MPxLocatorNode_localPosition_set(*args, **kwargs):
    pass


def MPxTransform_boundingBoxCenterX_get(*args, **kwargs):
    pass


def MPxContext_helpStateHasChanged(*args, **kwargs):
    pass


def MPxMotionPathNode_bankScale_set(*args, **kwargs):
    pass


def MPxImagePlane_center_set(*args, **kwargs):
    pass


def MExternalContentLocationTable_length(*args, **kwargs):
    pass


def MPxSurfaceShape_boundingBox(*args, **kwargs):
    pass


def MPxLocatorNode_objectGroups_get(*args, **kwargs):
    pass


def MPxImagePlane_type(*args, **kwargs):
    pass


def MPxUITableControl_numberOfRows(*args, **kwargs):
    pass


def MPxTransformationMatrix_isEquivalent(*args, **kwargs):
    pass


def MPxFileResolver_className(*args, **kwargs):
    pass


def MPxTransform_scale_get(*args, **kwargs):
    pass


def MPxNode_legalConnection(*args, **kwargs):
    pass


def MPxTransform_maxScaleYLimit_set(*args, **kwargs):
    pass


def MPxUITableControl_addToSelection(*args, **kwargs):
    pass


def MPxSurfaceShape_weightedTweakUsing(*args, **kwargs):
    pass


def MPxTransform_rotateAxisY_set(*args, **kwargs):
    pass


def MPxLocatorNode_nodeBoundingBoxSizeY_set(*args, **kwargs):
    pass


def MPxTransform_rotatePivotTranslate_get(*args, **kwargs):
    pass


def MPxParticleAttributeMapperNode_vCoordPP_get(*args, **kwargs):
    pass


def MFnPlugin_deregisterModelEditorCommand(*args, **kwargs):
    pass


def delete_MaterialInputData(*args, **kwargs):
    pass


def MPxTransform_translateX_set(*args, **kwargs):
    pass


def MPxCameraSet_sceneData_get(*args, **kwargs):
    pass


def MPxConstraintCommand_worldUpVectorAttribute(*args, **kwargs):
    pass


def disown_MPxBakeEngine(*args, **kwargs):
    pass


def MPxMotionPathNode_sideTwist_set(*args, **kwargs):
    pass


def MPxImagePlane_alreadyPremult_get(*args, **kwargs):
    pass


def MPxTransform__dirtyMatrix(*args, **kwargs):
    pass


def MPxSurfaceShape_mControlPoints_set(*args, **kwargs):
    pass


def MPxCommand_setResult(*args, **kwargs):
    pass


def MPxTransform_displayHandle_set(*args, **kwargs):
    pass


def MPxTransform_parentMatrix_set(*args, **kwargs):
    pass


def MPxTransform_nodeBoundingBoxMinZ_get(*args, **kwargs):
    pass


def MPxGeometryFilter_className(*args, **kwargs):
    pass


def MPxFluidEmitterNode_mEmissionFunction_set(*args, **kwargs):
    pass


def MPxSkinCluster_matrix_set(*args, **kwargs):
    pass


def MPxConstraintCommand_constraintNode(*args, **kwargs):
    pass


def MPxEditData_swigregister(*args, **kwargs):
    pass


def MPxImagePlane_imageName_set(*args, **kwargs):
    pass


def MPxImagePlane_colorOffsetB_set(*args, **kwargs):
    pass


def MPxSurfaceShape_inverseMatrix_get(*args, **kwargs):
    pass


def MPxTransform_getScale(*args, **kwargs):
    pass


def MPxHwShaderNode_outTransparency_set(*args, **kwargs):
    pass


def MPx3dModelView_setCameraInDraw(*args, **kwargs):
    pass


def MPx3dModelView_setViewSelectedPrefix(*args, **kwargs):
    pass


def MPxMotionPathNode_updateOrientationMarkers_get(*args, **kwargs):
    pass


def MPxTransform_maxScaleXLimitEnable_get(*args, **kwargs):
    pass


def MPxTransformationMatrix_setScalePivot(*args, **kwargs):
    pass


def MPxMidiInputDevice_swiginit(*args, **kwargs):
    pass


def MPxAssembly_swigregister(*args, **kwargs):
    pass


def disown_MPxTexContext(*args, **kwargs):
    pass


def MPxEmitterNode_mDirectionX_set(*args, **kwargs):
    pass


def MPxFluidEmitterNode_mFluidHeatEmission_set(*args, **kwargs):
    pass


def MPxManipContainer_addDistanceManip(*args, **kwargs):
    pass


def MPxPolyTweakUVInteractiveCommand_swigregister(*args, **kwargs):
    pass


def MPxGeometryData_smartCopy(*args, **kwargs):
    pass


def MPxEmitterNode_getWorldMatrix(*args, **kwargs):
    pass


def MPxMotionPathNode_follow_set(*args, **kwargs):
    pass


def MPxImagePlane_depthScale_get(*args, **kwargs):
    pass


def MPxIkSolverNode__setJointAngles(*args, **kwargs):
    pass


def MPxImagePlane_alphaGain_get(*args, **kwargs):
    pass


def MPxUITableControl_getCellColor(*args, **kwargs):
    pass


def MPxSurfaceShape_getComponentSelectionMask(*args, **kwargs):
    pass


def MPxMotionPathNode_inverseUp_set(*args, **kwargs):
    pass


def MPxObjectSet_edgesOnlySet_get(*args, **kwargs):
    pass


def MPxCacheFormat_open(*args, **kwargs):
    pass


def MPxTransform_objectGroupId_set(*args, **kwargs):
    pass


def MPxDeformerNode_swiginit(*args, **kwargs):
    pass


def MPxSpringNode_mEnd2Weight_set(*args, **kwargs):
    pass


def MPxBlendShape_weight_set(*args, **kwargs):
    pass


def MPxTransform_overrideTexturing_set(*args, **kwargs):
    pass


def MPxTransform_translateY_set(*args, **kwargs):
    pass


def new_MPxMayaAsciiFilter(*args, **kwargs):
    pass


def MPxFileResolver_resolveURIWithContext(*args, **kwargs):
    pass


def MPxSurfaceShape_matrix_set(*args, **kwargs):
    pass


def MPxImagePlane_displayMode_get(*args, **kwargs):
    pass


def MPxManipulatorNode_newManipulator(*args, **kwargs):
    pass


def MPxTransform_displayHandle_get(*args, **kwargs):
    pass


def disown_MPxHwShaderNode(*args, **kwargs):
    pass


def MPxManipContainer_type(*args, **kwargs):
    pass


def MPxLocatorNode_nodeBoundingBoxSizeZ_get(*args, **kwargs):
    pass


def MPxPolyTweakUVCommand_newSyntax(*args, **kwargs):
    pass


def MPxTransform_overrideLevelOfDetail_get(*args, **kwargs):
    pass


def MPxFieldNode_mMaxDistance_get(*args, **kwargs):
    pass


def MPxTransform_lodVisibility_set(*args, **kwargs):
    pass


def MPxTransform_maxScaleYLimitEnable_get(*args, **kwargs):
    pass


def MPxTransformationMatrix_decomposeMatrix(*args, **kwargs):
    pass


def MPxNode_inheritAttributesFrom(*args, **kwargs):
    pass


def MPxModelEditorCommand_swigregister(*args, **kwargs):
    pass


def MPxContext_swiginit(*args, **kwargs):
    pass


def MPxFieldNode_mOwnerPPData_set(*args, **kwargs):
    pass


def MPxControlCommand_className(*args, **kwargs):
    pass


def MPx3dModelView_isTwoSidedLighting(*args, **kwargs):
    pass


def MFnPlugin_deregisterFileTranslator(*args, **kwargs):
    pass


def MPxManipContainer_addToManipConnectTable(*args, **kwargs):
    pass


def MPxTransform_getRotatePivot(*args, **kwargs):
    pass


def MPxCacheFormat_className(*args, **kwargs):
    pass


def MPxMotionPathNode_worldUpVector_set(*args, **kwargs):
    pass


def MPxMidiInputDevice_getMessage(*args, **kwargs):
    pass


def MPxMayaAsciiFilter_writer(*args, **kwargs):
    pass


def MPxIkSolverNode_isSingleChainOnly(*args, **kwargs):
    pass


def MPxEditData_swiginit(*args, **kwargs):
    pass


def MPxAssembly_getInitialRep(*args, **kwargs):
    pass


def MPxTransform_showManipDefault_set(*args, **kwargs):
    pass


def MPxSurfaceShape_componentToPlugs(*args, **kwargs):
    pass


def MPx3dModelView_setDrawColor(*args, **kwargs):
    pass


def MPxIkSolverNode_singleChainOnly(*args, **kwargs):
    pass


def MPxGeometryFilter_swiginit(*args, **kwargs):
    pass


def MPxHwShaderNode_renderSwatchImage(*args, **kwargs):
    pass


def MPxTransform_maxRotXLimit_get(*args, **kwargs):
    pass


def MPxManipulatorNode_labelColor(*args, **kwargs):
    pass


def MPxManipulatorNode_setVectorValue(*args, **kwargs):
    pass


def MPxLocatorNode_worldPositionX_set(*args, **kwargs):
    pass


def MPxTransform_rotateZ_set(*args, **kwargs):
    pass


def MFnPlugin_className(*args, **kwargs):
    pass


def MPxGeometryIterator_className(*args, **kwargs):
    pass


def MPxTransform_minScaleXLimit_get(*args, **kwargs):
    pass


def MPxSurfaceShape_boundingBoxCenterY_get(*args, **kwargs):
    pass


def MPxSurfaceShape_mHasHistoryOnCreate_set(*args, **kwargs):
    pass


def MPxTransform_rotateAxisX_set(*args, **kwargs):
    pass


def MPxLocatorNode_parentMatrix_get(*args, **kwargs):
    pass


def MaterialInputData_ambient_get(*args, **kwargs):
    pass


def delete_MPxCameraSet(*args, **kwargs):
    pass


def MPxConstraintCommand_doCreate(*args, **kwargs):
    pass


def MPxRepresentation_canApplyEdits(*args, **kwargs):
    pass


def MPxManipContainer_initialize(*args, **kwargs):
    pass


def MPxFieldNode_mMagnitude_get(*args, **kwargs):
    pass


def MPxTransform_isNonAffineMatricesEnabled(*args, **kwargs):
    pass


def MPxNode_setExternalContent(*args, **kwargs):
    pass


def MPxTransformationMatrix_transformBy(*args, **kwargs):
    pass


def MPxFieldNode_mOwnerCentroidX_get(*args, **kwargs):
    pass


def MPxAssembly_canRepApplyEdits(*args, **kwargs):
    pass


def MPxAttributePatternFactory_name(*args, **kwargs):
    pass


def MPxTransform_xformMatrix_get(*args, **kwargs):
    pass


def MPxTransform_boundingBoxCenterY_set(*args, **kwargs):
    pass


def MPxContext_addManipulator(*args, **kwargs):
    pass


def MPxGeometryFilter_setModifiedCallback(*args, **kwargs):
    pass


def MPxTransform_nodeBoundingBoxMinY_get(*args, **kwargs):
    pass


def delete_MPxSkinCluster(*args, **kwargs):
    pass


def MPxParticleAttributeMapperNode_className(*args, **kwargs):
    pass


def MPxImagePlane_centerY_set(*args, **kwargs):
    pass


def MPxFileResolver_resolveURI(*args, **kwargs):
    pass


def MPx3dModelView_colorAtIndex(*args, **kwargs):
    pass


def MPxSurfaceShape_nodeBoundingBoxMax_set(*args, **kwargs):
    pass


def MPxImagePlane_setImageDirty(*args, **kwargs):
    pass


def MPxCacheFormat_readFloatVectorArray(*args, **kwargs):
    pass


def MPxSurfaceShapeUI_material(*args, **kwargs):
    pass


def MPxLocatorNode_localScale_set(*args, **kwargs):
    pass


def MPxHwShaderNode_outTransparencyR_set(*args, **kwargs):
    pass


def MPx3dModelView_destroyOnPanelDestruction(*args, **kwargs):
    pass


def MPxFluidEmitterNode_type(*args, **kwargs):
    pass


def MPxPolyTrg_swigregister(*args, **kwargs):
    pass


def MPxEmitterNode_mCurrentTime_set(*args, **kwargs):
    pass


def MPxTransform_minScaleLimitEnable_get(*args, **kwargs):
    pass


def MPxIkSolverNode_postSolve(*args, **kwargs):
    pass


def MPxFileTranslator_haveReferenceMethod(*args, **kwargs):
    pass


def delete_MPxManipulatorNode(*args, **kwargs):
    pass


def MPxMidiInputDevice_nameAxes(*args, **kwargs):
    pass


def MPxEmitterNode_mOwnerCentroidZ_get(*args, **kwargs):
    pass


def MPxMaterialInformation_useMaterialAsTexture(*args, **kwargs):
    pass


def MPxTransform_applyRotatePivotLocks(*args, **kwargs):
    pass


def MPxLocatorNode_underWorldObject_set(*args, **kwargs):
    pass


def MPxConstraintCommand_constraintInstancedAttribute(*args, **kwargs):
    pass


def MPx3dModelView_fogMode(*args, **kwargs):
    pass


def MPxTransform_rotateQuaternionY_get(*args, **kwargs):
    pass


def MPxHwShaderNode_provideLocalUVCoord(*args, **kwargs):
    pass


def MPxSurfaceShape_mControlPoints_get(*args, **kwargs):
    pass


def MPxTransform_rotateAxis_set(*args, **kwargs):
    pass


def MPxHwShaderNode_currentPath(*args, **kwargs):
    pass


def MPxTransform_displayRotatePivot_get(*args, **kwargs):
    pass


def MPxTransform_visibility_get(*args, **kwargs):
    pass


def new_MPxParticleAttributeMapperNode(*args, **kwargs):
    pass


def MPxSkinCluster_className(*args, **kwargs):
    pass


def MFnPlugin_registerAnimCurveInterpolator(*args, **kwargs):
    pass


def MPxConstraintCommand_upVectorAttribute(*args, **kwargs):
    pass


def MPxTransform_maxRotLimit_set(*args, **kwargs):
    pass


def MPx3dModelView_setWireframeOnShaded(*args, **kwargs):
    pass


def MPxSurfaceShape_nodeBoundingBoxSizeY_get(*args, **kwargs):
    pass


def MPxImagePlane_coverageY_set(*args, **kwargs):
    pass


def MPxSelectionContext__newToolCommand(*args, **kwargs):
    pass


def MPxHwShaderNode_outGlowColorB_get(*args, **kwargs):
    pass


def MPxLocatorNode_nodeBoundingBoxMax_set(*args, **kwargs):
    pass


def MPxMotionPathNode_allCoordinates_set(*args, **kwargs):
    pass


def MPxSurfaceShape_visibility_set(*args, **kwargs):
    pass


def MPxTransformationMatrix_scalePivotTranslation(*args, **kwargs):
    pass


def MFnPlugin_name(*args, **kwargs):
    pass


def delete_MPxDragAndDropBehavior(*args, **kwargs):
    pass


def MPxTransform_overrideColor_get(*args, **kwargs):
    pass


def MPxLocatorNode_boundingBoxCenterY_set(*args, **kwargs):
    pass


def MPxTransformationMatrix_rotatePivot(*args, **kwargs):
    pass


def MPxModelEditorCommand_doQueryFlags(*args, **kwargs):
    pass


def MPxRepresentation_activate(*args, **kwargs):
    pass


def MPxFluidEmitterNode_mFluidDensityEmission_set(*args, **kwargs):
    pass


def MPxTransform_shearYZ_get(*args, **kwargs):
    pass


def MPxTexContext_swigregister(*args, **kwargs):
    pass


def MPxConstraintCommand_swigregister(*args, **kwargs):
    pass


def MPx3dModelView_handleDraw(*args, **kwargs):
    pass


def MPxImagePlane_swigregister(*args, **kwargs):
    pass


def MPxRepresentation_setExternalContent(*args, **kwargs):
    pass


def MPxIkSolverNode_solverTypeName(*args, **kwargs):
    pass


def new_MPxHwShaderNode(*args, **kwargs):
    pass


def MFnPlugin_registerCacheFormat(*args, **kwargs):
    pass


def MPxTransform_nodeBoundingBoxSizeZ_set(*args, **kwargs):
    pass


def MPxLocatorNode_intermediateObject_set(*args, **kwargs):
    pass


def MPxObjectSet_editPointsOnlySet_get(*args, **kwargs):
    pass


def MPxCacheFormat_extension(*args, **kwargs):
    pass


def MPxTransform_minRotZLimit_set(*args, **kwargs):
    pass


def MPxTransform_useObjectColor_set(*args, **kwargs):
    pass


def new_MPxBakeEngine(*args, **kwargs):
    pass


def MPxPolyTweakUVInteractiveCommand_className(*args, **kwargs):
    pass


def MPxSpringNode_mEnd2Weight_get(*args, **kwargs):
    pass


def disown_MPxFileResolver(*args, **kwargs):
    pass


def MPxNode_getInternalValueInContext(*args, **kwargs):
    pass


def MPxManipulatorNode_mainColor(*args, **kwargs):
    pass


def MPxGeometryIterator_component(*args, **kwargs):
    pass


def MPxTransform_minRotYLimitEnable_set(*args, **kwargs):
    pass


def MPxSurfaceShape_nodeBoundingBoxMin_set(*args, **kwargs):
    pass


def MPxTransform_rotateAxis_get(*args, **kwargs):
    pass


def new_MPxUIControl(*args, **kwargs):
    pass


def MPxAssembly_deleteAllRepresentations(*args, **kwargs):
    pass


def MPxManipulatorNode_draw(*args, **kwargs):
    pass


def MPx3dModelView_displayAxisAtOriginOn(*args, **kwargs):
    pass


def MPxLocatorNode_boundingBoxCenterX_get(*args, **kwargs):
    pass


def MPxMotionPathNode_rotateY_get(*args, **kwargs):
    pass


def MPxPolyTweakUVCommand_swiginit(*args, **kwargs):
    pass


def MPxBlendShape_swiginit(*args, **kwargs):
    pass


def MPxRepresentation_inactivate(*args, **kwargs):
    pass


def MPxEmitterNode_volumePrimitivePointInside(*args, **kwargs):
    pass


def MPxFluidEmitterNode_mFluidHeatEmission_get(*args, **kwargs):
    pass


def MPxTransform_updateMatrixAttrs(*args, **kwargs):
    pass


def new_MPxTransform(*args, **kwargs):
    pass


def MPxNode__setDoNotWrite(*args, **kwargs):
    pass


def MPxLocatorNode_localPositionZ_set(*args, **kwargs):
    pass


def delete_MPxSelectionContext(*args, **kwargs):
    pass


def MPxPolyTrg_registerTrgFunction(*args, **kwargs):
    pass


def MPxAssembly_getActive(*args, **kwargs):
    pass


def MPxSurfaceShape_isBounded(*args, **kwargs):
    pass


def MPxManipContainer_addPlugToManipConversion(*args, **kwargs):
    pass


def MPxMotionPathNode_rotate_set(*args, **kwargs):
    pass


def MPxFieldNode_mInputVelocities_get(*args, **kwargs):
    pass


def MPxTransform_setScalePivotTranslation(*args, **kwargs):
    pass


def MPxTransform_nodeBoundingBoxMinX_get(*args, **kwargs):
    pass


def MPxMayaAsciiFilter_writesMetadata(*args, **kwargs):
    pass


def MPxIkSolverNode_hasJointLimitSupport(*args, **kwargs):
    pass


def MPxFileResolver_resolverName(*args, **kwargs):
    pass


def MPxSurfaceShape_activeComponents(*args, **kwargs):
    pass


def MPx3dModelView_numActiveColors(*args, **kwargs):
    pass


def MPxTexContext_portSize(*args, **kwargs):
    pass


def MPxCacheFormat_writeFloatArray(*args, **kwargs):
    pass


def MPxSelectionContext_swigregister(*args, **kwargs):
    pass


def MPxTransform_translateBy(*args, **kwargs):
    pass


def MPxLocatorNode_worldPositionY_set(*args, **kwargs):
    pass


def new_MPxImageFile(*args, **kwargs):
    pass


def MPxUITableControl_collapseOrExpandRow(*args, **kwargs):
    pass


def MPxHwShaderNode_hasTransparency(*args, **kwargs):
    pass


def MPxHardwareShader_profile(*args, **kwargs):
    pass


def MPxLocatorNode_visibility_get(*args, **kwargs):
    pass


def MPxFluidEmitterNode_mFluidJitter_set(*args, **kwargs):
    pass


def MaterialInputData_emission_set(*args, **kwargs):
    pass


def MPxTransform__dirtyRotatePivot(*args, **kwargs):
    pass


def disown_MPxSurfaceShape(*args, **kwargs):
    pass


def MPxConstraintCommand_supportsOffset(*args, **kwargs):
    pass


def MPxTransform_nodeBoundingBoxMinX_set(*args, **kwargs):
    pass


def MPxFieldNode_mInputData_set(*args, **kwargs):
    pass


def MPxTransform_rotateQuaternion_set(*args, **kwargs):
    pass


def new_MPxCommand(*args, **kwargs):
    pass


def MPxTransformationMatrix_asScaleMatrixInverse(*args, **kwargs):
    pass


def MPxFieldNode_mOwnerCentroidY_set(*args, **kwargs):
    pass


def MPxAssembly_postLoad(*args, **kwargs):
    pass


def MPxImagePlane_offsetY_set(*args, **kwargs):
    pass


def MPxTransform_rotatePivotZ_get(*args, **kwargs):
    pass


def MPxMayaAsciiFilter_writePostHeader(*args, **kwargs):
    pass


def MPxUIControl_swigregister(*args, **kwargs):
    pass


def MPxTransform_matrix_get(*args, **kwargs):
    pass


def MPxEmitterNode_mRandStateX_set(*args, **kwargs):
    pass


def delete_MPxMayaAsciiFilterOutput(*args, **kwargs):
    pass


def MPxSkinCluster_weightValue(*args, **kwargs):
    pass


def MPxTransform_renderLayerColor_set(*args, **kwargs):
    pass


def MPxSurfaceShape_objectGrpCompList_set(*args, **kwargs):
    pass


def MPxImagePlane_width_get(*args, **kwargs):
    pass


def MPxTransform_maxTransYLimitEnable_set(*args, **kwargs):
    pass


def MPxManipContainer_addFreePointTriadManip(*args, **kwargs):
    pass


def MPxIkSolverNode__getJointAngles(*args, **kwargs):
    pass


def MPxSurfaceShape_nodeBoundingBoxMaxX_get(*args, **kwargs):
    pass


def MPxImagePlane_imageName_get(*args, **kwargs):
    pass


def MPxCacheFormat_findChannelName(*args, **kwargs):
    pass


def disown_MPxSurfaceShapeUI(*args, **kwargs):
    pass


def MPx3dModelView_viewSelectedSet(*args, **kwargs):
    pass


def MPxTransform_selectHandleY_get(*args, **kwargs):
    pass


def MPxHwShaderNode_outMatteOpacityG_get(*args, **kwargs):
    pass


def MPxLocatorNode_nodeBoundingBoxMinX_set(*args, **kwargs):
    pass


def MPxImagePlane_shadingSamples_get(*args, **kwargs):
    pass


def MPxUITableControl_setSelection(*args, **kwargs):
    pass


def MPxLocatorNode_localScaleX_set(*args, **kwargs):
    pass


def delete_MPxFieldNode(*args, **kwargs):
    pass


def MPxTransformationMatrix_eulerRotateOrientation(*args, **kwargs):
    pass


def MPxManipulatorNode_colorAndName(*args, **kwargs):
    pass


def MPxFluidEmitterNode_mFluidColorG_set(*args, **kwargs):
    pass


def MPxToolCommand_className(*args, **kwargs):
    pass


def MPxManipulatorNode_dependentPlugsReset(*args, **kwargs):
    pass


def MPxSurfaceShape_renderGroupComponentType(*args, **kwargs):
    pass


def MPxMotionPathNode_pathGeometry_set(*args, **kwargs):
    pass


def MPxImagePlane_depthOversample_set(*args, **kwargs):
    pass


def MPxNode_isHistoricallyInteresting_get(*args, **kwargs):
    pass


def MPxSurfaceShape_weightedTransformUsing(*args, **kwargs):
    pass


def MPxLocatorNode_visibility_set(*args, **kwargs):
    pass


def MPxTransform_getRotation(*args, **kwargs):
    pass


def MPxAssembly_getInstancePtr(*args, **kwargs):
    pass


def MPxManipulatorNode_swigregister(*args, **kwargs):
    pass


def MPxTransform_scalePivot_set(*args, **kwargs):
    pass


def MPxObjectSet_dagSetMembers_set(*args, **kwargs):
    pass


def MPxTransform_isTemplated_get(*args, **kwargs):
    pass


def MPxTransform_minRotZLimit_get(*args, **kwargs):
    pass


def MPxDeformerNode_weightValue(*args, **kwargs):
    pass


def MPx3dModelView_isBackgroundFogEnabled(*args, **kwargs):
    pass


def MPxPolyTrg_swiginit(*args, **kwargs):
    pass


def MPxFieldNode_mInputPPData_set(*args, **kwargs):
    pass


def MPxRenderPassImpl_typesSupported(*args, **kwargs):
    pass


def MPxTransform_maxRotYLimit_get(*args, **kwargs):
    pass


def MPxSurfaceShape_nodeBoundingBoxMaxY_set(*args, **kwargs):
    pass


def MPxTransform_scalePivotTranslateZ_get(*args, **kwargs):
    pass


def MPxSelectionContext_helpStateHasChanged(*args, **kwargs):
    pass


def MPxHwShaderNode_outMatteOpacity_get(*args, **kwargs):
    pass


def MPxLocatorNode_worldPositionY_get(*args, **kwargs):
    pass


def MPxTransform_minTransXLimitEnable_get(*args, **kwargs):
    pass


def delete_MPxRepresentation(*args, **kwargs):
    pass


def MPxNode_swiginit(*args, **kwargs):
    pass


def MPxModelEditorCommand_editorCommandName(*args, **kwargs):
    pass


def MPxContext_newToolCommand(*args, **kwargs):
    pass


def MFnPlugin_deregisterControlCommand(*args, **kwargs):
    pass


def MPxCommand_currentResultType(*args, **kwargs):
    pass


def MPxPolyTweakUVInteractiveCommand_doIt(*args, **kwargs):
    pass


def delete_MPxMotionPathNode(*args, **kwargs):
    pass


def MPxTransform_nodeBoundingBox_set(*args, **kwargs):
    pass


def MPxMotionPathNode_inverseFront_set(*args, **kwargs):
    pass


def MPx3dModelView_setViewSelected(*args, **kwargs):
    pass


def MPxIkSolverNode_swiginit(*args, **kwargs):
    pass


def MPxImagePlane_maxShadingSamples_get(*args, **kwargs):
    pass


def disown_MPxUITableControl(*args, **kwargs):
    pass


def MPxSurfaceShape_isRenderable(*args, **kwargs):
    pass


def MPxGeometryFilter_groupId_set(*args, **kwargs):
    pass


def MPxTransform_getMatrixInverse(*args, **kwargs):
    pass


def MPxTransform_drawOverride_set(*args, **kwargs):
    pass


def MPxSpringNode_mEnd1Weight_get(*args, **kwargs):
    pass


def MPxBlendShape_inputGeomTarget_get(*args, **kwargs):
    pass


def MPxLocatorNode_localPositionX_set(*args, **kwargs):
    pass


def MPxTransform_maxRotLimitEnable_set(*args, **kwargs):
    pass


def MPxSurfaceShape_boundingBoxCenterZ_get(*args, **kwargs):
    pass


def MPxImagePlane_colorGainG_get(*args, **kwargs):
    pass


def MPxCacheFormat_swigregister(*args, **kwargs):
    pass


def MPxManipulatorNode_doMove(*args, **kwargs):
    pass


def MPxSurfaceShape_objectGrpCompList_get(*args, **kwargs):
    pass


def delete_MPxToolCommand(*args, **kwargs):
    pass


def MPxMotionPathNode_rotateZ_set(*args, **kwargs):
    pass


def MPxLocatorNode_boundingBoxCenterZ_get(*args, **kwargs):
    pass


def MPxMultiPolyTweakUVCommand_parseSyntax(*args, **kwargs):
    pass


def MPxManipulatorNode_selectedColor(*args, **kwargs):
    pass


def MPxGeometryIterator_setMaxPoints(*args, **kwargs):
    pass


def MPxEmitterNode_swigregister(*args, **kwargs):
    pass


def MPxTransform_specifiedManipLocation_set(*args, **kwargs):
    pass


def MPxTransform_createTransformationMatrix(*args, **kwargs):
    pass


def MPxNode_dependsOn(*args, **kwargs):
    pass


def MPxContextCommand_makeObj(*args, **kwargs):
    pass


def MPxFieldNode_mWorldMatrix_set(*args, **kwargs):
    pass


def MPxAssembly_getRepLabel(*args, **kwargs):
    pass


def MPxTransform_shearXY_set(*args, **kwargs):
    pass


def delete_MExternalContentLocationTable(*args, **kwargs):
    pass


def MPxParticleAttributeMapperNode_outMinValue_get(*args, **kwargs):
    pass


def MPxContext_doRelease(*args, **kwargs):
    pass


def delete_MPxGlBuffer(*args, **kwargs):
    pass


def MPxTransform_renderLayerRenderable_get(*args, **kwargs):
    pass


def MPxConstraint_targetAttribute(*args, **kwargs):
    pass


def MPxManipulatorNode_getPointValue(*args, **kwargs):
    pass


def MExternalContentLocationTable_getEntryByIndex(*args, **kwargs):
    pass


def new_MPxPolyTrg(*args, **kwargs):
    pass


def MPx3dModelView_setUserDefinedColor(*args, **kwargs):
    pass


def MPxSurfaceShapeUI_getDrawData(*args, **kwargs):
    pass


def MPxHwShaderNode_outMatteOpacityG_set(*args, **kwargs):
    pass


def MPxFluidEmitterNode_mTurbulence_set(*args, **kwargs):
    pass


def delete_MPxModelEditorCommand(*args, **kwargs):
    pass


def MPxFileTranslator_allowMultipleFileOptimization(*args, **kwargs):
    pass


def MPxConstraintCommand_constraintTargetAttribute(*args, **kwargs):
    pass


def MPxNode_setDependentsDirty(*args, **kwargs):
    pass


def MPxImageFile_glLoad(*args, **kwargs):
    pass


def MPxTransform_minScaleZLimit_set(*args, **kwargs):
    pass


def MPxTransform_overridePlayback_set(*args, **kwargs):
    pass


def MPxTransform_minScaleYLimitEnable_set(*args, **kwargs):
    pass


def MPxHardwareShader_outColorG_get(*args, **kwargs):
    pass


def MPxManipContainer_doDrag(*args, **kwargs):
    pass


def MPxTransform_rotateQuaternionZ_get(*args, **kwargs):
    pass


def MPxEmitterNode_mDirectionY_get(*args, **kwargs):
    pass


def MPx3dModelView_name(*args, **kwargs):
    pass


def MPxTransform_shear_set(*args, **kwargs):
    pass


def MPxLocatorNode_useObjectColor_set(*args, **kwargs):
    pass


def MPxConstraintCommand_targetType(*args, **kwargs):
    pass


def MPxImagePlane_visibleInReflections_set(*args, **kwargs):
    pass


def MPxNode__forceCache(*args, **kwargs):
    pass


def MPxGlBuffer_bindFbo(*args, **kwargs):
    pass


def MPxLocatorNode_worldInverseMatrix_get(*args, **kwargs):
    pass


def MPxMayaAsciiFilter_writePreCreateNodesBlock(*args, **kwargs):
    pass


def MPxTransform_minRotXLimit_set(*args, **kwargs):
    pass


def MPxParticleAttributeMapperNode_computeNode_get(*args, **kwargs):
    pass


def MPxPolyTrg_unregisterTrgFunction(*args, **kwargs):
    pass


def new_MPxConstraintCommand(*args, **kwargs):
    pass


def MPxTransform_minRotLimit_get(*args, **kwargs):
    pass


def MaterialInputData_specular_get(*args, **kwargs):
    pass


def MPxSurfaceShape_nodeBoundingBoxSize_set(*args, **kwargs):
    pass


def MPxTransform_scalePivotTranslateY_get(*args, **kwargs):
    pass


def MPxImagePlane_frameExtension_get(*args, **kwargs):
    pass


def MPxHwShaderNode_outColorR_get(*args, **kwargs):
    pass


def MPx3dModelView_setDoUpdateOnMove(*args, **kwargs):
    pass


def MPxLocatorNode_nodeBoundingBoxMinZ_set(*args, **kwargs):
    pass


def MPxTransform_rotate_get(*args, **kwargs):
    pass


def MPxTransform_maxTransZLimit_set(*args, **kwargs):
    pass


def disown_MPxAssembly(*args, **kwargs):
    pass


def MPxGeometryData_updateCompleteVertexGroup(*args, **kwargs):
    pass


def MPxTransform_setRotatePivot(*args, **kwargs):
    pass


def MPxHardwareShader_outColorB_get(*args, **kwargs):
    pass


def new_MPxMidiInputDevice(*args, **kwargs):
    pass


def MPxFluidEmitterNode_mFluidColor_set(*args, **kwargs):
    pass


def MPxManipContainer_connectToDependNode(*args, **kwargs):
    pass


def new_MPxUITableControl(*args, **kwargs):
    pass


def MPx3dModelView_customDrawEnabled(*args, **kwargs):
    pass


def MPxImagePlane_separateDepth_set(*args, **kwargs):
    pass


def MPxIkSolverNode_setUniqueSolution(*args, **kwargs):
    pass


def MPxImagePlane_colorOffsetR_set(*args, **kwargs):
    pass


def MPxSurfaceShape_closestPoint(*args, **kwargs):
    pass


def MPxAssembly_activating(*args, **kwargs):
    pass


def MPxObjectSet_memberWireframeColor_set(*args, **kwargs):
    pass


def MPxMaterialInformation_swigregister(*args, **kwargs):
    pass


def MPxTransform_instObjGroups_get(*args, **kwargs):
    pass


def MPxDeformerNode_weights_get(*args, **kwargs):
    pass


def MPx3dModelView_fogEnd(*args, **kwargs):
    pass


def delete_MPxBlendShape(*args, **kwargs):
    pass


def MPxGeometryData_setMatrix(*args, **kwargs):
    pass


def MFnPlugin_swiginit(*args, **kwargs):
    pass


def MPxGeometryIterator_setPoint(*args, **kwargs):
    pass


def MPxEditData__setStringValue(*args, **kwargs):
    pass


def MPxTransform_applyTranslationLimits(*args, **kwargs):
    pass


def MPxSurfaceShape_parentInverseMatrix_get(*args, **kwargs):
    pass


def MPxImagePlane_coverageOriginY_set(*args, **kwargs):
    pass


def MPxSelectionContext_doDrag(*args, **kwargs):
    pass


def MPxUITableControl_labelString(*args, **kwargs):
    pass


def MPxHwShaderNode_outTransparencyG_set(*args, **kwargs):
    pass


def MPx3dModelView_displayHUD(*args, **kwargs):
    pass


def MPxLocatorNode_nodeBoundingBoxSize_get(*args, **kwargs):
    pass


def MPxMotionPathNode_zCoordinate_get(*args, **kwargs):
    pass


def MPxLocatorNode_isTransparent(*args, **kwargs):
    pass


def MPxTransform_rotatePivotTranslateX_set(*args, **kwargs):
    pass


def MPxFieldNode_mApplyPerVertex_set(*args, **kwargs):
    pass


def delete_MPxControlCommand(*args, **kwargs):
    pass


def MPxTransformationMatrix_creator(*args, **kwargs):
    pass


def MPxNode__doNotWrite(*args, **kwargs):
    pass


def MPxModelEditorCommand_modelView(*args, **kwargs):
    pass


def MPxContext_feedbackNumericalInput(*args, **kwargs):
    pass


def MPxFieldNode_mDeltaTime_set(*args, **kwargs):
    pass


def MPxParticleAttributeMapperNode_computeNodeColor_get(*args, **kwargs):
    pass


def MFnPlugin_deregisterConstraintCommand(*args, **kwargs):
    pass


def new_MPxSurfaceShape(*args, **kwargs):
    pass


def MPxImagePlane_offset_get(*args, **kwargs):
    pass


def MPxTransform_maxTransXLimitEnable_set(*args, **kwargs):
    pass


def MPxToolCommand_swigregister(*args, **kwargs):
    pass


def MPxImagePlane_offset_set(*args, **kwargs):
    pass


def MPxEmitterNode_mInheritFactor_get(*args, **kwargs):
    pass


def MPxTransform_renderLayerInfo_set(*args, **kwargs):
    pass


def delete_MPxMayaAsciiFilter(*args, **kwargs):
    pass


def MPxAnimCurveInterpolator_evaluate(*args, **kwargs):
    pass


def MPxHwShaderNode_glUnbind(*args, **kwargs):
    pass


def MPxIkSolverNode_positionOnly(*args, **kwargs):
    pass


def MPxObjectSet_groupNodes_get(*args, **kwargs):
    pass


def MPxCacheFormat_beginReadChunk(*args, **kwargs):
    pass


def MPxTransform_xformMatrix_set(*args, **kwargs):
    pass


def delete_MPxSpringNode(*args, **kwargs):
    pass


def MPx3dModelView_setLightingMode(*args, **kwargs):
    pass


def MPxBlendShape_inputPointsTarget_set(*args, **kwargs):
    pass


def MPxFileResolver_findURIResolverByScheme(*args, **kwargs):
    pass


def MFnPlugin_registeringCallableScript(*args, **kwargs):
    pass


def MPxTransform_maxRotYLimitEnable_set(*args, **kwargs):
    pass


def MPxFluidEmitterNode_mEmissionFunction_get(*args, **kwargs):
    pass


def MPxSurfaceShape_worldMatrix_get(*args, **kwargs):
    pass


def MPxTransform_worldMatrix_get(*args, **kwargs):
    pass


def MPxLocatorNode_parentInverseMatrix_get(*args, **kwargs):
    pass


def MPxMotionPathNode_wraparoundFractionalValue(*args, **kwargs):
    pass


def MPx3dModelView_displayStyle(*args, **kwargs):
    pass


def MPxEmitterNode_mOwnerPosData_get(*args, **kwargs):
    pass


def MPxMotionPathNode_getVectors(*args, **kwargs):
    pass


def MPxMultiPolyTweakUVCommand_getTweakedUVs(*args, **kwargs):
    pass


def MPxUITableControl_clearSelection(*args, **kwargs):
    pass


def MPxSurfaceShape_createFullRenderGroup(*args, **kwargs):
    pass


def MPxFieldNode_falloffCurve(*args, **kwargs):
    pass


def MPxTransform_transMinusRotatePivotY_get(*args, **kwargs):
    pass


def MPxTransform_transformationMatrix(*args, **kwargs):
    pass


def MPxNode_isHistoricallyInteresting_set(*args, **kwargs):
    pass


def MPxContextCommand__syntax(*args, **kwargs):
    pass


def MPxFieldNode_mInputForce_get(*args, **kwargs):
    pass


def MPxAssembly_getRepNamespace(*args, **kwargs):
    pass


def MPxAttributePatternFactory_createPatternsFromFile(*args, **kwargs):
    pass


def MPxTransform_minScaleLimit_set(*args, **kwargs):
    pass


def MPxEmitterNode_getEmitterType(*args, **kwargs):
    pass


def MPxMotionPathNode_bank_get(*args, **kwargs):
    pass


def MPxRenderPassImpl_isCompatible(*args, **kwargs):
    pass


def MPxIkSolverNode_handleGroup(*args, **kwargs):
    pass


def MPxTransform_minTransYLimitEnable_set(*args, **kwargs):
    pass


def MPxImagePlane_offsetX_set(*args, **kwargs):
    pass


def MPxSurfaceShape_acceptsGeometryIterator(*args, **kwargs):
    pass


def MPx3dModelView_templateColor(*args, **kwargs):
    pass


def MPxTransform_scalePivotTranslate_set(*args, **kwargs):
    pass


def MPxImageFile_swiginit(*args, **kwargs):
    pass


def MPxCacheFormat_readDoubleArray(*args, **kwargs):
    pass


def MPxHwShaderNode_outTransparencyR_get(*args, **kwargs):
    pass


def MPxTransform_nodeBoundingBoxMaxZ_set(*args, **kwargs):
    pass


def MPx3dModelView_postMultipleDrawPass(*args, **kwargs):
    pass


def MPxFileTranslator_reader(*args, **kwargs):
    pass


def MFnPlugin_swigregister(*args, **kwargs):
    pass


def MPxTransform_maxScaleXLimit_get(*args, **kwargs):
    pass


def MPxTransform_getRotatePivotTranslation(*args, **kwargs):
    pass


def MPxTransformationMatrix_translateBy(*args, **kwargs):
    pass


def MPxManipulatorNode_finishAddingManips(*args, **kwargs):
    pass


def MPxManipContainer_swigregister(*args, **kwargs):
    pass


def MPxEmitterNode_mSweptGeometry_set(*args, **kwargs):
    pass


def MaterialInputData_hasTransparency_get(*args, **kwargs):
    pass


def MPxLocatorNode_className(*args, **kwargs):
    pass


def MPxComponentShape_swigregister(*args, **kwargs):
    pass


def MPxGeometryIterator_indexUnsimplified(*args, **kwargs):
    pass


def MPxFileTranslator_haveNamespaceSupport(*args, **kwargs):
    pass


def MPxGlBuffer_beginBufferNotify(*args, **kwargs):
    pass


def MPxCommand_setCommandString(*args, **kwargs):
    pass


def MPxTransform_inheritsTransform_get(*args, **kwargs):
    pass


def MPxTransform_setLimit(*args, **kwargs):
    pass


def MPxFluidEmitterNode_fluidFuelEmission(*args, **kwargs):
    pass


def MPxConstraintCommand_redoIt(*args, **kwargs):
    pass


def MPxRenderPassImpl_swiginit(*args, **kwargs):
    pass


def disown_MPxTransform(*args, **kwargs):
    pass


def MPxEditData__getStringValue(*args, **kwargs):
    pass


def MPxTransform__dirtyScalePivotTranslation(*args, **kwargs):
    pass


def MPx3dModelView_setObjectDisplay(*args, **kwargs):
    pass


def MPxSurfaceShape_nodeBoundingBoxMinY_get(*args, **kwargs):
    pass


def MPxImagePlane_frameOffset_set(*args, **kwargs):
    pass


def MPx3dModelView_drawText(*args, **kwargs):
    pass


def MPxMotionPathNode_evaluatePath(*args, **kwargs):
    pass


def MPxMotionPathNode_fractionMode_get(*args, **kwargs):
    pass


def MPxTransform_maxScaleZLimitEnable_get(*args, **kwargs):
    pass


def MPxTransform_maxScaleLimitEnable_get(*args, **kwargs):
    pass


def MPxTransform_dynamics_get(*args, **kwargs):
    pass


def MPxContext__setHelpString(*args, **kwargs):
    pass


def MaterialInputData_ambient_set(*args, **kwargs):
    pass


def MPxFluidEmitterNode_mFluidFuelEmission_set(*args, **kwargs):
    pass


def MPxSurfaceShape_worldMatrix_set(*args, **kwargs):
    pass


def MPxMaterialInformation_fInstance_get(*args, **kwargs):
    pass


def MPxManipContainer_addDirectionManip(*args, **kwargs):
    pass


def MPxTransformationMatrix_asInterpolationMatrix(*args, **kwargs):
    pass


def disown_MPxDragAndDropBehavior(*args, **kwargs):
    pass


def MPxEmitterNode_getDeltaTime(*args, **kwargs):
    pass


def MFnPlugin_version(*args, **kwargs):
    pass


def MPxTransform_layerOverrideColor_set(*args, **kwargs):
    pass


def MPxTransform_minTransYLimit_set(*args, **kwargs):
    pass


def MPxImagePlane_depthBias_get(*args, **kwargs):
    pass


def MPxIkSolverNode_type(*args, **kwargs):
    pass


def MPxSurfaceShape_getWorldMatrix(*args, **kwargs):
    pass


def MPxLocatorNode_color(*args, **kwargs):
    pass


def MPxEmitterNode_mRate_get(*args, **kwargs):
    pass


def MPxObjectSet_isLayer_set(*args, **kwargs):
    pass


def MPxTransform_objectGrpCompList_get(*args, **kwargs):
    pass


def MPxTransform_geometry_set(*args, **kwargs):
    pass


def disown_MPxDeformerNode(*args, **kwargs):
    pass


def MPxBlendShape_deformData(*args, **kwargs):
    pass


def MPxGeometryData_deleteComponentsFromGroups(*args, **kwargs):
    pass


def new_MPxNode(*args, **kwargs):
    pass


def MPxEditData__dataStringValue_set(*args, **kwargs):
    pass


def MPxGeometryIterator_isDone(*args, **kwargs):
    pass


def MPxSurfaceShape_nodeBoundingBoxMaxZ_set(*args, **kwargs):
    pass


def MPxImagePlane_sourceTexture_set(*args, **kwargs):
    pass


def MPxSelectionContext_setAllowDoubleClickAction(*args, **kwargs):
    pass


def disown_MPxHardwareShader(*args, **kwargs):
    pass


def MPx3dModelView_drawAdornments(*args, **kwargs):
    pass


def MPxEmitterNode_mWorldMatrix_set(*args, **kwargs):
    pass


def MPxTransformationMatrix_asRotateMatrix(*args, **kwargs):
    pass


def MPxMotionPathNode_orientMatrix_set(*args, **kwargs):
    pass


def MPxTransform_scaleY_set(*args, **kwargs):
    pass


def MPxPolyTweakUVCommand_parseSyntax(*args, **kwargs):
    pass


def MPxEmitterNode_mDirectionY_set(*args, **kwargs):
    pass


def MPxTransform_transMinusRotatePivotX_get(*args, **kwargs):
    pass


def MPxCommand_redoIt(*args, **kwargs):
    pass


def MPxModelEditorCommand__parser(*args, **kwargs):
    pass


def MPxContext_className(*args, **kwargs):
    pass


def MPxControlCommand__syntax(*args, **kwargs):
    pass


def MPxTransform_scaleY_get(*args, **kwargs):
    pass


def MPxTransform_nodeBoundingBoxMaxX_set(*args, **kwargs):
    pass


def MPxMotionPathNode_upTwist_set(*args, **kwargs):
    pass


def MPxEmitterNode_mIsFull_set(*args, **kwargs):
    pass


def disown_MPxAnimCurveInterpolator(*args, **kwargs):
    pass


def MPxCommand_isHistoryOn(*args, **kwargs):
    pass


def MPxImagePlane_squeezeCorrection_set(*args, **kwargs):
    pass


def MPx3dModelView_beginXorDrawing(*args, **kwargs):
    pass


def MPxObjectSet_className(*args, **kwargs):
    pass


def MPxCacheFormat_readTime(*args, **kwargs):
    pass


def MFnPlugin_deregisterAttributePatternFactory(*args, **kwargs):
    pass


def disown_MPxFluidEmitterNode(*args, **kwargs):
    pass


def delete_MFnPlugin(*args, **kwargs):
    pass


def MPxBlendShape_inputComponentsTarget_set(*args, **kwargs):
    pass


def MPxLocatorNode_worldPosition_get(*args, **kwargs):
    pass


def MFnPlugin_unregisterBakeEngine(*args, **kwargs):
    pass


def MPxLocatorNode_isTemplated_set(*args, **kwargs):
    pass


def MFnPlugin_matrixTypeIdFromXformId(*args, **kwargs):
    pass


def MPxTransform_minScaleLimit_get(*args, **kwargs):
    pass


def MPxSurfaceShape_visibility_get(*args, **kwargs):
    pass


def MPxUITableControl_allowEdit(*args, **kwargs):
    pass


def MPxHardwareShader_outColorG_set(*args, **kwargs):
    pass


def MPxLocatorNode_worldMatrix_set(*args, **kwargs):
    pass


def MPxMotionPathNode_parametricToFractional(*args, **kwargs):
    pass


def MFnPlugin_deregisterEvaluator(*args, **kwargs):
    pass


def MPxCameraSet_cameraLayer_set(*args, **kwargs):
    pass


def MPxFieldNode_mAttenuation_set(*args, **kwargs):
    pass


def MPxGeometryData_deleteComponent(*args, **kwargs):
    pass


def MPxTransformationMatrix___ne__(*args, **kwargs):
    pass


def MPxFieldNode_mOwnerCentroid_set(*args, **kwargs):
    pass


def MPxAssembly_setRepLabel(*args, **kwargs):
    pass


def MPxBakeEngine_getUVRange(*args, **kwargs):
    pass


def MPxLocatorNode_isTemplated_get(*args, **kwargs):
    pass


def MPxLocatorNode_localPositionZ_get(*args, **kwargs):
    pass


def MPxTransform_boundingBoxCenterX_set(*args, **kwargs):
    pass


def MPxContext_deleteAction(*args, **kwargs):
    pass


def MPxGeometryFilter_setDeformationDetails(*args, **kwargs):
    pass


def MPxConstraint_lockOutput_get(*args, **kwargs):
    pass


def MPxParticleAttributeMapperNode_outColorPP_get(*args, **kwargs):
    pass


def MPxImagePlane_centerX_get(*args, **kwargs):
    pass


def MPxEditData_isLessThan(*args, **kwargs):
    pass


def MPxSurfaceShape_match(*args, **kwargs):
    pass


def MPxHwShaderNode_normalsPerVertex(*args, **kwargs):
    pass


def MPxImagePlane_loadImageMap(*args, **kwargs):
    pass


def MPxCacheFormat_readIntArray(*args, **kwargs):
    pass


def MPxSurfaceShapeUI_drawUV(*args, **kwargs):
    pass


def MPxHwShaderNode_outTransparencyG_get(*args, **kwargs):
    pass


def MPxEmitterNode_mRate_set(*args, **kwargs):
    pass


def MPx3dModelView_multipleDrawEnabled(*args, **kwargs):
    pass


def MPxFileResolver_findURIResolverByName(*args, **kwargs):
    pass


def MPxTransform_rotateX_get(*args, **kwargs):
    pass


def MPxNode_connectionMade(*args, **kwargs):
    pass


def MPxManipulatorNode_getDoubleValue(*args, **kwargs):
    pass


def MPxMayaAsciiFilter_reader(*args, **kwargs):
    pass


def disown_MPxContextCommand(*args, **kwargs):
    pass


def MPxTransform_maxRotXLimitEnable_set(*args, **kwargs):
    pass


def MPxConstraint_swigregister(*args, **kwargs):
    pass


def MPxTransformationMatrix_rotateTo(*args, **kwargs):
    pass


def MPxManipulatorNode_mousePosition(*args, **kwargs):
    pass


def MPxMidiInputDevice_openDevice(*args, **kwargs):
    pass


def MPxEmitterNode_mDirection_get(*args, **kwargs):
    pass


def MPxImagePlane_size_set(*args, **kwargs):
    pass


def MPxTransform_maxTransXLimitEnable_get(*args, **kwargs):
    pass


def MFnPlugin_registerEvaluator(*args, **kwargs):
    pass


def MPxTransform_applyRotateOrientationLocks(*args, **kwargs):
    pass


def MPxDragAndDropBehavior_className(*args, **kwargs):
    pass


def MPxImagePlane_alreadyPremult_set(*args, **kwargs):
    pass


def delete_MPxParticleAttributeMapperNode(*args, **kwargs):
    pass


def MPxNode_shouldSave(*args, **kwargs):
    pass


def MPxSurfaceShape_localShapeInAttr(*args, **kwargs):
    pass


def MPxGlBuffer_className(*args, **kwargs):
    pass


def MFnPlugin_registerNode(*args, **kwargs):
    pass


def MPxCommand_isCurrentResultArray(*args, **kwargs):
    pass


def MPxMayaAsciiFilter_swigregister(*args, **kwargs):
    pass


def MPxTransform_parentInverseMatrix_get(*args, **kwargs):
    pass


def MPxParticleAttributeMapperNode_compute(*args, **kwargs):
    pass


def MPxTransform_maxTransLimit_set(*args, **kwargs):
    pass


def MPxSkinCluster_bindPreMatrix_get(*args, **kwargs):
    pass


def MPxConstraintCommand__syntax(*args, **kwargs):
    pass


def MPxParticleAttributeMapperNode_computeNodeColorG_get(*args, **kwargs):
    pass


def MPxConstraint_swiginit(*args, **kwargs):
    pass


def MPxEditData__dataValue_set(*args, **kwargs):
    pass


def MPx3dModelView_setBackfaceCulling(*args, **kwargs):
    pass


def MPxSurfaceShape_parentMatrix_get(*args, **kwargs):
    pass


def MPxImagePlane_coverageX_get(*args, **kwargs):
    pass


def MPxTexContext_viewRect(*args, **kwargs):
    pass


def MPxManipulatorNode_labelBackgroundColor(*args, **kwargs):
    pass


def MPxSurfaceShape_instObjGroups_get(*args, **kwargs):
    pass


def MPxMotionPathNode_updateOrientationMarkers_set(*args, **kwargs):
    pass


def MPxTransform_scaleX_set(*args, **kwargs):
    pass


def MPxTransform_maxScaleXLimitEnable_set(*args, **kwargs):
    pass


def MPx3dModelView_includeInvisible(*args, **kwargs):
    pass


def MPxTransform_transMinusRotatePivot_get(*args, **kwargs):
    pass


def getLockCaptureCount(*args, **kwargs):
    pass


def MPxAssembly_addEdits(*args, **kwargs):
    pass


def new_MPxModelEditorCommand(*args, **kwargs):
    pass


def MPxAssembly_swiginit(*args, **kwargs):
    pass


def MPxLocatorNode_matrix_set(*args, **kwargs):
    pass


def MPxFieldNode_mOutputForce_set(*args, **kwargs):
    pass


def new_MPxPolyTweakUVInteractiveCommand(*args, **kwargs):
    pass


def MPxManipContainer_addPointOnCurveManip(*args, **kwargs):
    pass


def MFnPlugin_deregisterAnimCurveInterpolator(*args, **kwargs):
    pass


def MPxConstraintCommand_setRestPosition(*args, **kwargs):
    pass


def MPxEmitterNode_mRandStateZ_set(*args, **kwargs):
    pass


def MPxMotionPathNode_normal_get(*args, **kwargs):
    pass


def MPxImagePlane_depthScale_set(*args, **kwargs):
    pass


def MPxIkSolverNode__setToRestAngles(*args, **kwargs):
    pass


def MPxManipulatorNode_setInstancePtr(*args, **kwargs):
    pass


def MPxUITableControl_swigregister(*args, **kwargs):
    pass


def MFnPlugin_registerIkSolver(*args, **kwargs):
    pass


def MFnPlugin_registerCommand(*args, **kwargs):
    pass


def MPxTransform_scalePivotY_get(*args, **kwargs):
    pass


def MPxObjectSet_edgesOnlySet_set(*args, **kwargs):
    pass


def MPxCacheFormat_close(*args, **kwargs):
    pass


def MPxEmitterNode_mRandStateY_set(*args, **kwargs):
    pass


def MPxTransform_nodeBoundingBoxMaxX_get(*args, **kwargs):
    pass


def MPxFluidEmitterNode_mFluidDropoff_set(*args, **kwargs):
    pass


def MPxBlendShape_inputTarget_get(*args, **kwargs):
    pass


def MPxLocatorNode_underWorldObject_get(*args, **kwargs):
    pass


def MPxNode_postEvaluation(*args, **kwargs):
    pass


def MPxCameraSet_order_set(*args, **kwargs):
    pass


def MPxTexContext_newToolCommand(*args, **kwargs):
    pass


def MPxSurfaceShape_nodeBoundingBoxMinZ_set(*args, **kwargs):
    pass


def MPxImagePlane_displayMode_set(*args, **kwargs):
    pass


def MPxSelectionContext_image(*args, **kwargs):
    pass


def MPxLocatorNode_localScaleZ_get(*args, **kwargs):
    pass


def MPxDeformerNode_weightList_set(*args, **kwargs):
    pass


def MPx3dModelView_displayAxisOn(*args, **kwargs):
    pass


def MPxLocatorNode_nodeBoundingBoxSizeZ_set(*args, **kwargs):
    pass


def MPx3dModelView_backgroundColorTop(*args, **kwargs):
    pass


def MPxTransform_nodeBoundingBoxMax_get(*args, **kwargs):
    pass


def disown_MPxPolyTweakUVCommand(*args, **kwargs):
    pass


def MPxEmitterNode_mRandStateX_get(*args, **kwargs):
    pass


def MPxUITableControl_removeFromSelection(*args, **kwargs):
    pass


def MPxData_typeId(*args, **kwargs):
    pass


def MPxTransform_checkAndSetRotation(*args, **kwargs):
    pass


def MPxParticleAttributeMapperNode_outColorPP_set(*args, **kwargs):
    pass


def new_MPxFileTranslator(*args, **kwargs):
    pass


def disown_MPxTransformationMatrix(*args, **kwargs):
    pass


def MPxNode_attributeAffects(*args, **kwargs):
    pass


def MPxPolyTrg_postConstructor(*args, **kwargs):
    pass


def MFnPlugin_registerImageFile(*args, **kwargs):
    pass


def MPxLocatorNode_nodeBoundingBoxMaxZ_set(*args, **kwargs):
    pass


def MPxTransform_compute(*args, **kwargs):
    pass


def MPxManipContainer_removeFromManipConnectTable(*args, **kwargs):
    pass


def MPxEmitterNode_mOutput_get(*args, **kwargs):
    pass


def MPxUITableControl_redrawCells(*args, **kwargs):
    pass


def MPxConstraint_weightAttribute(*args, **kwargs):
    pass


def MPxMotionPathNode_worldUpVectorX_get(*args, **kwargs):
    pass


def MPxMayaAsciiFilter_processReadOptions(*args, **kwargs):
    pass


def MPxAnimCurveInterpolator_swiginit(*args, **kwargs):
    pass


def MPxImagePlane_sizeX_set(*args, **kwargs):
    pass


def MExternalContentInfoTable_swigregister(*args, **kwargs):
    pass


def MPxImagePlane_colorGain_get(*args, **kwargs):
    pass


def MPxEditData_performIsEqual(*args, **kwargs):
    pass


def MPxCacheFormat_writeDoubleArray(*args, **kwargs):
    pass


def MPxSelectionContext_argTypeNumericalInput(*args, **kwargs):
    pass


def MPxEmitterNode_mIsFull_get(*args, **kwargs):
    pass


def disown_MPxGlBuffer(*args, **kwargs):
    pass


def MPxManipulatorNode_deregisterForMouseMove(*args, **kwargs):
    pass


def MPxTransform_layerOverrideColor_get(*args, **kwargs):
    pass


def MFnPlugin_findPlugin(*args, **kwargs):
    pass


def MPxMayaAsciiFilter_haveWriteMethod(*args, **kwargs):
    pass


def disown_MPxGeometryIterator(*args, **kwargs):
    pass


def MPxTransform_nodeBoundingBoxMin_get(*args, **kwargs):
    pass


def MPxSurfaceShape_boundingBoxCenterX_get(*args, **kwargs):
    pass


def MPxTransform_scalePivotX_get(*args, **kwargs):
    pass


def MPxHardwareShader_className(*args, **kwargs):
    pass


def MPxLocatorNode_parentMatrix_set(*args, **kwargs):
    pass


def MPxMotionPathNode_matrix(*args, **kwargs):
    pass


def MaterialInputData_diffuse_set(*args, **kwargs):
    pass


def MPxSurfaceShape_swigregister(*args, **kwargs):
    pass


def MPxConstraintCommand_doQuery(*args, **kwargs):
    pass


def MPxMotionPathNode_uValue_get(*args, **kwargs):
    pass


def MPxNode_typeId(*args, **kwargs):
    pass


def MPxLocatorNode_objectGrpCompList_set(*args, **kwargs):
    pass


def MPxTransformationMatrix_asMatrixInverse(*args, **kwargs):
    pass


def MPxFieldNode_mOwnerCentroidZ_set(*args, **kwargs):
    pass


def MPxAssembly_handlesAddEdits(*args, **kwargs):
    pass


def MPxBakeEngine_fInstance_set(*args, **kwargs):
    pass


def MPxMayaAsciiFilter_writesSelectNode(*args, **kwargs):
    pass


def MPxTransform_rotatePivotX_get(*args, **kwargs):
    pass


def MPxTransform_boundingBoxCenterZ_get(*args, **kwargs):
    pass


def MPxEmitterNode_getMaxDistance(*args, **kwargs):
    pass


def MPxGeometryFilter_input_get(*args, **kwargs):
    pass


def MPxContext_doPtrMoved(*args, **kwargs):
    pass


def MPxImagePlane_colorOffset_get(*args, **kwargs):
    pass


def MPxConstraint_passiveOutputAttribute(*args, **kwargs):
    pass


def MPxImagePlane_centerZ_get(*args, **kwargs):
    pass


def MExternalContentLocationTable_swigregister(*args, **kwargs):
    pass


def MPxSurfaceShape_boundingBoxCenterY_set(*args, **kwargs):
    pass


def MPxSurfaceShapeUI_materials(*args, **kwargs):
    pass


def delete_MPxBakeEngine(*args, **kwargs):
    pass


def MPxTransformationMatrix_reverse(*args, **kwargs):
    pass


def MFnPlugin_vendor(*args, **kwargs):
    pass


def MPxLocatorNode_objectGroups_set(*args, **kwargs):
    pass


def MPxLocatorNode_nodeBoundingBoxMin_get(*args, **kwargs):
    pass


def MPxGeometryFilter_swigregister(*args, **kwargs):
    pass


def MPx3dModelView_setDrawInterrupt(*args, **kwargs):
    pass


def MPxTransform_rotateAxisZ_get(*args, **kwargs):
    pass


def MPxTransformationMatrix_setRotationOrder(*args, **kwargs):
    pass


def MPxHardwareShader_swiginit(*args, **kwargs):
    pass


def MPxMidiInputDevice_nameButtons(*args, **kwargs):
    pass


def MPxLocatorNode_boundingBoxCenterZ_set(*args, **kwargs):
    pass


def MPxEmitterNode_mOwnerCentroid_get(*args, **kwargs):
    pass


def MPxTransform_applyScaleLocksPivotTranslate(*args, **kwargs):
    pass


def MPxData_name(*args, **kwargs):
    pass


def MPxConstraintCommand_constraintOutputAttribute(*args, **kwargs):
    pass


def MPxRepresentation__getAssembly(*args, **kwargs):
    pass


def MPxMotionPathNode_flowNode_set(*args, **kwargs):
    pass


def MPxEmitterNode_resetRandomState(*args, **kwargs):
    pass


def MPxImagePlane_composite_set(*args, **kwargs):
    pass


def MPxTransform__dirtyTranslation(*args, **kwargs):
    pass


def MPxNode_passThroughToOne(*args, **kwargs):
    pass


def MPxSurfaceShape_cachedShapeAttr(*args, **kwargs):
    pass


def MPxGlBuffer_swiginit(*args, **kwargs):
    pass


def MPxFileResolver_performAfterSaveURI(*args, **kwargs):
    pass


def MFnPlugin_registerData(*args, **kwargs):
    pass


def MPxTransform_rotatePivotTranslateZ_set(*args, **kwargs):
    pass


def MPxObjectSet_type(*args, **kwargs):
    pass


def MPxTransform_visibility_set(*args, **kwargs):
    pass


def new_MPxDeformerNode(*args, **kwargs):
    pass


def MPxTransform_nodeBoundingBoxMinZ_set(*args, **kwargs):
    pass


def disown_MPxSkinCluster(*args, **kwargs):
    pass


def disown_MPxParticleAttributeMapperNode(*args, **kwargs):
    pass


def MPxNode_compute(*args, **kwargs):
    pass


def MPxCameraSet_className(*args, **kwargs):
    pass


def MPx3dModelView_isWireframeOnShaded(*args, **kwargs):
    pass


def MPxSurfaceShape_intermediateObject_get(*args, **kwargs):
    pass


def disown_MPxConstraint(*args, **kwargs):
    pass


def MPxImagePlane_coverageOrigin_get(*args, **kwargs):
    pass


def MPxSelectionContext_setAllowPreSelectHilight(*args, **kwargs):
    pass


def MPxUITableControl_cellString(*args, **kwargs):
    pass


def MPxTransform_scaleTo(*args, **kwargs):
    pass


def MPxLocatorNode_localScaleY_get(*args, **kwargs):
    pass


def MPxHwShaderNode_getHwShaderNodePtr(*args, **kwargs):
    pass


def MPx3dModelView_getCamera(*args, **kwargs):
    pass


def MPxLocatorNode_nodeBoundingBoxMaxX_get(*args, **kwargs):
    pass


def MPxFileResolver_getURIResolversByName(*args, **kwargs):
    pass


def MPxEmitterNode_swiginit(*args, **kwargs):
    pass


def MPxTransformationMatrix_setRotatePivot(*args, **kwargs):
    pass


def MPxTransform_minRotLimitEnable_get(*args, **kwargs):
    pass


def MPxModelEditorCommand_appendSyntax(*args, **kwargs):
    pass


def MPxContext__ignoreEntry(*args, **kwargs):
    pass


def MPxFluidEmitterNode_mFluidDensityEmission_get(*args, **kwargs):
    pass


def MFnPlugin_registerModelEditorCommand(*args, **kwargs):
    pass


def MPxFluidEmitterNode_fluidDropoff(*args, **kwargs):
    pass


def new_MPxMotionPathNode(*args, **kwargs):
    pass


def MPxManipContainer_addCircleSweepManip(*args, **kwargs):
    pass


def MPxConstraintCommand_swiginit(*args, **kwargs):
    pass


def MPxEmitterNode_mRandStateZ_get(*args, **kwargs):
    pass


def MFnPlugin_apiVersion(*args, **kwargs):
    pass


def MPx3dModelView_isFogEnabled(*args, **kwargs):
    pass


def MPxImagePlane_swiginit(*args, **kwargs):
    pass


def disown_MPxIkSolverNode(*args, **kwargs):
    pass


def MPxIkSolverNode_rotatePlane(*args, **kwargs):
    pass


def MPxSurfaceShape_newControlPointComponent(*args, **kwargs):
    pass


def MFnPlugin_deregisterContextCommand(*args, **kwargs):
    pass


def MPxObjectSet_editPointsOnlySet_set(*args, **kwargs):
    pass


def MPxCacheFormat_readHeader(*args, **kwargs):
    pass


def MPxTransform_objectColor_get(*args, **kwargs):
    pass


def MPxSpringNode_mEnd1Weight_set(*args, **kwargs):
    pass


def MPxBlendShape_inputTargetGroup_set(*args, **kwargs):
    pass


def MPxTransform_overrideEnabled_set(*args, **kwargs):
    pass


def MPxImagePlane_width_set(*args, **kwargs):
    pass


def MFnPlugin_deregisterRenderer(*args, **kwargs):
    pass


def MPxTransform__dirtyRotatePivotTranslation(*args, **kwargs):
    pass


def MPxGeometryIterator_hasPoints(*args, **kwargs):
    pass


def MPxTransform_minRotZLimitEnable_get(*args, **kwargs):
    pass


def MPxSurfaceShape_nodeBoundingBoxSizeX_get(*args, **kwargs):
    pass


def MPxTransform_scalePivot_get(*args, **kwargs):
    pass


def MPxUITableControl_className(*args, **kwargs):
    pass


def MPxHardwareShader_getHardwareShaderPtr(*args, **kwargs):
    pass


def MPxLocatorNode_boundingBoxCenterX_set(*args, **kwargs):
    pass


def MPxMultiPolyTweakUVCommand_newSyntax(*args, **kwargs):
    pass


def MPxMotionPathNode_rotateY_set(*args, **kwargs):
    pass


def MPxImagePlane_lockedToCamera_set(*args, **kwargs):
    pass


def MPxLocatorNode_getShapeSelectionMask(*args, **kwargs):
    pass


def MPxComponentShape_match(*args, **kwargs):
    pass


def delete_MPxTransform(*args, **kwargs):
    pass


def MPxHardwareShader_swigregister(*args, **kwargs):
    pass


def MPxImagePlane_depthOversample_get(*args, **kwargs):
    pass


def MPxSelectionContext_doPress(*args, **kwargs):
    pass


def MPxContextCommand_doEditFlags(*args, **kwargs):
    pass


def MFnPlugin_registerUIStrings(*args, **kwargs):
    pass


def MPxAssembly_isActive(*args, **kwargs):
    pass


def MPxCommand_displayWarning(*args, **kwargs):
    pass


def MPxLocatorNode_objectGroupId_get(*args, **kwargs):
    pass


def MPxFieldNode_type(*args, **kwargs):
    pass


def MPxManipContainer_addManipToPlugConversion(*args, **kwargs):
    pass


def MPxParticleAttributeMapperNode_outMaxValue_get(*args, **kwargs):
    pass


def MPxContext_toolOffCleanup(*args, **kwargs):
    pass


def delete_MPxGeometryFilter(*args, **kwargs):
    pass


def MaterialInputData_swigregister(*args, **kwargs):
    pass


def delete_MPxConstraint(*args, **kwargs):
    pass


def MPxManipulatorNode_addDependentPlug(*args, **kwargs):
    pass


def MExternalContentInfoTable_getEntryByIndex(*args, **kwargs):
    pass


def MPxSurfaceShape_worldShapeOutAttr(*args, **kwargs):
    pass


def MPxLocatorNode_instObjGroups_set(*args, **kwargs):
    pass


def MPxUIControl_swiginit(*args, **kwargs):
    pass


def MPxSelectionContext_swiginit(*args, **kwargs):
    pass


def MPxFluidEmitterNode_fluidColor(*args, **kwargs):
    pass


def MPxLocatorNode_worldPositionZ_get(*args, **kwargs):
    pass


def MPxNode_preEvaluation(*args, **kwargs):
    pass


def new_MPxEmitterNode(*args, **kwargs):
    pass


def delete_MPxImageFile(*args, **kwargs):
    pass


def MPxSurfaceShape_mControlValueX_get(*args, **kwargs):
    pass


def MPxLocatorNode_nodeBoundingBoxMax_get(*args, **kwargs):
    pass


def MPxManipContainer_getConverterPlugValue(*args, **kwargs):
    pass


def MPxEmitterNode_mSpeed_set(*args, **kwargs):
    pass


def MPxMotionPathNode_swiginit(*args, **kwargs):
    pass


def MaterialInputData_emission_get(*args, **kwargs):
    pass


def MPxToolCommand__doFinalize(*args, **kwargs):
    pass


def MPxConstraintCommand_hasVectorFlags(*args, **kwargs):
    pass


def MPxTransform_copyInternalData(*args, **kwargs):
    pass


def MPxNode_existWithoutOutConnections(*args, **kwargs):
    pass


def MPxControlCommand_doEditFlags(*args, **kwargs):
    pass


def MPxFieldNode_mOwnerCentroidX_set(*args, **kwargs):
    pass


def MPxAssembly_memberAdded(*args, **kwargs):
    pass


def MPxMayaAsciiFilter_writePostRequires(*args, **kwargs):
    pass


def MFnPlugin_deregisterDevice(*args, **kwargs):
    pass


def MPxTransform_matrix_set(*args, **kwargs):
    pass


def MPxTransform__dirtyScalePivot(*args, **kwargs):
    pass


def MPxGeometryFilter_inputGeom_set(*args, **kwargs):
    pass


def MPxSkinCluster_weightList_get(*args, **kwargs):
    pass


def MPxParticleAttributeMapperNode_computeNodeColor_set(*args, **kwargs):
    pass


def disown_MPxFileTranslator(*args, **kwargs):
    pass


def MPxSurfaceShape_intermediateObject_set(*args, **kwargs):
    pass


def MPxCacheFormat_readChannelName(*args, **kwargs):
    pass


def MPxSurfaceShapeUI_swigregister(*args, **kwargs):
    pass


def MPxTransform_rotateTo(*args, **kwargs):
    pass


def MPxLocatorNode_nodeBoundingBoxMinY_get(*args, **kwargs):
    pass


def MPxTransform_minScaleXLimitEnable_set(*args, **kwargs):
    pass


def MPxTransform_displayRotatePivot_set(*args, **kwargs):
    pass


def MPxTransform_applyScaleLocksPivot(*args, **kwargs):
    pass


def delete_MPxUITableControl(*args, **kwargs):
    pass


def MPxTransformationMatrix_setRotateOrientation(*args, **kwargs):
    pass


def MPxHardwareShader_transparencyOptions(*args, **kwargs):
    pass


def MExternalContentLocationTable_addEntry(*args, **kwargs):
    pass


def MPxManipContainer_newManipulator(*args, **kwargs):
    pass


def MPxConstraintCommand_constraintEnableRestAttribute(*args, **kwargs):
    pass


def MPxEmitterNode_getCurrentTime(*args, **kwargs):
    pass


def MPx3dModelView_fogStart(*args, **kwargs):
    pass


def MPxHwShaderNode_colorsPerVertex(*args, **kwargs):
    pass


def MPxSurfaceShape_pointAtParm(*args, **kwargs):
    pass


def MPxAssembly_setInstancePtr(*args, **kwargs):
    pass


def MPxCommand_currentDoubleResult(*args, **kwargs):
    pass


def MPxObjectSet_DNSetMembers_get(*args, **kwargs):
    pass


def MPxTransform_isTemplated_set(*args, **kwargs):
    pass


def MPxDeformerNode_weightList_get(*args, **kwargs):
    pass


def MPxSpringNode_swigregister(*args, **kwargs):
    pass


def MPxTransform_renderLayerRenderable_set(*args, **kwargs):
    pass


def MPxParticleAttributeMapperNode_computeNodeColorB_set(*args, **kwargs):
    pass


def delete_MPxEditData(*args, **kwargs):
    pass


def new_MPxIkSolverNode(*args, **kwargs):
    pass


def MPx3dModelView_isXrayEnabled(*args, **kwargs):
    pass


def MPxImagePlane_coverageOriginX_get(*args, **kwargs):
    pass


def MPxTransform_rotatePivotTranslateZ_get(*args, **kwargs):
    pass


def MPx3dModelView_setInStereoDrawMode(*args, **kwargs):
    pass


def MPxSelectionContext_setAllowSoftSelect(*args, **kwargs):
    pass


def MPxHwShaderNode_outMatteOpacity_set(*args, **kwargs):
    pass


def MPx3dModelView_getCurrentCameraSetCamera(*args, **kwargs):
    pass


def MPxLocatorNode_nodeBoundingBoxMaxY_set(*args, **kwargs):
    pass


def disown_MPxImagePlane(*args, **kwargs):
    pass


def MPxMotionPathNode_yCoordinate_get(*args, **kwargs):
    pass


def MPxNode_setExistWithoutInConnections(*args, **kwargs):
    pass


def new_MPxComponentShape(*args, **kwargs):
    pass


def MPxTransform_selectHandleZ_set(*args, **kwargs):
    pass


def MPxTransform_renderLayerInfo_get(*args, **kwargs):
    pass


def MPxTransformationMatrix_unSquishIt(*args, **kwargs):
    pass


def MPxModelEditorCommand_editorMenuScriptName(*args, **kwargs):
    pass


def MPxContext_abortAction(*args, **kwargs):
    pass


def MPxTransform_rotateOrder_get(*args, **kwargs):
    pass


def MPxManipContainer_addStateManip(*args, **kwargs):
    pass


def MPxMotionPathNode_type(*args, **kwargs):
    pass


def MPxEmitterNode_getRandomState(*args, **kwargs):
    pass


def MPxMotionPathNode_frontAxis_get(*args, **kwargs):
    pass


def MPxTransform_minTransXLimit_set(*args, **kwargs):
    pass


def MPxMotionPathNode_flowNode_get(*args, **kwargs):
    pass


def MPxImagePlane_maxShadingSamples_set(*args, **kwargs):
    pass


def MPxSurfaceShape_excludeAsPluginShape(*args, **kwargs):
    pass


def MPxObjectSet_renderableOnlySet_set(*args, **kwargs):
    pass


def MPxCacheFormat_beginWriteChunk(*args, **kwargs):
    pass


def MPxTransform_layerRenderable_get(*args, **kwargs):
    pass


def MPxTransform_maxRotLimit_get(*args, **kwargs):
    pass


def MPxFluidEmitterNode_mFluidJitter_get(*args, **kwargs):
    pass


def MPxTransformationMatrix_typeId(*args, **kwargs):
    pass


def MPxTransform_overrideColor_set(*args, **kwargs):
    pass


def MPxParticleAttributeMapperNode_time_set(*args, **kwargs):
    pass


def MPxGeometryIterator_setPointGetNext(*args, **kwargs):
    pass


def MPxTransform_maxRotXLimitEnable_get(*args, **kwargs):
    pass


def MPxSurfaceShape_center_get(*args, **kwargs):
    pass


def MPxImagePlane_colorGainG_set(*args, **kwargs):
    pass


def MPxGeometryFilter_deform(*args, **kwargs):
    pass


def MPxHardwareShader_setUniformParameters(*args, **kwargs):
    pass


def MPx3dModelView_displayCameraAnnotationOn(*args, **kwargs):
    pass


def MPxEmitterNode_type(*args, **kwargs):
    pass


def MPxImagePlane_coverageY_get(*args, **kwargs):
    pass


def MPxMotionPathNode_rotateOrder_get(*args, **kwargs):
    pass


def MPxSkinCluster_weights_set(*args, **kwargs):
    pass


def MPxComponentShape_localShapeInAttr(*args, **kwargs):
    pass


def disown_MPxData(*args, **kwargs):
    pass


def MPxRepresentation_getType(*args, **kwargs):
    pass


def MPxControlCommand_doQueryFlags(*args, **kwargs):
    pass


def MPxTransform_isBounded(*args, **kwargs):
    pass


def MPxTransform_mustCallValidateAndSet(*args, **kwargs):
    pass


def MPxContextCommand_appendSyntax(*args, **kwargs):
    pass


def MPxFieldNode_mWorldMatrix_get(*args, **kwargs):
    pass


def MPxDragAndDropBehavior_shouldBeUsedFor(*args, **kwargs):
    pass


def MPxCommand_appendToResult(*args, **kwargs):
    pass


def MPxParticleAttributeMapperNode_vCoordPP_set(*args, **kwargs):
    pass


def MPxTransform_nodeBoundingBoxSizeY_set(*args, **kwargs):
    pass


def MPxEmitterNode_mSeed_set(*args, **kwargs):
    pass


def MPxConstraint_constraintRotateOrderAttribute(*args, **kwargs):
    pass


def MPxRenderPassImpl_swigregister(*args, **kwargs):
    pass


def MPxIkSolverNode_groupHandlesByTopology(*args, **kwargs):
    pass


def MPxSurfaceShape_transformUsing(*args, **kwargs):
    pass


def new_MPxToolCommand(*args, **kwargs):
    pass


def MPxCacheFormat_writeFloatVectorArray(*args, **kwargs):
    pass


def MPxSurfaceShapeUI_getDrawRequests(*args, **kwargs):
    pass


def MPxAssembly_type(*args, **kwargs):
    pass


def MPxManipulatorNode_addPointValue(*args, **kwargs):
    pass


def MPxGeometryData_matrix(*args, **kwargs):
    pass


def new_MPxSelectionContext(*args, **kwargs):
    pass


def MFnPlugin_setRegisteringCallableScript(*args, **kwargs):
    pass


def MPxImageFile_close(*args, **kwargs):
    pass


def MPxTransform_scaleZ_set(*args, **kwargs):
    pass


def new_MPxManipulatorNode(*args, **kwargs):
    pass


def MPxEmitterNode_mDirectionZ_set(*args, **kwargs):
    pass


def MPxFluidEmitterNode_fluidJitter(*args, **kwargs):
    pass


def MFnPlugin_registerShape(*args, **kwargs):
    pass


def MPxConstraintCommand_connectObjectAndConstraint(*args, **kwargs):
    pass


def new_MPxData(*args, **kwargs):
    pass


def MPxConstraintCommand_aimVectorAttribute(*args, **kwargs):
    pass


def MPxImagePlane_visibleInRefractions_get(*args, **kwargs):
    pass


def MPxTransform_rotateQuaternionX_get(*args, **kwargs):
    pass


def MPxNode_isAbstractClass(*args, **kwargs):
    pass


def MPx3dModelView_multipleDrawPassCount(*args, **kwargs):
    pass


def MPxControlCommand_skipFlagForCreate(*args, **kwargs):
    pass


def MPxAssembly_performInactivate(*args, **kwargs):
    pass


def MPxTransform_rotatePivotTranslate_set(*args, **kwargs):
    pass


def MPxMayaAsciiFilter_writePostCreateNodesBlock(*args, **kwargs):
    pass


def delete_MPxFileResolver(*args, **kwargs):
    pass


def MPxTransform_worldMatrix_set(*args, **kwargs):
    pass


def MPxManipulatorNode_setDoubleValue(*args, **kwargs):
    pass


def MPxTransform_objectColor_set(*args, **kwargs):
    pass


def MPxTransform_translate_get(*args, **kwargs):
    pass


def delete_MPxConstraintCommand(*args, **kwargs):
    pass


def MPxRenderPassImpl_frameBufferSemantic(*args, **kwargs):
    pass


def MPxCameraSet_active_get(*args, **kwargs):
    pass


def MPxTransformationMatrix_assign(*args, **kwargs):
    pass


def MPxSurfaceShape_nodeBoundingBoxMaxZ_get(*args, **kwargs):
    pass


def MPxImagePlane_frameExtension_set(*args, **kwargs):
    pass


def MPxTransform_rotatePivotTranslateY_get(*args, **kwargs):
    pass


def MPxHwShaderNode_outTransparencyB_set(*args, **kwargs):
    pass


def MPxTransform_overrideDisplayType_set(*args, **kwargs):
    pass


def MPxGeometryData_swiginit(*args, **kwargs):
    pass


def MPxManipContainer_doRelease(*args, **kwargs):
    pass


def MPxTransform_overrideVisibility_get(*args, **kwargs):
    pass


def MPxSurfaceShape_instObjGroups_set(*args, **kwargs):
    pass


def MPxTransform_maxRotZLimit_get(*args, **kwargs):
    pass


def MPxFluidEmitterNode_mFluidColor_get(*args, **kwargs):
    pass


def MPxTransform_shearXZ_get(*args, **kwargs):
    pass


def MPxMaterialInformation_computeMaterial(*args, **kwargs):
    pass


def MPxManipContainer_createChildren(*args, **kwargs):
    pass


def MPxConstraintCommand_constraintTargetWeightAttribute(*args, **kwargs):
    pass


def MPxTransform_isLimited(*args, **kwargs):
    pass


def MPxImagePlane_depthFile_get(*args, **kwargs):
    pass


def MPxSelectionContext__lastDragPoint(*args, **kwargs):
    pass


def MPxImagePlane_colorOffsetG_get(*args, **kwargs):
    pass


def MPxSurfaceShape_mControlValueY_get(*args, **kwargs):
    pass


def MPxAssembly_addSetAttrEdit(*args, **kwargs):
    pass


def MPxTransform_transMinusRotatePivotZ_set(*args, **kwargs):
    pass


def MPxObjectSet_annotation_get(*args, **kwargs):
    pass


def MPxManipulatorNode_connectedNodes_set(*args, **kwargs):
    pass


def MPxCommand_commandString(*args, **kwargs):
    pass


def MPxImagePlane_rotate_get(*args, **kwargs):
    pass


def new_MPxTransformationMatrix(*args, **kwargs):
    pass


def MPxTransform_maxRotXLimit_set(*args, **kwargs):
    pass


def MPxFileTranslator_swigregister(*args, **kwargs):
    pass


def disown_MPxMayaAsciiFilter(*args, **kwargs):
    pass


def MPxNode_internalArrayCount(*args, **kwargs):
    pass


def MPxTransform_maxRotZLimit_set(*args, **kwargs):
    pass


def MPxSurfaceShape_nodeBoundingBox_get(*args, **kwargs):
    pass


def MPxTransform_scalePivotTranslateZ_set(*args, **kwargs):
    pass


def MPxSelectionContext_addManipulator(*args, **kwargs):
    pass


def MPxHwShaderNode_className(*args, **kwargs):
    pass


def MPx3dModelView_drawHUDNow(*args, **kwargs):
    pass


def MPxEmitterNode_mSweptGeometry_get(*args, **kwargs):
    pass


def MPxTransform_selectHandleY_set(*args, **kwargs):
    pass


def MPxComponentShape_createFullVertexGroup(*args, **kwargs):
    pass


def disown_MPxEmitterNode(*args, **kwargs):
    pass


def MPxTransform_getRotateOrientation(*args, **kwargs):
    pass


def MPxCommand_doIt(*args, **kwargs):
    pass


def MPxModelEditorCommand__syntax(*args, **kwargs):
    pass


def new_MPxRepresentation(*args, **kwargs):
    pass


def MPxTransform_rotateOrder_set(*args, **kwargs):
    pass


def MPxCameraSet_swigregister(*args, **kwargs):
    pass


def MFnPlugin_deregisterData(*args, **kwargs):
    pass


def MPxManipContainer_addScaleManip(*args, **kwargs):
    pass


def MPxEmitterNode_setRandomState(*args, **kwargs):
    pass


def MPxMotionPathNode_frontTwist_get(*args, **kwargs):
    pass


def MPxEmitterNode_getStartTime(*args, **kwargs):
    pass


def MPxMotionPathNode_upAxis_set(*args, **kwargs):
    pass


def MPxAnimCurveInterpolator_typeId(*args, **kwargs):
    pass


def MPxIkSolverNode_setPositionOnly(*args, **kwargs):
    pass


def MPx3dModelView_portWidth(*args, **kwargs):
    pass


def MPxObjectSet_groupNodes_set(*args, **kwargs):
    pass


def MPxTransform_getTranslation(*args, **kwargs):
    pass


def MPxHwShaderNode_outGlowColorR_set(*args, **kwargs):
    pass


def MExternalContentInfoTable_swiginit(*args, **kwargs):
    pass


def new_MPxSpringNode(*args, **kwargs):
    pass


def MPxTransform_renderInfo_get(*args, **kwargs):
    pass


def MFnPlugin_deregisterRenderPassImpl(*args, **kwargs):
    pass


def MPxHwShaderNode_outMatteOpacityB_get(*args, **kwargs):
    pass


def MPxTransform_applyScaleLimits(*args, **kwargs):
    pass


def MPxSurfaceShape_nodeBoundingBoxSizeZ_set(*args, **kwargs):
    pass


def MPx3dModelView_endXorDrawing(*args, **kwargs):
    pass


def MPxFileResolver_swigregister(*args, **kwargs):
    pass


def MPxModelEditorCommand_className(*args, **kwargs):
    pass


def MPxHwShaderNode_outGlowColorB_set(*args, **kwargs):
    pass


def MPxLocatorNode_inverseMatrix_get(*args, **kwargs):
    pass


def MPxMotionPathNode_banking(*args, **kwargs):
    pass


def MPxLocatorNode_useClosestPointForSelection(*args, **kwargs):
    pass


def disown_MPxMultiPolyTweakUVCommand(*args, **kwargs):
    pass


def MPxFieldNode_mAttenuation_get(*args, **kwargs):
    pass


def MPxNode_type(*args, **kwargs):
    pass


def MPxFieldNode_mOwnerVelData_get(*args, **kwargs):
    pass


def MPxDragAndDropBehavior_connectNodeToAttr(*args, **kwargs):
    pass


def MFnPlugin_registerControlCommand(*args, **kwargs):
    pass


def MPxBakeEngine_swiginit(*args, **kwargs):
    pass


def MPxImagePlane_offsetY_get(*args, **kwargs):
    pass


def MPxTransform_center_get(*args, **kwargs):
    pass


def MPxEmitterNode_getRate(*args, **kwargs):
    pass


def MPxMotionPathNode_bank_set(*args, **kwargs):
    pass


def MPxFieldNode_compute(*args, **kwargs):
    pass


def MPxSpringNode_className(*args, **kwargs):
    pass


def MPxRenderPassImpl_getNumChannels(*args, **kwargs):
    pass


def MPxImagePlane_center_get(*args, **kwargs):
    pass


def MPxTransform_minTransZLimitEnable_get(*args, **kwargs):
    pass


def MPxSurfaceShape_matchComponent(*args, **kwargs):
    pass


def MPx3dModelView_backgroundColor(*args, **kwargs):
    pass


def new_MPxImagePlane(*args, **kwargs):
    pass


def MPxCacheFormat_readFloatArray(*args, **kwargs):
    pass


def MPxSurfaceShapeUI_snap(*args, **kwargs):
    pass


def MPxHwShaderNode_outColorB_get(*args, **kwargs):
    pass


def MPxLocatorNode_localScaleY_set(*args, **kwargs):
    pass


def MPxRepresentation_swigregister(*args, **kwargs):
    pass


def MPxNode_getInternalValue(*args, **kwargs):
    pass


def MPxTransform_maxScaleXLimit_set(*args, **kwargs):
    pass


def MPxTransform_overrideEnabled_get(*args, **kwargs):
    pass


def MPxTransformationMatrix_rotation(*args, **kwargs):
    pass


def MPxManipulatorNode_mouseRay(*args, **kwargs):
    pass


def MPxManipContainer_swiginit(*args, **kwargs):
    pass


def MPxEmitterNode_draw(*args, **kwargs):
    pass


def MPxMotionPathNode_positionMarkerTime_get(*args, **kwargs):
    pass


def MPxTransform_applyScaleLocks(*args, **kwargs):
    pass


def MPxCameraSet_camera_set(*args, **kwargs):
    pass


def MPxConstraintCommand_worldUpMatrixAttribute(*args, **kwargs):
    pass


def delete_MPxContext(*args, **kwargs):
    pass


def MPxTransform_minTransYLimitEnable_get(*args, **kwargs):
    pass


def MPx3dModelView_lightingMode(*args, **kwargs):
    pass


def MPxNode_frozen_set(*args, **kwargs):
    pass


def MPxControlCommand__control(*args, **kwargs):
    pass


def MPxAssembly_postActivateRep(*args, **kwargs):
    pass


def MPxAttributePatternFactory_className(*args, **kwargs):
    pass


def MPxMayaAsciiFilter_writePostConnectAttrsBlock(*args, **kwargs):
    pass


def MPxTransform_minRotYLimit_get(*args, **kwargs):
    pass


def MPxGeometryFilter_envelope_get(*args, **kwargs):
    pass


def MPxTransform_minRotYLimit_set(*args, **kwargs):
    pass


def MPxSurfaceShape_nodeBoundingBoxMinZ_get(*args, **kwargs):
    pass


def MPxImagePlane_coverage_get(*args, **kwargs):
    pass


def MPxAssembly_repTypes(*args, **kwargs):
    pass


def MPxHwShaderNode_outGlowColor_set(*args, **kwargs):
    pass


def MPxLocatorNode_nodeBoundingBoxSizeX_set(*args, **kwargs):
    pass


def MPx3dModelView_beginGL(*args, **kwargs):
    pass


def disown_MPxGeometryData(*args, **kwargs):
    pass


def MPxTransform_setRotatePivotTranslation(*args, **kwargs):
    pass


def MPxTransformationMatrix_shearBy(*args, **kwargs):
    pass


def MPxMidiInputDevice_swigregister(*args, **kwargs):
    pass


def MPxAssembly_addParentEdit(*args, **kwargs):
    pass


def disown_MPxPolyTweakUVInteractiveCommand(*args, **kwargs):
    pass


def MPx3dModelView_filteredObjectList(*args, **kwargs):
    pass


def MPxTexContext_swiginit(*args, **kwargs):
    pass


def MPxTransformationMatrix_rotationOrder(*args, **kwargs):
    pass


def MPxConstraintCommand_handleNewTargets(*args, **kwargs):
    pass


def MPx3dModelView_drawOnePass(*args, **kwargs):
    pass


def MPxTransform_nodeBoundingBox_get(*args, **kwargs):
    pass


def MPx3dModelView_fogColor(*args, **kwargs):
    pass


def MPxAttributePatternFactory_swiginit(*args, **kwargs):
    pass


def new_MPxGeometryIterator(*args, **kwargs):
    pass


def MPxImagePlane_colorOffsetB_get(*args, **kwargs):
    pass


def MPxSurfaceShape_geometryData(*args, **kwargs):
    pass


def MPxAssembly_addDeleteAttrEdit(*args, **kwargs):
    pass


def MPxObjectSet_verticesOnlySet_get(*args, **kwargs):
    pass


def new_MPxCacheFormat(*args, **kwargs):
    pass


def MPxTransform_objectGrpCompList_set(*args, **kwargs):
    pass


def MPxUITableControl_redrawLabels(*args, **kwargs):
    pass


def MPxSpringNode_mDeltaTime_get(*args, **kwargs):
    pass


def MPxBlendShape_weight_get(*args, **kwargs):
    pass


def MPxLocatorNode_closestPoint(*args, **kwargs):
    pass


def MPxParticleAttributeMapperNode_computeNodeColorR_set(*args, **kwargs):
    pass


def MPxNode_connectionBroken(*args, **kwargs):
    pass


def MPxEmitterNode_getRandomSeed(*args, **kwargs):
    pass


def delete_MPxGeometryIterator(*args, **kwargs):
    pass


def MPxTransform_applyTranslationLocks(*args, **kwargs):
    pass


def MPxSurfaceShape_nodeBoundingBoxMax_get(*args, **kwargs):
    pass


def MPxImagePlane_fit_get(*args, **kwargs):
    pass


def MPxSelectionContext_feedbackNumericalInput(*args, **kwargs):
    pass


def new_MExternalContentLocationTable(*args, **kwargs):
    pass


def delete_MPxIkSolverNode(*args, **kwargs):
    pass


def MPxHardwareShader_setVaryingParameters(*args, **kwargs):
    pass


def MPx3dModelView_drawAdornmentsNow(*args, **kwargs):
    pass


def MPxEmitterNode_mSpeed_get(*args, **kwargs):
    pass


def MPxMotionPathNode_rotate_get(*args, **kwargs):
    pass


def MPxMotionPathNode_swigregister(*args, **kwargs):
    pass


def MPxPolyTweakUVCommand_getTweakedUVs(*args, **kwargs):
    pass


def MPx3dModelView_updateViewingParameters(*args, **kwargs):
    pass


def MPxLocatorNode_drawLast(*args, **kwargs):
    pass


def MPxComponentShape_swiginit(*args, **kwargs):
    pass


def MPxFieldNode_mMagnitude_set(*args, **kwargs):
    pass


def MPxTransformationMatrix_baseTransformationMatrixId_set(*args, **kwargs):
    pass


def MPxNode_setExistWithoutOutConnections(*args, **kwargs):
    pass


def disown_MPxContext(*args, **kwargs):
    pass


def disown_MPxFieldNode(*args, **kwargs):
    pass


def MPxControlCommand__parser(*args, **kwargs):
    pass


def MPxMotionPathNode_orientationMarkerTime_get(*args, **kwargs):
    pass


def MPxCommand_syntax(*args, **kwargs):
    pass


def MPxManipContainer_isManipActive(*args, **kwargs):
    pass


def new_MPxGlBuffer(*args, **kwargs):
    pass


def MPxEmitterNode_randgen(*args, **kwargs):
    pass


def MPxCacheFormat_writeDescription(*args, **kwargs):
    pass


def MPxTransform_renderLayerId_get(*args, **kwargs):
    pass


def MPxEmitterNode_mOwnerCentroidY_get(*args, **kwargs):
    pass


def MPxHwShaderNode_unbind(*args, **kwargs):
    pass


def MPxImagePlane_size_get(*args, **kwargs):
    pass


def MPxMotionPathNode_rotateZ_get(*args, **kwargs):
    pass


def MPxCacheFormat_readArraySize(*args, **kwargs):
    pass


def MPxCacheFormat_findTime(*args, **kwargs):
    pass


def MPxMultiPolyTweakUVCommand_preProcessUVs(*args, **kwargs):
    pass


def MPxManipulatorNode_addVectorValue(*args, **kwargs):
    pass


def MPxBlendShape_targetWeights_get(*args, **kwargs):
    pass


def MPxFileTranslator_writer(*args, **kwargs):
    pass


def MPxImagePlane_colorGain_set(*args, **kwargs):
    pass


def MFnPlugin_loadPath(*args, **kwargs):
    pass


def MPxGeometryIterator_setObject(*args, **kwargs):
    pass


def MPxSurfaceShape_boundingBoxCenterX_set(*args, **kwargs):
    pass


def MPxTransform_minRotXLimitEnable_get(*args, **kwargs):
    pass


def new_MPxHardwareShader(*args, **kwargs):
    pass


def MPxEmitterNode_mEmitterType_get(*args, **kwargs):
    pass


def MPxTransform_shear_get(*args, **kwargs):
    pass


def MaterialInputData_shininess_get(*args, **kwargs):
    pass


def MPxConstraintCommand_parseArgs(*args, **kwargs):
    pass


def MPxSurfaceShape_localShapeOutAttr(*args, **kwargs):
    pass


def MPxTransform_transMinusRotatePivotY_set(*args, **kwargs):
    pass


def MPxTransformationMatrix_swiginit(*args, **kwargs):
    pass


def MPxNode_getExternalContent(*args, **kwargs):
    pass


def MPxHwShaderNode_bind(*args, **kwargs):
    pass


def MPx3dModelView_numUserDefinedColors(*args, **kwargs):
    pass


def MPxFieldNode_mOwnerCentroidY_get(*args, **kwargs):
    pass


def MPxAssembly_supportsEdits(*args, **kwargs):
    pass


def MPxCommand_swigregister(*args, **kwargs):
    pass


def MPxMayaAsciiFilter_writesDisconnectAttr(*args, **kwargs):
    pass


def MPxTransform_minRotLimit_set(*args, **kwargs):
    pass


def MPxContext_completeAction(*args, **kwargs):
    pass


def MPxGeometryFilter_getDeformationDetails(*args, **kwargs):
    pass


def new_MPxSkinCluster(*args, **kwargs):
    pass


def MPxConstraint_lockOutput_set(*args, **kwargs):
    pass


def MPxParticleAttributeMapperNode_outValuePP_set(*args, **kwargs):
    pass


def MPxImagePlane_centerX_set(*args, **kwargs):
    pass


def MPxTransform_maxTransLimitEnable_set(*args, **kwargs):
    pass


def MPxSurfaceShape_mControlValueX_set(*args, **kwargs):
    pass


def MPx3dModelView_backgroundColorBottom(*args, **kwargs):
    pass


def MPxImagePlane_exactImageFile(*args, **kwargs):
    pass


def MPxTransform_scalePivotTranslateX_get(*args, **kwargs):
    pass


def MPxTransformationMatrix_shearTo(*args, **kwargs):
    pass


def MPxSurfaceShapeUI_selectUV(*args, **kwargs):
    pass


def delete_MPxPolyTrg(*args, **kwargs):
    pass


def MPxHwShaderNode_outColor_get(*args, **kwargs):
    pass


def MPxTransform_nodeBoundingBoxSize_get(*args, **kwargs):
    pass


def MPxLocatorNode_localScaleZ_set(*args, **kwargs):
    pass


def MPxNode_legalDisconnection(*args, **kwargs):
    pass


def MPxTransform_maxScaleZLimit_set(*args, **kwargs):
    pass


def MPxCommand_hasSyntax(*args, **kwargs):
    pass


def MPxMotionPathNode_orientationMarkerTime_set(*args, **kwargs):
    pass


def MPxTransform_setScalePivot(*args, **kwargs):
    pass


def MPxTransformationMatrix_rotateBy(*args, **kwargs):
    pass


def MPxHardwareShader_outColor_set(*args, **kwargs):
    pass


def MPxMidiInputDevice_closeDevice(*args, **kwargs):
    pass


def MPxEmitterNode_mDirection_set(*args, **kwargs):
    pass


def MaterialInputData_swiginit(*args, **kwargs):
    pass


def MPxLocatorNode_swigregister(*args, **kwargs):
    pass


def MPxSurfaceShape_objectColor_get(*args, **kwargs):
    pass


def MPxConstraintCommand_offsetAttribute(*args, **kwargs):
    pass


def MPxTransform_checkAndSetRotatePivotTranslation(*args, **kwargs):
    pass


def MPxNode_state_set(*args, **kwargs):
    pass


def MPxIkSolverNode_setSupportJointLimits(*args, **kwargs):
    pass


def MPxTransform_limitValue(*args, **kwargs):
    pass


def MPxAssembly_postApplyEdits(*args, **kwargs):
    pass


def MFnPlugin_registerDragAndDropBehavior(*args, **kwargs):
    pass


def MPxTransform_rotatePivotTranslateY_set(*args, **kwargs):
    pass


def MPxMayaAsciiFilter_swiginit(*args, **kwargs):
    pass


def disown_MPxGeometryFilter(*args, **kwargs):
    pass


def MPxParticleAttributeMapperNode_type(*args, **kwargs):
    pass


def MPx3dModelView_setFogDensity(*args, **kwargs):
    pass


def MPxTransform_swigregister(*args, **kwargs):
    pass


def MPxNode_schedulingType(*args, **kwargs):
    pass


def MExternalContentLocationTable_swiginit(*args, **kwargs):
    pass


def MPx3dModelView_isBackfaceCulling(*args, **kwargs):
    pass


def MPxSurfaceShape_mControlValueZ_get(*args, **kwargs):
    pass


def MPxImagePlane_coverageX_set(*args, **kwargs):
    pass


def MPxSelectionContext_doHold(*args, **kwargs):
    pass


def disown_MPxBlendShape(*args, **kwargs):
    pass


def MPxHwShaderNode_outTransparencyB_get(*args, **kwargs):
    pass


def MPx3dModelView_setDrawCameraOverride(*args, **kwargs):
    pass


def MPxMotionPathNode_allCoordinates_get(*args, **kwargs):
    pass


def MPxMayaAsciiFilter_writesRequirements(*args, **kwargs):
    pass


def MaterialInputData_shininess_set(*args, **kwargs):
    pass


def MPxEmitterNode_volumePrimitiveBoundingBox(*args, **kwargs):
    pass


def MPxTransform_dynamics_set(*args, **kwargs):
    pass


def MPxHwShaderNode_transparencyOptions(*args, **kwargs):
    pass


def MPxContext__beginMarquee(*args, **kwargs):
    pass


def MPx3dModelView_setIncludeInvisible(*args, **kwargs):
    pass


def MPxImagePlane_sizeY_get(*args, **kwargs):
    pass


def MPxManipContainer_addPointOnSurfaceManip(*args, **kwargs):
    pass


def disown_MPxConstraintCommand(*args, **kwargs):
    pass


def MPx3dModelView_requestOkForDraw(*args, **kwargs):
    pass


def MPxMotionPathNode_normal_set(*args, **kwargs):
    pass


def MPx3dModelView_setBackgroundFogEnabled(*args, **kwargs):
    pass


def MPxIkSolverNode_className(*args, **kwargs):
    pass


def MPxHwShaderNode_glBind(*args, **kwargs):
    pass


def MPxHwShaderNode_dirtyMask(*args, **kwargs):
    pass


def MPxTransform_rotateQuaternionW_get(*args, **kwargs):
    pass


def delete_MPxHwShaderNode(*args, **kwargs):
    pass


def MFnPlugin_deregisterCacheFormat(*args, **kwargs):
    pass


def MFnPlugin_registerContextCommand(*args, **kwargs):
    pass


def MPxObjectSet_facetsOnlySet_get(*args, **kwargs):
    pass


def MPxCacheFormat_isValid(*args, **kwargs):
    pass


def MPxLocatorNode_draw(*args, **kwargs):
    pass


def MPxTransform_objectGroupColor_set(*args, **kwargs):
    pass


def MPxBlendShape_inputTarget_set(*args, **kwargs):
    pass


def MPxGeometryData_name(*args, **kwargs):
    pass


def MPxAssembly_addDisconnectAttrEdit(*args, **kwargs):
    pass


def MPxGeometryIterator_next(*args, **kwargs):
    pass


def MPxSurfaceShape_isTemplated_get(*args, **kwargs):
    pass


def MPx3dModelView_setFogStart(*args, **kwargs):
    pass


def MPxSelectionContext_doRelease(*args, **kwargs):
    pass


def MPxImagePlane_visibleInReflections_get(*args, **kwargs):
    pass


def MPxManipulatorNode_glActiveName(*args, **kwargs):
    pass


def MPxUITableControl_setNumberOfRows(*args, **kwargs):
    pass


def MPxLocatorNode_center_get(*args, **kwargs):
    pass


def disown_MPxAttributePatternFactory(*args, **kwargs):
    pass


def MPxMotionPathNode_rotateX_get(*args, **kwargs):
    pass


def MPxTransform_scaleZ_get(*args, **kwargs):
    pass


def MPxData_swiginit(*args, **kwargs):
    pass


def MPxTransform_transMinusRotatePivotX_set(*args, **kwargs):
    pass


def MPxFieldNode_isFalloffCurveConstantOne(*args, **kwargs):
    pass


def MPxTransformationMatrix_swigregister(*args, **kwargs):
    pass


def MPxNode_name(*args, **kwargs):
    pass


def MPxModelEditorCommand_swiginit(*args, **kwargs):
    pass


def MPxPolyTrg_compute(*args, **kwargs):
    pass


def MPxImagePlane_useDepthMap_get(*args, **kwargs):
    pass


def MPxFieldNode_mOwnerPPData_get(*args, **kwargs):
    pass


def MPxAssembly_createRepresentation(*args, **kwargs):
    pass


def MPxSurfaceShape_type(*args, **kwargs):
    pass


def MPxTransform_rotateY_get(*args, **kwargs):
    pass


def MPxManipContainer_plugToManipConversion(*args, **kwargs):
    pass


def MPxTransform_maxTransZLimitEnable_get(*args, **kwargs):
    pass


def MPxEmitterNode_mOutput_set(*args, **kwargs):
    pass


def MPx3dModelView_getCameraSet(*args, **kwargs):
    pass


def MPxMotionPathNode_worldUpVectorX_set(*args, **kwargs):
    pass


def MPxFieldNode_mInputData_get(*args, **kwargs):
    pass


def MPx3dModelView_hasStereoBufferSupport(*args, **kwargs):
    pass


def new_MPxConstraint(*args, **kwargs):
    pass


def MPxHwShaderNode_texCoordsPerVertex(*args, **kwargs):
    pass


def MPxTransform_maxTransYLimit_set(*args, **kwargs):
    pass


def MPxMayaAsciiFilter_processWriteOptions(*args, **kwargs):
    pass


def MPxSurfaceShape_convertToTweakNodePlug(*args, **kwargs):
    pass


def MPxTransform_scalePivotZ_set(*args, **kwargs):
    pass


def MPxSelectionContext_className(*args, **kwargs):
    pass


def MPxTransform_nodeBoundingBoxMaxY_set(*args, **kwargs):
    pass


def MPxManipulatorNode_registerForMouseMove(*args, **kwargs):
    pass


def MPxGeometryData_iterator(*args, **kwargs):
    pass


def MFnPlugin_deregisterImageFile(*args, **kwargs):
    pass


def MPxTransform_maxTransYLimit_get(*args, **kwargs):
    pass


def MPxIkSolverNode_toSolverSpace(*args, **kwargs):
    pass


def MPxFileTranslator_haveReadMethod(*args, **kwargs):
    pass


def MPxGeometryIterator_swigregister(*args, **kwargs):
    pass


def MPxTransform_minScaleXLimit_set(*args, **kwargs):
    pass


def disown_MPxToolCommand(*args, **kwargs):
    pass


def MPxLocatorNode_nodeBoundingBox_set(*args, **kwargs):
    pass


def MPxEmitterNode_mStartTime_get(*args, **kwargs):
    pass


def disown_MPxMotionPathNode(*args, **kwargs):
    pass


def MPxEmitterNode_hasValidEmission2dTexture(*args, **kwargs):
    pass


def MaterialInputData_diffuse_get(*args, **kwargs):
    pass


def MPxData_writeASCII(*args, **kwargs):
    pass


def MPxConstraintCommand_createdConstraint(*args, **kwargs):
    pass


def MPxHwShaderNode_glGeometry(*args, **kwargs):
    pass


def MPxTransformationMatrix_asScaleMatrix(*args, **kwargs):
    pass


def MPxFieldNode_mInputMass_set(*args, **kwargs):
    pass


def MPxDragAndDropBehavior_swiginit(*args, **kwargs):
    pass


def new_MPxAttributePatternFactory(*args, **kwargs):
    pass


def MPxMayaAsciiFilter_writesFileReference(*args, **kwargs):
    pass


def MPxTransform_boundingBoxCenterZ_set(*args, **kwargs):
    pass


def MPxTransform__dirtyShear(*args, **kwargs):
    pass


def MPxGeometryFilter_input_set(*args, **kwargs):
    pass


def MPxConstraint_getOutputAttributes(*args, **kwargs):
    pass


def MPxImagePlane_centerZ_set(*args, **kwargs):
    pass


def MPxCameraSet_sceneData_set(*args, **kwargs):
    pass


def MPxSurfaceShape_matrix_get(*args, **kwargs):
    pass


def MPxImagePlane_imageType_get(*args, **kwargs):
    pass


def MPxCacheFormat_readInt32(*args, **kwargs):
    pass


def MPxSurfaceShapeUI_surfaceShapeUI(*args, **kwargs):
    pass


def MPxMotionPathNode_inverseUp_get(*args, **kwargs):
    pass


def MPxHwShaderNode_outTransparency_get(*args, **kwargs):
    pass


def MPxLocatorNode_nodeBoundingBoxMin_set(*args, **kwargs):
    pass


def MPxTransform_rotateX_set(*args, **kwargs):
    pass


def MPxTransform_minScaleLimitEnable_set(*args, **kwargs):
    pass


def MPxTransform_nodeBoundingBoxSizeX_set(*args, **kwargs):
    pass


def MPxTransform_displayLocalAxis_get(*args, **kwargs):
    pass


def MPxTransformationMatrix_rotateOrientation(*args, **kwargs):
    pass


def MPxManipulatorNode_doRelease(*args, **kwargs):
    pass


def MPxMidiInputDevice_deviceState(*args, **kwargs):
    pass


def MPxLocatorNode_objectGroupId_set(*args, **kwargs):
    pass


def MPxImagePlane_sizeX_get(*args, **kwargs):
    pass


def MPxTransform_applyRotatePivotLocksTranslate(*args, **kwargs):
    pass


def delete_MPxComponentShape(*args, **kwargs):
    pass


def MPxTransform_instObjGroups_set(*args, **kwargs):
    pass


def MPxTransform_layerRenderable_set(*args, **kwargs):
    pass


def MPx3dModelView_fogDensity(*args, **kwargs):
    pass


def MPxNode_message_set(*args, **kwargs):
    pass


def MPxFieldNode_draw(*args, **kwargs):
    pass


def delete_MPxContextCommand(*args, **kwargs):
    pass


def MPxAssembly_className(*args, **kwargs):
    pass


def MPxAttributePatternFactory_swigregister(*args, **kwargs):
    pass


def MPxObjectSet_canBeDeleted(*args, **kwargs):
    pass


def MPxTransform_rotatePivotY_set(*args, **kwargs):
    pass


def MPxTransform_maxScaleZLimitEnable_set(*args, **kwargs):
    pass


def MPxTransform_intermediateObject_get(*args, **kwargs):
    pass


def delete_MPxDeformerNode(*args, **kwargs):
    pass


def MPxFluidEmitterNode_fluidDensityEmission(*args, **kwargs):
    pass


def MPxSkinCluster_swigregister(*args, **kwargs):
    pass


def MPxTransform_maxTransXLimit_get(*args, **kwargs):
    pass


def MFnPlugin_isNodeRegistered(*args, **kwargs):
    pass


def MPxEditData_className(*args, **kwargs):
    pass


def MPxSurfaceShape_parentInverseMatrix_set(*args, **kwargs):
    pass


def MPxSelectionContext_deleteManipulators(*args, **kwargs):
    pass


def MPxUITableControl_suspendUpdates(*args, **kwargs):
    pass


def MPxHwShaderNode_outGlowColorG_set(*args, **kwargs):
    pass


def MPx3dModelView_setCameraSet(*args, **kwargs):
    pass


def MPxEmitterNode_mDirectionZ_get(*args, **kwargs):
    pass


def MPxMotionPathNode_xCoordinate_get(*args, **kwargs):
    pass


def MPxEditData_isEqual(*args, **kwargs):
    pass


def MPxSurfaceShape_objectGroupColor_get(*args, **kwargs):
    pass


def MPxPolyTweakUVInteractiveCommand_swiginit(*args, **kwargs):
    pass


def MPxTransformationMatrix_rotatePivotTranslation(*args, **kwargs):
    pass


def MPxModelEditorCommand_skipFlagForCreate(*args, **kwargs):
    pass


def MPxContext__newToolCommand(*args, **kwargs):
    pass


def MPxFluidEmitterNode_fluidEmitter(*args, **kwargs):
    pass


def new_MPxManipContainer(*args, **kwargs):
    pass


def MPxTexContext_className(*args, **kwargs):
    pass


def MPxManipulatorNode_connectedNodes_get(*args, **kwargs):
    pass


def MPxTransformationMatrix_scaleBy(*args, **kwargs):
    pass


def MPxEmitterNode_mMaxDistance_set(*args, **kwargs):
    pass


def MPxRepresentation_swiginit(*args, **kwargs):
    pass


def MPxFieldNode_swiginit(*args, **kwargs):
    pass


def MPxMotionPathNode_inverseFront_get(*args, **kwargs):
    pass


def new_MPxMayaAsciiFilterOutput(*args, **kwargs):
    pass


def MPxIkSolverNode_setRotatePlane(*args, **kwargs):
    pass


def MPxUITableControl_swiginit(*args, **kwargs):
    pass


def MPxSurfaceShape_canMakeLive(*args, **kwargs):
    pass


def MPxManipulatorNode_swiginit(*args, **kwargs):
    pass


def MPxTransform_scalePivotY_set(*args, **kwargs):
    pass


def MPxObjectSet_renderableOnlySet_get(*args, **kwargs):
    pass


def MPxObjectSet_swiginit(*args, **kwargs):
    pass


def MPx3dModelView_swigregister(*args, **kwargs):
    pass


def MPxBlendShape_inputTargetItem_get(*args, **kwargs):
    pass


def MPxLocatorNode_localPositionX_get(*args, **kwargs):
    pass


def MPxIkSolverNode_toWorldSpace(*args, **kwargs):
    pass


def new_MFnPlugin(*args, **kwargs):
    pass


def MPxGeometryIterator_iteratorCount(*args, **kwargs):
    pass


def MPxTransform_minRotZLimitEnable_set(*args, **kwargs):
    pass


def MPxTransform_minTransLimit_set(*args, **kwargs):
    pass


def MPxImagePlane_colorGainR_get(*args, **kwargs):
    pass


def MPxTransform_shearTo(*args, **kwargs):
    pass


def MPxManipulatorNode_mouseDown(*args, **kwargs):
    pass


def MPx3dModelView_setDisplayCameraAnnotation(*args, **kwargs):
    pass


def MPxEmitterNode_mDeltaTime_get(*args, **kwargs):
    pass


def MFnPlugin_registerDevice(*args, **kwargs):
    pass


def MPxImagePlane_useDepthMap_set(*args, **kwargs):
    pass


def MPxUITableControl_setNumberOfColumns(*args, **kwargs):
    pass


def MPxSurfaceShape_swiginit(*args, **kwargs):
    pass


def MPxImagePlane_composite_get(*args, **kwargs):
    pass


def MPxFieldNode_getForceAtPoint(*args, **kwargs):
    pass


def MPxHwShaderNode_swiginit(*args, **kwargs):
    pass


def MPxTransform_postConstructor(*args, **kwargs):
    pass


def MPxNode_message_get(*args, **kwargs):
    pass


def MPxTransform_maxTransXLimit_set(*args, **kwargs):
    pass


def disown_MPxPolyTrg(*args, **kwargs):
    pass


def MExternalContentInfoTable_getInfoByKey(*args, **kwargs):
    pass


def MPxFieldNode_mInputPPData_get(*args, **kwargs):
    pass


def MPxAssembly_getRepresentations(*args, **kwargs):
    pass


def MPxMotionPathNode_uValue_set(*args, **kwargs):
    pass


def MPxToolCommand_finalize(*args, **kwargs):
    pass


def MPxLocatorNode_localPositionY_get(*args, **kwargs):
    pass


def MPxEmitterNode_getWorldPosition(*args, **kwargs):
    pass


def MPxGeometryFilter_type(*args, **kwargs):
    pass


def MPxMotionPathNode_worldUpVectorZ_get(*args, **kwargs):
    pass


def MPxMayaAsciiFilter_writesCreateNode(*args, **kwargs):
    pass


def MPxTransform_rotateQuaternionW_set(*args, **kwargs):
    pass


def MPxManipulatorNode_getVectorValue(*args, **kwargs):
    pass


def MPxTransform_minTransLimitEnable_get(*args, **kwargs):
    pass


def new_MPxSurfaceShapeUI(*args, **kwargs):
    pass


def MPxEmitterNode_mOwnerCentroidZ_set(*args, **kwargs):
    pass


def MPxLocatorNode_worldPositionZ_set(*args, **kwargs):
    pass


def MPxTransform_minTransZLimit_set(*args, **kwargs):
    pass


def MPxImageFile_open(*args, **kwargs):
    pass


def MPxTransform_minScaleYLimit_set(*args, **kwargs):
    pass


def MPxAssembly_memberRemoved(*args, **kwargs):
    pass


def MPxManipContainer_doPress(*args, **kwargs):
    pass


def new_MPx3dModelView(*args, **kwargs):
    pass


def MPxTransform_minTransYLimit_get(*args, **kwargs):
    pass


def MPxLocatorNode_objectGroupColor_set(*args, **kwargs):
    pass


def MPxCameraSet_cameraLayer_get(*args, **kwargs):
    pass


def MPxTransform_identification_get(*args, **kwargs):
    pass


def MPx3dModelView_setTwoSidedLighting(*args, **kwargs):
    pass


def MPxNode_setExternalContentForFileAttr(*args, **kwargs):
    pass


def MPxTransformationMatrix_asRotateMatrixInverse(*args, **kwargs):
    pass


def MPxGlBuffer_openFbo(*args, **kwargs):
    pass


def MPxTransform_rotatePivotZ_set(*args, **kwargs):
    pass


def MPxTransform_selectHandleX_get(*args, **kwargs):
    pass


def MPxTransform_rotatePivotX_set(*args, **kwargs):
    pass


def MPxTransform_inverseMatrix_get(*args, **kwargs):
    pass


def MPxAssembly_performActivate(*args, **kwargs):
    pass


def MPxParticleAttributeMapperNode_computeNodeColorB_get(*args, **kwargs):
    pass


def MPx3dModelView_swiginit(*args, **kwargs):
    pass


def MPxSurfaceShape_nodeBoundingBoxMaxX_set(*args, **kwargs):
    pass


def MPxImagePlane_useFrameExtension_get(*args, **kwargs):
    pass


def MPxCacheFormat_handlesDescription(*args, **kwargs):
    pass


def MPxTransform_maxScaleZLimit_get(*args, **kwargs):
    pass


def MPxHwShaderNode_outColorR_set(*args, **kwargs):
    pass


def MPxLocatorNode_nodeBoundingBoxMinY_set(*args, **kwargs):
    pass


def MPxTransform_scale_set(*args, **kwargs):
    pass


def MPxTransform_minScaleYLimitEnable_get(*args, **kwargs):
    pass


def MPxTransform_rotateAxisZ_set(*args, **kwargs):
    pass


def MPxTransformationMatrix_convertTransformationRotationOrder(*args, **kwargs):
    pass


def MPxTransformationMatrix_scale(*args, **kwargs):
    pass


def MPxManipulatorNode_mouseRayWorld(*args, **kwargs):
    pass


def MPxMidiInputDevice_doButtonEvents(*args, **kwargs):
    pass


def MPxFluidEmitterNode_mFluidColorR_set(*args, **kwargs):
    pass


def MPxMotionPathNode_frontAxis_set(*args, **kwargs):
    pass


def MPxTransform_checkAndSetScale(*args, **kwargs):
    pass


def MPxConstraintCommand_constraintTargetInstancedAttribute(*args, **kwargs):
    pass


def MPxTransform_computeLocalTransformation(*args, **kwargs):
    pass


def delete_MPxFluidEmitterNode(*args, **kwargs):
    pass


def MPxImagePlane_separateDepth_get(*args, **kwargs):
    pass


def MPxTransform__dirtyRotation(*args, **kwargs):
    pass


def MPxHwShaderNode_geometry(*args, **kwargs):
    pass


def MPxImagePlane_colorOffset_set(*args, **kwargs):
    pass


def MPxSurfaceShape_setRenderable(*args, **kwargs):
    pass


def delete_MPxLocatorNode(*args, **kwargs):
    pass


def MPxTransform_scalePivotX_set(*args, **kwargs):
    pass


def MPxObjectSet_DNSetMembers_set(*args, **kwargs):
    pass


def disown_MPxMaterialInformation(*args, **kwargs):
    pass


def MPxTransform_ghosting_get(*args, **kwargs):
    pass


def MPxFluidEmitterNode_fluidHeatEmission(*args, **kwargs):
    pass


def new_MPxRenderPassImpl(*args, **kwargs):
    pass


def MFnPlugin_deregisterDisplayFilter(*args, **kwargs):
    pass


def MPxFileTranslator_identifyFile(*args, **kwargs):
    pass


def MPxSurfaceShape_nodeBoundingBoxMinX_set(*args, **kwargs):
    pass


def MPxImagePlane_coverageOriginX_set(*args, **kwargs):
    pass


def MPxImagePlane_className(*args, **kwargs):
    pass


def MPxSelectionContext__startPoint(*args, **kwargs):
    pass


def MPxTransform_scaleBy(*args, **kwargs):
    pass


def MPx3dModelView_viewSelected(*args, **kwargs):
    pass


def MPx3dModelView_getCameraHUDName(*args, **kwargs):
    pass


def MPxEmitterNode_mOwnerVelData_get(*args, **kwargs):
    pass


def delete_MPxData(*args, **kwargs):
    pass


def MPxFieldNode_mUseMaxDistance_set(*args, **kwargs):
    pass


def delete_MPxManipContainer(*args, **kwargs):
    pass


def MPxTransformationMatrix_unSquishMatrix(*args, **kwargs):
    pass


def MPxNode_addAttribute(*args, **kwargs):
    pass


def MPxModelEditorCommand_makeModelView(*args, **kwargs):
    pass


def MPxContext_processNumericalInput(*args, **kwargs):
    pass


def MFnPlugin_registerUI(*args, **kwargs):
    pass


def MPxCommand_getCurrentResult(*args, **kwargs):
    pass


def MPxManipContainer_addCurveSegmentManip(*args, **kwargs):
    pass


def MPxEmitterNode_mMaxDistance_get(*args, **kwargs):
    pass


def MPx3dModelView_fogSource(*args, **kwargs):
    pass


def MPxAssembly_activateRep(*args, **kwargs):
    pass


def delete_MPxAnimCurveInterpolator(*args, **kwargs):
    pass


def MPxImagePlane_lockedToCamera_get(*args, **kwargs):
    pass


def MPxSurfaceShape_childChanged(*args, **kwargs):
    pass


def MPx3dModelView_isShadeActiveOnly(*args, **kwargs):
    pass


def MPxParticleAttributeMapperNode_uCoordPP_get(*args, **kwargs):
    pass


def MPxObjectSet_partition_get(*args, **kwargs):
    pass


def MPxSpringNode_applySpringLaw(*args, **kwargs):
    pass


def MPxEmitterNode_mEmitterType_set(*args, **kwargs):
    pass


def MFnPlugin_deregisterDragAndDropBehavior(*args, **kwargs):
    pass


def MPxBlendShape_inputGeomTarget_set(*args, **kwargs):
    pass


def MPxFileTranslator_swiginit(*args, **kwargs):
    pass


def MPxTransform_translateZ_get(*args, **kwargs):
    pass


def MFnPlugin_registerRenderer(*args, **kwargs):
    pass


def MPxSurfaceShape_objectGroupId_get(*args, **kwargs):
    pass


def MPxGeometryIterator_index(*args, **kwargs):
    pass


def MFnPlugin_setName(*args, **kwargs):
    pass


def MPxManipulatorNode_dimmedColor(*args, **kwargs):
    pass


def MPxSurfaceShape_nodeBoundingBoxSizeZ_get(*args, **kwargs):
    pass


def MFnPlugin_registerTransform(*args, **kwargs):
    pass


def MPxImagePlane_colorGainB_get(*args, **kwargs):
    pass


def MPxTransform_displayScalePivot_get(*args, **kwargs):
    pass


def MPxManipulatorNode_connectToDependNode(*args, **kwargs):
    pass


def MPx3dModelView_isVisible(*args, **kwargs):
    pass


def MPxLocatorNode_matrix_get(*args, **kwargs):
    pass


def MPxManipContainer_addDiscManip(*args, **kwargs):
    pass


def MPxMotionPathNode_rotateOrder_set(*args, **kwargs):
    pass


def MPxImagePlane_depth_get(*args, **kwargs):
    pass


def MPxGlBuffer_unbindFbo(*args, **kwargs):
    pass


def new_MPxCameraSet(*args, **kwargs):
    pass


def MPxToolCommand_doIt(*args, **kwargs):
    pass


def MPxLocatorNode_boundingBox(*args, **kwargs):
    pass


def MPxFieldNode_iconBitmap(*args, **kwargs):
    pass


def MPxTransform_boundingBox(*args, **kwargs):
    pass


def MPxNode_swigregister(*args, **kwargs):
    pass


def MPxContextCommand_setResult(*args, **kwargs):
    pass


def MPxFieldNode_mInputMass_get(*args, **kwargs):
    pass


def MPxDragAndDropBehavior_connectAttrToAttr(*args, **kwargs):
    pass


def MPxHwShaderNode_outGlowColorG_get(*args, **kwargs):
    pass


def MPxTransform_nodeBoundingBoxSizeZ_get(*args, **kwargs):
    pass


def MPxContext_doHold(*args, **kwargs):
    pass


def MPxGeometryFilter_accessoryNodeSetup(*args, **kwargs):
    pass


def MPxMotionPathNode_worldUpMatrix_set(*args, **kwargs):
    pass


def MPxTransform_minTransZLimit_get(*args, **kwargs):
    pass


def MPxConstraint_enableRestPosition_get(*args, **kwargs):
    pass


def MPxParticleAttributeMapperNode_time_get(*args, **kwargs):
    pass


def MPxIkSolverNode_setFuncValueTolerance(*args, **kwargs):
    pass


def MPxCameraSet_order_get(*args, **kwargs):
    pass


def MPx3dModelView_userDefinedColorIndex(*args, **kwargs):
    pass


def MPxImageFile_swigregister(*args, **kwargs):
    pass


def delete_MPxPolyTweakUVInteractiveCommand(*args, **kwargs):
    pass


def MPxCacheFormat_writeInt32(*args, **kwargs):
    pass


def MPxSurfaceShapeUI_draw(*args, **kwargs):
    pass


def MPxCacheFormat_writeIntArray(*args, **kwargs):
    pass


def MPxManipulatorNode_connectPlugToValue(*args, **kwargs):
    pass


def MPx3dModelView_postMultipleDraw(*args, **kwargs):
    pass


def MPxLocatorNode_localScaleX_get(*args, **kwargs):
    pass


def MPxTransform_scalePivotZ_get(*args, **kwargs):
    pass


def MPxAssembly_activate(*args, **kwargs):
    pass


def disown_MPxImageFile(*args, **kwargs):
    pass


def MPxTransform_maxScaleLimit_get(*args, **kwargs):
    pass


def MPxSurfaceShape_createFullVertexGroup(*args, **kwargs):
    pass


def MPxTransform_rotateAxisY_get(*args, **kwargs):
    pass


def MPxManipulatorNode_doDrag(*args, **kwargs):
    pass


def MPxManipContainer_className(*args, **kwargs):
    pass


def MPxEmitterNode_mOwnerCentroid_set(*args, **kwargs):
    pass


def disown_MPxLocatorNode(*args, **kwargs):
    pass


def MPx3dModelView_viewType(*args, **kwargs):
    pass


def MPxGeometryIterator_currentPoint(*args, **kwargs):
    pass


def MPxTransform_maxTransLimitEnable_get(*args, **kwargs):
    pass


def MPxLocatorNode_objectColor_get(*args, **kwargs):
    pass


def MPxRepresentation_getExternalContent(*args, **kwargs):
    pass


def MPxMayaAsciiFilter_writesConnectAttr(*args, **kwargs):
    pass


def MPxImagePlane_visibleInRefractions_set(*args, **kwargs):
    pass


def MPxNode_caching_get(*args, **kwargs):
    pass


def MPxEmitterNode_volumePrimitiveDistanceFromAxis(*args, **kwargs):
    pass


def MPxTransform_setNonAffineMatricesEnabled(*args, **kwargs):
    pass


def MPxControlCommand_clearResult(*args, **kwargs):
    pass


def MPxParticleAttributeMapperNode_outMaxValue_set(*args, **kwargs):
    pass


def MPxTransform_rotatePivotTranslateX_get(*args, **kwargs):
    pass


def MPxTransform_selectHandleZ_get(*args, **kwargs):
    pass


def MPxTransform_nodeBoundingBoxMaxY_get(*args, **kwargs):
    pass


def MPxTransform_worldInverseMatrix_get(*args, **kwargs):
    pass


def MPxTransform_nodeBoundingBoxMinY_set(*args, **kwargs):
    pass


def MPxGeometryFilter_outputGeom_get(*args, **kwargs):
    pass


def MPxParticleAttributeMapperNode_computeNode_set(*args, **kwargs):
    pass


def MPxSkinCluster_weightList_set(*args, **kwargs):
    pass


def MPxConstraintCommand_doIt(*args, **kwargs):
    pass


def MPxParticleAttributeMapperNode_swiginit(*args, **kwargs):
    pass


def MPxTransform_minRotXLimit_get(*args, **kwargs):
    pass


def MPx3dModelView_worldToView(*args, **kwargs):
    pass


def MPxSurfaceShape_nodeBoundingBoxSizeX_set(*args, **kwargs):
    pass


def MPxImagePlane_frameOffset_get(*args, **kwargs):
    pass


def MPxTransform_rotateBy(*args, **kwargs):
    pass


def MPxTransform_setRotationOrder(*args, **kwargs):
    pass


def MPx3dModelView_doUpdateOnMove(*args, **kwargs):
    pass


def MPxMotionPathNode_bankThreshold_get(*args, **kwargs):
    pass


def MPxContext_doPress(*args, **kwargs):
    pass


def MPxTransformationMatrix_shear(*args, **kwargs):
    pass


def MPxManipulatorNode_shouldDrawHandleAsSelected(*args, **kwargs):
    pass


def MPxMidiInputDevice_className(*args, **kwargs):
    pass


def MPxFluidEmitterNode_mEmitFluidColor_set(*args, **kwargs):
    pass


def MFnPlugin_registerConstraintCommand(*args, **kwargs):
    pass


def new_MPxMaterialInformation(*args, **kwargs):
    pass


def MPxTransform_checkAndSetRotatePivot(*args, **kwargs):
    pass


def MPxConstraintCommand_objectAttribute(*args, **kwargs):
    pass


def MPx3dModelView_setCustomDrawEnable(*args, **kwargs):
    pass


def MPxImagePlane_depthFile_set(*args, **kwargs):
    pass


def MPxTransform_rotateQuaternionY_set(*args, **kwargs):
    pass


def MPxImagePlane_colorOffsetG_set(*args, **kwargs):
    pass


def MPxLocatorNode_isBounded(*args, **kwargs):
    pass


def MPxObjectSet_annotation_set(*args, **kwargs):
    pass


def MPxTransform_objectGroups_get(*args, **kwargs):
    pass


def MPxAssembly_preApplyEdits(*args, **kwargs):
    pass


def MPxDeformerNode_weights_set(*args, **kwargs):
    pass


def MPxGlBuffer_endBufferNotify(*args, **kwargs):
    pass


def MPxBlendShape_type(*args, **kwargs):
    pass


def MPxFileResolver_numURIResolvers(*args, **kwargs):
    pass


def MPxTransform_translateY_get(*args, **kwargs):
    pass


def MExternalContentInfoTable_addUnresolvedEntry(*args, **kwargs):
    pass


def MPxMayaAsciiFilterOutput_swiginit(*args, **kwargs):
    pass


def MPxSurfaceShape_isTemplated_set(*args, **kwargs):
    pass


def MPxImagePlane_sourceTexture_get(*args, **kwargs):
    pass


def MPxSelectionContext__isSelecting(*args, **kwargs):
    pass


def MPxTransform_inheritsTransform_set(*args, **kwargs):
    pass


def MPxSurfaceShape_objectGroupId_set(*args, **kwargs):
    pass


def MPxEmitterNode_mOwnerCentroidY_set(*args, **kwargs):
    pass


def new_MPxPolyTweakUVCommand(*args, **kwargs):
    pass


def new_MPxDragAndDropBehavior(*args, **kwargs):
    pass


def MPxFieldNode_mInputPositions_set(*args, **kwargs):
    pass


def MPxTransform_lodVisibility_get(*args, **kwargs):
    pass


def MPxTransformationMatrix_convertEulerRotationOrder(*args, **kwargs):
    pass


def disown_MPxNode(*args, **kwargs):
    pass


def MPxContext_argTypeNumericalInput(*args, **kwargs):
    pass


def MPxModelEditorCommand_setResult(*args, **kwargs):
    pass


def MPxFieldNode_swigregister(*args, **kwargs):
    pass


def MPxTransform_shearYZ_set(*args, **kwargs):
    pass


def MPxCommand_clearResult(*args, **kwargs):
    pass


def MPxPolyTweakUVInteractiveCommand_cancel(*args, **kwargs):
    pass


def MPxMotionPathNode_frontTwist_set(*args, **kwargs):
    pass


def MPxEmitterNode_getOwnerShape(*args, **kwargs):
    pass


def MPxMotionPathNode_worldUpType_get(*args, **kwargs):
    pass


def MPxAnimCurveInterpolator_typeName(*args, **kwargs):
    pass


def MPxIkSolverNode_supportJointLimits(*args, **kwargs):
    pass


def MFnPlugin_deregisterURIFileResolver(*args, **kwargs):
    pass


def MPx3dModelView_portHeight(*args, **kwargs):
    pass


def MPxEmitterNode_mWorldMatrix_get(*args, **kwargs):
    pass


def MPxManipulatorNode_className(*args, **kwargs):
    pass


def MPxObjectSet_usedByNodes_get(*args, **kwargs):
    pass


def MPxCacheFormat_endReadChunk(*args, **kwargs):
    pass


def MPxGeometryFilter_setUseExistingConnectionWhenSetEditing(*args, **kwargs):
    pass


def MPxFluidEmitterNode_swiginit(*args, **kwargs):
    pass


def MPxBlendShape_inputComponentsTarget_get(*args, **kwargs):
    pass


def MPxTransform_renderInfo_set(*args, **kwargs):
    pass


def delete_MPxObjectSet(*args, **kwargs):
    pass


def MPxTransform_rotateZ_get(*args, **kwargs):
    pass


def MFnPlugin_registerDisplayFilter(*args, **kwargs):
    pass


def MPxEmitterNode_mRandState_set(*args, **kwargs):
    pass


def MPxGeometryIterator_setCurrentPoint(*args, **kwargs):
    pass


def MPxTransform_maxRotZLimitEnable_get(*args, **kwargs):
    pass


def MPxSurfaceShape_mControlValueY_set(*args, **kwargs):
    pass


def MPxEditData__dataStringValue_get(*args, **kwargs):
    pass


def MPxTransform_rotateAxisX_get(*args, **kwargs):
    pass


def MPxControlCommand_setResult(*args, **kwargs):
    pass


def MPxTexContext_viewToPort(*args, **kwargs):
    pass


def MPxHardwareShader_renderSwatchImage(*args, **kwargs):
    pass


def MPxEmitterNode_mOwnerCentroidX_get(*args, **kwargs):
    pass


def MPxMultiPolyTweakUVCommand_swigregister(*args, **kwargs):
    pass


def MPxData_readASCII(*args, **kwargs):
    pass


def MPxCommand_swiginit(*args, **kwargs):
    pass


def MPxTransformationMatrix_setScalePivotTranslation(*args, **kwargs):
    pass


def MPxTransform_transformationMatrixPtr(*args, **kwargs):
    pass


def MPxNode_existWithoutInConnections(*args, **kwargs):
    pass


def MPxContextCommand_className(*args, **kwargs):
    pass


def MPxFieldNode_mOwnerPosData_set(*args, **kwargs):
    pass


def MPxAssembly_updateRepNamespace(*args, **kwargs):
    pass


def MPxBakeEngine_fInstance_get(*args, **kwargs):
    pass


def MPxTransform_center_set(*args, **kwargs):
    pass


def MPxEmitterNode_mMinDistance_set(*args, **kwargs):
    pass


def MPxMotionPathNode_bankScale_get(*args, **kwargs):
    pass


def MPxComponentShape_setControlPoints(*args, **kwargs):
    pass


def MPxRenderPassImpl_getDefaultType(*args, **kwargs):
    pass


def MPxIkSolverNode_setHandleGroup(*args, **kwargs):
    pass


def new_MPxEditData(*args, **kwargs):
    pass


def delete_MPxImagePlane(*args, **kwargs):
    pass


def MPxSurfaceShapeUI_canDrawUV(*args, **kwargs):
    pass


def MPxTransform_getEulerRotation(*args, **kwargs):
    pass


def MPxHwShaderNode_outMatteOpacityR_get(*args, **kwargs):
    pass


def MPx3dModelView_okForMultipleDraw(*args, **kwargs):
    pass


def MPxTransform_translateX_get(*args, **kwargs):
    pass


def MPxTransform_maxScaleYLimit_get(*args, **kwargs):
    pass


def delete_MExternalContentInfoTable(*args, **kwargs):
    pass


def MPxTransformationMatrix_eulerRotation(*args, **kwargs):
    pass


def MPxHardwareShader_type(*args, **kwargs):
    pass


def delete_MPxMidiInputDevice(*args, **kwargs):
    pass


def MPxEmitterNode_mOwnerCentroidX_set(*args, **kwargs):
    pass


def MPxGlBuffer_swigregister(*args, **kwargs):
    pass


def MPxTransform_applyRotationLocks(*args, **kwargs):
    pass


def new_MaterialInputData(*args, **kwargs):
    pass


def MPxTransform_applyShearLocks(*args, **kwargs):
    pass


def MPxComponentShape_transformUsing(*args, **kwargs):
    pass


def MPxConstraintCommand_worldUpTypeAttribute(*args, **kwargs):
    pass


def MPxMotionPathNode_sideTwist_get(*args, **kwargs):
    pass


def MPxTransform_rotationInterpolation_get(*args, **kwargs):
    pass


def MPx3dModelView_setFogEnabled(*args, **kwargs):
    pass


def MPxNode_typeName(*args, **kwargs):
    pass


def MPxTransform_rotateQuaternionX_set(*args, **kwargs):
    pass


def MPxTransformationMatrix_translateTo(*args, **kwargs):
    pass


def MPxHwShaderNode_provideVertexIDs(*args, **kwargs):
    pass


def MPxBakeEngine_swigregister(*args, **kwargs):
    pass


def MPxMayaAsciiFilter_writePreTrailer(*args, **kwargs):
    pass


def MPxTransform_parentMatrix_get(*args, **kwargs):
    pass


def MPxGeometryFilter_envelope_set(*args, **kwargs):
    pass


def MPxFluidEmitterNode_mFluidColorB_set(*args, **kwargs):
    pass


def MPxSkinCluster_matrix_get(*args, **kwargs):
    pass


def MPxTransform_translate_set(*args, **kwargs):
    pass


def MPxConstraintCommand_appendSyntax(*args, **kwargs):
    pass


def MExternalContentLocationTable_getLocationByKey(*args, **kwargs):
    pass


def MPx3dModelView_objectDisplay(*args, **kwargs):
    pass


def MPxSurfaceShape_inverseMatrix_set(*args, **kwargs):
    pass


def MPxImagePlane_coverage_set(*args, **kwargs):
    pass


def MPx3dModelView_getObjectsToView(*args, **kwargs):
    pass


def MPxTexContext_portToView(*args, **kwargs):
    pass


def new_MExternalContentInfoTable(*args, **kwargs):
    pass


def MPxHwShaderNode_outColor_set(*args, **kwargs):
    pass


def MPx3dModelView_endGL(*args, **kwargs):
    pass


def MPxMotionPathNode_fractionMode_set(*args, **kwargs):
    pass


def MPxTransform_maxScaleLimitEnable_set(*args, **kwargs):
    pass


def MPxControlCommand_swiginit(*args, **kwargs):
    pass


def new_MPxFieldNode(*args, **kwargs):
    pass


def MPxTransformationMatrix_scalePivot(*args, **kwargs):
    pass


def MPxContext__setCursor(*args, **kwargs):
    pass


def MPxFluidEmitterNode_mFluidFuelEmission_get(*args, **kwargs):
    pass


def MPxContext__setTitleString(*args, **kwargs):
    pass


def MPxTransform_shearXZ_set(*args, **kwargs):
    pass


def MPxTransform_checkAndSetScalePivotTranslation(*args, **kwargs):
    pass


def MPxConstraintCommand_connectTarget(*args, **kwargs):
    pass


def MPxEmitterNode_getMinDistance(*args, **kwargs):
    pass


def MPxMotionPathNode_follow_get(*args, **kwargs):
    pass


def MPx3dModelView_setFogColor(*args, **kwargs):
    pass


def MPxContext_doEnterRegion(*args, **kwargs):
    pass


def MPxIkSolverNode_doSolve(*args, **kwargs):
    pass


def MPxAssembly_preUnapplyEdits(*args, **kwargs):
    pass


def MPxSurfaceShape_getShapeSelectionMask(*args, **kwargs):
    pass


def MPxAssembly_addAddAttrEdit(*args, **kwargs):
    pass


def MPxObjectSet_verticesOnlySet_set(*args, **kwargs):
    pass


def delete_MPxCacheFormat(*args, **kwargs):
    pass


def MPxTransform_objectGroupId_get(*args, **kwargs):
    pass


def delete_MPxSurfaceShape(*args, **kwargs):
    pass


def MPxDeformerNode_swigregister(*args, **kwargs):
    pass


def MPxFluidEmitterNode_mFluidDropoff_get(*args, **kwargs):
    pass


def MPxTransform_rotateY_set(*args, **kwargs):
    pass


def MPxGeometryData_swigregister(*args, **kwargs):
    pass


def MPxParticleAttributeMapperNode_uCoordPP_set(*args, **kwargs):
    pass


def MPxParticleAttributeMapperNode_swigregister(*args, **kwargs):
    pass


def MPxNode_setInternalValue(*args, **kwargs):
    pass


def MPxSurfaceShape_worldInverseMatrix_set(*args, **kwargs):
    pass


def MPxImagePlane_fit_set(*args, **kwargs):
    pass


def MPxSelectionContext_setImage(*args, **kwargs):
    pass


def MPxAssembly_deleteRepresentation(*args, **kwargs):
    pass


def new_MPxTexContext(*args, **kwargs):
    pass


def MPx3dModelView_setDisplayAxis(*args, **kwargs):
    pass


def MPxEmitterNode_mOwnerVelData_set(*args, **kwargs):
    pass


def MPxMotionPathNode_worldUpVectorY_set(*args, **kwargs):
    pass


def MPxTransform_minTransXLimitEnable_set(*args, **kwargs):
    pass


def MPxData_swigregister(*args, **kwargs):
    pass


def MPxTransform_setRotateOrientation(*args, **kwargs):
    pass


def disown_MPxModelEditorCommand(*args, **kwargs):
    pass


def MPxContext_swigregister(*args, **kwargs):
    pass


def MPx3dModelView_getModelView(*args, **kwargs):
    pass


def MPxFieldNode_className(*args, **kwargs):
    pass


def delete_MPxAssembly(*args, **kwargs):
    pass


def MPxCommand_currentIntResult(*args, **kwargs):
    pass


def MPxManipContainer_finishAddingManips(*args, **kwargs):
    pass


def MPxTransform_getScalePivot(*args, **kwargs):
    pass


def MPxTransform_nodeBoundingBoxMin_set(*args, **kwargs):
    pass


def MPxMotionPathNode_worldUpVector_get(*args, **kwargs):
    pass


def MPxPolyTweakUVInteractiveCommand_finalize(*args, **kwargs):
    pass


def MPx3dModelView_removingCamera(*args, **kwargs):
    pass


def MPx3dModelView_viewIsFiltered(*args, **kwargs):
    pass


def MPxManipulatorNode_zColor(*args, **kwargs):
    pass


def MPxTexContext_getMarqueeSelection(*args, **kwargs):
    pass


def MPxContextCommand__parser(*args, **kwargs):
    pass


def MPxObjectSet_swigregister(*args, **kwargs):
    pass


def MPxCacheFormat_readNextTime(*args, **kwargs):
    pass


def MPxMayaAsciiFilter_haveReadMethod(*args, **kwargs):
    pass


def MPxManipulatorNode_setPointValue(*args, **kwargs):
    pass


def MPxImagePlane_height_get(*args, **kwargs):
    pass


def MPxBlendShape_targetWeights_set(*args, **kwargs):
    pass


def MPxLocatorNode_worldPositionX_get(*args, **kwargs):
    pass


def MPxGeometryIterator_geometry(*args, **kwargs):
    pass


def MFnPlugin_setVersion(*args, **kwargs):
    pass


def MPxSurfaceShape_parentMatrix_set(*args, **kwargs):
    pass


def MPxIkSolverNode_preSolve(*args, **kwargs):
    pass


def MPxHardwareShader_findResource(*args, **kwargs):
    pass


def delete_MPxEmitterNode(*args, **kwargs):
    pass


def MPxLocatorNode_worldInverseMatrix_set(*args, **kwargs):
    pass


def MPxMotionPathNode_fractionalToParametric(*args, **kwargs):
    pass


def MPxFluidEmitterNode_className(*args, **kwargs):
    pass


def MFnPlugin_deregisterNode(*args, **kwargs):
    pass


def MPxSurfaceShape_useObjectColor_get(*args, **kwargs):
    pass


def MPxConstraintCommand_doEdit(*args, **kwargs):
    pass


def MPxFieldNode_mInputVelocities_set(*args, **kwargs):
    pass


def MPxNode_getFilesToArchive(*args, **kwargs):
    pass


def MPxEditData_performIsLessThan(*args, **kwargs):
    pass


def MPxContextCommand_swiginit(*args, **kwargs):
    pass


def MPxFieldNode_mOwnerCentroid_get(*args, **kwargs):
    pass


def MPxAssembly_supportsMemberChanges(*args, **kwargs):
    pass


def MPxAttributePatternFactory_createPatternsFromString(*args, **kwargs):
    pass


def MPxMayaAsciiFilter_writesParentNode(*args, **kwargs):
    pass


def MPxTransform_boundingBoxCenterY_get(*args, **kwargs):
    pass


def MPxEmitterNode_mInheritFactor_set(*args, **kwargs):
    pass


def MPxTransform_renderLayerColor_get(*args, **kwargs):
    pass


def MPxConstraint_className(*args, **kwargs):
    pass


def MPxParticleAttributeMapperNode_computeNodeColorG_set(*args, **kwargs):
    pass


def MPxSpringNode_mDeltaTime_set(*args, **kwargs):
    pass


def MPxImagePlane_centerY_get(*args, **kwargs):
    pass


def MPxCameraSet_swiginit(*args, **kwargs):
    pass


def MPxSurfaceShape_nodeBoundingBox_set(*args, **kwargs):
    pass


def MPxImagePlane_refreshImage(*args, **kwargs):
    pass


def new_MPxContextCommand(*args, **kwargs):
    pass


def MPxCacheFormat_readDoubleVectorArray(*args, **kwargs):
    pass


def MPxSurfaceShapeUI_surfaceShape(*args, **kwargs):
    pass


def MPxHwShaderNode_outColorB_set(*args, **kwargs):
    pass


def MPx3dModelView_setMultipleDrawEnable(*args, **kwargs):
    pass


def MPxLocatorNode_nodeBoundingBox_get(*args, **kwargs):
    pass


def MPxImagePlane_shadingSamplesOverride_set(*args, **kwargs):
    pass


def MPxMotionPathNode_worldUpVectorZ_set(*args, **kwargs):
    pass


def disown_MPxControlCommand(*args, **kwargs):
    pass


def MPxImagePlane_rotate_set(*args, **kwargs):
    pass


def MPxTransform_minScaleZLimitEnable_get(*args, **kwargs):
    pass


def MPxHardwareShader_outColor_get(*args, **kwargs):
    pass


def MPxEmitterNode_mDirectionX_get(*args, **kwargs):
    pass


def MPxTransformationMatrix_translation(*args, **kwargs):
    pass


def MPxTransform_shearXY_get(*args, **kwargs):
    pass


def delete_MPxMaterialInformation(*args, **kwargs):
    pass


def MPxLocatorNode_swiginit(*args, **kwargs):
    pass


def MPxComponentShape_getControlPoints(*args, **kwargs):
    pass


def MPxContext_toolOnSetup(*args, **kwargs):
    pass


def MPxTransform_minTransLimit_get(*args, **kwargs):
    pass


def MPx3dModelView_setFogSource(*args, **kwargs):
    pass


def MPxNode_passThroughToMany(*args, **kwargs):
    pass


def MPxSurfaceShape_undeleteComponents(*args, **kwargs):
    pass


def MPxTransform_nodeBoundingBoxSizeY_get(*args, **kwargs):
    pass


def MPxAssembly_postUnapplyEdits(*args, **kwargs):
    pass


def MPxBakeEngine_setNeedTransparency(*args, **kwargs):
    pass


def new_MPxObjectSet(*args, **kwargs):
    pass


def MPxTransform_parentInverseMatrix_set(*args, **kwargs):
    pass


def MPxMotionPathNode_worldUpMatrix_get(*args, **kwargs):
    pass


def MFnPlugin_addMenuItem(*args, **kwargs):
    pass


def MPxSkinCluster_bindPreMatrix_set(*args, **kwargs):
    pass


def MPxParticleAttributeMapperNode_computeNodeColorR_get(*args, **kwargs):
    pass


def MPxNode_postConstructor(*args, **kwargs):
    pass


def MExternalContentInfoTable_length(*args, **kwargs):
    pass


def MPxSurfaceShape_nodeBoundingBoxMaxY_get(*args, **kwargs):
    pass


def MPxTransform_scalePivotTranslateY_set(*args, **kwargs):
    pass


def MPxSelectionContext_abortAction(*args, **kwargs):
    pass


def MPxHwShaderNode_outGlowColorR_get(*args, **kwargs):
    pass


def MPxLocatorNode_nodeBoundingBoxSizeY_get(*args, **kwargs):
    pass


def MPx3dModelView_setCamera(*args, **kwargs):
    pass


def MPxTransform_maxScaleYLimitEnable_set(*args, **kwargs):
    pass


def MPxBakeEngine_bake(*args, **kwargs):
    pass


def MPxFieldNode_mApplyPerVertex_get(*args, **kwargs):
    pass


def MPxTransform_getRotationOrder(*args, **kwargs):
    pass


def MPxLocatorNode_nodeBoundingBoxMinZ_get(*args, **kwargs):
    pass


def disown_MPxCacheFormat(*args, **kwargs):
    pass


def MPxModelEditorCommand_doEditFlags(*args, **kwargs):
    pass


def MPxContext__releaseMarquee(*args, **kwargs):
    pass


def MPxMaterialInformation_connectAsTexture(*args, **kwargs):
    pass


def MPxTransform_translateTo(*args, **kwargs):
    pass


def MPxTransform_rotatePivotY_get(*args, **kwargs):
    pass


def MPxToolCommand_swiginit(*args, **kwargs):
    pass


def MPx3dModelView_processDraw(*args, **kwargs):
    pass


def MPx3dModelView_viewSelectedPrefix(*args, **kwargs):
    pass


def disown_MPxEditData(*args, **kwargs):
    pass


def delete_MPxFileTranslator(*args, **kwargs):
    pass


def MPxImagePlane_shadingSamplesOverride_get(*args, **kwargs):
    pass


def MPxHwShaderNode_type(*args, **kwargs):
    pass


def MFnPlugin_deregisterIkSolver(*args, **kwargs):
    pass


def MPxPolyTweakUVInteractiveCommand_setUVs(*args, **kwargs):
    pass


def MPxObjectSet_facetsOnlySet_set(*args, **kwargs):
    pass


def MPxCacheFormat_rewind(*args, **kwargs):
    pass


def MPxTransform_getMatrix(*args, **kwargs):
    pass


def delete_MPxTransformationMatrix(*args, **kwargs):
    pass


def MPxTransform_useObjectColor_get(*args, **kwargs):
    pass


def MPxFluidEmitterNode_mFluidColorB_get(*args, **kwargs):
    pass


def MPxBlendShape_inputTargetGroup_get(*args, **kwargs):
    pass


def MPxFileResolver_swiginit(*args, **kwargs):
    pass


def MFnPlugin_registerBakeEngine(*args, **kwargs):
    pass


def MPxGeometryIterator_reset(*args, **kwargs):
    pass


def MPxTransform_minRotYLimitEnable_get(*args, **kwargs):
    pass


def MPxSurfaceShape_nodeBoundingBoxMin_get(*args, **kwargs):
    pass


def MPxTransform_applyRotationLimits(*args, **kwargs):
    pass


def MPxManipulatorNode_mouseUp(*args, **kwargs):
    pass


def MPxImagePlane_displayOnlyIfCurrent_set(*args, **kwargs):
    pass


def MPxTransform_maxTransLimit_get(*args, **kwargs):
    pass


def MPxContext_doDrag(*args, **kwargs):
    pass


def MPx3dModelView_setDisplayAxisAtOrigin(*args, **kwargs):
    pass


def MPxLocatorNode_center_set(*args, **kwargs):
    pass


def MPxMotionPathNode_rotateX_set(*args, **kwargs):
    pass


def MPxPolyTweakUVCommand_swigregister(*args, **kwargs):
    pass


def MPxSurfaceShape_className(*args, **kwargs):
    pass


def MPxTransform_specifiedManipLocation_get(*args, **kwargs):
    pass


def MPxNode__setMPSafe(*args, **kwargs):
    pass


def MPxTransform_overrideShading_set(*args, **kwargs):
    pass


def MPxPolyTrg_isAbstractClass(*args, **kwargs):
    pass


def MPxFileTranslator_fileAccessMode(*args, **kwargs):
    pass


def MPxFieldNode_mOutputForce_get(*args, **kwargs):
    pass


def MPxControlCommand_swigregister(*args, **kwargs):
    pass


def MPxImagePlane_offsetX_get(*args, **kwargs):
    pass


def MPxCommand_className(*args, **kwargs):
    pass


def MPxManipContainer_manipToPlugConversion(*args, **kwargs):
    pass


def MPxParticleAttributeMapperNode_outMinValue_set(*args, **kwargs):
    pass


def MPxManipContainer_addToggleManip(*args, **kwargs):
    pass


def MPxEmitterNode_mSeed_get(*args, **kwargs):
    pass


def MPxEmitterNode_mDeltaTime_set(*args, **kwargs):
    pass


def MPxTransform_objectGroupColor_get(*args, **kwargs):
    pass


def MPxMotionPathNode_worldUpVectorY_get(*args, **kwargs):
    pass


def MPxMaterialInformation_textureDisconnected(*args, **kwargs):
    pass


def MPx3dModelView_getAsM3dView(*args, **kwargs):
    pass


def MPxTransform_renderLayerId_set(*args, **kwargs):
    pass


def MPxIkSolverNode_isPositionOnly(*args, **kwargs):
    pass


def MPxManipContainer_addPlugToInViewEditor(*args, **kwargs):
    pass


def MPxSurfaceShape_mHasHistoryOnCreate_get(*args, **kwargs):
    pass


def MPx3dModelView_numDormantColors(*args, **kwargs):
    pass


def disown_MPxManipulatorNode(*args, **kwargs):
    pass


def disown_MPxSelectionContext(*args, **kwargs):
    pass


def MPxTransform_selectHandle_set(*args, **kwargs):
    pass


def MPxContext_setImage(*args, **kwargs):
    pass


def MPxManipulatorNode_addDoubleValue(*args, **kwargs):
    pass


def MPxFileTranslator_haveWriteMethod(*args, **kwargs):
    pass


def MPxImagePlane_alphaGain_set(*args, **kwargs):
    pass


def MPxNode_copyInternalData(*args, **kwargs):
    pass


def MPxGeometryIterator_swiginit(*args, **kwargs):
    pass


def MPxTransform_minScaleYLimit_get(*args, **kwargs):
    pass


def MPxTransform_overridePlayback_get(*args, **kwargs):
    pass


def MPxTransform_minTransXLimit_get(*args, **kwargs):
    pass


def MPxTransform_minRotXLimitEnable_set(*args, **kwargs):
    pass


def MPxManipulatorNode_getInstancePtr(*args, **kwargs):
    pass


def MPxHardwareShader_outColorR_set(*args, **kwargs):
    pass


def MPxManipContainer_getConverterManipValue(*args, **kwargs):
    pass


def MPxLocatorNode_parentInverseMatrix_set(*args, **kwargs):
    pass


def MPxTransform_maxRotYLimit_set(*args, **kwargs):
    pass


def MPxFluidEmitterNode_mTurbulence_get(*args, **kwargs):
    pass


def MPxData_copy(*args, **kwargs):
    pass


def new_MPxContext(*args, **kwargs):
    pass


def MPxTransform_transMinusRotatePivotZ_get(*args, **kwargs):
    pass


def MPxFieldNode_mInputPositions_get(*args, **kwargs):
    pass


def disown_MPx3dModelView(*args, **kwargs):
    pass


def MPxNode_addExternalContentForFileAttr(*args, **kwargs):
    pass


def disown_MPxUIControl(*args, **kwargs):
    pass


def MPxControlCommand_makeControl(*args, **kwargs):
    pass


def MPxFieldNode_mOwnerCentroidZ_get(*args, **kwargs):
    pass


def MPxAssembly_beforeSave(*args, **kwargs):
    pass


def MPxCommand_setHistoryOn(*args, **kwargs):
    pass


def MPxTransform_selectHandle_get(*args, **kwargs):
    pass


def MPxManipulatorNode_yColor(*args, **kwargs):
    pass


def MPxTransform__dirtyRotateOrientation(*args, **kwargs):
    pass


def MPxGeometryFilter_inputGeom_get(*args, **kwargs):
    pass


def MPxSkinCluster_type(*args, **kwargs):
    pass


def delete_MPxRenderPassImpl(*args, **kwargs):
    pass


def MPxIkSolverNode_maxIterations(*args, **kwargs):
    pass


def MPxTransform_maxTransYLimitEnable_get(*args, **kwargs):
    pass


def MPx3dModelView_getColorIndexAndTable(*args, **kwargs):
    pass


def MPxSurfaceShape_nodeBoundingBoxSizeY_set(*args, **kwargs):
    pass


def MPxImagePlane_imageType_set(*args, **kwargs):
    pass


def MPxTransform_scalePivotTranslateX_set(*args, **kwargs):
    pass


def MPxTransform_validateAndSetValue(*args, **kwargs):
    pass


def MExternalContentInfoTable_addResolvedEntry(*args, **kwargs):
    pass


def MPxCacheFormat_writeChannelName(*args, **kwargs):
    pass


def MPxSurfaceShapeUI_className(*args, **kwargs):
    pass


def MPxHwShaderNode_outMatteOpacityR_set(*args, **kwargs):
    pass


def MPxTransform_nodeBoundingBoxSize_set(*args, **kwargs):
    pass


def MPx3dModelView_setDestroyOnPanelDestruction(*args, **kwargs):
    pass


def MPxLocatorNode_nodeBoundingBoxSize_set(*args, **kwargs):
    pass


def MPxLocatorNode_nodeBoundingBoxMinX_get(*args, **kwargs):
    pass


def MPxTransform_maxTransZLimit_get(*args, **kwargs):
    pass


def MPxIkSolverNode_snapHandle(*args, **kwargs):
    pass


def MPxTransform_minScaleXLimitEnable_get(*args, **kwargs):
    pass


def disown_MPxCommand(*args, **kwargs):
    pass


def MPxEmitterNode_className(*args, **kwargs):
    pass


def MPxManipulatorNode_setHandleColor(*args, **kwargs):
    pass


def MPxMidiInputDevice_sendMessage(*args, **kwargs):
    pass


def MPxFieldNode_mDeltaTime_get(*args, **kwargs):
    pass


def MPxMaterialInformation_materialInfoIsDirty(*args, **kwargs):
    pass


def MPxTransform_checkAndSetTranslation(*args, **kwargs):
    pass


def MPxData_writeBinary(*args, **kwargs):
    pass


def MPxConstraintCommand_constraintRestAttribute(*args, **kwargs):
    pass


def MPxTransform_checkAndSetScalePivot(*args, **kwargs):
    pass


def MPxMotionPathNode_pathGeometry_get(*args, **kwargs):
    pass


def MPxContext_image(*args, **kwargs):
    pass


def MPxNode_thisMObject(*args, **kwargs):
    pass


def MPxIkSolverNode_uniqueSolution(*args, **kwargs):
    pass


def MPxSurfaceShape_tweakUsing(*args, **kwargs):
    pass


def MPxObjectSet_dagSetMembers_get(*args, **kwargs):
    pass


def MPxTransform_enableLimit(*args, **kwargs):
    pass


def MPxLocatorNode_worldPosition_set(*args, **kwargs):
    pass


def MPxTransform_intermediateObject_set(*args, **kwargs):
    pass


def MPxDeformerNode_type(*args, **kwargs):
    pass


def MPxSpringNode_swiginit(*args, **kwargs):
    pass


def MFnPlugin_registerMaterialInfo(*args, **kwargs):
    pass


def MPxTransform_swiginit(*args, **kwargs):
    pass


def MPxFileResolver_uriScheme(*args, **kwargs):
    pass


def MPx3dModelView_setXrayEnabled(*args, **kwargs):
    pass


def MPxSurfaceShape_mControlValueZ_set(*args, **kwargs):
    pass


def MPxImagePlane_coverageOrigin_set(*args, **kwargs):
    pass


def MPxSelectionContext_setAllowSymmetry(*args, **kwargs):
    pass


def MPxUITableControl_numberOfColumns(*args, **kwargs):
    pass


def delete_MPxGeometryData(*args, **kwargs):
    pass


def MPxHwShaderNode_outGlowColor_get(*args, **kwargs):
    pass


def MPxEmitterNode_compute(*args, **kwargs):
    pass


def MPxLocatorNode_nodeBoundingBoxMaxX_set(*args, **kwargs):
    pass


def MPxMotionPathNode_xCoordinate_set(*args, **kwargs):
    pass


def MPx3dModelView_wantStereoGLBuffer(*args, **kwargs):
    pass


def MPxLocatorNode_excludeAsLocator(*args, **kwargs):
    pass


def MPxSurfaceShape_objectGroups_get(*args, **kwargs):
    pass


def MPxSurfaceShape_useObjectColor_set(*args, **kwargs):
    pass


def MPxAnimCurveInterpolator_swigregister(*args, **kwargs):
    pass


def MPxFieldNode_iconSizeAndOrigin(*args, **kwargs):
    pass


def new_MPxControlCommand(*args, **kwargs):
    pass


def MPxTransform_showManipDefault_get(*args, **kwargs):
    pass


def MPxTransformationMatrix_setRotatePivotTranslation(*args, **kwargs):
    pass


def MPxNode_caching_set(*args, **kwargs):
    pass


def MPxRepresentation_getName(*args, **kwargs):
    pass


def delete_MPxAttributePatternFactory(*args, **kwargs):
    pass


def MPxFluidEmitterNode_compute(*args, **kwargs):
    pass


def MPxImagePlane_sizeY_set(*args, **kwargs):
    pass


def MPxCommand_displayError(*args, **kwargs):
    pass


def MPxPolyTweakUVInteractiveCommand_isUndoable(*args, **kwargs):
    pass


def MPxEmitterNode_mRandState_get(*args, **kwargs):
    pass


def MPxDragAndDropBehavior_swigregister(*args, **kwargs):
    pass


def MPxMayaAsciiFilterOutput___lshift__(*args, **kwargs):
    pass


def MPxIkSolverNode_swigregister(*args, **kwargs):
    pass


def MPxImagePlane_shadingSamples_set(*args, **kwargs):
    pass


def MPxImagePlane_depthBias_set(*args, **kwargs):
    pass



MPxRenderPassImpl_kFloat32 = 512

MPxNode_kGeometryFilter = 24

MPxRenderPassImpl_kFloat16 = 256

MPxRenderPassImpl_kBit = 2048

cvar = None

MPxRenderPassImpl_kFloat64 = 1024

MPxNode_kTransformNode = 11

MPxRenderPassImpl_kInt16 = 32

MPxNode_kLast = 26

MPxNode_kBlendShape = 25

MPxNode_kSkinCluster = 23

MPxNode_kAssembly = 22

MPxNode_kThreadedDeviceNode = 21

MPxNode_kClientDeviceNode = 20

MPxNode_kMotionPathNode = 19

MPxNode_kManipulatorNode = 18

MPxNode_kConstraintNode = 17

MPxNode_kCameraSetNode = 16

MPxHwShaderNode_kDirtyAll = 15

MPxNode_kImagePlaneNode = 14

MPxNode_kFluidEmitterNode = 13

MPxNode_kObjectSet = 12

MPxManipContainer_kCustomManip = 10

MPxManipContainer_kCurveSegmentManip = 9

MPxHwShaderNode_kDirtyTexCoordArrays = 8

MPxManipContainer_kToggleManip = 7

MPxFileTranslator_kExportActiveAccessMode = 6

MPx3dModelView_kLightQuality = 5

MPx3dModelView_kLightNone = 4

MPx3dModelView_kLightDefault = 3

MPx3dModelView_kFogExponentialSquared = 2

MPx3dModelView_kFogCoordinate = 1

MPx3dModelView_kFogFragment = 0

MPxRenderPassImpl_kOther = 4096

MPxRenderPassImpl_kInt32 = 64

PLUGIN_COMPANY = 'Autodesk'

MPxRenderPassImpl_kInt64 = 128


