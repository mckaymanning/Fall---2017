from PySide2.QtCore import QObject as _QObject

class QUiLoader(_QObject):
    def __init__(*args, **kwargs):
        """
        x.__init__(...) initializes x; see help(type(x)) for signature
        """
    
        pass
    
    
    def addPluginPath(*args, **kwargs):
        pass
    
    
    def availableLayouts(*args, **kwargs):
        pass
    
    
    def availableWidgets(*args, **kwargs):
        pass
    
    
    def clearPluginPaths(*args, **kwargs):
        pass
    
    
    def createAction(*args, **kwargs):
        pass
    
    
    def createActionGroup(*args, **kwargs):
        pass
    
    
    def createLayout(*args, **kwargs):
        pass
    
    
    def createWidget(*args, **kwargs):
        pass
    
    
    def errorString(*args, **kwargs):
        pass
    
    
    def isLanguageChangeEnabled(*args, **kwargs):
        pass
    
    
    def isTranslationEnabled(*args, **kwargs):
        pass
    
    
    def load(*args, **kwargs):
        pass
    
    
    def pluginPaths(*args, **kwargs):
        pass
    
    
    def registerCustomWidget(*args, **kwargs):
        pass
    
    
    def setLanguageChangeEnabled(*args, **kwargs):
        pass
    
    
    def setTranslationEnabled(*args, **kwargs):
        pass
    
    
    def setWorkingDirectory(*args, **kwargs):
        pass
    
    
    def workingDirectory(*args, **kwargs):
        pass
    
    
    __new__ = None
    
    
    staticMetaObject = None



