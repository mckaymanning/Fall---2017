def meshHeight(name, x, z):
    pass



