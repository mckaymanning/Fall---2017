def createBasicRenderSetup():
    """
    Create a basic render setup
    """

    pass


def tmpSubDirName(dir, subDir):
    """
    Create a unique sub directory
    """

    pass



