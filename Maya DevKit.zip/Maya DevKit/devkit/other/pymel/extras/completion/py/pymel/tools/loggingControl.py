from pymel.core.uitypes import Menu as _Menu

class LoggingMenu(_Menu):
    def __init__(self, name=None, parent=None):
        pass
    
    
    def addHandler(self, logger):
        pass
    
    
    def buildLevelMenu(self, parent, item):
        pass
    
    
    def buildSubMenu(self, parent, logger):
        pass
    
    
    def changeLevel(self, item, level):
        pass
    
    
    def refresh(self, *args):
        pass
    
    
    def refreshLoggingMenu(self):
        pass
    
    
    def setFormatter(self, handler):
        pass
    
    
    def __new__(cls, name='pymelLoggingControl', parent=None):
        pass
    
    
    __melui__ = 'loggingMenu'
    
    
    __readonly__ = {}



def refreshLoggerHierarchy():
    pass


def initMenu():
    pass



levelsDict = {}

n = 50

logger = None

logLevelNames = []


