def createLightEditorUI():
    """
    Creates the light editor UI
    """

    pass


def reloadModules():
    """
    Reload all light editor modules
    """

    pass



lightEditorWindow = None


