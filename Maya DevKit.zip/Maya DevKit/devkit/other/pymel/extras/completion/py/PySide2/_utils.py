"""
# This file is part of PySide: Python for Qt
#
# Copyright (C) 2013 Digia Plc and/or its subsidiary(-ies).
#
# Contact: PySide team <contact@pyside.org>
#
# This program is free software; you can redistribute it and/or
# modify it under the terms of the GNU Lesser General Public License
# version 2 as published by the Free Software Foundation.
#
# This program is distributed in the hope that it will be useful, but
# WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
# Lesser General Public License for more details.
#
# You should have received a copy of the GNU Lesser General Public
# License along with this program; if not, write to the Free Software
# Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA
# 02110-1301 USA
"""

def _rcc_write_data(out, data):
    pass


def get_pyside_dir():
    pass


def _rcc_write_number(out, number, width):
    pass


def register_qt_conf(prefix, binaries, plugins, imports, translations, force=False):
    """
    Register qt.conf in Qt resource system to override the built-in
    configuration variables, if there is no default qt.conf in
    executable folder and another qt.conf is not already registered in
    Qt resource system.
    """

    pass


def _dir_contains(dir, filter):
    pass


def _get_qt_conf_resource(prefix, binaries, plugins, imports, translations):
    """
    Generate Qt resource with embedded qt.conf
    """

    pass


def _filter_match(name, patterns):
    pass



