def exportFile(filename):
    pass


def importFile(filename):
    """
    # Cannot name function "import", as this is a reserved Python keyword.
    """

    pass


def readFile(file):
    """
    Returns a list of the lines in the argument file.
    """

    pass



