"""
# PLY package
# Author: David Beazley (dave@dabeaz.com)
"""

