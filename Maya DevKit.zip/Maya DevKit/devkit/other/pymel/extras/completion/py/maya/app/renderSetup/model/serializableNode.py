class SerializableNode(object):
    def __init__(self):
        pass
    
    
    def decode(self, dict, mergeType, prependToName):
        pass
    
    
    def encode(self, notes=None):
        pass
    
    
    __dict__ = None
    
    __weakref__ = None



