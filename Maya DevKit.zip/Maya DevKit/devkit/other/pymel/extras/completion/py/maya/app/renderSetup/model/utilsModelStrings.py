"""
# This file exists only to work around a localization script limitation.
# As of April 2016, the script requires that files with localized
# strings have unique names.
"""

kNoSuchNode = []

kPlugTypeMismatch = []


