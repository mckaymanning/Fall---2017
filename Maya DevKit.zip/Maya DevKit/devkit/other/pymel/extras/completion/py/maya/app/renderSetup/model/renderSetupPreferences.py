def getUserTemplateDirectory():
    pass


def _getGlobalDirectory(globalDirectoryOptionVar):
    pass


def _getUserDirectory(userDirectoryOptionVar, defaultUserDirectoryName):
    pass


def setEditMode(value):
    pass


def getEditMode():
    pass


def getGlobalPresetsDirectory():
    pass


def getFileExtension():
    pass


def initialize():
    pass


def getGlobalTemplateDirectory():
    pass


def useDynamicUpdate():
    pass


def setUseDynamicUpdate(value):
    pass


def getUserPresetsDirectory():
    pass



kOptionVarUseDynamicUpdate = 'renderSetup_useDynamicUpdate'

kGlobalTemplatePathInvalid = []

kOptionVarUserPresetsDirectory = 'renderSetup_userPresetsDirectory'

kGlobalPresetsPathInvalid = []

kOptionVarUserTemplateDirectory = 'renderSetup_userTemplateDirectory'

kOptionVarEditMode = 'renderSetup_editMode'

kOptionVarGlobalTemplateDirectory = 'renderSetup_globalTemplateDirectory'

kOptionVarGlobalPresetsDirectory = 'renderSetup_globalPresetsDirectory'


