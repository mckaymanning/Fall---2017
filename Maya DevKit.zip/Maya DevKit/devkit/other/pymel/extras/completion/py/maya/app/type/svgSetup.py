def connectSVGAdjustDeformer(svgMesh, svgTransform, svgExtruder, svgTool):
    pass


def addPolyRemeshNodeType(svgTransform, svgExtruder, svgTool, svgMesh, svgAdjuster):
    pass


def svgScriptJobSetup(svgTool):
    pass


def createSVGTool(fromPaste=False, fromImport=False):
    pass


def connectSVGShellDeformer(svgMesh, svgTransform, svgExtruder, svgTool, svgAdjuster):
    pass


def setUpSVGNetwork(fromPaste=False, fromImport=False):
    pass


def addUVNodeToSVG(svgTransform, svgExtruder):
    pass


def showThesvgTool(svgTool, svgTransform):
    pass



