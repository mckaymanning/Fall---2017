"""
This module exists to avoid cyclic dependencies between modules.
"""

def computeValidObjectName(dict, mergeType, prependToName, objectTypeName):
    pass



SCENE_AOVS_ATTRIBUTE_NAME = 'sceneAOVs'

DECODE_AND_ADD = 0

IMPORTED_ATTRIBUTE_NAME = 'imported'

NAME_ATTRIBUTE_NAME = 'name'

kFaultyTypeName = []

kMissingTypeName = []

NOTES_ATTRIBUTE_NAME = 'notes'

kUnknownKeys = []

kMissingProperty = []

kObjectAlreadyExists = []

kWrongMergeType = []

SCENE_SETTINGS_ATTRIBUTE_NAME = 'sceneSettings'

kUnknownData = []

DECODE_AND_MERGE = 1

CHILDREN_ATTRIBUTE_NAME = 'children'

kUnknownTypeNode = []

COLLECTIONS_ATTRIBUTE_NAME = 'collections'

DECODE_AND_RENAME = 2

LAYERS_ATTRIBUTE_NAME = 'renderLayers'

VISIBILITY_ATTRIBUTE_NAME = 'isVisible'

kTypeNodeCreationFailed = []


