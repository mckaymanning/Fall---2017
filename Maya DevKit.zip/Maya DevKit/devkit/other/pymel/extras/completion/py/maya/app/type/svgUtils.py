from PySide2.QtWidgets import *
from PySide2.QtCore import *
from PySide2.QtGui import *

from maya.OpenMaya import MVector
from subprocess import call
from subprocess import Popen

def getVectorOffsetAttribute(adjustNode, svgNode):
    """
    #same as above, but this refreshes the sliders when you change selection in the AE
    """

    pass


def setVectorOffsetAttribute(adjustNode, svgNode):
    """
    #this sets the manipulation offsets (z position and extrusion scale)
    """

    pass


def clearVectorOffsetAttributes(adjustNode, svgNode):
    pass


def svg_catchPaste():
    pass



PIPE = -1


