from maya.app.renderSetup.views.propertyEditor.expressionLabels import *

from maya.app.renderSetup.views.propertyEditor.collectionStaticSelectionWidget import CollectionStaticSelectionWidget
from maya.app.renderSetup.views.propertyEditor.layout import Layout
from PySide2.QtWidgets import QShortcut
from PySide2.QtWidgets import QPushButton
from PySide2.QtWidgets import QWidget
from PySide2.QtWidgets import QStyle
from PySide2.QtGui import QIcon
from maya.app.general.mayaMixin import MayaQWidgetBaseMixin
from PySide2.QtWidgets import QAction
from PySide2.QtGui import QAbstractTextDocumentLayout
from PySide2.QtGui import QPen
from PySide2.QtWidgets import QLineEdit
from PySide2.QtGui import QPainter
from PySide2.QtCore import QItemSelectionModel
from PySide2.QtWidgets import QApplication
from PySide2.QtWidgets import QStyledItemDelegate
from PySide2.QtGui import QTextDocument
from PySide2.QtCore import QTimer
from PySide2.QtGui import QColor
from PySide2.QtCore import QRect
from PySide2.QtGui import QKeySequence
from PySide2.QtWidgets import QStyleOptionViewItem
from PySide2.QtCore import QSize
from PySide2.QtWidgets import QFormLayout
from PySide2.QtWidgets import QGroupBox
from PySide2.QtWidgets import QHBoxLayout
from PySide2.QtWidgets import QListWidget
from maya.app.renderSetup.views.propertyEditor.collectionStaticSelectionWidget import HTMLDelegate
from PySide2.QtGui import QFont
from PySide2.QtWidgets import QVBoxLayout
from PySide2.QtWidgets import QAbstractItemView
from PySide2.QtWidgets import QTextEdit
from PySide2.QtGui import QPalette

class LightsCollection(MayaQWidgetBaseMixin, QGroupBox):
    """
    This class represents the property editor view of a lights collection.
    """
    
    
    
    def __init__(self, item, treeView, parent):
        pass
    
    
    def paintEvent(self, event):
        pass
    
    
    EXPRESSION_BUTTON_WIDTH = 50.0
    
    
    LIST_BOX_HEIGHT = 100.0
    
    
    staticMetaObject = None



