class ClassInfo(object):
    def __call__(*args, **kwargs):
        """
        x.__call__(...) <==> x(...)
        """
    
        pass
    
    
    def __init__(*args, **kwargs):
        """
        x.__init__(...) initializes x; see help(type(x)) for signature
        """
    
        pass
    
    
    __new__ = None


class Property(object):
    def __call__(*args, **kwargs):
        """
        x.__call__(...) <==> x(...)
        """
    
        pass
    
    
    def __init__(*args, **kwargs):
        """
        x.__init__(...) initializes x; see help(type(x)) for signature
        """
    
        pass
    
    
    def getter(*args, **kwargs):
        pass
    
    
    def read(*args, **kwargs):
        pass
    
    
    def setter(*args, **kwargs):
        pass
    
    
    def write(*args, **kwargs):
        pass
    
    
    __new__ = None


class _Object(object):
    __dict__ = None


class QtMsgType(object):
    def __add__(*args, **kwargs):
        """
        x.__add__(y) <==> x+y
        """
    
        pass
    
    
    def __and__(*args, **kwargs):
        """
        x.__and__(y) <==> x&y
        """
    
        pass
    
    
    def __div__(*args, **kwargs):
        """
        x.__div__(y) <==> x/y
        """
    
        pass
    
    
    def __eq__(*args, **kwargs):
        """
        x.__eq__(y) <==> x==y
        """
    
        pass
    
    
    def __ge__(*args, **kwargs):
        """
        x.__ge__(y) <==> x>=y
        """
    
        pass
    
    
    def __gt__(*args, **kwargs):
        """
        x.__gt__(y) <==> x>y
        """
    
        pass
    
    
    def __hash__(*args, **kwargs):
        """
        x.__hash__() <==> hash(x)
        """
    
        pass
    
    
    def __index__(*args, **kwargs):
        """
        x[y:z] <==> x[y.__index__():z.__index__()]
        """
    
        pass
    
    
    def __int__(*args, **kwargs):
        """
        x.__int__() <==> int(x)
        """
    
        pass
    
    
    def __le__(*args, **kwargs):
        """
        x.__le__(y) <==> x<=y
        """
    
        pass
    
    
    def __long__(*args, **kwargs):
        """
        x.__long__() <==> long(x)
        """
    
        pass
    
    
    def __lt__(*args, **kwargs):
        """
        x.__lt__(y) <==> x<y
        """
    
        pass
    
    
    def __mul__(*args, **kwargs):
        """
        x.__mul__(y) <==> x*y
        """
    
        pass
    
    
    def __ne__(*args, **kwargs):
        """
        x.__ne__(y) <==> x!=y
        """
    
        pass
    
    
    def __nonzero__(*args, **kwargs):
        """
        x.__nonzero__() <==> x != 0
        """
    
        pass
    
    
    def __or__(*args, **kwargs):
        """
        x.__or__(y) <==> x|y
        """
    
        pass
    
    
    def __pos__(*args, **kwargs):
        """
        x.__pos__() <==> +x
        """
    
        pass
    
    
    def __radd__(*args, **kwargs):
        """
        x.__radd__(y) <==> y+x
        """
    
        pass
    
    
    def __rand__(*args, **kwargs):
        """
        x.__rand__(y) <==> y&x
        """
    
        pass
    
    
    def __rdiv__(*args, **kwargs):
        """
        x.__rdiv__(y) <==> y/x
        """
    
        pass
    
    
    def __repr__(*args, **kwargs):
        """
        x.__repr__() <==> repr(x)
        """
    
        pass
    
    
    def __rmul__(*args, **kwargs):
        """
        x.__rmul__(y) <==> y*x
        """
    
        pass
    
    
    def __ror__(*args, **kwargs):
        """
        x.__ror__(y) <==> y|x
        """
    
        pass
    
    
    def __rsub__(*args, **kwargs):
        """
        x.__rsub__(y) <==> y-x
        """
    
        pass
    
    
    def __rxor__(*args, **kwargs):
        """
        x.__rxor__(y) <==> y^x
        """
    
        pass
    
    
    def __str__(*args, **kwargs):
        """
        x.__str__() <==> str(x)
        """
    
        pass
    
    
    def __sub__(*args, **kwargs):
        """
        x.__sub__(y) <==> x-y
        """
    
        pass
    
    
    def __xor__(*args, **kwargs):
        """
        x.__xor__(y) <==> x^y
        """
    
        pass
    
    
    name = None
    
    QtCriticalMsg = None
    
    
    QtDebugMsg = None
    
    
    QtFatalMsg = None
    
    
    QtInfoMsg = None
    
    
    QtSystemMsg = None
    
    
    QtWarningMsg = None
    
    
    __new__ = None
    
    
    values = {}


class MetaFunction(object):
    """
    MetaFunction
    """
    
    
    
    def __call__(*args, **kwargs):
        """
        x.__call__(...) <==> x(...)
        """
    
        pass
    
    
    __new__ = None


class Signal(object):
    """
    Signal
    """
    
    
    
    def __call__(*args, **kwargs):
        """
        x.__call__(...) <==> x(...)
        """
    
        pass
    
    
    def __getitem__(*args, **kwargs):
        """
        x.__getitem__(y) <==> x[y]
        """
    
        pass
    
    
    def __init__(*args, **kwargs):
        """
        x.__init__(...) initializes x; see help(type(x)) for signature
        """
    
        pass
    
    
    def __str__(*args, **kwargs):
        """
        x.__str__() <==> str(x)
        """
    
        pass
    
    
    __new__ = None


class Slot(object):
    """
    Slot
    """
    
    
    
    def __call__(*args, **kwargs):
        """
        x.__call__(...) <==> x(...)
        """
    
        pass
    
    
    def __init__(*args, **kwargs):
        """
        x.__init__(...) initializes x; see help(type(x)) for signature
        """
    
        pass
    
    
    __new__ = None


class QMetaProperty(_Object):
    def __copy__(*args, **kwargs):
        pass
    
    
    def __init__(*args, **kwargs):
        """
        x.__init__(...) initializes x; see help(type(x)) for signature
        """
    
        pass
    
    
    def enumerator(*args, **kwargs):
        pass
    
    
    def hasNotifySignal(*args, **kwargs):
        pass
    
    
    def hasStdCppSet(*args, **kwargs):
        pass
    
    
    def isConstant(*args, **kwargs):
        pass
    
    
    def isDesignable(*args, **kwargs):
        pass
    
    
    def isEditable(*args, **kwargs):
        pass
    
    
    def isEnumType(*args, **kwargs):
        pass
    
    
    def isFinal(*args, **kwargs):
        pass
    
    
    def isFlagType(*args, **kwargs):
        pass
    
    
    def isReadable(*args, **kwargs):
        pass
    
    
    def isResettable(*args, **kwargs):
        pass
    
    
    def isScriptable(*args, **kwargs):
        pass
    
    
    def isStored(*args, **kwargs):
        pass
    
    
    def isUser(*args, **kwargs):
        pass
    
    
    def isValid(*args, **kwargs):
        pass
    
    
    def isWritable(*args, **kwargs):
        pass
    
    
    def name(*args, **kwargs):
        pass
    
    
    def notifySignal(*args, **kwargs):
        pass
    
    
    def notifySignalIndex(*args, **kwargs):
        pass
    
    
    def propertyIndex(*args, **kwargs):
        pass
    
    
    def read(*args, **kwargs):
        pass
    
    
    def readOnGadget(*args, **kwargs):
        pass
    
    
    def reset(*args, **kwargs):
        pass
    
    
    def resetOnGadget(*args, **kwargs):
        pass
    
    
    def revision(*args, **kwargs):
        pass
    
    
    def type(*args, **kwargs):
        pass
    
    
    def typeName(*args, **kwargs):
        pass
    
    
    def userType(*args, **kwargs):
        pass
    
    
    def write(*args, **kwargs):
        pass
    
    
    def writeOnGadget(*args, **kwargs):
        pass
    
    
    __new__ = None


class QJsonValue(_Object):
    def __copy__(*args, **kwargs):
        pass
    
    
    def __eq__(*args, **kwargs):
        """
        x.__eq__(y) <==> x==y
        """
    
        pass
    
    
    def __ge__(*args, **kwargs):
        """
        x.__ge__(y) <==> x>=y
        """
    
        pass
    
    
    def __gt__(*args, **kwargs):
        """
        x.__gt__(y) <==> x>y
        """
    
        pass
    
    
    def __init__(*args, **kwargs):
        """
        x.__init__(...) initializes x; see help(type(x)) for signature
        """
    
        pass
    
    
    def __le__(*args, **kwargs):
        """
        x.__le__(y) <==> x<=y
        """
    
        pass
    
    
    def __lt__(*args, **kwargs):
        """
        x.__lt__(y) <==> x<y
        """
    
        pass
    
    
    def __ne__(*args, **kwargs):
        """
        x.__ne__(y) <==> x!=y
        """
    
        pass
    
    
    def __nonzero__(*args, **kwargs):
        """
        x.__nonzero__() <==> x != 0
        """
    
        pass
    
    
    def __repr__(*args, **kwargs):
        """
        x.__repr__() <==> repr(x)
        """
    
        pass
    
    
    def isArray(*args, **kwargs):
        pass
    
    
    def isBool(*args, **kwargs):
        pass
    
    
    def isDouble(*args, **kwargs):
        pass
    
    
    def isNull(*args, **kwargs):
        pass
    
    
    def isObject(*args, **kwargs):
        pass
    
    
    def isString(*args, **kwargs):
        pass
    
    
    def isUndefined(*args, **kwargs):
        pass
    
    
    def toArray(*args, **kwargs):
        pass
    
    
    def toBool(*args, **kwargs):
        pass
    
    
    def toDouble(*args, **kwargs):
        pass
    
    
    def toInt(*args, **kwargs):
        pass
    
    
    def toObject(*args, **kwargs):
        pass
    
    
    def toString(*args, **kwargs):
        pass
    
    
    def toVariant(*args, **kwargs):
        pass
    
    
    def type(*args, **kwargs):
        pass
    
    
    def fromVariant(*args, **kwargs):
        pass
    
    
    Array = None
    
    
    Bool = None
    
    
    Double = None
    
    
    Null = None
    
    
    Object = None
    
    
    String = None
    
    
    Type = None
    
    
    Undefined = None
    
    
    __new__ = None


class Qt(_Object):
    def qt_getEnumMetaObject(*args, **kwargs):
        pass
    
    
    def qt_getEnumName(*args, **kwargs):
        pass
    
    
    AA_AttributeCount = None
    
    
    AA_DisableHighDpiScaling = None
    
    
    AA_DontCreateNativeWidgetSiblings = None
    
    
    AA_DontShowIconsInMenus = None
    
    
    AA_DontUseNativeMenuBar = None
    
    
    AA_EnableHighDpiScaling = None
    
    
    AA_ForceRasterWidgets = None
    
    
    AA_ImmediateWidgetCreation = None
    
    
    AA_MSWindowsUseDirect3DByDefault = None
    
    
    AA_MacDontSwapCtrlAndMeta = None
    
    
    AA_MacPluginApplication = None
    
    
    AA_NativeWindows = None
    
    
    AA_SetPalette = None
    
    
    AA_ShareOpenGLContexts = None
    
    
    AA_SynthesizeMouseForUnhandledTouchEvents = None
    
    
    AA_SynthesizeTouchForUnhandledMouseEvents = None
    
    
    AA_Use96Dpi = None
    
    
    AA_UseDesktopOpenGL = None
    
    
    AA_UseHighDpiPixmaps = None
    
    
    AA_UseOpenGLES = None
    
    
    AA_UseSoftwareOpenGL = None
    
    
    AA_X11InitThreads = None
    
    
    ALT = None
    
    
    AbsoluteSize = None
    
    
    AccessibleDescriptionRole = None
    
    
    AccessibleTextRole = None
    
    
    ActionMask = None
    
    
    ActionsContextMenu = None
    
    
    ActiveWindowFocusReason = None
    
    
    AddToSelection = None
    
    
    AlignAbsolute = None
    
    
    AlignBaseline = None
    
    
    AlignBottom = None
    
    
    AlignCenter = None
    
    
    AlignHCenter = None
    
    
    AlignHorizontal_Mask = None
    
    
    AlignJustify = None
    
    
    AlignLeading = None
    
    
    AlignLeft = None
    
    
    AlignRight = None
    
    
    AlignTop = None
    
    
    AlignTrailing = None
    
    
    AlignVCenter = None
    
    
    AlignVertical_Mask = None
    
    
    Alignment = None
    
    
    AlignmentFlag = None
    
    
    AllButtons = None
    
    
    AllDockWidgetAreas = None
    
    
    AllToolBarAreas = None
    
    
    AlphaDither_Mask = None
    
    
    AltModifier = None
    
    
    AnchorBottom = None
    
    
    AnchorHorizontalCenter = None
    
    
    AnchorLeft = None
    
    
    AnchorPoint = None
    
    
    AnchorRight = None
    
    
    AnchorTop = None
    
    
    AnchorVerticalCenter = None
    
    
    ApplicationActive = None
    
    
    ApplicationAttribute = None
    
    
    ApplicationHidden = None
    
    
    ApplicationInactive = None
    
    
    ApplicationModal = None
    
    
    ApplicationShortcut = None
    
    
    ApplicationState = None
    
    
    ApplicationStates = None
    
    
    ApplicationSuspended = None
    
    
    ArrowCursor = None
    
    
    ArrowType = None
    
    
    AscendingOrder = None
    
    
    AspectRatioMode = None
    
    
    AutoColor = None
    
    
    AutoConnection = None
    
    
    AutoDither = None
    
    
    AutoText = None
    
    
    AvoidDither = None
    
    
    Axis = None
    
    
    BDiagPattern = None
    
    
    BGMode = None
    
    
    BackButton = None
    
    
    BackgroundColorRole = None
    
    
    BackgroundRole = None
    
    
    BacktabFocusReason = None
    
    
    BeginNativeGesture = None
    
    
    BevelJoin = None
    
    
    BitmapCursor = None
    
    
    BlankCursor = None
    
    
    BlockingQueuedConnection = None
    
    
    BottomDockWidgetArea = None
    
    
    BottomEdge = None
    
    
    BottomLeftCorner = None
    
    
    BottomLeftSection = None
    
    
    BottomRightCorner = None
    
    
    BottomRightSection = None
    
    
    BottomSection = None
    
    
    BottomToolBarArea = None
    
    
    BrushStyle = None
    
    
    BusyCursor = None
    
    
    BypassGraphicsProxyWidget = None
    
    
    BypassWindowManagerHint = None
    
    
    CTRL = None
    
    
    CaseInsensitive = None
    
    
    CaseSensitive = None
    
    
    CaseSensitivity = None
    
    
    CheckState = None
    
    
    CheckStateRole = None
    
    
    Checked = None
    
    
    ClickFocus = None
    
    
    ClipOperation = None
    
    
    ClosedHandCursor = None
    
    
    CoarseTimer = None
    
    
    ColorMode_Mask = None
    
    
    ColorOnly = None
    
    
    ConicalGradientPattern = None
    
    
    ConnectionType = None
    
    
    ContainsItemBoundingRect = None
    
    
    ContainsItemShape = None
    
    
    ContextMenuPolicy = None
    
    
    ControlModifier = None
    
    
    CoordinateSystem = None
    
    
    CopyAction = None
    
    
    Corner = None
    
    
    CoverWindow = None
    
    
    CrossCursor = None
    
    
    CrossPattern = None
    
    
    CursorMoveStyle = None
    
    
    CursorShape = None
    
    
    CustomContextMenu = None
    
    
    CustomCursor = None
    
    
    CustomDashLine = None
    
    
    CustomGesture = None
    
    
    CustomizeWindowHint = None
    
    
    DashDotDotLine = None
    
    
    DashDotLine = None
    
    
    DashLine = None
    
    
    DateFormat = None
    
    
    DayOfWeek = None
    
    
    DecorationPropertyRole = None
    
    
    DecorationRole = None
    
    
    DefaultContextMenu = None
    
    
    DefaultLocaleLongDate = None
    
    
    DefaultLocaleShortDate = None
    
    
    Dense1Pattern = None
    
    
    Dense2Pattern = None
    
    
    Dense3Pattern = None
    
    
    Dense4Pattern = None
    
    
    Dense5Pattern = None
    
    
    Dense6Pattern = None
    
    
    Dense7Pattern = None
    
    
    DescendingOrder = None
    
    
    Desktop = None
    
    
    DeviceCoordinates = None
    
    
    DiagCrossPattern = None
    
    
    Dialog = None
    
    
    DiffuseAlphaDither = None
    
    
    DiffuseDither = None
    
    
    DirectConnection = None
    
    
    DisplayPropertyRole = None
    
    
    DisplayRole = None
    
    
    DitherMode_Mask = None
    
    
    Dither_Mask = None
    
    
    DockWidgetArea = None
    
    
    DockWidgetAreaSizes = None
    
    
    DockWidgetArea_Mask = None
    
    
    DockWidgetAreas = None
    
    
    DontStartGestureOnChildren = None
    
    
    DotLine = None
    
    
    DownArrow = None
    
    
    DragCopyCursor = None
    
    
    DragLinkCursor = None
    
    
    DragMoveCursor = None
    
    
    Drawer = None
    
    
    DropAction = None
    
    
    DropActions = None
    
    
    Edge = None
    
    
    Edges = None
    
    
    EditRole = None
    
    
    ElideLeft = None
    
    
    ElideMiddle = None
    
    
    ElideNone = None
    
    
    ElideRight = None
    
    
    EndNativeGesture = None
    
    
    EventPriority = None
    
    
    ExactHit = None
    
    
    ExtraButton1 = None
    
    
    ExtraButton10 = None
    
    
    ExtraButton11 = None
    
    
    ExtraButton12 = None
    
    
    ExtraButton13 = None
    
    
    ExtraButton14 = None
    
    
    ExtraButton15 = None
    
    
    ExtraButton16 = None
    
    
    ExtraButton17 = None
    
    
    ExtraButton18 = None
    
    
    ExtraButton19 = None
    
    
    ExtraButton2 = None
    
    
    ExtraButton20 = None
    
    
    ExtraButton21 = None
    
    
    ExtraButton22 = None
    
    
    ExtraButton23 = None
    
    
    ExtraButton24 = None
    
    
    ExtraButton3 = None
    
    
    ExtraButton4 = None
    
    
    ExtraButton5 = None
    
    
    ExtraButton6 = None
    
    
    ExtraButton7 = None
    
    
    ExtraButton8 = None
    
    
    ExtraButton9 = None
    
    
    FDiagPattern = None
    
    
    FastTransformation = None
    
    
    FillRule = None
    
    
    FindChildOption = None
    
    
    FindChildOptions = None
    
    
    FindChildrenRecursively = None
    
    
    FindDirectChildrenOnly = None
    
    
    FlatCap = None
    
    
    FocusPolicy = None
    
    
    FocusReason = None
    
    
    FontRole = None
    
    
    ForbiddenCursor = None
    
    
    ForegroundRole = None
    
    
    ForeignWindow = None
    
    
    ForwardButton = None
    
    
    FramelessWindowHint = None
    
    
    Friday = None
    
    
    FuzzyHit = None
    
    
    GestureCanceled = None
    
    
    GestureFinished = None
    
    
    GestureFlag = None
    
    
    GestureFlags = None
    
    
    GestureStarted = None
    
    
    GestureState = None
    
    
    GestureType = None
    
    
    GestureUpdated = None
    
    
    GlobalColor = None
    
    
    GroupSwitchModifier = None
    
    
    HighEventPriority = None
    
    
    HitTestAccuracy = None
    
    
    HorPattern = None
    
    
    Horizontal = None
    
    
    IBeamCursor = None
    
    
    ISODate = None
    
    
    IgnoreAction = None
    
    
    IgnoreAspectRatio = None
    
    
    IgnoredGesturesPropagateToParent = None
    
    
    ImAbsolutePosition = None
    
    
    ImAnchorPosition = None
    
    
    ImCurrentSelection = None
    
    
    ImCursorPosition = None
    
    
    ImCursorRectangle = None
    
    
    ImEnabled = None
    
    
    ImEnterKeyType = None
    
    
    ImFont = None
    
    
    ImHints = None
    
    
    ImMaximumTextLength = None
    
    
    ImMicroFocus = None
    
    
    ImPlatformData = None
    
    
    ImPreferredLanguage = None
    
    
    ImQueryAll = None
    
    
    ImQueryInput = None
    
    
    ImSurroundingText = None
    
    
    ImTextAfterCursor = None
    
    
    ImTextBeforeCursor = None
    
    
    ImageConversionFlag = None
    
    
    ImageConversionFlags = None
    
    
    ImhDate = None
    
    
    ImhDialableCharactersOnly = None
    
    
    ImhDigitsOnly = None
    
    
    ImhEmailCharactersOnly = None
    
    
    ImhExclusiveInputMask = None
    
    
    ImhFormattedNumbersOnly = None
    
    
    ImhHiddenText = None
    
    
    ImhLatinOnly = None
    
    
    ImhLowercaseOnly = None
    
    
    ImhMultiLine = None
    
    
    ImhNoAutoUppercase = None
    
    
    ImhNoPredictiveText = None
    
    
    ImhNone = None
    
    
    ImhPreferLatin = None
    
    
    ImhPreferLowercase = None
    
    
    ImhPreferNumbers = None
    
    
    ImhPreferUppercase = None
    
    
    ImhSensitiveData = None
    
    
    ImhTime = None
    
    
    ImhUppercaseOnly = None
    
    
    ImhUrlCharactersOnly = None
    
    
    InitialSortOrderRole = None
    
    
    InputMethodHint = None
    
    
    InputMethodHints = None
    
    
    InputMethodQuery = None
    
    
    IntersectClip = None
    
    
    IntersectsItemBoundingRect = None
    
    
    IntersectsItemShape = None
    
    
    InvertedLandscapeOrientation = None
    
    
    InvertedPortraitOrientation = None
    
    
    ItemDataRole = None
    
    
    ItemFlag = None
    
    
    ItemFlags = None
    
    
    ItemIsAutoTristate = None
    
    
    ItemIsDragEnabled = None
    
    
    ItemIsDropEnabled = None
    
    
    ItemIsEditable = None
    
    
    ItemIsEnabled = None
    
    
    ItemIsSelectable = None
    
    
    ItemIsTristate = None
    
    
    ItemIsUserCheckable = None
    
    
    ItemIsUserTristate = None
    
    
    ItemNeverHasChildren = None
    
    
    ItemSelectionMode = None
    
    
    ItemSelectionOperation = None
    
    
    KeepAspectRatio = None
    
    
    KeepAspectRatioByExpanding = None
    
    
    Key = None
    
    
    Key_0 = None
    
    
    Key_1 = None
    
    
    Key_2 = None
    
    
    Key_3 = None
    
    
    Key_4 = None
    
    
    Key_5 = None
    
    
    Key_6 = None
    
    
    Key_7 = None
    
    
    Key_8 = None
    
    
    Key_9 = None
    
    
    Key_A = None
    
    
    Key_AE = None
    
    
    Key_Aacute = None
    
    
    Key_Acircumflex = None
    
    
    Key_AddFavorite = None
    
    
    Key_Adiaeresis = None
    
    
    Key_Agrave = None
    
    
    Key_Alt = None
    
    
    Key_AltGr = None
    
    
    Key_Ampersand = None
    
    
    Key_Any = None
    
    
    Key_Apostrophe = None
    
    
    Key_ApplicationLeft = None
    
    
    Key_ApplicationRight = None
    
    
    Key_Aring = None
    
    
    Key_AsciiCircum = None
    
    
    Key_AsciiTilde = None
    
    
    Key_Asterisk = None
    
    
    Key_At = None
    
    
    Key_Atilde = None
    
    
    Key_AudioCycleTrack = None
    
    
    Key_AudioForward = None
    
    
    Key_AudioRandomPlay = None
    
    
    Key_AudioRepeat = None
    
    
    Key_AudioRewind = None
    
    
    Key_Away = None
    
    
    Key_B = None
    
    
    Key_Back = None
    
    
    Key_BackForward = None
    
    
    Key_Backslash = None
    
    
    Key_Backspace = None
    
    
    Key_Backtab = None
    
    
    Key_Bar = None
    
    
    Key_BassBoost = None
    
    
    Key_BassDown = None
    
    
    Key_BassUp = None
    
    
    Key_Battery = None
    
    
    Key_Blue = None
    
    
    Key_Bluetooth = None
    
    
    Key_Book = None
    
    
    Key_BraceLeft = None
    
    
    Key_BraceRight = None
    
    
    Key_BracketLeft = None
    
    
    Key_BracketRight = None
    
    
    Key_BrightnessAdjust = None
    
    
    Key_C = None
    
    
    Key_CD = None
    
    
    Key_Calculator = None
    
    
    Key_Calendar = None
    
    
    Key_Call = None
    
    
    Key_Camera = None
    
    
    Key_CameraFocus = None
    
    
    Key_Cancel = None
    
    
    Key_CapsLock = None
    
    
    Key_Ccedilla = None
    
    
    Key_ChannelDown = None
    
    
    Key_ChannelUp = None
    
    
    Key_Clear = None
    
    
    Key_ClearGrab = None
    
    
    Key_Close = None
    
    
    Key_Codeinput = None
    
    
    Key_Colon = None
    
    
    Key_Comma = None
    
    
    Key_Community = None
    
    
    Key_Context1 = None
    
    
    Key_Context2 = None
    
    
    Key_Context3 = None
    
    
    Key_Context4 = None
    
    
    Key_ContrastAdjust = None
    
    
    Key_Control = None
    
    
    Key_Copy = None
    
    
    Key_Cut = None
    
    
    Key_D = None
    
    
    Key_DOS = None
    
    
    Key_Dead_Abovedot = None
    
    
    Key_Dead_Abovering = None
    
    
    Key_Dead_Acute = None
    
    
    Key_Dead_Belowdot = None
    
    
    Key_Dead_Breve = None
    
    
    Key_Dead_Caron = None
    
    
    Key_Dead_Cedilla = None
    
    
    Key_Dead_Circumflex = None
    
    
    Key_Dead_Diaeresis = None
    
    
    Key_Dead_Doubleacute = None
    
    
    Key_Dead_Grave = None
    
    
    Key_Dead_Hook = None
    
    
    Key_Dead_Horn = None
    
    
    Key_Dead_Iota = None
    
    
    Key_Dead_Macron = None
    
    
    Key_Dead_Ogonek = None
    
    
    Key_Dead_Semivoiced_Sound = None
    
    
    Key_Dead_Tilde = None
    
    
    Key_Dead_Voiced_Sound = None
    
    
    Key_Delete = None
    
    
    Key_Direction_L = None
    
    
    Key_Direction_R = None
    
    
    Key_Display = None
    
    
    Key_Documents = None
    
    
    Key_Dollar = None
    
    
    Key_Down = None
    
    
    Key_E = None
    
    
    Key_ETH = None
    
    
    Key_Eacute = None
    
    
    Key_Ecircumflex = None
    
    
    Key_Ediaeresis = None
    
    
    Key_Egrave = None
    
    
    Key_Eisu_Shift = None
    
    
    Key_Eisu_toggle = None
    
    
    Key_Eject = None
    
    
    Key_End = None
    
    
    Key_Enter = None
    
    
    Key_Equal = None
    
    
    Key_Escape = None
    
    
    Key_Excel = None
    
    
    Key_Exclam = None
    
    
    Key_Execute = None
    
    
    Key_Exit = None
    
    
    Key_Explorer = None
    
    
    Key_F = None
    
    
    Key_F1 = None
    
    
    Key_F10 = None
    
    
    Key_F11 = None
    
    
    Key_F12 = None
    
    
    Key_F13 = None
    
    
    Key_F14 = None
    
    
    Key_F15 = None
    
    
    Key_F16 = None
    
    
    Key_F17 = None
    
    
    Key_F18 = None
    
    
    Key_F19 = None
    
    
    Key_F2 = None
    
    
    Key_F20 = None
    
    
    Key_F21 = None
    
    
    Key_F22 = None
    
    
    Key_F23 = None
    
    
    Key_F24 = None
    
    
    Key_F25 = None
    
    
    Key_F26 = None
    
    
    Key_F27 = None
    
    
    Key_F28 = None
    
    
    Key_F29 = None
    
    
    Key_F3 = None
    
    
    Key_F30 = None
    
    
    Key_F31 = None
    
    
    Key_F32 = None
    
    
    Key_F33 = None
    
    
    Key_F34 = None
    
    
    Key_F35 = None
    
    
    Key_F4 = None
    
    
    Key_F5 = None
    
    
    Key_F6 = None
    
    
    Key_F7 = None
    
    
    Key_F8 = None
    
    
    Key_F9 = None
    
    
    Key_Favorites = None
    
    
    Key_Finance = None
    
    
    Key_Find = None
    
    
    Key_Flip = None
    
    
    Key_Forward = None
    
    
    Key_G = None
    
    
    Key_Game = None
    
    
    Key_Go = None
    
    
    Key_Greater = None
    
    
    Key_Green = None
    
    
    Key_Guide = None
    
    
    Key_H = None
    
    
    Key_Hangul = None
    
    
    Key_Hangul_Banja = None
    
    
    Key_Hangul_End = None
    
    
    Key_Hangul_Hanja = None
    
    
    Key_Hangul_Jamo = None
    
    
    Key_Hangul_Jeonja = None
    
    
    Key_Hangul_PostHanja = None
    
    
    Key_Hangul_PreHanja = None
    
    
    Key_Hangul_Romaja = None
    
    
    Key_Hangul_Special = None
    
    
    Key_Hangul_Start = None
    
    
    Key_Hangup = None
    
    
    Key_Hankaku = None
    
    
    Key_Help = None
    
    
    Key_Henkan = None
    
    
    Key_Hibernate = None
    
    
    Key_Hiragana = None
    
    
    Key_Hiragana_Katakana = None
    
    
    Key_History = None
    
    
    Key_Home = None
    
    
    Key_HomePage = None
    
    
    Key_HotLinks = None
    
    
    Key_Hyper_L = None
    
    
    Key_Hyper_R = None
    
    
    Key_I = None
    
    
    Key_Iacute = None
    
    
    Key_Icircumflex = None
    
    
    Key_Idiaeresis = None
    
    
    Key_Igrave = None
    
    
    Key_Info = None
    
    
    Key_Insert = None
    
    
    Key_J = None
    
    
    Key_K = None
    
    
    Key_Kana_Lock = None
    
    
    Key_Kana_Shift = None
    
    
    Key_Kanji = None
    
    
    Key_Katakana = None
    
    
    Key_KeyboardBrightnessDown = None
    
    
    Key_KeyboardBrightnessUp = None
    
    
    Key_KeyboardLightOnOff = None
    
    
    Key_L = None
    
    
    Key_LastNumberRedial = None
    
    
    Key_Launch0 = None
    
    
    Key_Launch1 = None
    
    
    Key_Launch2 = None
    
    
    Key_Launch3 = None
    
    
    Key_Launch4 = None
    
    
    Key_Launch5 = None
    
    
    Key_Launch6 = None
    
    
    Key_Launch7 = None
    
    
    Key_Launch8 = None
    
    
    Key_Launch9 = None
    
    
    Key_LaunchA = None
    
    
    Key_LaunchB = None
    
    
    Key_LaunchC = None
    
    
    Key_LaunchD = None
    
    
    Key_LaunchE = None
    
    
    Key_LaunchF = None
    
    
    Key_LaunchG = None
    
    
    Key_LaunchH = None
    
    
    Key_LaunchMail = None
    
    
    Key_LaunchMedia = None
    
    
    Key_Left = None
    
    
    Key_Less = None
    
    
    Key_LightBulb = None
    
    
    Key_LogOff = None
    
    
    Key_M = None
    
    
    Key_MailForward = None
    
    
    Key_Market = None
    
    
    Key_Massyo = None
    
    
    Key_MediaLast = None
    
    
    Key_MediaNext = None
    
    
    Key_MediaPause = None
    
    
    Key_MediaPlay = None
    
    
    Key_MediaPrevious = None
    
    
    Key_MediaRecord = None
    
    
    Key_MediaStop = None
    
    
    Key_MediaTogglePlayPause = None
    
    
    Key_Meeting = None
    
    
    Key_Memo = None
    
    
    Key_Menu = None
    
    
    Key_MenuKB = None
    
    
    Key_MenuPB = None
    
    
    Key_Messenger = None
    
    
    Key_Meta = None
    
    
    Key_MicMute = None
    
    
    Key_MicVolumeDown = None
    
    
    Key_MicVolumeUp = None
    
    
    Key_Minus = None
    
    
    Key_Mode_switch = None
    
    
    Key_MonBrightnessDown = None
    
    
    Key_MonBrightnessUp = None
    
    
    Key_Muhenkan = None
    
    
    Key_Multi_key = None
    
    
    Key_MultipleCandidate = None
    
    
    Key_Music = None
    
    
    Key_MySites = None
    
    
    Key_N = None
    
    
    Key_New = None
    
    
    Key_News = None
    
    
    Key_No = None
    
    
    Key_Ntilde = None
    
    
    Key_NumLock = None
    
    
    Key_NumberSign = None
    
    
    Key_O = None
    
    
    Key_Oacute = None
    
    
    Key_Ocircumflex = None
    
    
    Key_Odiaeresis = None
    
    
    Key_OfficeHome = None
    
    
    Key_Ograve = None
    
    
    Key_Ooblique = None
    
    
    Key_Open = None
    
    
    Key_OpenUrl = None
    
    
    Key_Option = None
    
    
    Key_Otilde = None
    
    
    Key_P = None
    
    
    Key_PageDown = None
    
    
    Key_PageUp = None
    
    
    Key_ParenLeft = None
    
    
    Key_ParenRight = None
    
    
    Key_Paste = None
    
    
    Key_Pause = None
    
    
    Key_Percent = None
    
    
    Key_Period = None
    
    
    Key_Phone = None
    
    
    Key_Pictures = None
    
    
    Key_Play = None
    
    
    Key_Plus = None
    
    
    Key_PowerDown = None
    
    
    Key_PowerOff = None
    
    
    Key_PreviousCandidate = None
    
    
    Key_Print = None
    
    
    Key_Printer = None
    
    
    Key_Q = None
    
    
    Key_Question = None
    
    
    Key_QuoteDbl = None
    
    
    Key_QuoteLeft = None
    
    
    Key_R = None
    
    
    Key_Red = None
    
    
    Key_Redo = None
    
    
    Key_Refresh = None
    
    
    Key_Reload = None
    
    
    Key_Reply = None
    
    
    Key_Return = None
    
    
    Key_Right = None
    
    
    Key_Romaji = None
    
    
    Key_RotateWindows = None
    
    
    Key_RotationKB = None
    
    
    Key_RotationPB = None
    
    
    Key_S = None
    
    
    Key_Save = None
    
    
    Key_ScreenSaver = None
    
    
    Key_ScrollLock = None
    
    
    Key_Search = None
    
    
    Key_Select = None
    
    
    Key_Semicolon = None
    
    
    Key_Send = None
    
    
    Key_Settings = None
    
    
    Key_Shift = None
    
    
    Key_Shop = None
    
    
    Key_SingleCandidate = None
    
    
    Key_Slash = None
    
    
    Key_Sleep = None
    
    
    Key_Space = None
    
    
    Key_Spell = None
    
    
    Key_SplitScreen = None
    
    
    Key_Standby = None
    
    
    Key_Stop = None
    
    
    Key_Subtitle = None
    
    
    Key_Super_L = None
    
    
    Key_Super_R = None
    
    
    Key_Support = None
    
    
    Key_Suspend = None
    
    
    Key_SysReq = None
    
    
    Key_T = None
    
    
    Key_THORN = None
    
    
    Key_Tab = None
    
    
    Key_TaskPane = None
    
    
    Key_Terminal = None
    
    
    Key_Time = None
    
    
    Key_ToDoList = None
    
    
    Key_ToggleCallHangup = None
    
    
    Key_Tools = None
    
    
    Key_TopMenu = None
    
    
    Key_TouchpadOff = None
    
    
    Key_TouchpadOn = None
    
    
    Key_TouchpadToggle = None
    
    
    Key_Touroku = None
    
    
    Key_Travel = None
    
    
    Key_TrebleDown = None
    
    
    Key_TrebleUp = None
    
    
    Key_U = None
    
    
    Key_UWB = None
    
    
    Key_Uacute = None
    
    
    Key_Ucircumflex = None
    
    
    Key_Udiaeresis = None
    
    
    Key_Ugrave = None
    
    
    Key_Underscore = None
    
    
    Key_Undo = None
    
    
    Key_Up = None
    
    
    Key_V = None
    
    
    Key_Video = None
    
    
    Key_View = None
    
    
    Key_VoiceDial = None
    
    
    Key_VolumeDown = None
    
    
    Key_VolumeMute = None
    
    
    Key_VolumeUp = None
    
    
    Key_W = None
    
    
    Key_WLAN = None
    
    
    Key_WWW = None
    
    
    Key_WakeUp = None
    
    
    Key_WebCam = None
    
    
    Key_Word = None
    
    
    Key_X = None
    
    
    Key_Xfer = None
    
    
    Key_Y = None
    
    
    Key_Yacute = None
    
    
    Key_Yellow = None
    
    
    Key_Yes = None
    
    
    Key_Z = None
    
    
    Key_Zenkaku = None
    
    
    Key_Zenkaku_Hankaku = None
    
    
    Key_Zoom = None
    
    
    Key_ZoomIn = None
    
    
    Key_ZoomOut = None
    
    
    Key_acute = None
    
    
    Key_brokenbar = None
    
    
    Key_cedilla = None
    
    
    Key_cent = None
    
    
    Key_copyright = None
    
    
    Key_currency = None
    
    
    Key_degree = None
    
    
    Key_diaeresis = None
    
    
    Key_division = None
    
    
    Key_exclamdown = None
    
    
    Key_guillemotleft = None
    
    
    Key_guillemotright = None
    
    
    Key_hyphen = None
    
    
    Key_iTouch = None
    
    
    Key_macron = None
    
    
    Key_masculine = None
    
    
    Key_mu = None
    
    
    Key_multiply = None
    
    
    Key_nobreakspace = None
    
    
    Key_notsign = None
    
    
    Key_onehalf = None
    
    
    Key_onequarter = None
    
    
    Key_onesuperior = None
    
    
    Key_ordfeminine = None
    
    
    Key_paragraph = None
    
    
    Key_periodcentered = None
    
    
    Key_plusminus = None
    
    
    Key_questiondown = None
    
    
    Key_registered = None
    
    
    Key_section = None
    
    
    Key_ssharp = None
    
    
    Key_sterling = None
    
    
    Key_threequarters = None
    
    
    Key_threesuperior = None
    
    
    Key_twosuperior = None
    
    
    Key_unknown = None
    
    
    Key_ydiaeresis = None
    
    
    Key_yen = None
    
    
    KeyboardModifier = None
    
    
    KeyboardModifierMask = None
    
    
    KeyboardModifiers = None
    
    
    KeypadModifier = None
    
    
    LandscapeOrientation = None
    
    
    LastCursor = None
    
    
    LastGestureType = None
    
    
    LayoutDirection = None
    
    
    LayoutDirectionAuto = None
    
    
    LeftArrow = None
    
    
    LeftButton = None
    
    
    LeftDockWidgetArea = None
    
    
    LeftEdge = None
    
    
    LeftSection = None
    
    
    LeftToRight = None
    
    
    LeftToolBarArea = None
    
    
    LinearGradientPattern = None
    
    
    LinkAction = None
    
    
    LinksAccessibleByKeyboard = None
    
    
    LinksAccessibleByMouse = None
    
    
    LocalDate = None
    
    
    LocalTime = None
    
    
    LocaleDate = None
    
    
    LogicalCoordinates = None
    
    
    LogicalMoveStyle = None
    
    
    LowEventPriority = None
    
    
    META = None
    
    
    MODIFIER_MASK = None
    
    
    MPenCapStyle = None
    
    
    MPenJoinStyle = None
    
    
    MPenStyle = None
    
    
    MSWindowsFixedSizeDialogHint = None
    
    
    MSWindowsOwnDC = None
    
    
    MacWindowToolBarButtonHint = None
    
    
    MaskInColor = None
    
    
    MaskMode = None
    
    
    MaskOutColor = None
    
    
    MatchCaseSensitive = None
    
    
    MatchContains = None
    
    
    MatchEndsWith = None
    
    
    MatchExactly = None
    
    
    MatchFixedString = None
    
    
    MatchFlag = None
    
    
    MatchFlags = None
    
    
    MatchRecursive = None
    
    
    MatchRegExp = None
    
    
    MatchStartsWith = None
    
    
    MatchWildcard = None
    
    
    MatchWrap = None
    
    
    MaxMouseButton = None
    
    
    MaximizeUsingFullscreenGeometryHint = None
    
    
    MaximumSize = None
    
    
    MenuBarFocusReason = None
    
    
    MetaModifier = None
    
    
    MidButton = None
    
    
    MiddleButton = None
    
    
    MinimumDescent = None
    
    
    MinimumSize = None
    
    
    MiterJoin = None
    
    
    Modifier = None
    
    
    Monday = None
    
    
    MonoOnly = None
    
    
    MouseButton = None
    
    
    MouseButtonMask = None
    
    
    MouseButtons = None
    
    
    MouseEventCreatedDoubleClick = None
    
    
    MouseEventFlag = None
    
    
    MouseEventFlagMask = None
    
    
    MouseEventFlags = None
    
    
    MouseEventNotSynthesized = None
    
    
    MouseEventSource = None
    
    
    MouseEventSynthesizedByApplication = None
    
    
    MouseEventSynthesizedByQt = None
    
    
    MouseEventSynthesizedBySystem = None
    
    
    MouseFocusReason = None
    
    
    MoveAction = None
    
    
    NDockWidgetAreas = None
    
    
    NSizeHints = None
    
    
    NToolBarAreas = None
    
    
    NativeGestureType = None
    
    
    NavigationMode = None
    
    
    NavigationModeCursorAuto = None
    
    
    NavigationModeCursorForceVisible = None
    
    
    NavigationModeKeypadDirectional = None
    
    
    NavigationModeKeypadTabOrder = None
    
    
    NavigationModeNone = None
    
    
    NoAlpha = None
    
    
    NoArrow = None
    
    
    NoBrush = None
    
    
    NoButton = None
    
    
    NoClip = None
    
    
    NoContextMenu = None
    
    
    NoDockWidgetArea = None
    
    
    NoDropShadowWindowHint = None
    
    
    NoFocus = None
    
    
    NoFocusReason = None
    
    
    NoFormatConversion = None
    
    
    NoGesture = None
    
    
    NoItemFlags = None
    
    
    NoModifier = None
    
    
    NoOpaqueDetection = None
    
    
    NoPen = None
    
    
    NoSection = None
    
    
    NoTabFocus = None
    
    
    NoTextInteraction = None
    
    
    NoToolBarArea = None
    
    
    NonModal = None
    
    
    NormalEventPriority = None
    
    
    OddEvenFill = None
    
    
    OffsetFromUTC = None
    
    
    OpaqueMode = None
    
    
    OpenHandCursor = None
    
    
    OrderedAlphaDither = None
    
    
    OrderedDither = None
    
    
    Orientation = None
    
    
    Orientations = None
    
    
    OtherFocusReason = None
    
    
    PanGesture = None
    
    
    PanNativeGesture = None
    
    
    PartiallyChecked = None
    
    
    PenCapStyle = None
    
    
    PenJoinStyle = None
    
    
    PenStyle = None
    
    
    PinchGesture = None
    
    
    PlainText = None
    
    
    PointingHandCursor = None
    
    
    Popup = None
    
    
    PopupFocusReason = None
    
    
    PortraitOrientation = None
    
    
    PreciseTimer = None
    
    
    PreferDither = None
    
    
    PreferredSize = None
    
    
    PreventContextMenu = None
    
    
    PrimaryOrientation = None
    
    
    QueuedConnection = None
    
    
    RFC2822Date = None
    
    
    RadialGradientPattern = None
    
    
    ReceivePartialGestures = None
    
    
    RelativeSize = None
    
    
    RepeatTile = None
    
    
    ReplaceClip = None
    
    
    ReplaceSelection = None
    
    
    RichText = None
    
    
    RightArrow = None
    
    
    RightButton = None
    
    
    RightDockWidgetArea = None
    
    
    RightEdge = None
    
    
    RightSection = None
    
    
    RightToLeft = None
    
    
    RightToolBarArea = None
    
    
    RotateNativeGesture = None
    
    
    RoundCap = None
    
    
    RoundJoin = None
    
    
    RoundTile = None
    
    
    SHIFT = None
    
    
    Saturday = None
    
    
    ScreenOrientation = None
    
    
    ScreenOrientations = None
    
    
    ScrollBarAlwaysOff = None
    
    
    ScrollBarAlwaysOn = None
    
    
    ScrollBarAsNeeded = None
    
    
    ScrollBarPolicy = None
    
    
    ScrollBegin = None
    
    
    ScrollEnd = None
    
    
    ScrollPhase = None
    
    
    ScrollUpdate = None
    
    
    Sheet = None
    
    
    ShiftModifier = None
    
    
    ShortcutContext = None
    
    
    ShortcutFocusReason = None
    
    
    SizeAllCursor = None
    
    
    SizeBDiagCursor = None
    
    
    SizeFDiagCursor = None
    
    
    SizeHint = None
    
    
    SizeHintRole = None
    
    
    SizeHorCursor = None
    
    
    SizeMode = None
    
    
    SizeVerCursor = None
    
    
    SmartZoomNativeGesture = None
    
    
    SmoothTransformation = None
    
    
    SolidLine = None
    
    
    SolidPattern = None
    
    
    SortOrder = None
    
    
    SplashScreen = None
    
    
    SplitHCursor = None
    
    
    SplitVCursor = None
    
    
    SquareCap = None
    
    
    StatusTipPropertyRole = None
    
    
    StatusTipRole = None
    
    
    StretchTile = None
    
    
    StrongFocus = None
    
    
    SubWindow = None
    
    
    Sunday = None
    
    
    SvgMiterJoin = None
    
    
    SwipeGesture = None
    
    
    SwipeNativeGesture = None
    
    
    SystemLocaleDate = None
    
    
    SystemLocaleLongDate = None
    
    
    SystemLocaleShortDate = None
    
    
    TabFocus = None
    
    
    TabFocusAllControls = None
    
    
    TabFocusBehavior = None
    
    
    TabFocusListControls = None
    
    
    TabFocusReason = None
    
    
    TabFocusTextControls = None
    
    
    TapAndHoldGesture = None
    
    
    TapGesture = None
    
    
    TargetMoveAction = None
    
    
    TaskButton = None
    
    
    TextAlignmentRole = None
    
    
    TextBrowserInteraction = None
    
    
    TextBypassShaping = None
    
    
    TextColorRole = None
    
    
    TextDate = None
    
    
    TextDontClip = None
    
    
    TextDontPrint = None
    
    
    TextEditable = None
    
    
    TextEditorInteraction = None
    
    
    TextElideMode = None
    
    
    TextExpandTabs = None
    
    
    TextFlag = None
    
    
    TextForceLeftToRight = None
    
    
    TextForceRightToLeft = None
    
    
    TextFormat = None
    
    
    TextHideMnemonic = None
    
    
    TextIncludeTrailingSpaces = None
    
    
    TextInteractionFlag = None
    
    
    TextInteractionFlags = None
    
    
    TextJustificationForced = None
    
    
    TextLongestVariant = None
    
    
    TextSelectableByKeyboard = None
    
    
    TextSelectableByMouse = None
    
    
    TextShowMnemonic = None
    
    
    TextSingleLine = None
    
    
    TextWordWrap = None
    
    
    TextWrapAnywhere = None
    
    
    TexturePattern = None
    
    
    ThresholdAlphaDither = None
    
    
    ThresholdDither = None
    
    
    Thursday = None
    
    
    TileRule = None
    
    
    TimeSpec = None
    
    
    TimeZone = None
    
    
    TimerType = None
    
    
    TitleBarArea = None
    
    
    Tool = None
    
    
    ToolBarArea = None
    
    
    ToolBarAreaSizes = None
    
    
    ToolBarArea_Mask = None
    
    
    ToolBarAreas = None
    
    
    ToolButtonFollowStyle = None
    
    
    ToolButtonIconOnly = None
    
    
    ToolButtonStyle = None
    
    
    ToolButtonTextBesideIcon = None
    
    
    ToolButtonTextOnly = None
    
    
    ToolButtonTextUnderIcon = None
    
    
    ToolTip = None
    
    
    ToolTipPropertyRole = None
    
    
    ToolTipRole = None
    
    
    TopDockWidgetArea = None
    
    
    TopEdge = None
    
    
    TopLeftCorner = None
    
    
    TopLeftSection = None
    
    
    TopRightCorner = None
    
    
    TopRightSection = None
    
    
    TopSection = None
    
    
    TopToolBarArea = None
    
    
    TouchPointMoved = None
    
    
    TouchPointPressed = None
    
    
    TouchPointReleased = None
    
    
    TouchPointState = None
    
    
    TouchPointStationary = None
    
    
    TransformationMode = None
    
    
    TransparentMode = None
    
    
    Tuesday = None
    
    
    UIEffect = None
    
    
    UI_AnimateCombo = None
    
    
    UI_AnimateMenu = None
    
    
    UI_AnimateToolBox = None
    
    
    UI_AnimateTooltip = None
    
    
    UI_FadeMenu = None
    
    
    UI_FadeTooltip = None
    
    
    UI_General = None
    
    
    UNICODE_ACCEL = None
    
    
    UTC = None
    
    
    Unchecked = None
    
    
    UniqueConnection = None
    
    
    UpArrow = None
    
    
    UpArrowCursor = None
    
    
    UserRole = None
    
    
    VerPattern = None
    
    
    Vertical = None
    
    
    VeryCoarseTimer = None
    
    
    VisualMoveStyle = None
    
    
    WA_AcceptDrops = None
    
    
    WA_AcceptTouchEvents = None
    
    
    WA_AlwaysShowToolTips = None
    
    
    WA_AlwaysStackOnTop = None
    
    
    WA_AttributeCount = None
    
    
    WA_CanHostQMdiSubWindowTitleBar = None
    
    
    WA_ContentsPropagated = None
    
    
    WA_CustomWhatsThis = None
    
    
    WA_DeleteOnClose = None
    
    
    WA_Disabled = None
    
    
    WA_DontCreateNativeAncestors = None
    
    
    WA_DontShowOnScreen = None
    
    
    WA_DropSiteRegistered = None
    
    
    WA_ForceAcceptDrops = None
    
    
    WA_ForceDisabled = None
    
    
    WA_ForceUpdatesDisabled = None
    
    
    WA_GrabbedShortcut = None
    
    
    WA_GroupLeader = None
    
    
    WA_Hover = None
    
    
    WA_InputMethodEnabled = None
    
    
    WA_InputMethodTransparent = None
    
    
    WA_InvalidSize = None
    
    
    WA_KeyCompression = None
    
    
    WA_KeyboardFocusChange = None
    
    
    WA_LaidOut = None
    
    
    WA_LayoutOnEntireRect = None
    
    
    WA_LayoutUsesWidgetRect = None
    
    
    WA_MSWindowsUseDirect3D = None
    
    
    WA_MacAlwaysShowToolWindow = None
    
    
    WA_MacBrushedMetal = None
    
    
    WA_MacFrameworkScaled = None
    
    
    WA_MacMetalStyle = None
    
    
    WA_MacMiniSize = None
    
    
    WA_MacNoClickThrough = None
    
    
    WA_MacNoShadow = None
    
    
    WA_MacNormalSize = None
    
    
    WA_MacOpaqueSizeGrip = None
    
    
    WA_MacShowFocusRect = None
    
    
    WA_MacSmallSize = None
    
    
    WA_MacVariableSize = None
    
    
    WA_Mapped = None
    
    
    WA_MouseNoMask = None
    
    
    WA_MouseTracking = None
    
    
    WA_Moved = None
    
    
    WA_NativeWindow = None
    
    
    WA_NoBackground = None
    
    
    WA_NoChildEventsForParent = None
    
    
    WA_NoChildEventsFromChildren = None
    
    
    WA_NoMousePropagation = None
    
    
    WA_NoMouseReplay = None
    
    
    WA_NoSystemBackground = None
    
    
    WA_NoX11EventCompression = None
    
    
    WA_OpaquePaintEvent = None
    
    
    WA_OutsideWSRange = None
    
    
    WA_PaintOnScreen = None
    
    
    WA_PaintUnclipped = None
    
    
    WA_PendingMoveEvent = None
    
    
    WA_PendingResizeEvent = None
    
    
    WA_PendingUpdate = None
    
    
    WA_QuitOnClose = None
    
    
    WA_Resized = None
    
    
    WA_RightToLeft = None
    
    
    WA_SetCursor = None
    
    
    WA_SetFont = None
    
    
    WA_SetLayoutDirection = None
    
    
    WA_SetLocale = None
    
    
    WA_SetPalette = None
    
    
    WA_SetStyle = None
    
    
    WA_SetWindowIcon = None
    
    
    WA_SetWindowModality = None
    
    
    WA_ShowModal = None
    
    
    WA_ShowWithoutActivating = None
    
    
    WA_StaticContents = None
    
    
    WA_StyleSheet = None
    
    
    WA_StyledBackground = None
    
    
    WA_TintedBackground = None
    
    
    WA_TouchPadAcceptSingleTouchEvents = None
    
    
    WA_TranslucentBackground = None
    
    
    WA_TransparentForMouseEvents = None
    
    
    WA_UnderMouse = None
    
    
    WA_UpdatesDisabled = None
    
    
    WA_WState_AcceptedTouchBeginEvent = None
    
    
    WA_WState_CompressKeys = None
    
    
    WA_WState_ConfigPending = None
    
    
    WA_WState_Created = None
    
    
    WA_WState_DND = None
    
    
    WA_WState_ExplicitShowHide = None
    
    
    WA_WState_Hidden = None
    
    
    WA_WState_InPaintEvent = None
    
    
    WA_WState_OwnSizePolicy = None
    
    
    WA_WState_Polished = None
    
    
    WA_WState_Reparented = None
    
    
    WA_WState_Visible = None
    
    
    WA_WState_WindowOpacitySet = None
    
    
    WA_WindowModified = None
    
    
    WA_WindowPropagation = None
    
    
    WA_X11BypassTransientForHint = None
    
    
    WA_X11DoNotAcceptFocus = None
    
    
    WA_X11NetWmWindowTypeCombo = None
    
    
    WA_X11NetWmWindowTypeDND = None
    
    
    WA_X11NetWmWindowTypeDesktop = None
    
    
    WA_X11NetWmWindowTypeDialog = None
    
    
    WA_X11NetWmWindowTypeDock = None
    
    
    WA_X11NetWmWindowTypeDropDownMenu = None
    
    
    WA_X11NetWmWindowTypeMenu = None
    
    
    WA_X11NetWmWindowTypeNotification = None
    
    
    WA_X11NetWmWindowTypePopupMenu = None
    
    
    WA_X11NetWmWindowTypeSplash = None
    
    
    WA_X11NetWmWindowTypeToolBar = None
    
    
    WA_X11NetWmWindowTypeToolTip = None
    
    
    WA_X11NetWmWindowTypeUtility = None
    
    
    WA_X11OpenGLOverlay = None
    
    
    WaitCursor = None
    
    
    Wednesday = None
    
    
    WhatsThisCursor = None
    
    
    WhatsThisPropertyRole = None
    
    
    WhatsThisRole = None
    
    
    WheelFocus = None
    
    
    WhiteSpaceMode = None
    
    
    WhiteSpaceModeUndefined = None
    
    
    WhiteSpaceNoWrap = None
    
    
    WhiteSpaceNormal = None
    
    
    WhiteSpacePre = None
    
    
    Widget = None
    
    
    WidgetAttribute = None
    
    
    WidgetShortcut = None
    
    
    WidgetWithChildrenShortcut = None
    
    
    WindingFill = None
    
    
    Window = None
    
    
    WindowActive = None
    
    
    WindowCancelButtonHint = None
    
    
    WindowCloseButtonHint = None
    
    
    WindowContextHelpButtonHint = None
    
    
    WindowDoesNotAcceptFocus = None
    
    
    WindowFlags = None
    
    
    WindowFrameSection = None
    
    
    WindowFullScreen = None
    
    
    WindowFullscreenButtonHint = None
    
    
    WindowMaximizeButtonHint = None
    
    
    WindowMaximized = None
    
    
    WindowMinMaxButtonsHint = None
    
    
    WindowMinimizeButtonHint = None
    
    
    WindowMinimized = None
    
    
    WindowModal = None
    
    
    WindowModality = None
    
    
    WindowNoState = None
    
    
    WindowOkButtonHint = None
    
    
    WindowOverridesSystemGestures = None
    
    
    WindowShadeButtonHint = None
    
    
    WindowShortcut = None
    
    
    WindowState = None
    
    
    WindowStates = None
    
    
    WindowStaysOnBottomHint = None
    
    
    WindowStaysOnTopHint = None
    
    
    WindowSystemMenuHint = None
    
    
    WindowTitleHint = None
    
    
    WindowTransparentForInput = None
    
    
    WindowType = None
    
    
    WindowType_Mask = None
    
    
    X11BypassWindowManagerHint = None
    
    
    XAxis = None
    
    
    XButton1 = None
    
    
    XButton2 = None
    
    
    YAxis = None
    
    
    ZAxis = None
    
    
    ZoomNativeGesture = None
    
    
    black = None
    
    
    blue = None
    
    
    color0 = None
    
    
    color1 = None
    
    
    cyan = None
    
    
    darkBlue = None
    
    
    darkCyan = None
    
    
    darkGray = None
    
    
    darkGreen = None
    
    
    darkMagenta = None
    
    
    darkRed = None
    
    
    darkYellow = None
    
    
    gray = None
    
    
    green = None
    
    
    lightGray = None
    
    
    magenta = None
    
    
    red = None
    
    
    transparent = None
    
    
    white = None
    
    
    yellow = None


class QDate(_Object):
    def __copy__(*args, **kwargs):
        pass
    
    
    def __eq__(*args, **kwargs):
        """
        x.__eq__(y) <==> x==y
        """
    
        pass
    
    
    def __ge__(*args, **kwargs):
        """
        x.__ge__(y) <==> x>=y
        """
    
        pass
    
    
    def __getattribute__(*args, **kwargs):
        """
        x.__getattribute__('name') <==> x.name
        """
    
        pass
    
    
    def __gt__(*args, **kwargs):
        """
        x.__gt__(y) <==> x>y
        """
    
        pass
    
    
    def __hash__(*args, **kwargs):
        """
        x.__hash__() <==> hash(x)
        """
    
        pass
    
    
    def __init__(*args, **kwargs):
        """
        x.__init__(...) initializes x; see help(type(x)) for signature
        """
    
        pass
    
    
    def __le__(*args, **kwargs):
        """
        x.__le__(y) <==> x<=y
        """
    
        pass
    
    
    def __lt__(*args, **kwargs):
        """
        x.__lt__(y) <==> x<y
        """
    
        pass
    
    
    def __ne__(*args, **kwargs):
        """
        x.__ne__(y) <==> x!=y
        """
    
        pass
    
    
    def __nonzero__(*args, **kwargs):
        """
        x.__nonzero__() <==> x != 0
        """
    
        pass
    
    
    def __reduce__(*args, **kwargs):
        pass
    
    
    def __repr__(*args, **kwargs):
        """
        x.__repr__() <==> repr(x)
        """
    
        pass
    
    
    def addDays(*args, **kwargs):
        pass
    
    
    def addMonths(*args, **kwargs):
        pass
    
    
    def addYears(*args, **kwargs):
        pass
    
    
    def day(*args, **kwargs):
        pass
    
    
    def dayOfWeek(*args, **kwargs):
        pass
    
    
    def dayOfYear(*args, **kwargs):
        pass
    
    
    def daysInMonth(*args, **kwargs):
        pass
    
    
    def daysInYear(*args, **kwargs):
        pass
    
    
    def daysTo(*args, **kwargs):
        pass
    
    
    def getDate(*args, **kwargs):
        pass
    
    
    def isNull(*args, **kwargs):
        pass
    
    
    def month(*args, **kwargs):
        pass
    
    
    def setDate(*args, **kwargs):
        pass
    
    
    def toJulianDay(*args, **kwargs):
        pass
    
    
    def toPython(*args, **kwargs):
        pass
    
    
    def toString(*args, **kwargs):
        pass
    
    
    def weekNumber(*args, **kwargs):
        pass
    
    
    def year(*args, **kwargs):
        pass
    
    
    def currentDate(*args, **kwargs):
        pass
    
    
    def fromJulianDay(*args, **kwargs):
        pass
    
    
    def fromString(*args, **kwargs):
        pass
    
    
    def isLeapYear(*args, **kwargs):
        pass
    
    
    def isValid(*args, **kwargs):
        pass
    
    
    def longDayName(*args, **kwargs):
        pass
    
    
    def longMonthName(*args, **kwargs):
        pass
    
    
    def shortDayName(*args, **kwargs):
        pass
    
    
    def shortMonthName(*args, **kwargs):
        pass
    
    
    DateFormat = None
    
    
    MonthNameType = None
    
    
    StandaloneFormat = None
    
    
    __new__ = None


class QProcessEnvironment(_Object):
    def __copy__(*args, **kwargs):
        pass
    
    
    def __eq__(*args, **kwargs):
        """
        x.__eq__(y) <==> x==y
        """
    
        pass
    
    
    def __ge__(*args, **kwargs):
        """
        x.__ge__(y) <==> x>=y
        """
    
        pass
    
    
    def __gt__(*args, **kwargs):
        """
        x.__gt__(y) <==> x>y
        """
    
        pass
    
    
    def __init__(*args, **kwargs):
        """
        x.__init__(...) initializes x; see help(type(x)) for signature
        """
    
        pass
    
    
    def __le__(*args, **kwargs):
        """
        x.__le__(y) <==> x<=y
        """
    
        pass
    
    
    def __lt__(*args, **kwargs):
        """
        x.__lt__(y) <==> x<y
        """
    
        pass
    
    
    def __ne__(*args, **kwargs):
        """
        x.__ne__(y) <==> x!=y
        """
    
        pass
    
    
    def clear(*args, **kwargs):
        pass
    
    
    def contains(*args, **kwargs):
        pass
    
    
    def insert(*args, **kwargs):
        pass
    
    
    def isEmpty(*args, **kwargs):
        pass
    
    
    def keys(*args, **kwargs):
        pass
    
    
    def remove(*args, **kwargs):
        pass
    
    
    def swap(*args, **kwargs):
        pass
    
    
    def toStringList(*args, **kwargs):
        pass
    
    
    def value(*args, **kwargs):
        pass
    
    
    def systemEnvironment(*args, **kwargs):
        pass
    
    
    __new__ = None


class QLine(_Object):
    def __copy__(*args, **kwargs):
        pass
    
    
    def __eq__(*args, **kwargs):
        """
        x.__eq__(y) <==> x==y
        """
    
        pass
    
    
    def __ge__(*args, **kwargs):
        """
        x.__ge__(y) <==> x>=y
        """
    
        pass
    
    
    def __gt__(*args, **kwargs):
        """
        x.__gt__(y) <==> x>y
        """
    
        pass
    
    
    def __hash__(*args, **kwargs):
        """
        x.__hash__() <==> hash(x)
        """
    
        pass
    
    
    def __init__(*args, **kwargs):
        """
        x.__init__(...) initializes x; see help(type(x)) for signature
        """
    
        pass
    
    
    def __le__(*args, **kwargs):
        """
        x.__le__(y) <==> x<=y
        """
    
        pass
    
    
    def __lt__(*args, **kwargs):
        """
        x.__lt__(y) <==> x<y
        """
    
        pass
    
    
    def __ne__(*args, **kwargs):
        """
        x.__ne__(y) <==> x!=y
        """
    
        pass
    
    
    def __nonzero__(*args, **kwargs):
        """
        x.__nonzero__() <==> x != 0
        """
    
        pass
    
    
    def __reduce__(*args, **kwargs):
        pass
    
    
    def __repr__(*args, **kwargs):
        """
        x.__repr__() <==> repr(x)
        """
    
        pass
    
    
    def dx(*args, **kwargs):
        pass
    
    
    def dy(*args, **kwargs):
        pass
    
    
    def isNull(*args, **kwargs):
        pass
    
    
    def p1(*args, **kwargs):
        pass
    
    
    def p2(*args, **kwargs):
        pass
    
    
    def setLine(*args, **kwargs):
        pass
    
    
    def setP1(*args, **kwargs):
        pass
    
    
    def setP2(*args, **kwargs):
        pass
    
    
    def setPoints(*args, **kwargs):
        pass
    
    
    def toTuple(*args, **kwargs):
        pass
    
    
    def translate(*args, **kwargs):
        pass
    
    
    def translated(*args, **kwargs):
        pass
    
    
    def x1(*args, **kwargs):
        pass
    
    
    def x2(*args, **kwargs):
        pass
    
    
    def y1(*args, **kwargs):
        pass
    
    
    def y2(*args, **kwargs):
        pass
    
    
    __new__ = None


class QMetaClassInfo(_Object):
    def __copy__(*args, **kwargs):
        pass
    
    
    def __init__(*args, **kwargs):
        """
        x.__init__(...) initializes x; see help(type(x)) for signature
        """
    
        pass
    
    
    def name(*args, **kwargs):
        pass
    
    
    def value(*args, **kwargs):
        pass
    
    
    __new__ = None


class QXmlStreamNamespaceDeclaration(_Object):
    def __copy__(*args, **kwargs):
        pass
    
    
    def __eq__(*args, **kwargs):
        """
        x.__eq__(y) <==> x==y
        """
    
        pass
    
    
    def __ge__(*args, **kwargs):
        """
        x.__ge__(y) <==> x>=y
        """
    
        pass
    
    
    def __gt__(*args, **kwargs):
        """
        x.__gt__(y) <==> x>y
        """
    
        pass
    
    
    def __init__(*args, **kwargs):
        """
        x.__init__(...) initializes x; see help(type(x)) for signature
        """
    
        pass
    
    
    def __le__(*args, **kwargs):
        """
        x.__le__(y) <==> x<=y
        """
    
        pass
    
    
    def __lt__(*args, **kwargs):
        """
        x.__lt__(y) <==> x<y
        """
    
        pass
    
    
    def __ne__(*args, **kwargs):
        """
        x.__ne__(y) <==> x!=y
        """
    
        pass
    
    
    def namespaceUri(*args, **kwargs):
        pass
    
    
    def prefix(*args, **kwargs):
        pass
    
    
    __new__ = None


class QByteArrayMatcher(_Object):
    def __copy__(*args, **kwargs):
        pass
    
    
    def __init__(*args, **kwargs):
        """
        x.__init__(...) initializes x; see help(type(x)) for signature
        """
    
        pass
    
    
    def indexIn(*args, **kwargs):
        pass
    
    
    def pattern(*args, **kwargs):
        pass
    
    
    def setPattern(*args, **kwargs):
        pass
    
    
    __new__ = None


class QBasicMutex(_Object):
    def __init__(*args, **kwargs):
        """
        x.__init__(...) initializes x; see help(type(x)) for signature
        """
    
        pass
    
    
    def isRecursive(*args, **kwargs):
        pass
    
    
    def lock(*args, **kwargs):
        pass
    
    
    def tryLock(*args, **kwargs):
        pass
    
    
    def unlock(*args, **kwargs):
        pass
    
    
    __new__ = None


class QRectF(_Object):
    def __and__(*args, **kwargs):
        """
        x.__and__(y) <==> x&y
        """
    
        pass
    
    
    def __copy__(*args, **kwargs):
        pass
    
    
    def __eq__(*args, **kwargs):
        """
        x.__eq__(y) <==> x==y
        """
    
        pass
    
    
    def __ge__(*args, **kwargs):
        """
        x.__ge__(y) <==> x>=y
        """
    
        pass
    
    
    def __gt__(*args, **kwargs):
        """
        x.__gt__(y) <==> x>y
        """
    
        pass
    
    
    def __iand__(*args, **kwargs):
        """
        x.__iand__(y) <==> x&=y
        """
    
        pass
    
    
    def __init__(*args, **kwargs):
        """
        x.__init__(...) initializes x; see help(type(x)) for signature
        """
    
        pass
    
    
    def __ior__(*args, **kwargs):
        """
        x.__ior__(y) <==> x|=y
        """
    
        pass
    
    
    def __le__(*args, **kwargs):
        """
        x.__le__(y) <==> x<=y
        """
    
        pass
    
    
    def __lt__(*args, **kwargs):
        """
        x.__lt__(y) <==> x<y
        """
    
        pass
    
    
    def __ne__(*args, **kwargs):
        """
        x.__ne__(y) <==> x!=y
        """
    
        pass
    
    
    def __nonzero__(*args, **kwargs):
        """
        x.__nonzero__() <==> x != 0
        """
    
        pass
    
    
    def __or__(*args, **kwargs):
        """
        x.__or__(y) <==> x|y
        """
    
        pass
    
    
    def __rand__(*args, **kwargs):
        """
        x.__rand__(y) <==> y&x
        """
    
        pass
    
    
    def __reduce__(*args, **kwargs):
        pass
    
    
    def __repr__(*args, **kwargs):
        """
        x.__repr__() <==> repr(x)
        """
    
        pass
    
    
    def __ror__(*args, **kwargs):
        """
        x.__ror__(y) <==> y|x
        """
    
        pass
    
    
    def adjust(*args, **kwargs):
        pass
    
    
    def adjusted(*args, **kwargs):
        pass
    
    
    def bottom(*args, **kwargs):
        pass
    
    
    def bottomLeft(*args, **kwargs):
        pass
    
    
    def bottomRight(*args, **kwargs):
        pass
    
    
    def center(*args, **kwargs):
        pass
    
    
    def contains(*args, **kwargs):
        pass
    
    
    def getCoords(*args, **kwargs):
        pass
    
    
    def getRect(*args, **kwargs):
        pass
    
    
    def height(*args, **kwargs):
        pass
    
    
    def intersected(*args, **kwargs):
        pass
    
    
    def intersects(*args, **kwargs):
        pass
    
    
    def isEmpty(*args, **kwargs):
        pass
    
    
    def isNull(*args, **kwargs):
        pass
    
    
    def isValid(*args, **kwargs):
        pass
    
    
    def left(*args, **kwargs):
        pass
    
    
    def moveBottom(*args, **kwargs):
        pass
    
    
    def moveBottomLeft(*args, **kwargs):
        pass
    
    
    def moveBottomRight(*args, **kwargs):
        pass
    
    
    def moveCenter(*args, **kwargs):
        pass
    
    
    def moveLeft(*args, **kwargs):
        pass
    
    
    def moveRight(*args, **kwargs):
        pass
    
    
    def moveTo(*args, **kwargs):
        pass
    
    
    def moveTop(*args, **kwargs):
        pass
    
    
    def moveTopLeft(*args, **kwargs):
        pass
    
    
    def moveTopRight(*args, **kwargs):
        pass
    
    
    def normalized(*args, **kwargs):
        pass
    
    
    def right(*args, **kwargs):
        pass
    
    
    def setBottom(*args, **kwargs):
        pass
    
    
    def setBottomLeft(*args, **kwargs):
        pass
    
    
    def setBottomRight(*args, **kwargs):
        pass
    
    
    def setCoords(*args, **kwargs):
        pass
    
    
    def setHeight(*args, **kwargs):
        pass
    
    
    def setLeft(*args, **kwargs):
        pass
    
    
    def setRect(*args, **kwargs):
        pass
    
    
    def setRight(*args, **kwargs):
        pass
    
    
    def setSize(*args, **kwargs):
        pass
    
    
    def setTop(*args, **kwargs):
        pass
    
    
    def setTopLeft(*args, **kwargs):
        pass
    
    
    def setTopRight(*args, **kwargs):
        pass
    
    
    def setWidth(*args, **kwargs):
        pass
    
    
    def setX(*args, **kwargs):
        pass
    
    
    def setY(*args, **kwargs):
        pass
    
    
    def size(*args, **kwargs):
        pass
    
    
    def toAlignedRect(*args, **kwargs):
        pass
    
    
    def toRect(*args, **kwargs):
        pass
    
    
    def top(*args, **kwargs):
        pass
    
    
    def topLeft(*args, **kwargs):
        pass
    
    
    def topRight(*args, **kwargs):
        pass
    
    
    def translate(*args, **kwargs):
        pass
    
    
    def translated(*args, **kwargs):
        pass
    
    
    def united(*args, **kwargs):
        pass
    
    
    def width(*args, **kwargs):
        pass
    
    
    def x(*args, **kwargs):
        pass
    
    
    def y(*args, **kwargs):
        pass
    
    
    __new__ = None


class QSystemSemaphore(_Object):
    def __init__(*args, **kwargs):
        """
        x.__init__(...) initializes x; see help(type(x)) for signature
        """
    
        pass
    
    
    def acquire(*args, **kwargs):
        pass
    
    
    def error(*args, **kwargs):
        pass
    
    
    def errorString(*args, **kwargs):
        pass
    
    
    def key(*args, **kwargs):
        pass
    
    
    def release(*args, **kwargs):
        pass
    
    
    def setKey(*args, **kwargs):
        pass
    
    
    AccessMode = None
    
    
    AlreadyExists = None
    
    
    Create = None
    
    
    KeyError = None
    
    
    NoError = None
    
    
    NotFound = None
    
    
    Open = None
    
    
    OutOfResources = None
    
    
    PermissionDenied = None
    
    
    SystemSemaphoreError = None
    
    
    UnknownError = None
    
    
    __new__ = None


class QWaitCondition(_Object):
    def __init__(*args, **kwargs):
        """
        x.__init__(...) initializes x; see help(type(x)) for signature
        """
    
        pass
    
    
    def wait(*args, **kwargs):
        pass
    
    
    def wakeAll(*args, **kwargs):
        pass
    
    
    def wakeOne(*args, **kwargs):
        pass
    
    
    __new__ = None


class QMetaEnum(_Object):
    def __copy__(*args, **kwargs):
        pass
    
    
    def __init__(*args, **kwargs):
        """
        x.__init__(...) initializes x; see help(type(x)) for signature
        """
    
        pass
    
    
    def isFlag(*args, **kwargs):
        pass
    
    
    def isValid(*args, **kwargs):
        pass
    
    
    def key(*args, **kwargs):
        pass
    
    
    def keyCount(*args, **kwargs):
        pass
    
    
    def keyToValue(*args, **kwargs):
        pass
    
    
    def keysToValue(*args, **kwargs):
        pass
    
    
    def name(*args, **kwargs):
        pass
    
    
    def scope(*args, **kwargs):
        pass
    
    
    def value(*args, **kwargs):
        pass
    
    
    def valueToKey(*args, **kwargs):
        pass
    
    
    def valueToKeys(*args, **kwargs):
        pass
    
    
    __new__ = None


class QBasicTimer(_Object):
    def __copy__(*args, **kwargs):
        pass
    
    
    def __init__(*args, **kwargs):
        """
        x.__init__(...) initializes x; see help(type(x)) for signature
        """
    
        pass
    
    
    def isActive(*args, **kwargs):
        pass
    
    
    def start(*args, **kwargs):
        pass
    
    
    def stop(*args, **kwargs):
        pass
    
    
    def timerId(*args, **kwargs):
        pass
    
    
    __new__ = None


class QEasingCurve(_Object):
    def __copy__(*args, **kwargs):
        pass
    
    
    def __eq__(*args, **kwargs):
        """
        x.__eq__(y) <==> x==y
        """
    
        pass
    
    
    def __ge__(*args, **kwargs):
        """
        x.__ge__(y) <==> x>=y
        """
    
        pass
    
    
    def __gt__(*args, **kwargs):
        """
        x.__gt__(y) <==> x>y
        """
    
        pass
    
    
    def __init__(*args, **kwargs):
        """
        x.__init__(...) initializes x; see help(type(x)) for signature
        """
    
        pass
    
    
    def __le__(*args, **kwargs):
        """
        x.__le__(y) <==> x<=y
        """
    
        pass
    
    
    def __lt__(*args, **kwargs):
        """
        x.__lt__(y) <==> x<y
        """
    
        pass
    
    
    def __ne__(*args, **kwargs):
        """
        x.__ne__(y) <==> x!=y
        """
    
        pass
    
    
    def __repr__(*args, **kwargs):
        """
        x.__repr__() <==> repr(x)
        """
    
        pass
    
    
    def addCubicBezierSegment(*args, **kwargs):
        pass
    
    
    def addTCBSegment(*args, **kwargs):
        pass
    
    
    def amplitude(*args, **kwargs):
        pass
    
    
    def customType(*args, **kwargs):
        pass
    
    
    def overshoot(*args, **kwargs):
        pass
    
    
    def period(*args, **kwargs):
        pass
    
    
    def setAmplitude(*args, **kwargs):
        pass
    
    
    def setCustomType(*args, **kwargs):
        pass
    
    
    def setOvershoot(*args, **kwargs):
        pass
    
    
    def setPeriod(*args, **kwargs):
        pass
    
    
    def setType(*args, **kwargs):
        pass
    
    
    def swap(*args, **kwargs):
        pass
    
    
    def toCubicSpline(*args, **kwargs):
        pass
    
    
    def type(*args, **kwargs):
        pass
    
    
    def valueForProgress(*args, **kwargs):
        pass
    
    
    BezierSpline = None
    
    
    CosineCurve = None
    
    
    Custom = None
    
    
    InBack = None
    
    
    InBounce = None
    
    
    InCirc = None
    
    
    InCubic = None
    
    
    InCurve = None
    
    
    InElastic = None
    
    
    InExpo = None
    
    
    InOutBack = None
    
    
    InOutBounce = None
    
    
    InOutCirc = None
    
    
    InOutCubic = None
    
    
    InOutElastic = None
    
    
    InOutExpo = None
    
    
    InOutQuad = None
    
    
    InOutQuart = None
    
    
    InOutQuint = None
    
    
    InOutSine = None
    
    
    InQuad = None
    
    
    InQuart = None
    
    
    InQuint = None
    
    
    InSine = None
    
    
    Linear = None
    
    
    NCurveTypes = None
    
    
    OutBack = None
    
    
    OutBounce = None
    
    
    OutCirc = None
    
    
    OutCubic = None
    
    
    OutCurve = None
    
    
    OutElastic = None
    
    
    OutExpo = None
    
    
    OutInBack = None
    
    
    OutInBounce = None
    
    
    OutInCirc = None
    
    
    OutInCubic = None
    
    
    OutInElastic = None
    
    
    OutInExpo = None
    
    
    OutInQuad = None
    
    
    OutInQuart = None
    
    
    OutInQuint = None
    
    
    OutInSine = None
    
    
    OutQuad = None
    
    
    OutQuart = None
    
    
    OutQuint = None
    
    
    OutSine = None
    
    
    SineCurve = None
    
    
    TCBSpline = None
    
    
    Type = None
    
    
    __new__ = None


class QTextStream(_Object):
    def __init__(*args, **kwargs):
        """
        x.__init__(...) initializes x; see help(type(x)) for signature
        """
    
        pass
    
    
    def __lshift__(*args, **kwargs):
        """
        x.__lshift__(y) <==> x<<y
        """
    
        pass
    
    
    def __rlshift__(*args, **kwargs):
        """
        x.__rlshift__(y) <==> y<<x
        """
    
        pass
    
    
    def __rrshift__(*args, **kwargs):
        """
        x.__rrshift__(y) <==> y>>x
        """
    
        pass
    
    
    def __rshift__(*args, **kwargs):
        """
        x.__rshift__(y) <==> x>>y
        """
    
        pass
    
    
    def atEnd(*args, **kwargs):
        pass
    
    
    def autoDetectUnicode(*args, **kwargs):
        pass
    
    
    def codec(*args, **kwargs):
        pass
    
    
    def device(*args, **kwargs):
        pass
    
    
    def fieldAlignment(*args, **kwargs):
        pass
    
    
    def fieldWidth(*args, **kwargs):
        pass
    
    
    def flush(*args, **kwargs):
        pass
    
    
    def generateByteOrderMark(*args, **kwargs):
        pass
    
    
    def integerBase(*args, **kwargs):
        pass
    
    
    def locale(*args, **kwargs):
        pass
    
    
    def numberFlags(*args, **kwargs):
        pass
    
    
    def padChar(*args, **kwargs):
        pass
    
    
    def pos(*args, **kwargs):
        pass
    
    
    def read(*args, **kwargs):
        pass
    
    
    def readAll(*args, **kwargs):
        pass
    
    
    def readLine(*args, **kwargs):
        pass
    
    
    def realNumberNotation(*args, **kwargs):
        pass
    
    
    def realNumberPrecision(*args, **kwargs):
        pass
    
    
    def reset(*args, **kwargs):
        pass
    
    
    def resetStatus(*args, **kwargs):
        pass
    
    
    def seek(*args, **kwargs):
        pass
    
    
    def setAutoDetectUnicode(*args, **kwargs):
        pass
    
    
    def setCodec(*args, **kwargs):
        pass
    
    
    def setDevice(*args, **kwargs):
        pass
    
    
    def setFieldAlignment(*args, **kwargs):
        pass
    
    
    def setFieldWidth(*args, **kwargs):
        pass
    
    
    def setGenerateByteOrderMark(*args, **kwargs):
        pass
    
    
    def setIntegerBase(*args, **kwargs):
        pass
    
    
    def setLocale(*args, **kwargs):
        pass
    
    
    def setNumberFlags(*args, **kwargs):
        pass
    
    
    def setPadChar(*args, **kwargs):
        pass
    
    
    def setRealNumberNotation(*args, **kwargs):
        pass
    
    
    def setRealNumberPrecision(*args, **kwargs):
        pass
    
    
    def setStatus(*args, **kwargs):
        pass
    
    
    def skipWhiteSpace(*args, **kwargs):
        pass
    
    
    def status(*args, **kwargs):
        pass
    
    
    def string(*args, **kwargs):
        pass
    
    
    AlignAccountingStyle = None
    
    
    AlignCenter = None
    
    
    AlignLeft = None
    
    
    AlignRight = None
    
    
    FieldAlignment = None
    
    
    FixedNotation = None
    
    
    ForcePoint = None
    
    
    ForceSign = None
    
    
    NumberFlag = None
    
    
    NumberFlags = None
    
    
    Ok = None
    
    
    ReadCorruptData = None
    
    
    ReadPastEnd = None
    
    
    RealNumberNotation = None
    
    
    ScientificNotation = None
    
    
    ShowBase = None
    
    
    SmartNotation = None
    
    
    Status = None
    
    
    UppercaseBase = None
    
    
    UppercaseDigits = None
    
    
    WriteFailed = None
    
    
    __new__ = None


class QLineF(_Object):
    def __copy__(*args, **kwargs):
        pass
    
    
    def __eq__(*args, **kwargs):
        """
        x.__eq__(y) <==> x==y
        """
    
        pass
    
    
    def __ge__(*args, **kwargs):
        """
        x.__ge__(y) <==> x>=y
        """
    
        pass
    
    
    def __gt__(*args, **kwargs):
        """
        x.__gt__(y) <==> x>y
        """
    
        pass
    
    
    def __init__(*args, **kwargs):
        """
        x.__init__(...) initializes x; see help(type(x)) for signature
        """
    
        pass
    
    
    def __le__(*args, **kwargs):
        """
        x.__le__(y) <==> x<=y
        """
    
        pass
    
    
    def __lt__(*args, **kwargs):
        """
        x.__lt__(y) <==> x<y
        """
    
        pass
    
    
    def __ne__(*args, **kwargs):
        """
        x.__ne__(y) <==> x!=y
        """
    
        pass
    
    
    def __nonzero__(*args, **kwargs):
        """
        x.__nonzero__() <==> x != 0
        """
    
        pass
    
    
    def __reduce__(*args, **kwargs):
        pass
    
    
    def __repr__(*args, **kwargs):
        """
        x.__repr__() <==> repr(x)
        """
    
        pass
    
    
    def angle(*args, **kwargs):
        pass
    
    
    def angleTo(*args, **kwargs):
        pass
    
    
    def dx(*args, **kwargs):
        pass
    
    
    def dy(*args, **kwargs):
        pass
    
    
    def intersect(*args, **kwargs):
        pass
    
    
    def isNull(*args, **kwargs):
        pass
    
    
    def length(*args, **kwargs):
        pass
    
    
    def normalVector(*args, **kwargs):
        pass
    
    
    def p1(*args, **kwargs):
        pass
    
    
    def p2(*args, **kwargs):
        pass
    
    
    def pointAt(*args, **kwargs):
        pass
    
    
    def setAngle(*args, **kwargs):
        pass
    
    
    def setLength(*args, **kwargs):
        pass
    
    
    def setLine(*args, **kwargs):
        pass
    
    
    def setP1(*args, **kwargs):
        pass
    
    
    def setP2(*args, **kwargs):
        pass
    
    
    def setPoints(*args, **kwargs):
        pass
    
    
    def toLine(*args, **kwargs):
        pass
    
    
    def toTuple(*args, **kwargs):
        pass
    
    
    def translate(*args, **kwargs):
        pass
    
    
    def translated(*args, **kwargs):
        pass
    
    
    def unitVector(*args, **kwargs):
        pass
    
    
    def x1(*args, **kwargs):
        pass
    
    
    def x2(*args, **kwargs):
        pass
    
    
    def y1(*args, **kwargs):
        pass
    
    
    def y2(*args, **kwargs):
        pass
    
    
    def fromPolar(*args, **kwargs):
        pass
    
    
    BoundedIntersection = None
    
    
    IntersectType = None
    
    
    NoIntersection = None
    
    
    UnboundedIntersection = None
    
    
    __new__ = None


class QWriteLocker(_Object):
    def __enter__(*args, **kwargs):
        pass
    
    
    def __exit__(*args, **kwargs):
        pass
    
    
    def __init__(*args, **kwargs):
        """
        x.__init__(...) initializes x; see help(type(x)) for signature
        """
    
        pass
    
    
    def readWriteLock(*args, **kwargs):
        pass
    
    
    def relock(*args, **kwargs):
        pass
    
    
    def unlock(*args, **kwargs):
        pass
    
    
    __new__ = None


class QDateTime(_Object):
    def __copy__(*args, **kwargs):
        pass
    
    
    def __eq__(*args, **kwargs):
        """
        x.__eq__(y) <==> x==y
        """
    
        pass
    
    
    def __ge__(*args, **kwargs):
        """
        x.__ge__(y) <==> x>=y
        """
    
        pass
    
    
    def __gt__(*args, **kwargs):
        """
        x.__gt__(y) <==> x>y
        """
    
        pass
    
    
    def __hash__(*args, **kwargs):
        """
        x.__hash__() <==> hash(x)
        """
    
        pass
    
    
    def __init__(*args, **kwargs):
        """
        x.__init__(...) initializes x; see help(type(x)) for signature
        """
    
        pass
    
    
    def __le__(*args, **kwargs):
        """
        x.__le__(y) <==> x<=y
        """
    
        pass
    
    
    def __lt__(*args, **kwargs):
        """
        x.__lt__(y) <==> x<y
        """
    
        pass
    
    
    def __ne__(*args, **kwargs):
        """
        x.__ne__(y) <==> x!=y
        """
    
        pass
    
    
    def __nonzero__(*args, **kwargs):
        """
        x.__nonzero__() <==> x != 0
        """
    
        pass
    
    
    def __reduce__(*args, **kwargs):
        pass
    
    
    def __repr__(*args, **kwargs):
        """
        x.__repr__() <==> repr(x)
        """
    
        pass
    
    
    def addDays(*args, **kwargs):
        pass
    
    
    def addMSecs(*args, **kwargs):
        pass
    
    
    def addMonths(*args, **kwargs):
        pass
    
    
    def addSecs(*args, **kwargs):
        pass
    
    
    def addYears(*args, **kwargs):
        pass
    
    
    def date(*args, **kwargs):
        pass
    
    
    def daysTo(*args, **kwargs):
        pass
    
    
    def isDaylightTime(*args, **kwargs):
        pass
    
    
    def isNull(*args, **kwargs):
        pass
    
    
    def isValid(*args, **kwargs):
        pass
    
    
    def msecsTo(*args, **kwargs):
        pass
    
    
    def offsetFromUtc(*args, **kwargs):
        pass
    
    
    def secsTo(*args, **kwargs):
        pass
    
    
    def setDate(*args, **kwargs):
        pass
    
    
    def setMSecsSinceEpoch(*args, **kwargs):
        pass
    
    
    def setOffsetFromUtc(*args, **kwargs):
        pass
    
    
    def setTime(*args, **kwargs):
        pass
    
    
    def setTimeSpec(*args, **kwargs):
        pass
    
    
    def setTime_t(*args, **kwargs):
        pass
    
    
    def setUtcOffset(*args, **kwargs):
        pass
    
    
    def swap(*args, **kwargs):
        pass
    
    
    def time(*args, **kwargs):
        pass
    
    
    def timeSpec(*args, **kwargs):
        pass
    
    
    def timeZoneAbbreviation(*args, **kwargs):
        pass
    
    
    def toLocalTime(*args, **kwargs):
        pass
    
    
    def toMSecsSinceEpoch(*args, **kwargs):
        pass
    
    
    def toOffsetFromUtc(*args, **kwargs):
        pass
    
    
    def toPython(*args, **kwargs):
        pass
    
    
    def toString(*args, **kwargs):
        pass
    
    
    def toTimeSpec(*args, **kwargs):
        pass
    
    
    def toTime_t(*args, **kwargs):
        pass
    
    
    def toUTC(*args, **kwargs):
        pass
    
    
    def utcOffset(*args, **kwargs):
        pass
    
    
    def currentDateTime(*args, **kwargs):
        pass
    
    
    def currentDateTimeUtc(*args, **kwargs):
        pass
    
    
    def currentMSecsSinceEpoch(*args, **kwargs):
        pass
    
    
    def fromMSecsSinceEpoch(*args, **kwargs):
        pass
    
    
    def fromString(*args, **kwargs):
        pass
    
    
    def fromTime_t(*args, **kwargs):
        pass
    
    
    __new__ = None


class QReadLocker(_Object):
    def __enter__(*args, **kwargs):
        pass
    
    
    def __exit__(*args, **kwargs):
        pass
    
    
    def __init__(*args, **kwargs):
        """
        x.__init__(...) initializes x; see help(type(x)) for signature
        """
    
        pass
    
    
    def readWriteLock(*args, **kwargs):
        pass
    
    
    def relock(*args, **kwargs):
        pass
    
    
    def unlock(*args, **kwargs):
        pass
    
    
    __new__ = None


class QRegExp(_Object):
    def __copy__(*args, **kwargs):
        pass
    
    
    def __eq__(*args, **kwargs):
        """
        x.__eq__(y) <==> x==y
        """
    
        pass
    
    
    def __ge__(*args, **kwargs):
        """
        x.__ge__(y) <==> x>=y
        """
    
        pass
    
    
    def __gt__(*args, **kwargs):
        """
        x.__gt__(y) <==> x>y
        """
    
        pass
    
    
    def __init__(*args, **kwargs):
        """
        x.__init__(...) initializes x; see help(type(x)) for signature
        """
    
        pass
    
    
    def __le__(*args, **kwargs):
        """
        x.__le__(y) <==> x<=y
        """
    
        pass
    
    
    def __lt__(*args, **kwargs):
        """
        x.__lt__(y) <==> x<y
        """
    
        pass
    
    
    def __ne__(*args, **kwargs):
        """
        x.__ne__(y) <==> x!=y
        """
    
        pass
    
    
    def __reduce__(*args, **kwargs):
        pass
    
    
    def __repr__(*args, **kwargs):
        """
        x.__repr__() <==> repr(x)
        """
    
        pass
    
    
    def cap(*args, **kwargs):
        pass
    
    
    def captureCount(*args, **kwargs):
        pass
    
    
    def capturedTexts(*args, **kwargs):
        pass
    
    
    def caseSensitivity(*args, **kwargs):
        pass
    
    
    def errorString(*args, **kwargs):
        pass
    
    
    def exactMatch(*args, **kwargs):
        pass
    
    
    def indexIn(*args, **kwargs):
        pass
    
    
    def isEmpty(*args, **kwargs):
        pass
    
    
    def isMinimal(*args, **kwargs):
        pass
    
    
    def isValid(*args, **kwargs):
        pass
    
    
    def lastIndexIn(*args, **kwargs):
        pass
    
    
    def matchedLength(*args, **kwargs):
        pass
    
    
    def pattern(*args, **kwargs):
        pass
    
    
    def patternSyntax(*args, **kwargs):
        pass
    
    
    def pos(*args, **kwargs):
        pass
    
    
    def replace(*args, **kwargs):
        pass
    
    
    def setCaseSensitivity(*args, **kwargs):
        pass
    
    
    def setMinimal(*args, **kwargs):
        pass
    
    
    def setPattern(*args, **kwargs):
        pass
    
    
    def setPatternSyntax(*args, **kwargs):
        pass
    
    
    def swap(*args, **kwargs):
        pass
    
    
    def escape(*args, **kwargs):
        pass
    
    
    CaretAtOffset = None
    
    
    CaretAtZero = None
    
    
    CaretMode = None
    
    
    CaretWontMatch = None
    
    
    FixedString = None
    
    
    PatternSyntax = None
    
    
    RegExp = None
    
    
    RegExp2 = None
    
    
    W3CXmlSchema11 = None
    
    
    Wildcard = None
    
    
    WildcardUnix = None
    
    
    __new__ = None


class QItemSelection(_Object):
    def __add__(*args, **kwargs):
        """
        x.__add__(y) <==> x+y
        """
    
        pass
    
    
    def __copy__(*args, **kwargs):
        pass
    
    
    def __delitem__(*args, **kwargs):
        """
        x.__delitem__(y) <==> del x[y]
        """
    
        pass
    
    
    def __eq__(*args, **kwargs):
        """
        x.__eq__(y) <==> x==y
        """
    
        pass
    
    
    def __ge__(*args, **kwargs):
        """
        x.__ge__(y) <==> x>=y
        """
    
        pass
    
    
    def __getitem__(*args, **kwargs):
        """
        x.__getitem__(y) <==> x[y]
        """
    
        pass
    
    
    def __gt__(*args, **kwargs):
        """
        x.__gt__(y) <==> x>y
        """
    
        pass
    
    
    def __iadd__(*args, **kwargs):
        """
        x.__iadd__(y) <==> x+=y
        """
    
        pass
    
    
    def __init__(*args, **kwargs):
        """
        x.__init__(...) initializes x; see help(type(x)) for signature
        """
    
        pass
    
    
    def __le__(*args, **kwargs):
        """
        x.__le__(y) <==> x<=y
        """
    
        pass
    
    
    def __len__(*args, **kwargs):
        """
        x.__len__() <==> len(x)
        """
    
        pass
    
    
    def __lshift__(*args, **kwargs):
        """
        x.__lshift__(y) <==> x<<y
        """
    
        pass
    
    
    def __lt__(*args, **kwargs):
        """
        x.__lt__(y) <==> x<y
        """
    
        pass
    
    
    def __ne__(*args, **kwargs):
        """
        x.__ne__(y) <==> x!=y
        """
    
        pass
    
    
    def __radd__(*args, **kwargs):
        """
        x.__radd__(y) <==> y+x
        """
    
        pass
    
    
    def __rlshift__(*args, **kwargs):
        """
        x.__rlshift__(y) <==> y<<x
        """
    
        pass
    
    
    def __setitem__(*args, **kwargs):
        """
        x.__setitem__(i, y) <==> x[i]=y
        """
    
        pass
    
    
    def append(*args, **kwargs):
        pass
    
    
    def at(*args, **kwargs):
        pass
    
    
    def back(*args, **kwargs):
        pass
    
    
    def clear(*args, **kwargs):
        pass
    
    
    def constFirst(*args, **kwargs):
        pass
    
    
    def constLast(*args, **kwargs):
        pass
    
    
    def contains(*args, **kwargs):
        pass
    
    
    def count(*args, **kwargs):
        pass
    
    
    def detachShared(*args, **kwargs):
        pass
    
    
    def empty(*args, **kwargs):
        pass
    
    
    def endsWith(*args, **kwargs):
        pass
    
    
    def first(*args, **kwargs):
        pass
    
    
    def front(*args, **kwargs):
        pass
    
    
    def indexOf(*args, **kwargs):
        pass
    
    
    def indexes(*args, **kwargs):
        pass
    
    
    def insert(*args, **kwargs):
        pass
    
    
    def isEmpty(*args, **kwargs):
        pass
    
    
    def isSharedWith(*args, **kwargs):
        pass
    
    
    def last(*args, **kwargs):
        pass
    
    
    def lastIndexOf(*args, **kwargs):
        pass
    
    
    def length(*args, **kwargs):
        pass
    
    
    def merge(*args, **kwargs):
        pass
    
    
    def mid(*args, **kwargs):
        pass
    
    
    def move(*args, **kwargs):
        pass
    
    
    def pop_back(*args, **kwargs):
        pass
    
    
    def pop_front(*args, **kwargs):
        pass
    
    
    def prepend(*args, **kwargs):
        pass
    
    
    def push_back(*args, **kwargs):
        pass
    
    
    def push_front(*args, **kwargs):
        pass
    
    
    def removeAll(*args, **kwargs):
        pass
    
    
    def removeAt(*args, **kwargs):
        pass
    
    
    def removeFirst(*args, **kwargs):
        pass
    
    
    def removeLast(*args, **kwargs):
        pass
    
    
    def removeOne(*args, **kwargs):
        pass
    
    
    def replace(*args, **kwargs):
        pass
    
    
    def reserve(*args, **kwargs):
        pass
    
    
    def select(*args, **kwargs):
        pass
    
    
    def setSharable(*args, **kwargs):
        pass
    
    
    def size(*args, **kwargs):
        pass
    
    
    def startsWith(*args, **kwargs):
        pass
    
    
    def swap(*args, **kwargs):
        pass
    
    
    def takeAt(*args, **kwargs):
        pass
    
    
    def takeFirst(*args, **kwargs):
        pass
    
    
    def takeLast(*args, **kwargs):
        pass
    
    
    def toSet(*args, **kwargs):
        pass
    
    
    def toVector(*args, **kwargs):
        pass
    
    
    def value(*args, **kwargs):
        pass
    
    
    def fromSet(*args, **kwargs):
        pass
    
    
    def fromVector(*args, **kwargs):
        pass
    
    
    def split(*args, **kwargs):
        pass
    
    
    __new__ = None


class QTextBoundaryFinder(_Object):
    def __copy__(*args, **kwargs):
        pass
    
    
    def __init__(*args, **kwargs):
        """
        x.__init__(...) initializes x; see help(type(x)) for signature
        """
    
        pass
    
    
    def boundaryReasons(*args, **kwargs):
        pass
    
    
    def isAtBoundary(*args, **kwargs):
        pass
    
    
    def isValid(*args, **kwargs):
        pass
    
    
    def position(*args, **kwargs):
        pass
    
    
    def setPosition(*args, **kwargs):
        pass
    
    
    def string(*args, **kwargs):
        pass
    
    
    def toEnd(*args, **kwargs):
        pass
    
    
    def toNextBoundary(*args, **kwargs):
        pass
    
    
    def toPreviousBoundary(*args, **kwargs):
        pass
    
    
    def toStart(*args, **kwargs):
        pass
    
    
    def type(*args, **kwargs):
        pass
    
    
    BoundaryReason = None
    
    
    BoundaryReasons = None
    
    
    BoundaryType = None
    
    
    BreakOpportunity = None
    
    
    EndOfItem = None
    
    
    Grapheme = None
    
    
    Line = None
    
    
    MandatoryBreak = None
    
    
    NotAtBoundary = None
    
    
    Sentence = None
    
    
    SoftHyphen = None
    
    
    StartOfItem = None
    
    
    Word = None
    
    
    __new__ = None


class QModelIndex(_Object):
    def __copy__(*args, **kwargs):
        pass
    
    
    def __eq__(*args, **kwargs):
        """
        x.__eq__(y) <==> x==y
        """
    
        pass
    
    
    def __ge__(*args, **kwargs):
        """
        x.__ge__(y) <==> x>=y
        """
    
        pass
    
    
    def __gt__(*args, **kwargs):
        """
        x.__gt__(y) <==> x>y
        """
    
        pass
    
    
    def __hash__(*args, **kwargs):
        """
        x.__hash__() <==> hash(x)
        """
    
        pass
    
    
    def __init__(*args, **kwargs):
        """
        x.__init__(...) initializes x; see help(type(x)) for signature
        """
    
        pass
    
    
    def __le__(*args, **kwargs):
        """
        x.__le__(y) <==> x<=y
        """
    
        pass
    
    
    def __lt__(*args, **kwargs):
        """
        x.__lt__(y) <==> x<y
        """
    
        pass
    
    
    def __ne__(*args, **kwargs):
        """
        x.__ne__(y) <==> x!=y
        """
    
        pass
    
    
    def __repr__(*args, **kwargs):
        """
        x.__repr__() <==> repr(x)
        """
    
        pass
    
    
    def child(*args, **kwargs):
        pass
    
    
    def column(*args, **kwargs):
        pass
    
    
    def data(*args, **kwargs):
        pass
    
    
    def flags(*args, **kwargs):
        pass
    
    
    def internalId(*args, **kwargs):
        pass
    
    
    def internalPointer(*args, **kwargs):
        pass
    
    
    def isValid(*args, **kwargs):
        pass
    
    
    def model(*args, **kwargs):
        pass
    
    
    def parent(*args, **kwargs):
        pass
    
    
    def row(*args, **kwargs):
        pass
    
    
    def sibling(*args, **kwargs):
        pass
    
    
    __new__ = None


class QElapsedTimer(_Object):
    def __copy__(*args, **kwargs):
        pass
    
    
    def __eq__(*args, **kwargs):
        """
        x.__eq__(y) <==> x==y
        """
    
        pass
    
    
    def __ge__(*args, **kwargs):
        """
        x.__ge__(y) <==> x>=y
        """
    
        pass
    
    
    def __gt__(*args, **kwargs):
        """
        x.__gt__(y) <==> x>y
        """
    
        pass
    
    
    def __init__(*args, **kwargs):
        """
        x.__init__(...) initializes x; see help(type(x)) for signature
        """
    
        pass
    
    
    def __le__(*args, **kwargs):
        """
        x.__le__(y) <==> x<=y
        """
    
        pass
    
    
    def __lt__(*args, **kwargs):
        """
        x.__lt__(y) <==> x<y
        """
    
        pass
    
    
    def __ne__(*args, **kwargs):
        """
        x.__ne__(y) <==> x!=y
        """
    
        pass
    
    
    def elapsed(*args, **kwargs):
        pass
    
    
    def hasExpired(*args, **kwargs):
        pass
    
    
    def invalidate(*args, **kwargs):
        pass
    
    
    def isValid(*args, **kwargs):
        pass
    
    
    def msecsSinceReference(*args, **kwargs):
        pass
    
    
    def msecsTo(*args, **kwargs):
        pass
    
    
    def nsecsElapsed(*args, **kwargs):
        pass
    
    
    def restart(*args, **kwargs):
        pass
    
    
    def secsTo(*args, **kwargs):
        pass
    
    
    def start(*args, **kwargs):
        pass
    
    
    def clockType(*args, **kwargs):
        pass
    
    
    def isMonotonic(*args, **kwargs):
        pass
    
    
    ClockType = None
    
    
    MachAbsoluteTime = None
    
    
    MonotonicClock = None
    
    
    PerformanceCounter = None
    
    
    SystemTime = None
    
    
    TickCounter = None
    
    
    __new__ = None


class QTextStreamManipulator(_Object):
    def __copy__(*args, **kwargs):
        pass
    
    
    def exec_(*args, **kwargs):
        pass


class QFileInfo(_Object):
    def __copy__(*args, **kwargs):
        pass
    
    
    def __eq__(*args, **kwargs):
        """
        x.__eq__(y) <==> x==y
        """
    
        pass
    
    
    def __ge__(*args, **kwargs):
        """
        x.__ge__(y) <==> x>=y
        """
    
        pass
    
    
    def __getattribute__(*args, **kwargs):
        """
        x.__getattribute__('name') <==> x.name
        """
    
        pass
    
    
    def __gt__(*args, **kwargs):
        """
        x.__gt__(y) <==> x>y
        """
    
        pass
    
    
    def __init__(*args, **kwargs):
        """
        x.__init__(...) initializes x; see help(type(x)) for signature
        """
    
        pass
    
    
    def __le__(*args, **kwargs):
        """
        x.__le__(y) <==> x<=y
        """
    
        pass
    
    
    def __lt__(*args, **kwargs):
        """
        x.__lt__(y) <==> x<y
        """
    
        pass
    
    
    def __ne__(*args, **kwargs):
        """
        x.__ne__(y) <==> x!=y
        """
    
        pass
    
    
    def __reduce__(*args, **kwargs):
        pass
    
    
    def absoluteDir(*args, **kwargs):
        pass
    
    
    def absoluteFilePath(*args, **kwargs):
        pass
    
    
    def absolutePath(*args, **kwargs):
        pass
    
    
    def baseName(*args, **kwargs):
        pass
    
    
    def bundleName(*args, **kwargs):
        pass
    
    
    def caching(*args, **kwargs):
        pass
    
    
    def canonicalFilePath(*args, **kwargs):
        pass
    
    
    def canonicalPath(*args, **kwargs):
        pass
    
    
    def completeBaseName(*args, **kwargs):
        pass
    
    
    def completeSuffix(*args, **kwargs):
        pass
    
    
    def created(*args, **kwargs):
        pass
    
    
    def dir(*args, **kwargs):
        pass
    
    
    def fileName(*args, **kwargs):
        pass
    
    
    def filePath(*args, **kwargs):
        pass
    
    
    def group(*args, **kwargs):
        pass
    
    
    def groupId(*args, **kwargs):
        pass
    
    
    def isAbsolute(*args, **kwargs):
        pass
    
    
    def isBundle(*args, **kwargs):
        pass
    
    
    def isDir(*args, **kwargs):
        pass
    
    
    def isExecutable(*args, **kwargs):
        pass
    
    
    def isFile(*args, **kwargs):
        pass
    
    
    def isHidden(*args, **kwargs):
        pass
    
    
    def isNativePath(*args, **kwargs):
        pass
    
    
    def isReadable(*args, **kwargs):
        pass
    
    
    def isRelative(*args, **kwargs):
        pass
    
    
    def isRoot(*args, **kwargs):
        pass
    
    
    def isSymLink(*args, **kwargs):
        pass
    
    
    def isWritable(*args, **kwargs):
        pass
    
    
    def lastModified(*args, **kwargs):
        pass
    
    
    def lastRead(*args, **kwargs):
        pass
    
    
    def makeAbsolute(*args, **kwargs):
        pass
    
    
    def owner(*args, **kwargs):
        pass
    
    
    def ownerId(*args, **kwargs):
        pass
    
    
    def path(*args, **kwargs):
        pass
    
    
    def readLink(*args, **kwargs):
        pass
    
    
    def refresh(*args, **kwargs):
        pass
    
    
    def setCaching(*args, **kwargs):
        pass
    
    
    def setFile(*args, **kwargs):
        pass
    
    
    def size(*args, **kwargs):
        pass
    
    
    def suffix(*args, **kwargs):
        pass
    
    
    def swap(*args, **kwargs):
        pass
    
    
    def symLinkTarget(*args, **kwargs):
        pass
    
    
    def exists(*args, **kwargs):
        pass
    
    
    __new__ = None


class QBitArray(_Object):
    def __and__(*args, **kwargs):
        """
        x.__and__(y) <==> x&y
        """
    
        pass
    
    
    def __copy__(*args, **kwargs):
        pass
    
    
    def __delitem__(*args, **kwargs):
        """
        x.__delitem__(y) <==> del x[y]
        """
    
        pass
    
    
    def __eq__(*args, **kwargs):
        """
        x.__eq__(y) <==> x==y
        """
    
        pass
    
    
    def __ge__(*args, **kwargs):
        """
        x.__ge__(y) <==> x>=y
        """
    
        pass
    
    
    def __getitem__(*args, **kwargs):
        """
        x.__getitem__(y) <==> x[y]
        """
    
        pass
    
    
    def __gt__(*args, **kwargs):
        """
        x.__gt__(y) <==> x>y
        """
    
        pass
    
    
    def __hash__(*args, **kwargs):
        """
        x.__hash__() <==> hash(x)
        """
    
        pass
    
    
    def __iand__(*args, **kwargs):
        """
        x.__iand__(y) <==> x&=y
        """
    
        pass
    
    
    def __init__(*args, **kwargs):
        """
        x.__init__(...) initializes x; see help(type(x)) for signature
        """
    
        pass
    
    
    def __invert__(*args, **kwargs):
        """
        x.__invert__() <==> ~x
        """
    
        pass
    
    
    def __ior__(*args, **kwargs):
        """
        x.__ior__(y) <==> x|=y
        """
    
        pass
    
    
    def __ixor__(*args, **kwargs):
        """
        x.__ixor__(y) <==> x^=y
        """
    
        pass
    
    
    def __le__(*args, **kwargs):
        """
        x.__le__(y) <==> x<=y
        """
    
        pass
    
    
    def __len__(*args, **kwargs):
        """
        x.__len__() <==> len(x)
        """
    
        pass
    
    
    def __lt__(*args, **kwargs):
        """
        x.__lt__(y) <==> x<y
        """
    
        pass
    
    
    def __ne__(*args, **kwargs):
        """
        x.__ne__(y) <==> x!=y
        """
    
        pass
    
    
    def __nonzero__(*args, **kwargs):
        """
        x.__nonzero__() <==> x != 0
        """
    
        pass
    
    
    def __or__(*args, **kwargs):
        """
        x.__or__(y) <==> x|y
        """
    
        pass
    
    
    def __rand__(*args, **kwargs):
        """
        x.__rand__(y) <==> y&x
        """
    
        pass
    
    
    def __repr__(*args, **kwargs):
        """
        x.__repr__() <==> repr(x)
        """
    
        pass
    
    
    def __ror__(*args, **kwargs):
        """
        x.__ror__(y) <==> y|x
        """
    
        pass
    
    
    def __rxor__(*args, **kwargs):
        """
        x.__rxor__(y) <==> y^x
        """
    
        pass
    
    
    def __setitem__(*args, **kwargs):
        """
        x.__setitem__(i, y) <==> x[i]=y
        """
    
        pass
    
    
    def __xor__(*args, **kwargs):
        """
        x.__xor__(y) <==> x^y
        """
    
        pass
    
    
    def at(*args, **kwargs):
        pass
    
    
    def clear(*args, **kwargs):
        pass
    
    
    def clearBit(*args, **kwargs):
        pass
    
    
    def count(*args, **kwargs):
        pass
    
    
    def fill(*args, **kwargs):
        pass
    
    
    def isEmpty(*args, **kwargs):
        pass
    
    
    def isNull(*args, **kwargs):
        pass
    
    
    def resize(*args, **kwargs):
        pass
    
    
    def setBit(*args, **kwargs):
        pass
    
    
    def size(*args, **kwargs):
        pass
    
    
    def swap(*args, **kwargs):
        pass
    
    
    def testBit(*args, **kwargs):
        pass
    
    
    def toggleBit(*args, **kwargs):
        pass
    
    
    def truncate(*args, **kwargs):
        pass
    
    
    __new__ = None


class QMetaMethod(_Object):
    def __copy__(*args, **kwargs):
        pass
    
    
    def __eq__(*args, **kwargs):
        """
        x.__eq__(y) <==> x==y
        """
    
        pass
    
    
    def __ge__(*args, **kwargs):
        """
        x.__ge__(y) <==> x>=y
        """
    
        pass
    
    
    def __gt__(*args, **kwargs):
        """
        x.__gt__(y) <==> x>y
        """
    
        pass
    
    
    def __init__(*args, **kwargs):
        """
        x.__init__(...) initializes x; see help(type(x)) for signature
        """
    
        pass
    
    
    def __le__(*args, **kwargs):
        """
        x.__le__(y) <==> x<=y
        """
    
        pass
    
    
    def __lt__(*args, **kwargs):
        """
        x.__lt__(y) <==> x<y
        """
    
        pass
    
    
    def __ne__(*args, **kwargs):
        """
        x.__ne__(y) <==> x!=y
        """
    
        pass
    
    
    def access(*args, **kwargs):
        pass
    
    
    def enclosingMetaObject(*args, **kwargs):
        pass
    
    
    def invoke(*args, **kwargs):
        pass
    
    
    def invokeOnGadget(*args, **kwargs):
        pass
    
    
    def isValid(*args, **kwargs):
        pass
    
    
    def methodIndex(*args, **kwargs):
        pass
    
    
    def methodSignature(*args, **kwargs):
        pass
    
    
    def methodType(*args, **kwargs):
        pass
    
    
    def name(*args, **kwargs):
        pass
    
    
    def parameterCount(*args, **kwargs):
        pass
    
    
    def parameterNames(*args, **kwargs):
        pass
    
    
    def parameterType(*args, **kwargs):
        pass
    
    
    def parameterTypes(*args, **kwargs):
        pass
    
    
    def returnType(*args, **kwargs):
        pass
    
    
    def revision(*args, **kwargs):
        pass
    
    
    def tag(*args, **kwargs):
        pass
    
    
    def typeName(*args, **kwargs):
        pass
    
    
    Access = None
    
    
    Constructor = None
    
    
    Method = None
    
    
    MethodType = None
    
    
    Private = None
    
    
    Protected = None
    
    
    Public = None
    
    
    Signal = None
    
    
    Slot = None
    
    
    __new__ = None


class QPoint(_Object):
    def __add__(*args, **kwargs):
        """
        x.__add__(y) <==> x+y
        """
    
        pass
    
    
    def __copy__(*args, **kwargs):
        pass
    
    
    def __div__(*args, **kwargs):
        """
        x.__div__(y) <==> x/y
        """
    
        pass
    
    
    def __eq__(*args, **kwargs):
        """
        x.__eq__(y) <==> x==y
        """
    
        pass
    
    
    def __ge__(*args, **kwargs):
        """
        x.__ge__(y) <==> x>=y
        """
    
        pass
    
    
    def __gt__(*args, **kwargs):
        """
        x.__gt__(y) <==> x>y
        """
    
        pass
    
    
    def __hash__(*args, **kwargs):
        """
        x.__hash__() <==> hash(x)
        """
    
        pass
    
    
    def __iadd__(*args, **kwargs):
        """
        x.__iadd__(y) <==> x+=y
        """
    
        pass
    
    
    def __init__(*args, **kwargs):
        """
        x.__init__(...) initializes x; see help(type(x)) for signature
        """
    
        pass
    
    
    def __isub__(*args, **kwargs):
        """
        x.__isub__(y) <==> x-=y
        """
    
        pass
    
    
    def __le__(*args, **kwargs):
        """
        x.__le__(y) <==> x<=y
        """
    
        pass
    
    
    def __lt__(*args, **kwargs):
        """
        x.__lt__(y) <==> x<y
        """
    
        pass
    
    
    def __mul__(*args, **kwargs):
        """
        x.__mul__(y) <==> x*y
        """
    
        pass
    
    
    def __ne__(*args, **kwargs):
        """
        x.__ne__(y) <==> x!=y
        """
    
        pass
    
    
    def __neg__(*args, **kwargs):
        """
        x.__neg__() <==> -x
        """
    
        pass
    
    
    def __nonzero__(*args, **kwargs):
        """
        x.__nonzero__() <==> x != 0
        """
    
        pass
    
    
    def __pos__(*args, **kwargs):
        """
        x.__pos__() <==> +x
        """
    
        pass
    
    
    def __radd__(*args, **kwargs):
        """
        x.__radd__(y) <==> y+x
        """
    
        pass
    
    
    def __rdiv__(*args, **kwargs):
        """
        x.__rdiv__(y) <==> y/x
        """
    
        pass
    
    
    def __reduce__(*args, **kwargs):
        pass
    
    
    def __repr__(*args, **kwargs):
        """
        x.__repr__() <==> repr(x)
        """
    
        pass
    
    
    def __rmul__(*args, **kwargs):
        """
        x.__rmul__(y) <==> y*x
        """
    
        pass
    
    
    def __rsub__(*args, **kwargs):
        """
        x.__rsub__(y) <==> y-x
        """
    
        pass
    
    
    def __rtruediv__(*args, **kwargs):
        """
        x.__rtruediv__(y) <==> y/x
        """
    
        pass
    
    
    def __sub__(*args, **kwargs):
        """
        x.__sub__(y) <==> x-y
        """
    
        pass
    
    
    def __truediv__(*args, **kwargs):
        """
        x.__truediv__(y) <==> x/y
        """
    
        pass
    
    
    def isNull(*args, **kwargs):
        pass
    
    
    def manhattanLength(*args, **kwargs):
        pass
    
    
    def setX(*args, **kwargs):
        pass
    
    
    def setY(*args, **kwargs):
        pass
    
    
    def toTuple(*args, **kwargs):
        pass
    
    
    def x(*args, **kwargs):
        pass
    
    
    def y(*args, **kwargs):
        pass
    
    
    def dotProduct(*args, **kwargs):
        pass
    
    
    __new__ = None


class QLocale(_Object):
    def __copy__(*args, **kwargs):
        pass
    
    
    def __eq__(*args, **kwargs):
        """
        x.__eq__(y) <==> x==y
        """
    
        pass
    
    
    def __ge__(*args, **kwargs):
        """
        x.__ge__(y) <==> x>=y
        """
    
        pass
    
    
    def __gt__(*args, **kwargs):
        """
        x.__gt__(y) <==> x>y
        """
    
        pass
    
    
    def __init__(*args, **kwargs):
        """
        x.__init__(...) initializes x; see help(type(x)) for signature
        """
    
        pass
    
    
    def __le__(*args, **kwargs):
        """
        x.__le__(y) <==> x<=y
        """
    
        pass
    
    
    def __lt__(*args, **kwargs):
        """
        x.__lt__(y) <==> x<y
        """
    
        pass
    
    
    def __ne__(*args, **kwargs):
        """
        x.__ne__(y) <==> x!=y
        """
    
        pass
    
    
    def __repr__(*args, **kwargs):
        """
        x.__repr__() <==> repr(x)
        """
    
        pass
    
    
    def amText(*args, **kwargs):
        pass
    
    
    def bcp47Name(*args, **kwargs):
        pass
    
    
    def country(*args, **kwargs):
        pass
    
    
    def createSeparatedList(*args, **kwargs):
        pass
    
    
    def currencySymbol(*args, **kwargs):
        pass
    
    
    def dateFormat(*args, **kwargs):
        pass
    
    
    def dateTimeFormat(*args, **kwargs):
        pass
    
    
    def dayName(*args, **kwargs):
        pass
    
    
    def decimalPoint(*args, **kwargs):
        pass
    
    
    def exponential(*args, **kwargs):
        pass
    
    
    def firstDayOfWeek(*args, **kwargs):
        pass
    
    
    def groupSeparator(*args, **kwargs):
        pass
    
    
    def language(*args, **kwargs):
        pass
    
    
    def measurementSystem(*args, **kwargs):
        pass
    
    
    def monthName(*args, **kwargs):
        pass
    
    
    def name(*args, **kwargs):
        pass
    
    
    def nativeCountryName(*args, **kwargs):
        pass
    
    
    def nativeLanguageName(*args, **kwargs):
        pass
    
    
    def negativeSign(*args, **kwargs):
        pass
    
    
    def numberOptions(*args, **kwargs):
        pass
    
    
    def percent(*args, **kwargs):
        pass
    
    
    def pmText(*args, **kwargs):
        pass
    
    
    def positiveSign(*args, **kwargs):
        pass
    
    
    def quoteString(*args, **kwargs):
        pass
    
    
    def script(*args, **kwargs):
        pass
    
    
    def setNumberOptions(*args, **kwargs):
        pass
    
    
    def standaloneDayName(*args, **kwargs):
        pass
    
    
    def standaloneMonthName(*args, **kwargs):
        pass
    
    
    def textDirection(*args, **kwargs):
        pass
    
    
    def timeFormat(*args, **kwargs):
        pass
    
    
    def toCurrencyString(*args, **kwargs):
        pass
    
    
    def toDate(*args, **kwargs):
        pass
    
    
    def toDateTime(*args, **kwargs):
        pass
    
    
    def toDouble(*args, **kwargs):
        pass
    
    
    def toFloat(*args, **kwargs):
        pass
    
    
    def toInt(*args, **kwargs):
        pass
    
    
    def toLongLong(*args, **kwargs):
        pass
    
    
    def toLower(*args, **kwargs):
        pass
    
    
    def toShort(*args, **kwargs):
        pass
    
    
    def toString(*args, **kwargs):
        pass
    
    
    def toTime(*args, **kwargs):
        pass
    
    
    def toUInt(*args, **kwargs):
        pass
    
    
    def toULongLong(*args, **kwargs):
        pass
    
    
    def toUShort(*args, **kwargs):
        pass
    
    
    def toUpper(*args, **kwargs):
        pass
    
    
    def uiLanguages(*args, **kwargs):
        pass
    
    
    def weekdays(*args, **kwargs):
        pass
    
    
    def zeroDigit(*args, **kwargs):
        pass
    
    
    def c(*args, **kwargs):
        pass
    
    
    def countriesForLanguage(*args, **kwargs):
        pass
    
    
    def countryToString(*args, **kwargs):
        pass
    
    
    def languageToString(*args, **kwargs):
        pass
    
    
    def matchingLocales(*args, **kwargs):
        pass
    
    
    def scriptToString(*args, **kwargs):
        pass
    
    
    def setDefault(*args, **kwargs):
        pass
    
    
    def system(*args, **kwargs):
        pass
    
    
    Abkhazian = None
    
    
    Afan = None
    
    
    Afar = None
    
    
    Afghanistan = None
    
    
    Afrikaans = None
    
    
    Aghem = None
    
    
    Akan = None
    
    
    Akkadian = None
    
    
    Akoose = None
    
    
    AlandIslands = None
    
    
    Albania = None
    
    
    Albanian = None
    
    
    Algeria = None
    
    
    AlternateQuotation = None
    
    
    AmericanSamoa = None
    
    
    Amharic = None
    
    
    AncientEgyptian = None
    
    
    AncientGreek = None
    
    
    AncientNorthArabian = None
    
    
    Andorra = None
    
    
    Angola = None
    
    
    Anguilla = None
    
    
    Antarctica = None
    
    
    AntiguaAndBarbuda = None
    
    
    AnyCountry = None
    
    
    AnyLanguage = None
    
    
    AnyScript = None
    
    
    Arabic = None
    
    
    ArabicScript = None
    
    
    Aragonese = None
    
    
    Aramaic = None
    
    
    Argentina = None
    
    
    Armenia = None
    
    
    Armenian = None
    
    
    ArmenianScript = None
    
    
    Aruba = None
    
    
    AscensionIsland = None
    
    
    Assamese = None
    
    
    Asturian = None
    
    
    Asu = None
    
    
    Atsam = None
    
    
    Australia = None
    
    
    Austria = None
    
    
    Avaric = None
    
    
    Avestan = None
    
    
    AvestanScript = None
    
    
    Aymara = None
    
    
    Azerbaijan = None
    
    
    Azerbaijani = None
    
    
    Bafia = None
    
    
    Bahamas = None
    
    
    Bahrain = None
    
    
    Balinese = None
    
    
    BalineseScript = None
    
    
    Bambara = None
    
    
    BamumScript = None
    
    
    Bamun = None
    
    
    Bangladesh = None
    
    
    Barbados = None
    
    
    Basaa = None
    
    
    Bashkir = None
    
    
    Basque = None
    
    
    Bassa = None
    
    
    BassaVahScript = None
    
    
    BatakScript = None
    
    
    BatakToba = None
    
    
    Belarus = None
    
    
    Belarusian = None
    
    
    Belgium = None
    
    
    Belize = None
    
    
    Bemba = None
    
    
    Bena = None
    
    
    Bengali = None
    
    
    BengaliScript = None
    
    
    Benin = None
    
    
    Bermuda = None
    
    
    Bhutan = None
    
    
    Bhutani = None
    
    
    Bihari = None
    
    
    Bislama = None
    
    
    Blin = None
    
    
    Bodo = None
    
    
    Bolivia = None
    
    
    Bonaire = None
    
    
    BopomofoScript = None
    
    
    BosniaAndHerzegowina = None
    
    
    Bosnian = None
    
    
    Botswana = None
    
    
    BouvetIsland = None
    
    
    BrahmiScript = None
    
    
    BrailleScript = None
    
    
    Brazil = None
    
    
    Breton = None
    
    
    BritishIndianOceanTerritory = None
    
    
    BritishVirginIslands = None
    
    
    Brunei = None
    
    
    Buginese = None
    
    
    BugineseScript = None
    
    
    Buhid = None
    
    
    BuhidScript = None
    
    
    Bulgaria = None
    
    
    Bulgarian = None
    
    
    BurkinaFaso = None
    
    
    Burmese = None
    
    
    Burundi = None
    
    
    Byelorussian = None
    
    
    C = None
    
    
    Cambodia = None
    
    
    Cambodian = None
    
    
    Cameroon = None
    
    
    Canada = None
    
    
    CanadianAboriginalScript = None
    
    
    CanaryIslands = None
    
    
    CapeVerde = None
    
    
    Carian = None
    
    
    CarianScript = None
    
    
    Catalan = None
    
    
    CaucasianAlbanianScript = None
    
    
    CaymanIslands = None
    
    
    CentralAfricanRepublic = None
    
    
    CentralKurdish = None
    
    
    CentralMoroccoTamazight = None
    
    
    CeutaAndMelilla = None
    
    
    Chad = None
    
    
    Chakma = None
    
    
    ChakmaScript = None
    
    
    ChamScript = None
    
    
    Chamorro = None
    
    
    Chechen = None
    
    
    Cherokee = None
    
    
    CherokeeScript = None
    
    
    Chewa = None
    
    
    Chiga = None
    
    
    Chile = None
    
    
    China = None
    
    
    Chinese = None
    
    
    ChristmasIsland = None
    
    
    Church = None
    
    
    Chuvash = None
    
    
    ClassicalMandaic = None
    
    
    ClippertonIsland = None
    
    
    CocosIslands = None
    
    
    Colognian = None
    
    
    Colombia = None
    
    
    Comoros = None
    
    
    CongoBrazzaville = None
    
    
    CongoKinshasa = None
    
    
    CongoSwahili = None
    
    
    CookIslands = None
    
    
    Coptic = None
    
    
    CopticScript = None
    
    
    Cornish = None
    
    
    Corsican = None
    
    
    CostaRica = None
    
    
    Country = None
    
    
    Cree = None
    
    
    Croatia = None
    
    
    Croatian = None
    
    
    Cuba = None
    
    
    CuneiformScript = None
    
    
    CuraSao = None
    
    
    CurrencyDisplayName = None
    
    
    CurrencyIsoCode = None
    
    
    CurrencySymbol = None
    
    
    CurrencySymbolFormat = None
    
    
    CypriotScript = None
    
    
    Cyprus = None
    
    
    CyrillicScript = None
    
    
    Czech = None
    
    
    CzechRepublic = None
    
    
    Danish = None
    
    
    DemocraticRepublicOfCongo = None
    
    
    DemocraticRepublicOfKorea = None
    
    
    Denmark = None
    
    
    DeseretScript = None
    
    
    DevanagariScript = None
    
    
    DiegoGarcia = None
    
    
    Divehi = None
    
    
    Djibouti = None
    
    
    Dogri = None
    
    
    Dominica = None
    
    
    DominicanRepublic = None
    
    
    Duala = None
    
    
    DuployanScript = None
    
    
    Dutch = None
    
    
    Dzongkha = None
    
    
    EastTimor = None
    
    
    EasternCham = None
    
    
    EasternKayah = None
    
    
    Ecuador = None
    
    
    Egypt = None
    
    
    EgyptianHieroglyphsScript = None
    
    
    ElSalvador = None
    
    
    ElbasanScript = None
    
    
    Embu = None
    
    
    English = None
    
    
    EquatorialGuinea = None
    
    
    Eritrea = None
    
    
    Esperanto = None
    
    
    Estonia = None
    
    
    Estonian = None
    
    
    Ethiopia = None
    
    
    EthiopicScript = None
    
    
    Etruscan = None
    
    
    Ewe = None
    
    
    Ewondo = None
    
    
    FalklandIslands = None
    
    
    FaroeIslands = None
    
    
    Faroese = None
    
    
    Fiji = None
    
    
    Fijian = None
    
    
    Filipino = None
    
    
    Finland = None
    
    
    Finnish = None
    
    
    FormatType = None
    
    
    France = None
    
    
    FraserScript = None
    
    
    French = None
    
    
    FrenchGuiana = None
    
    
    FrenchPolynesia = None
    
    
    FrenchSouthernTerritories = None
    
    
    Frisian = None
    
    
    Friulian = None
    
    
    Fulah = None
    
    
    Ga = None
    
    
    Gabon = None
    
    
    Gaelic = None
    
    
    Galician = None
    
    
    Gambia = None
    
    
    Ganda = None
    
    
    Geez = None
    
    
    Georgia = None
    
    
    Georgian = None
    
    
    GeorgianScript = None
    
    
    German = None
    
    
    Germany = None
    
    
    Ghana = None
    
    
    Gibraltar = None
    
    
    GlagoliticScript = None
    
    
    Gothic = None
    
    
    GothicScript = None
    
    
    GranthaScript = None
    
    
    Greece = None
    
    
    Greek = None
    
    
    GreekScript = None
    
    
    Greenland = None
    
    
    Greenlandic = None
    
    
    Grenada = None
    
    
    Guadeloupe = None
    
    
    Guam = None
    
    
    Guarani = None
    
    
    Guatemala = None
    
    
    Guernsey = None
    
    
    Guinea = None
    
    
    GuineaBissau = None
    
    
    Gujarati = None
    
    
    GujaratiScript = None
    
    
    GurmukhiScript = None
    
    
    Gusii = None
    
    
    Guyana = None
    
    
    Haiti = None
    
    
    Haitian = None
    
    
    HanScript = None
    
    
    HangulScript = None
    
    
    Hanunoo = None
    
    
    HanunooScript = None
    
    
    Hausa = None
    
    
    Hawaiian = None
    
    
    HeardAndMcDonaldIslands = None
    
    
    Hebrew = None
    
    
    HebrewScript = None
    
    
    Herero = None
    
    
    Hindi = None
    
    
    HiraganaScript = None
    
    
    HiriMotu = None
    
    
    HmongNjua = None
    
    
    Ho = None
    
    
    Honduras = None
    
    
    HongKong = None
    
    
    Hungarian = None
    
    
    Hungary = None
    
    
    Iceland = None
    
    
    Icelandic = None
    
    
    Igbo = None
    
    
    ImperialAramaicScript = None
    
    
    ImperialSystem = None
    
    
    ImperialUKSystem = None
    
    
    ImperialUSSystem = None
    
    
    InariSami = None
    
    
    India = None
    
    
    Indonesia = None
    
    
    Indonesian = None
    
    
    Ingush = None
    
    
    InscriptionalPahlaviScript = None
    
    
    InscriptionalParthianScript = None
    
    
    Interlingua = None
    
    
    Interlingue = None
    
    
    Inuktitut = None
    
    
    Inupiak = None
    
    
    Iran = None
    
    
    Iraq = None
    
    
    Ireland = None
    
    
    Irish = None
    
    
    IsleOfMan = None
    
    
    Israel = None
    
    
    Italian = None
    
    
    Italy = None
    
    
    IvoryCoast = None
    
    
    Jamaica = None
    
    
    Japan = None
    
    
    Japanese = None
    
    
    JapaneseScript = None
    
    
    Javanese = None
    
    
    JavaneseScript = None
    
    
    Jersey = None
    
    
    Jju = None
    
    
    JolaFonyi = None
    
    
    Jordan = None
    
    
    Kabuverdianu = None
    
    
    Kabyle = None
    
    
    KaithiScript = None
    
    
    Kako = None
    
    
    Kalenjin = None
    
    
    Kamba = None
    
    
    Kannada = None
    
    
    KannadaScript = None
    
    
    Kanuri = None
    
    
    Kashmiri = None
    
    
    KatakanaScript = None
    
    
    KayahLiScript = None
    
    
    Kazakh = None
    
    
    Kazakhstan = None
    
    
    Kenya = None
    
    
    Kenyang = None
    
    
    KharoshthiScript = None
    
    
    Khmer = None
    
    
    KhmerScript = None
    
    
    KhojkiScript = None
    
    
    KhudawadiScript = None
    
    
    Kiche = None
    
    
    Kikuyu = None
    
    
    Kinyarwanda = None
    
    
    Kirghiz = None
    
    
    Kiribati = None
    
    
    Komi = None
    
    
    Kongo = None
    
    
    Konkani = None
    
    
    Korean = None
    
    
    KoreanScript = None
    
    
    Koro = None
    
    
    Kosovo = None
    
    
    KoyraChiini = None
    
    
    KoyraboroSenni = None
    
    
    Kpelle = None
    
    
    Kurdish = None
    
    
    Kurundi = None
    
    
    Kuwait = None
    
    
    Kwanyama = None
    
    
    Kwasio = None
    
    
    Kyrgyzstan = None
    
    
    Lakota = None
    
    
    Langi = None
    
    
    Language = None
    
    
    LannaScript = None
    
    
    Lao = None
    
    
    LaoScript = None
    
    
    Laos = None
    
    
    LargeFloweryMiao = None
    
    
    LastCountry = None
    
    
    LastLanguage = None
    
    
    LastScript = None
    
    
    Latin = None
    
    
    LatinAmericaAndTheCaribbean = None
    
    
    LatinScript = None
    
    
    Latvia = None
    
    
    Latvian = None
    
    
    Lebanon = None
    
    
    Lepcha = None
    
    
    LepchaScript = None
    
    
    Lesotho = None
    
    
    Lezghian = None
    
    
    Liberia = None
    
    
    Libya = None
    
    
    Liechtenstein = None
    
    
    Limbu = None
    
    
    LimbuScript = None
    
    
    Limburgish = None
    
    
    LinearA = None
    
    
    LinearAScript = None
    
    
    LinearBScript = None
    
    
    Lingala = None
    
    
    Lisu = None
    
    
    Lithuania = None
    
    
    Lithuanian = None
    
    
    LongFormat = None
    
    
    LowGerman = None
    
    
    LowerSorbian = None
    
    
    Lu = None
    
    
    LubaKatanga = None
    
    
    LuleSami = None
    
    
    Luo = None
    
    
    Luxembourg = None
    
    
    Luxembourgish = None
    
    
    Luyia = None
    
    
    Lycian = None
    
    
    LycianScript = None
    
    
    Lydian = None
    
    
    LydianScript = None
    
    
    Macau = None
    
    
    Macedonia = None
    
    
    Macedonian = None
    
    
    Machame = None
    
    
    Madagascar = None
    
    
    MahajaniScript = None
    
    
    Maithili = None
    
    
    MakhuwaMeetto = None
    
    
    Makonde = None
    
    
    Malagasy = None
    
    
    Malawi = None
    
    
    Malay = None
    
    
    Malayalam = None
    
    
    MalayalamScript = None
    
    
    Malaysia = None
    
    
    Maldives = None
    
    
    Mali = None
    
    
    Malta = None
    
    
    Maltese = None
    
    
    MandaeanScript = None
    
    
    Mandingo = None
    
    
    ManichaeanMiddlePersian = None
    
    
    ManichaeanScript = None
    
    
    Manipuri = None
    
    
    Manx = None
    
    
    Maori = None
    
    
    Mapuche = None
    
    
    Marathi = None
    
    
    MarshallIslands = None
    
    
    Marshallese = None
    
    
    Martinique = None
    
    
    Masai = None
    
    
    Mauritania = None
    
    
    Mauritius = None
    
    
    Mayotte = None
    
    
    MeasurementSystem = None
    
    
    MeiteiMayekScript = None
    
    
    Mende = None
    
    
    MendeKikakuiScript = None
    
    
    Meroitic = None
    
    
    MeroiticCursiveScript = None
    
    
    MeroiticScript = None
    
    
    Meru = None
    
    
    Meta = None
    
    
    MetricSystem = None
    
    
    Mexico = None
    
    
    Micronesia = None
    
    
    ModiScript = None
    
    
    Mohawk = None
    
    
    Moldavian = None
    
    
    Moldova = None
    
    
    Monaco = None
    
    
    Mongolia = None
    
    
    Mongolian = None
    
    
    MongolianScript = None
    
    
    Mono = None
    
    
    Montenegro = None
    
    
    Montserrat = None
    
    
    Morisyen = None
    
    
    Morocco = None
    
    
    Mozambique = None
    
    
    MroScript = None
    
    
    Mundang = None
    
    
    Myanmar = None
    
    
    MyanmarScript = None
    
    
    NabataeanScript = None
    
    
    Nama = None
    
    
    Namibia = None
    
    
    NarrowFormat = None
    
    
    NauruCountry = None
    
    
    NauruLanguage = None
    
    
    Navaho = None
    
    
    Ndonga = None
    
    
    Nepal = None
    
    
    Nepali = None
    
    
    Netherlands = None
    
    
    NewCaledonia = None
    
    
    NewTaiLueScript = None
    
    
    NewZealand = None
    
    
    Ngiemboon = None
    
    
    Ngomba = None
    
    
    Nicaragua = None
    
    
    Niger = None
    
    
    Nigeria = None
    
    
    Niue = None
    
    
    Nko = None
    
    
    NkoScript = None
    
    
    NorfolkIsland = None
    
    
    NorthKorea = None
    
    
    NorthNdebele = None
    
    
    NorthernMarianaIslands = None
    
    
    NorthernSami = None
    
    
    NorthernSotho = None
    
    
    NorthernThai = None
    
    
    Norway = None
    
    
    Norwegian = None
    
    
    NorwegianBokmal = None
    
    
    NorwegianNynorsk = None
    
    
    Nuer = None
    
    
    NumberOption = None
    
    
    NumberOptions = None
    
    
    Nyanja = None
    
    
    Nyankole = None
    
    
    Occitan = None
    
    
    OghamScript = None
    
    
    Ojibwa = None
    
    
    OlChikiScript = None
    
    
    OldIrish = None
    
    
    OldItalicScript = None
    
    
    OldNorse = None
    
    
    OldNorthArabianScript = None
    
    
    OldPermicScript = None
    
    
    OldPersian = None
    
    
    OldPersianScript = None
    
    
    OldSouthArabianScript = None
    
    
    OldTurkish = None
    
    
    Oman = None
    
    
    OmitGroupSeparator = None
    
    
    Oriya = None
    
    
    OriyaScript = None
    
    
    OrkhonScript = None
    
    
    Oromo = None
    
    
    OsmanyaScript = None
    
    
    Ossetic = None
    
    
    PahawhHmongScript = None
    
    
    Pahlavi = None
    
    
    Pakistan = None
    
    
    Palau = None
    
    
    PalestinianTerritories = None
    
    
    Pali = None
    
    
    PalmyreneScript = None
    
    
    Panama = None
    
    
    PapuaNewGuinea = None
    
    
    Paraguay = None
    
    
    Parthian = None
    
    
    Pashto = None
    
    
    PauCinHauScript = None
    
    
    PeoplesRepublicOfCongo = None
    
    
    Persian = None
    
    
    Peru = None
    
    
    PhagsPaScript = None
    
    
    Philippines = None
    
    
    Phoenician = None
    
    
    PhoenicianScript = None
    
    
    Pitcairn = None
    
    
    Poland = None
    
    
    Polish = None
    
    
    PollardPhoneticScript = None
    
    
    Portugal = None
    
    
    Portuguese = None
    
    
    PrakritLanguage = None
    
    
    Prussian = None
    
    
    PsalterPahlaviScript = None
    
    
    PuertoRico = None
    
    
    Punjabi = None
    
    
    Qatar = None
    
    
    Quechua = None
    
    
    QuotationStyle = None
    
    
    Rejang = None
    
    
    RejangScript = None
    
    
    RejectGroupSeparator = None
    
    
    RepublicOfKorea = None
    
    
    Reunion = None
    
    
    RhaetoRomance = None
    
    
    Romania = None
    
    
    Romanian = None
    
    
    Romansh = None
    
    
    Rombo = None
    
    
    Rundi = None
    
    
    RunicScript = None
    
    
    Russia = None
    
    
    Russian = None
    
    
    RussianFederation = None
    
    
    Rwa = None
    
    
    Rwanda = None
    
    
    Sabaean = None
    
    
    Saho = None
    
    
    SaintBarthelemy = None
    
    
    SaintHelena = None
    
    
    SaintKittsAndNevis = None
    
    
    SaintLucia = None
    
    
    SaintMartin = None
    
    
    SaintPierreAndMiquelon = None
    
    
    SaintVincentAndTheGrenadines = None
    
    
    Sakha = None
    
    
    Samaritan = None
    
    
    SamaritanScript = None
    
    
    Samburu = None
    
    
    Samoa = None
    
    
    Samoan = None
    
    
    SanMarino = None
    
    
    Sango = None
    
    
    Sangu = None
    
    
    Sanskrit = None
    
    
    Santali = None
    
    
    SaoTomeAndPrincipe = None
    
    
    Sardinian = None
    
    
    SaudiArabia = None
    
    
    Saurashtra = None
    
    
    SaurashtraScript = None
    
    
    Script = None
    
    
    Sena = None
    
    
    Senegal = None
    
    
    Serbia = None
    
    
    Serbian = None
    
    
    SerboCroatian = None
    
    
    Seychelles = None
    
    
    Shambala = None
    
    
    SharadaScript = None
    
    
    ShavianScript = None
    
    
    Shona = None
    
    
    ShortFormat = None
    
    
    SichuanYi = None
    
    
    Sidamo = None
    
    
    SiddhamScript = None
    
    
    SierraLeone = None
    
    
    SimplifiedChineseScript = None
    
    
    SimplifiedHanScript = None
    
    
    Sindhi = None
    
    
    Singapore = None
    
    
    Sinhala = None
    
    
    SinhalaScript = None
    
    
    SintMaarten = None
    
    
    SkoltSami = None
    
    
    Slovak = None
    
    
    Slovakia = None
    
    
    Slovenia = None
    
    
    Slovenian = None
    
    
    Soga = None
    
    
    SolomonIslands = None
    
    
    Somali = None
    
    
    Somalia = None
    
    
    Sora = None
    
    
    SoraSompengScript = None
    
    
    SouthAfrica = None
    
    
    SouthGeorgiaAndTheSouthSandwichIslands = None
    
    
    SouthKorea = None
    
    
    SouthNdebele = None
    
    
    SouthSudan = None
    
    
    SouthernSami = None
    
    
    SouthernSotho = None
    
    
    Spain = None
    
    
    Spanish = None
    
    
    SriLanka = None
    
    
    StandardMoroccanTamazight = None
    
    
    StandardQuotation = None
    
    
    Sudan = None
    
    
    Sundanese = None
    
    
    SundaneseScript = None
    
    
    Suriname = None
    
    
    SvalbardAndJanMayenIslands = None
    
    
    Swahili = None
    
    
    Swati = None
    
    
    Swaziland = None
    
    
    Sweden = None
    
    
    Swedish = None
    
    
    SwissGerman = None
    
    
    Switzerland = None
    
    
    Sylheti = None
    
    
    SylotiNagriScript = None
    
    
    Syria = None
    
    
    Syriac = None
    
    
    SyriacScript = None
    
    
    SyrianArabRepublic = None
    
    
    Tachelhit = None
    
    
    Tagalog = None
    
    
    TagalogScript = None
    
    
    Tagbanwa = None
    
    
    TagbanwaScript = None
    
    
    Tahitian = None
    
    
    TaiDam = None
    
    
    TaiLeScript = None
    
    
    TaiNua = None
    
    
    TaiVietScript = None
    
    
    Taita = None
    
    
    Taiwan = None
    
    
    Tajik = None
    
    
    Tajikistan = None
    
    
    TakriScript = None
    
    
    Tamil = None
    
    
    TamilScript = None
    
    
    Tanzania = None
    
    
    Taroko = None
    
    
    Tasawaq = None
    
    
    Tatar = None
    
    
    TedimChin = None
    
    
    Telugu = None
    
    
    TeluguScript = None
    
    
    Teso = None
    
    
    ThaanaScript = None
    
    
    Thai = None
    
    
    ThaiScript = None
    
    
    Thailand = None
    
    
    Tibetan = None
    
    
    TibetanScript = None
    
    
    TifinaghScript = None
    
    
    Tigre = None
    
    
    Tigrinya = None
    
    
    TirhutaScript = None
    
    
    Togo = None
    
    
    Tokelau = None
    
    
    Tonga = None
    
    
    Tongan = None
    
    
    TraditionalChineseScript = None
    
    
    TraditionalHanScript = None
    
    
    TrinidadAndTobago = None
    
    
    TristanDaCunha = None
    
    
    Tsonga = None
    
    
    Tswana = None
    
    
    Tunisia = None
    
    
    Turkey = None
    
    
    Turkish = None
    
    
    Turkmen = None
    
    
    Turkmenistan = None
    
    
    TurksAndCaicosIslands = None
    
    
    Tuvalu = None
    
    
    Twi = None
    
    
    Tyap = None
    
    
    Uganda = None
    
    
    Ugaritic = None
    
    
    UgariticScript = None
    
    
    Uighur = None
    
    
    Uigur = None
    
    
    Ukraine = None
    
    
    Ukrainian = None
    
    
    UnitedArabEmirates = None
    
    
    UnitedKingdom = None
    
    
    UnitedStates = None
    
    
    UnitedStatesMinorOutlyingIslands = None
    
    
    UnitedStatesVirginIslands = None
    
    
    UpperSorbian = None
    
    
    Urdu = None
    
    
    Uruguay = None
    
    
    Uzbek = None
    
    
    Uzbekistan = None
    
    
    Vai = None
    
    
    VaiScript = None
    
    
    Vanuatu = None
    
    
    VarangKshitiScript = None
    
    
    VaticanCityState = None
    
    
    Venda = None
    
    
    Venezuela = None
    
    
    Vietnam = None
    
    
    Vietnamese = None
    
    
    Volapuk = None
    
    
    Vunjo = None
    
    
    Walamo = None
    
    
    WallisAndFutunaIslands = None
    
    
    Walloon = None
    
    
    Walser = None
    
    
    Warlpiri = None
    
    
    Welsh = None
    
    
    WesternFrisian = None
    
    
    WesternSahara = None
    
    
    Wolof = None
    
    
    Xhosa = None
    
    
    Yangben = None
    
    
    Yemen = None
    
    
    YiScript = None
    
    
    Yiddish = None
    
    
    Yoruba = None
    
    
    Zambia = None
    
    
    Zarma = None
    
    
    Zhuang = None
    
    
    Zimbabwe = None
    
    
    Zulu = None
    
    
    __new__ = None


class QXmlStreamAttribute(_Object):
    def __copy__(*args, **kwargs):
        pass
    
    
    def __eq__(*args, **kwargs):
        """
        x.__eq__(y) <==> x==y
        """
    
        pass
    
    
    def __ge__(*args, **kwargs):
        """
        x.__ge__(y) <==> x>=y
        """
    
        pass
    
    
    def __gt__(*args, **kwargs):
        """
        x.__gt__(y) <==> x>y
        """
    
        pass
    
    
    def __init__(*args, **kwargs):
        """
        x.__init__(...) initializes x; see help(type(x)) for signature
        """
    
        pass
    
    
    def __le__(*args, **kwargs):
        """
        x.__le__(y) <==> x<=y
        """
    
        pass
    
    
    def __lt__(*args, **kwargs):
        """
        x.__lt__(y) <==> x<y
        """
    
        pass
    
    
    def __ne__(*args, **kwargs):
        """
        x.__ne__(y) <==> x!=y
        """
    
        pass
    
    
    def isDefault(*args, **kwargs):
        pass
    
    
    def name(*args, **kwargs):
        pass
    
    
    def namespaceUri(*args, **kwargs):
        pass
    
    
    def prefix(*args, **kwargs):
        pass
    
    
    def qualifiedName(*args, **kwargs):
        pass
    
    
    def value(*args, **kwargs):
        pass
    
    
    __new__ = None


class QXmlStreamNotationDeclaration(_Object):
    def __copy__(*args, **kwargs):
        pass
    
    
    def __eq__(*args, **kwargs):
        """
        x.__eq__(y) <==> x==y
        """
    
        pass
    
    
    def __ge__(*args, **kwargs):
        """
        x.__ge__(y) <==> x>=y
        """
    
        pass
    
    
    def __gt__(*args, **kwargs):
        """
        x.__gt__(y) <==> x>y
        """
    
        pass
    
    
    def __init__(*args, **kwargs):
        """
        x.__init__(...) initializes x; see help(type(x)) for signature
        """
    
        pass
    
    
    def __le__(*args, **kwargs):
        """
        x.__le__(y) <==> x<=y
        """
    
        pass
    
    
    def __lt__(*args, **kwargs):
        """
        x.__lt__(y) <==> x<y
        """
    
        pass
    
    
    def __ne__(*args, **kwargs):
        """
        x.__ne__(y) <==> x!=y
        """
    
        pass
    
    
    def name(*args, **kwargs):
        pass
    
    
    def publicId(*args, **kwargs):
        pass
    
    
    def systemId(*args, **kwargs):
        pass
    
    
    __new__ = None


class QReadWriteLock(_Object):
    def __init__(*args, **kwargs):
        """
        x.__init__(...) initializes x; see help(type(x)) for signature
        """
    
        pass
    
    
    def lockForRead(*args, **kwargs):
        pass
    
    
    def lockForWrite(*args, **kwargs):
        pass
    
    
    def tryLockForRead(*args, **kwargs):
        pass
    
    
    def tryLockForWrite(*args, **kwargs):
        pass
    
    
    def unlock(*args, **kwargs):
        pass
    
    
    NonRecursive = None
    
    
    RecursionMode = None
    
    
    Recursive = None
    
    
    __new__ = None


class QDir(_Object):
    def __copy__(*args, **kwargs):
        pass
    
    
    def __eq__(*args, **kwargs):
        """
        x.__eq__(y) <==> x==y
        """
    
        pass
    
    
    def __ge__(*args, **kwargs):
        """
        x.__ge__(y) <==> x>=y
        """
    
        pass
    
    
    def __gt__(*args, **kwargs):
        """
        x.__gt__(y) <==> x>y
        """
    
        pass
    
    
    def __init__(*args, **kwargs):
        """
        x.__init__(...) initializes x; see help(type(x)) for signature
        """
    
        pass
    
    
    def __le__(*args, **kwargs):
        """
        x.__le__(y) <==> x<=y
        """
    
        pass
    
    
    def __lt__(*args, **kwargs):
        """
        x.__lt__(y) <==> x<y
        """
    
        pass
    
    
    def __ne__(*args, **kwargs):
        """
        x.__ne__(y) <==> x!=y
        """
    
        pass
    
    
    def __reduce__(*args, **kwargs):
        pass
    
    
    def __repr__(*args, **kwargs):
        """
        x.__repr__() <==> repr(x)
        """
    
        pass
    
    
    def absoluteFilePath(*args, **kwargs):
        pass
    
    
    def absolutePath(*args, **kwargs):
        pass
    
    
    def canonicalPath(*args, **kwargs):
        pass
    
    
    def cd(*args, **kwargs):
        pass
    
    
    def cdUp(*args, **kwargs):
        pass
    
    
    def count(*args, **kwargs):
        pass
    
    
    def dirName(*args, **kwargs):
        pass
    
    
    def entryInfoList(*args, **kwargs):
        pass
    
    
    def entryList(*args, **kwargs):
        pass
    
    
    def exists(*args, **kwargs):
        pass
    
    
    def filePath(*args, **kwargs):
        pass
    
    
    def filter(*args, **kwargs):
        pass
    
    
    def isAbsolute(*args, **kwargs):
        pass
    
    
    def isReadable(*args, **kwargs):
        pass
    
    
    def isRelative(*args, **kwargs):
        pass
    
    
    def isRoot(*args, **kwargs):
        pass
    
    
    def makeAbsolute(*args, **kwargs):
        pass
    
    
    def mkdir(*args, **kwargs):
        pass
    
    
    def mkpath(*args, **kwargs):
        pass
    
    
    def nameFilters(*args, **kwargs):
        pass
    
    
    def path(*args, **kwargs):
        pass
    
    
    def refresh(*args, **kwargs):
        pass
    
    
    def relativeFilePath(*args, **kwargs):
        pass
    
    
    def remove(*args, **kwargs):
        pass
    
    
    def removeRecursively(*args, **kwargs):
        pass
    
    
    def rename(*args, **kwargs):
        pass
    
    
    def rmdir(*args, **kwargs):
        pass
    
    
    def rmpath(*args, **kwargs):
        pass
    
    
    def setFilter(*args, **kwargs):
        pass
    
    
    def setNameFilters(*args, **kwargs):
        pass
    
    
    def setPath(*args, **kwargs):
        pass
    
    
    def setSorting(*args, **kwargs):
        pass
    
    
    def sorting(*args, **kwargs):
        pass
    
    
    def swap(*args, **kwargs):
        pass
    
    
    def addResourceSearchPath(*args, **kwargs):
        pass
    
    
    def addSearchPath(*args, **kwargs):
        pass
    
    
    def cleanPath(*args, **kwargs):
        pass
    
    
    def current(*args, **kwargs):
        pass
    
    
    def currentPath(*args, **kwargs):
        pass
    
    
    def drives(*args, **kwargs):
        pass
    
    
    def fromNativeSeparators(*args, **kwargs):
        pass
    
    
    def home(*args, **kwargs):
        pass
    
    
    def homePath(*args, **kwargs):
        pass
    
    
    def isAbsolutePath(*args, **kwargs):
        pass
    
    
    def isRelativePath(*args, **kwargs):
        pass
    
    
    def listSeparator(*args, **kwargs):
        pass
    
    
    def match(*args, **kwargs):
        pass
    
    
    def nameFiltersFromString(*args, **kwargs):
        pass
    
    
    def root(*args, **kwargs):
        pass
    
    
    def rootPath(*args, **kwargs):
        pass
    
    
    def searchPaths(*args, **kwargs):
        pass
    
    
    def separator(*args, **kwargs):
        pass
    
    
    def setCurrent(*args, **kwargs):
        pass
    
    
    def setSearchPaths(*args, **kwargs):
        pass
    
    
    def temp(*args, **kwargs):
        pass
    
    
    def tempPath(*args, **kwargs):
        pass
    
    
    def toNativeSeparators(*args, **kwargs):
        pass
    
    
    AccessMask = None
    
    
    AllDirs = None
    
    
    AllEntries = None
    
    
    CaseSensitive = None
    
    
    Dirs = None
    
    
    DirsFirst = None
    
    
    DirsLast = None
    
    
    Drives = None
    
    
    Executable = None
    
    
    Files = None
    
    
    Filter = None
    
    
    Filters = None
    
    
    Hidden = None
    
    
    IgnoreCase = None
    
    
    LocaleAware = None
    
    
    Modified = None
    
    
    Name = None
    
    
    NoDot = None
    
    
    NoDotAndDotDot = None
    
    
    NoDotDot = None
    
    
    NoFilter = None
    
    
    NoSort = None
    
    
    NoSymLinks = None
    
    
    PermissionMask = None
    
    
    Readable = None
    
    
    Reversed = None
    
    
    Size = None
    
    
    SortByMask = None
    
    
    SortFlag = None
    
    
    SortFlags = None
    
    
    System = None
    
    
    Time = None
    
    
    Type = None
    
    
    TypeMask = None
    
    
    Unsorted = None
    
    
    Writable = None
    
    
    __new__ = None


class QEvent(_Object):
    def __init__(*args, **kwargs):
        """
        x.__init__(...) initializes x; see help(type(x)) for signature
        """
    
        pass
    
    
    def __repr__(*args, **kwargs):
        """
        x.__repr__() <==> repr(x)
        """
    
        pass
    
    
    def accept(*args, **kwargs):
        pass
    
    
    def ignore(*args, **kwargs):
        pass
    
    
    def isAccepted(*args, **kwargs):
        pass
    
    
    def setAccepted(*args, **kwargs):
        pass
    
    
    def spontaneous(*args, **kwargs):
        pass
    
    
    def type(*args, **kwargs):
        pass
    
    
    def registerEventType(*args, **kwargs):
        pass
    
    
    AcceptDropsChange = None
    
    
    ActionAdded = None
    
    
    ActionChanged = None
    
    
    ActionRemoved = None
    
    
    ActivateControl = None
    
    
    ActivationChange = None
    
    
    ApplicationActivate = None
    
    
    ApplicationActivated = None
    
    
    ApplicationDeactivate = None
    
    
    ApplicationDeactivated = None
    
    
    ApplicationFontChange = None
    
    
    ApplicationLayoutDirectionChange = None
    
    
    ApplicationPaletteChange = None
    
    
    ApplicationStateChange = None
    
    
    ApplicationWindowIconChange = None
    
    
    ChildAdded = None
    
    
    ChildPolished = None
    
    
    ChildRemoved = None
    
    
    Clipboard = None
    
    
    Close = None
    
    
    CloseSoftwareInputPanel = None
    
    
    ContentsRectChange = None
    
    
    ContextMenu = None
    
    
    Create = None
    
    
    CursorChange = None
    
    
    DeactivateControl = None
    
    
    DeferredDelete = None
    
    
    Destroy = None
    
    
    DragEnter = None
    
    
    DragLeave = None
    
    
    DragMove = None
    
    
    DragResponse = None
    
    
    Drop = None
    
    
    DynamicPropertyChange = None
    
    
    EmbeddingControl = None
    
    
    EnabledChange = None
    
    
    Enter = None
    
    
    EnterWhatsThisMode = None
    
    
    Expose = None
    
    
    FileOpen = None
    
    
    FocusAboutToChange = None
    
    
    FocusIn = None
    
    
    FocusOut = None
    
    
    FontChange = None
    
    
    FutureCallOut = None
    
    
    Gesture = None
    
    
    GestureOverride = None
    
    
    GrabKeyboard = None
    
    
    GrabMouse = None
    
    
    GraphicsSceneContextMenu = None
    
    
    GraphicsSceneDragEnter = None
    
    
    GraphicsSceneDragLeave = None
    
    
    GraphicsSceneDragMove = None
    
    
    GraphicsSceneDrop = None
    
    
    GraphicsSceneHelp = None
    
    
    GraphicsSceneHoverEnter = None
    
    
    GraphicsSceneHoverLeave = None
    
    
    GraphicsSceneHoverMove = None
    
    
    GraphicsSceneMouseDoubleClick = None
    
    
    GraphicsSceneMouseMove = None
    
    
    GraphicsSceneMousePress = None
    
    
    GraphicsSceneMouseRelease = None
    
    
    GraphicsSceneMove = None
    
    
    GraphicsSceneResize = None
    
    
    GraphicsSceneWheel = None
    
    
    HelpRequest = None
    
    
    Hide = None
    
    
    HideToParent = None
    
    
    HoverEnter = None
    
    
    HoverLeave = None
    
    
    HoverMove = None
    
    
    IconDrag = None
    
    
    IconTextChange = None
    
    
    InputMethod = None
    
    
    InputMethodQuery = None
    
    
    KeyPress = None
    
    
    KeyRelease = None
    
    
    KeyboardLayoutChange = None
    
    
    LanguageChange = None
    
    
    LayoutDirectionChange = None
    
    
    LayoutRequest = None
    
    
    Leave = None
    
    
    LeaveWhatsThisMode = None
    
    
    LocaleChange = None
    
    
    MacGLClearDrawable = None
    
    
    MacGLWindowChange = None
    
    
    MacSizeChange = None
    
    
    MaxUser = None
    
    
    MetaCall = None
    
    
    ModifiedChange = None
    
    
    MouseButtonDblClick = None
    
    
    MouseButtonPress = None
    
    
    MouseButtonRelease = None
    
    
    MouseMove = None
    
    
    MouseTrackingChange = None
    
    
    Move = None
    
    
    NativeGesture = None
    
    
    NetworkReplyUpdated = None
    
    
    NonClientAreaMouseButtonDblClick = None
    
    
    NonClientAreaMouseButtonPress = None
    
    
    NonClientAreaMouseButtonRelease = None
    
    
    NonClientAreaMouseMove = None
    
    
    locals()['None'] = None
    
    
    OkRequest = None
    
    
    OrientationChange = None
    
    
    Paint = None
    
    
    PaletteChange = None
    
    
    ParentAboutToChange = None
    
    
    ParentChange = None
    
    
    PlatformPanel = None
    
    
    PlatformSurface = None
    
    
    Polish = None
    
    
    PolishRequest = None
    
    
    QueryWhatsThis = None
    
    
    Quit = None
    
    
    ReadOnlyChange = None
    
    
    RequestSoftwareInputPanel = None
    
    
    Resize = None
    
    
    ScreenChangeInternal = None
    
    
    Scroll = None
    
    
    ScrollPrepare = None
    
    
    Shortcut = None
    
    
    ShortcutOverride = None
    
    
    Show = None
    
    
    ShowToParent = None
    
    
    ShowWindowRequest = None
    
    
    SockAct = None
    
    
    SockClose = None
    
    
    Speech = None
    
    
    StateMachineSignal = None
    
    
    StateMachineWrapped = None
    
    
    StatusTip = None
    
    
    Style = None
    
    
    StyleAnimationUpdate = None
    
    
    StyleChange = None
    
    
    TabletEnterProximity = None
    
    
    TabletLeaveProximity = None
    
    
    TabletMove = None
    
    
    TabletPress = None
    
    
    TabletRelease = None
    
    
    ThemeChange = None
    
    
    ThreadChange = None
    
    
    Timer = None
    
    
    ToolBarChange = None
    
    
    ToolTip = None
    
    
    ToolTipChange = None
    
    
    TouchBegin = None
    
    
    TouchCancel = None
    
    
    TouchEnd = None
    
    
    TouchUpdate = None
    
    
    Type = None
    
    
    UngrabKeyboard = None
    
    
    UngrabMouse = None
    
    
    UpdateLater = None
    
    
    UpdateRequest = None
    
    
    User = None
    
    
    WhatsThis = None
    
    
    WhatsThisClicked = None
    
    
    Wheel = None
    
    
    WinEventAct = None
    
    
    WinIdChange = None
    
    
    WindowActivate = None
    
    
    WindowBlocked = None
    
    
    WindowChangeInternal = None
    
    
    WindowDeactivate = None
    
    
    WindowIconChange = None
    
    
    WindowStateChange = None
    
    
    WindowTitleChange = None
    
    
    WindowUnblocked = None
    
    
    ZOrderChange = None
    
    
    ZeroTimerEvent = None
    
    
    __new__ = None


class QResource(_Object):
    def __init__(*args, **kwargs):
        """
        x.__init__(...) initializes x; see help(type(x)) for signature
        """
    
        pass
    
    
    def absoluteFilePath(*args, **kwargs):
        pass
    
    
    def children(*args, **kwargs):
        pass
    
    
    def data(*args, **kwargs):
        pass
    
    
    def fileName(*args, **kwargs):
        pass
    
    
    def isCompressed(*args, **kwargs):
        pass
    
    
    def isDir(*args, **kwargs):
        pass
    
    
    def isFile(*args, **kwargs):
        pass
    
    
    def isValid(*args, **kwargs):
        pass
    
    
    def locale(*args, **kwargs):
        pass
    
    
    def setFileName(*args, **kwargs):
        pass
    
    
    def setLocale(*args, **kwargs):
        pass
    
    
    def size(*args, **kwargs):
        pass
    
    
    def addSearchPath(*args, **kwargs):
        pass
    
    
    def registerResource(*args, **kwargs):
        pass
    
    
    def registerResourceData(*args, **kwargs):
        pass
    
    
    def searchPaths(*args, **kwargs):
        pass
    
    
    def unregisterResource(*args, **kwargs):
        pass
    
    
    def unregisterResourceData(*args, **kwargs):
        pass
    
    
    __new__ = None


class Connection(_Object):
    def __init__(*args, **kwargs):
        """
        x.__init__(...) initializes x; see help(type(x)) for signature
        """
    
        pass
    
    
    __new__ = None


class QJsonArray(_Object):
    def __add__(*args, **kwargs):
        """
        x.__add__(y) <==> x+y
        """
    
        pass
    
    
    def __copy__(*args, **kwargs):
        pass
    
    
    def __eq__(*args, **kwargs):
        """
        x.__eq__(y) <==> x==y
        """
    
        pass
    
    
    def __ge__(*args, **kwargs):
        """
        x.__ge__(y) <==> x>=y
        """
    
        pass
    
    
    def __gt__(*args, **kwargs):
        """
        x.__gt__(y) <==> x>y
        """
    
        pass
    
    
    def __iadd__(*args, **kwargs):
        """
        x.__iadd__(y) <==> x+=y
        """
    
        pass
    
    
    def __init__(*args, **kwargs):
        """
        x.__init__(...) initializes x; see help(type(x)) for signature
        """
    
        pass
    
    
    def __le__(*args, **kwargs):
        """
        x.__le__(y) <==> x<=y
        """
    
        pass
    
    
    def __lshift__(*args, **kwargs):
        """
        x.__lshift__(y) <==> x<<y
        """
    
        pass
    
    
    def __lt__(*args, **kwargs):
        """
        x.__lt__(y) <==> x<y
        """
    
        pass
    
    
    def __ne__(*args, **kwargs):
        """
        x.__ne__(y) <==> x!=y
        """
    
        pass
    
    
    def __radd__(*args, **kwargs):
        """
        x.__radd__(y) <==> y+x
        """
    
        pass
    
    
    def __repr__(*args, **kwargs):
        """
        x.__repr__() <==> repr(x)
        """
    
        pass
    
    
    def __rlshift__(*args, **kwargs):
        """
        x.__rlshift__(y) <==> y<<x
        """
    
        pass
    
    
    def append(*args, **kwargs):
        pass
    
    
    def at(*args, **kwargs):
        pass
    
    
    def contains(*args, **kwargs):
        pass
    
    
    def count(*args, **kwargs):
        pass
    
    
    def empty(*args, **kwargs):
        pass
    
    
    def first(*args, **kwargs):
        pass
    
    
    def insert(*args, **kwargs):
        pass
    
    
    def isEmpty(*args, **kwargs):
        pass
    
    
    def last(*args, **kwargs):
        pass
    
    
    def pop_back(*args, **kwargs):
        pass
    
    
    def pop_front(*args, **kwargs):
        pass
    
    
    def prepend(*args, **kwargs):
        pass
    
    
    def push_back(*args, **kwargs):
        pass
    
    
    def push_front(*args, **kwargs):
        pass
    
    
    def removeAt(*args, **kwargs):
        pass
    
    
    def removeFirst(*args, **kwargs):
        pass
    
    
    def removeLast(*args, **kwargs):
        pass
    
    
    def replace(*args, **kwargs):
        pass
    
    
    def size(*args, **kwargs):
        pass
    
    
    def takeAt(*args, **kwargs):
        pass
    
    
    def toVariantList(*args, **kwargs):
        pass
    
    
    def fromStringList(*args, **kwargs):
        pass
    
    
    def fromVariantList(*args, **kwargs):
        pass
    
    
    __new__ = None


class QXmlStreamReader(_Object):
    def __init__(*args, **kwargs):
        """
        x.__init__(...) initializes x; see help(type(x)) for signature
        """
    
        pass
    
    
    def addData(*args, **kwargs):
        pass
    
    
    def addExtraNamespaceDeclaration(*args, **kwargs):
        pass
    
    
    def addExtraNamespaceDeclarations(*args, **kwargs):
        pass
    
    
    def atEnd(*args, **kwargs):
        pass
    
    
    def attributes(*args, **kwargs):
        pass
    
    
    def characterOffset(*args, **kwargs):
        pass
    
    
    def clear(*args, **kwargs):
        pass
    
    
    def columnNumber(*args, **kwargs):
        pass
    
    
    def device(*args, **kwargs):
        pass
    
    
    def documentEncoding(*args, **kwargs):
        pass
    
    
    def documentVersion(*args, **kwargs):
        pass
    
    
    def dtdName(*args, **kwargs):
        pass
    
    
    def dtdPublicId(*args, **kwargs):
        pass
    
    
    def dtdSystemId(*args, **kwargs):
        pass
    
    
    def entityDeclarations(*args, **kwargs):
        pass
    
    
    def entityResolver(*args, **kwargs):
        pass
    
    
    def error(*args, **kwargs):
        pass
    
    
    def errorString(*args, **kwargs):
        pass
    
    
    def hasError(*args, **kwargs):
        pass
    
    
    def isCDATA(*args, **kwargs):
        pass
    
    
    def isCharacters(*args, **kwargs):
        pass
    
    
    def isComment(*args, **kwargs):
        pass
    
    
    def isDTD(*args, **kwargs):
        pass
    
    
    def isEndDocument(*args, **kwargs):
        pass
    
    
    def isEndElement(*args, **kwargs):
        pass
    
    
    def isEntityReference(*args, **kwargs):
        pass
    
    
    def isProcessingInstruction(*args, **kwargs):
        pass
    
    
    def isStandaloneDocument(*args, **kwargs):
        pass
    
    
    def isStartDocument(*args, **kwargs):
        pass
    
    
    def isStartElement(*args, **kwargs):
        pass
    
    
    def isWhitespace(*args, **kwargs):
        pass
    
    
    def lineNumber(*args, **kwargs):
        pass
    
    
    def name(*args, **kwargs):
        pass
    
    
    def namespaceDeclarations(*args, **kwargs):
        pass
    
    
    def namespaceProcessing(*args, **kwargs):
        pass
    
    
    def namespaceUri(*args, **kwargs):
        pass
    
    
    def notationDeclarations(*args, **kwargs):
        pass
    
    
    def prefix(*args, **kwargs):
        pass
    
    
    def processingInstructionData(*args, **kwargs):
        pass
    
    
    def processingInstructionTarget(*args, **kwargs):
        pass
    
    
    def qualifiedName(*args, **kwargs):
        pass
    
    
    def raiseError(*args, **kwargs):
        pass
    
    
    def readElementText(*args, **kwargs):
        pass
    
    
    def readNext(*args, **kwargs):
        pass
    
    
    def readNextStartElement(*args, **kwargs):
        pass
    
    
    def setDevice(*args, **kwargs):
        pass
    
    
    def setEntityResolver(*args, **kwargs):
        pass
    
    
    def setNamespaceProcessing(*args, **kwargs):
        pass
    
    
    def skipCurrentElement(*args, **kwargs):
        pass
    
    
    def text(*args, **kwargs):
        pass
    
    
    def tokenString(*args, **kwargs):
        pass
    
    
    def tokenType(*args, **kwargs):
        pass
    
    
    Characters = None
    
    
    Comment = None
    
    
    CustomError = None
    
    
    DTD = None
    
    
    EndDocument = None
    
    
    EndElement = None
    
    
    EntityReference = None
    
    
    Error = None
    
    
    ErrorOnUnexpectedElement = None
    
    
    IncludeChildElements = None
    
    
    Invalid = None
    
    
    NoError = None
    
    
    NoToken = None
    
    
    NotWellFormedError = None
    
    
    PrematureEndOfDocumentError = None
    
    
    ProcessingInstruction = None
    
    
    ReadElementTextBehaviour = None
    
    
    SkipChildElements = None
    
    
    StartDocument = None
    
    
    StartElement = None
    
    
    TokenType = None
    
    
    UnexpectedElementError = None
    
    
    __new__ = None


class QSize(_Object):
    def __add__(*args, **kwargs):
        """
        x.__add__(y) <==> x+y
        """
    
        pass
    
    
    def __copy__(*args, **kwargs):
        pass
    
    
    def __div__(*args, **kwargs):
        """
        x.__div__(y) <==> x/y
        """
    
        pass
    
    
    def __eq__(*args, **kwargs):
        """
        x.__eq__(y) <==> x==y
        """
    
        pass
    
    
    def __ge__(*args, **kwargs):
        """
        x.__ge__(y) <==> x>=y
        """
    
        pass
    
    
    def __gt__(*args, **kwargs):
        """
        x.__gt__(y) <==> x>y
        """
    
        pass
    
    
    def __hash__(*args, **kwargs):
        """
        x.__hash__() <==> hash(x)
        """
    
        pass
    
    
    def __iadd__(*args, **kwargs):
        """
        x.__iadd__(y) <==> x+=y
        """
    
        pass
    
    
    def __init__(*args, **kwargs):
        """
        x.__init__(...) initializes x; see help(type(x)) for signature
        """
    
        pass
    
    
    def __isub__(*args, **kwargs):
        """
        x.__isub__(y) <==> x-=y
        """
    
        pass
    
    
    def __le__(*args, **kwargs):
        """
        x.__le__(y) <==> x<=y
        """
    
        pass
    
    
    def __lt__(*args, **kwargs):
        """
        x.__lt__(y) <==> x<y
        """
    
        pass
    
    
    def __mul__(*args, **kwargs):
        """
        x.__mul__(y) <==> x*y
        """
    
        pass
    
    
    def __ne__(*args, **kwargs):
        """
        x.__ne__(y) <==> x!=y
        """
    
        pass
    
    
    def __nonzero__(*args, **kwargs):
        """
        x.__nonzero__() <==> x != 0
        """
    
        pass
    
    
    def __radd__(*args, **kwargs):
        """
        x.__radd__(y) <==> y+x
        """
    
        pass
    
    
    def __rdiv__(*args, **kwargs):
        """
        x.__rdiv__(y) <==> y/x
        """
    
        pass
    
    
    def __reduce__(*args, **kwargs):
        pass
    
    
    def __repr__(*args, **kwargs):
        """
        x.__repr__() <==> repr(x)
        """
    
        pass
    
    
    def __rmul__(*args, **kwargs):
        """
        x.__rmul__(y) <==> y*x
        """
    
        pass
    
    
    def __rsub__(*args, **kwargs):
        """
        x.__rsub__(y) <==> y-x
        """
    
        pass
    
    
    def __rtruediv__(*args, **kwargs):
        """
        x.__rtruediv__(y) <==> y/x
        """
    
        pass
    
    
    def __sub__(*args, **kwargs):
        """
        x.__sub__(y) <==> x-y
        """
    
        pass
    
    
    def __truediv__(*args, **kwargs):
        """
        x.__truediv__(y) <==> x/y
        """
    
        pass
    
    
    def boundedTo(*args, **kwargs):
        pass
    
    
    def expandedTo(*args, **kwargs):
        pass
    
    
    def height(*args, **kwargs):
        pass
    
    
    def isEmpty(*args, **kwargs):
        pass
    
    
    def isNull(*args, **kwargs):
        pass
    
    
    def isValid(*args, **kwargs):
        pass
    
    
    def scale(*args, **kwargs):
        pass
    
    
    def scaled(*args, **kwargs):
        pass
    
    
    def setHeight(*args, **kwargs):
        pass
    
    
    def setWidth(*args, **kwargs):
        pass
    
    
    def toTuple(*args, **kwargs):
        pass
    
    
    def transpose(*args, **kwargs):
        pass
    
    
    def transposed(*args, **kwargs):
        pass
    
    
    def width(*args, **kwargs):
        pass
    
    
    __new__ = None


class QPointF(_Object):
    def __add__(*args, **kwargs):
        """
        x.__add__(y) <==> x+y
        """
    
        pass
    
    
    def __copy__(*args, **kwargs):
        pass
    
    
    def __div__(*args, **kwargs):
        """
        x.__div__(y) <==> x/y
        """
    
        pass
    
    
    def __eq__(*args, **kwargs):
        """
        x.__eq__(y) <==> x==y
        """
    
        pass
    
    
    def __ge__(*args, **kwargs):
        """
        x.__ge__(y) <==> x>=y
        """
    
        pass
    
    
    def __gt__(*args, **kwargs):
        """
        x.__gt__(y) <==> x>y
        """
    
        pass
    
    
    def __iadd__(*args, **kwargs):
        """
        x.__iadd__(y) <==> x+=y
        """
    
        pass
    
    
    def __init__(*args, **kwargs):
        """
        x.__init__(...) initializes x; see help(type(x)) for signature
        """
    
        pass
    
    
    def __isub__(*args, **kwargs):
        """
        x.__isub__(y) <==> x-=y
        """
    
        pass
    
    
    def __le__(*args, **kwargs):
        """
        x.__le__(y) <==> x<=y
        """
    
        pass
    
    
    def __lt__(*args, **kwargs):
        """
        x.__lt__(y) <==> x<y
        """
    
        pass
    
    
    def __mul__(*args, **kwargs):
        """
        x.__mul__(y) <==> x*y
        """
    
        pass
    
    
    def __ne__(*args, **kwargs):
        """
        x.__ne__(y) <==> x!=y
        """
    
        pass
    
    
    def __neg__(*args, **kwargs):
        """
        x.__neg__() <==> -x
        """
    
        pass
    
    
    def __nonzero__(*args, **kwargs):
        """
        x.__nonzero__() <==> x != 0
        """
    
        pass
    
    
    def __pos__(*args, **kwargs):
        """
        x.__pos__() <==> +x
        """
    
        pass
    
    
    def __radd__(*args, **kwargs):
        """
        x.__radd__(y) <==> y+x
        """
    
        pass
    
    
    def __rdiv__(*args, **kwargs):
        """
        x.__rdiv__(y) <==> y/x
        """
    
        pass
    
    
    def __reduce__(*args, **kwargs):
        pass
    
    
    def __repr__(*args, **kwargs):
        """
        x.__repr__() <==> repr(x)
        """
    
        pass
    
    
    def __rmul__(*args, **kwargs):
        """
        x.__rmul__(y) <==> y*x
        """
    
        pass
    
    
    def __rsub__(*args, **kwargs):
        """
        x.__rsub__(y) <==> y-x
        """
    
        pass
    
    
    def __rtruediv__(*args, **kwargs):
        """
        x.__rtruediv__(y) <==> y/x
        """
    
        pass
    
    
    def __sub__(*args, **kwargs):
        """
        x.__sub__(y) <==> x-y
        """
    
        pass
    
    
    def __truediv__(*args, **kwargs):
        """
        x.__truediv__(y) <==> x/y
        """
    
        pass
    
    
    def isNull(*args, **kwargs):
        pass
    
    
    def manhattanLength(*args, **kwargs):
        pass
    
    
    def setX(*args, **kwargs):
        pass
    
    
    def setY(*args, **kwargs):
        pass
    
    
    def toPoint(*args, **kwargs):
        pass
    
    
    def toTuple(*args, **kwargs):
        pass
    
    
    def x(*args, **kwargs):
        pass
    
    
    def y(*args, **kwargs):
        pass
    
    
    def dotProduct(*args, **kwargs):
        pass
    
    
    __new__ = None


class QMutexLocker(_Object):
    def __enter__(*args, **kwargs):
        pass
    
    
    def __exit__(*args, **kwargs):
        pass
    
    
    def __init__(*args, **kwargs):
        """
        x.__init__(...) initializes x; see help(type(x)) for signature
        """
    
        pass
    
    
    def mutex(*args, **kwargs):
        pass
    
    
    def relock(*args, **kwargs):
        pass
    
    
    def unlock(*args, **kwargs):
        pass
    
    
    __new__ = None


class QRunnable(_Object):
    def __init__(*args, **kwargs):
        """
        x.__init__(...) initializes x; see help(type(x)) for signature
        """
    
        pass
    
    
    def autoDelete(*args, **kwargs):
        pass
    
    
    def run(*args, **kwargs):
        pass
    
    
    def setAutoDelete(*args, **kwargs):
        pass
    
    
    __new__ = None


class QUrl(_Object):
    def __copy__(*args, **kwargs):
        pass
    
    
    def __eq__(*args, **kwargs):
        """
        x.__eq__(y) <==> x==y
        """
    
        pass
    
    
    def __ge__(*args, **kwargs):
        """
        x.__ge__(y) <==> x>=y
        """
    
        pass
    
    
    def __gt__(*args, **kwargs):
        """
        x.__gt__(y) <==> x>y
        """
    
        pass
    
    
    def __hash__(*args, **kwargs):
        """
        x.__hash__() <==> hash(x)
        """
    
        pass
    
    
    def __init__(*args, **kwargs):
        """
        x.__init__(...) initializes x; see help(type(x)) for signature
        """
    
        pass
    
    
    def __le__(*args, **kwargs):
        """
        x.__le__(y) <==> x<=y
        """
    
        pass
    
    
    def __lt__(*args, **kwargs):
        """
        x.__lt__(y) <==> x<y
        """
    
        pass
    
    
    def __ne__(*args, **kwargs):
        """
        x.__ne__(y) <==> x!=y
        """
    
        pass
    
    
    def __reduce__(*args, **kwargs):
        pass
    
    
    def __repr__(*args, **kwargs):
        """
        x.__repr__() <==> repr(x)
        """
    
        pass
    
    
    def adjusted(*args, **kwargs):
        pass
    
    
    def clear(*args, **kwargs):
        pass
    
    
    def errorString(*args, **kwargs):
        pass
    
    
    def hasFragment(*args, **kwargs):
        pass
    
    
    def hasQuery(*args, **kwargs):
        pass
    
    
    def isEmpty(*args, **kwargs):
        pass
    
    
    def isLocalFile(*args, **kwargs):
        pass
    
    
    def isParentOf(*args, **kwargs):
        pass
    
    
    def isRelative(*args, **kwargs):
        pass
    
    
    def isValid(*args, **kwargs):
        pass
    
    
    def matches(*args, **kwargs):
        pass
    
    
    def port(*args, **kwargs):
        pass
    
    
    def resolved(*args, **kwargs):
        pass
    
    
    def scheme(*args, **kwargs):
        pass
    
    
    def setAuthority(*args, **kwargs):
        pass
    
    
    def setFragment(*args, **kwargs):
        pass
    
    
    def setHost(*args, **kwargs):
        pass
    
    
    def setPassword(*args, **kwargs):
        pass
    
    
    def setPath(*args, **kwargs):
        pass
    
    
    def setPort(*args, **kwargs):
        pass
    
    
    def setQuery(*args, **kwargs):
        pass
    
    
    def setScheme(*args, **kwargs):
        pass
    
    
    def setUrl(*args, **kwargs):
        pass
    
    
    def setUserInfo(*args, **kwargs):
        pass
    
    
    def setUserName(*args, **kwargs):
        pass
    
    
    def swap(*args, **kwargs):
        pass
    
    
    def toDisplayString(*args, **kwargs):
        pass
    
    
    def toEncoded(*args, **kwargs):
        pass
    
    
    def toLocalFile(*args, **kwargs):
        pass
    
    
    def toString(*args, **kwargs):
        pass
    
    
    def url(*args, **kwargs):
        pass
    
    
    def fromAce(*args, **kwargs):
        pass
    
    
    def fromEncoded(*args, **kwargs):
        pass
    
    
    def fromLocalFile(*args, **kwargs):
        pass
    
    
    def fromPercentEncoding(*args, **kwargs):
        pass
    
    
    def fromStringList(*args, **kwargs):
        pass
    
    
    def fromUserInput(*args, **kwargs):
        pass
    
    
    def idnWhitelist(*args, **kwargs):
        pass
    
    
    def setIdnWhitelist(*args, **kwargs):
        pass
    
    
    def toAce(*args, **kwargs):
        pass
    
    
    def toPercentEncoding(*args, **kwargs):
        pass
    
    
    def toStringList(*args, **kwargs):
        pass
    
    
    AssumeLocalFile = None
    
    
    ComponentFormattingOption = None
    
    
    DecodeReserved = None
    
    
    DecodedMode = None
    
    
    DefaultResolution = None
    
    
    EncodeDelimiters = None
    
    
    EncodeReserved = None
    
    
    EncodeSpaces = None
    
    
    EncodeUnicode = None
    
    
    FormattingOptions = None
    
    
    FullyDecoded = None
    
    
    FullyEncoded = None
    
    
    locals()['None'] = None
    
    
    NormalizePathSegments = None
    
    
    ParsingMode = None
    
    
    PreferLocalFile = None
    
    
    PrettyDecoded = None
    
    
    RemoveAuthority = None
    
    
    RemoveFilename = None
    
    
    RemoveFragment = None
    
    
    RemovePassword = None
    
    
    RemovePath = None
    
    
    RemovePort = None
    
    
    RemoveQuery = None
    
    
    RemoveScheme = None
    
    
    RemoveUserInfo = None
    
    
    StrictMode = None
    
    
    StripTrailingSlash = None
    
    
    TolerantMode = None
    
    
    UrlFormattingOption = None
    
    
    UserInputResolutionOption = None
    
    
    UserInputResolutionOptions = None
    
    
    __new__ = None


class QObject(_Object):
    def __delattr__(*args, **kwargs):
        """
        x.__delattr__('name') <==> del x.name
        """
    
        pass
    
    
    def __getattribute__(*args, **kwargs):
        """
        x.__getattribute__('name') <==> x.name
        """
    
        pass
    
    
    def __init__(*args, **kwargs):
        """
        x.__init__(...) initializes x; see help(type(x)) for signature
        """
    
        pass
    
    
    def __setattr__(*args, **kwargs):
        """
        x.__setattr__('name', value) <==> x.name = value
        """
    
        pass
    
    
    def blockSignals(*args, **kwargs):
        pass
    
    
    def childEvent(*args, **kwargs):
        pass
    
    
    def children(*args, **kwargs):
        pass
    
    
    def connectNotify(*args, **kwargs):
        pass
    
    
    def customEvent(*args, **kwargs):
        pass
    
    
    def deleteLater(*args, **kwargs):
        pass
    
    
    def disconnectNotify(*args, **kwargs):
        pass
    
    
    def dumpObjectInfo(*args, **kwargs):
        pass
    
    
    def dumpObjectTree(*args, **kwargs):
        pass
    
    
    def dynamicPropertyNames(*args, **kwargs):
        pass
    
    
    def emit(*args, **kwargs):
        pass
    
    
    def event(*args, **kwargs):
        pass
    
    
    def eventFilter(*args, **kwargs):
        pass
    
    
    def findChild(*args, **kwargs):
        pass
    
    
    def findChildren(*args, **kwargs):
        pass
    
    
    def inherits(*args, **kwargs):
        pass
    
    
    def installEventFilter(*args, **kwargs):
        pass
    
    
    def isSignalConnected(*args, **kwargs):
        pass
    
    
    def isWidgetType(*args, **kwargs):
        pass
    
    
    def isWindowType(*args, **kwargs):
        pass
    
    
    def killTimer(*args, **kwargs):
        pass
    
    
    def metaObject(*args, **kwargs):
        pass
    
    
    def moveToThread(*args, **kwargs):
        pass
    
    
    def objectName(*args, **kwargs):
        pass
    
    
    def parent(*args, **kwargs):
        pass
    
    
    def property(*args, **kwargs):
        pass
    
    
    def receivers(*args, **kwargs):
        pass
    
    
    def removeEventFilter(*args, **kwargs):
        pass
    
    
    def sender(*args, **kwargs):
        pass
    
    
    def senderSignalIndex(*args, **kwargs):
        pass
    
    
    def setObjectName(*args, **kwargs):
        pass
    
    
    def setParent(*args, **kwargs):
        pass
    
    
    def setProperty(*args, **kwargs):
        pass
    
    
    def signalsBlocked(*args, **kwargs):
        pass
    
    
    def startTimer(*args, **kwargs):
        pass
    
    
    def thread(*args, **kwargs):
        pass
    
    
    def timerEvent(*args, **kwargs):
        pass
    
    
    def tr(*args, **kwargs):
        pass
    
    
    def connect(*args, **kwargs):
        pass
    
    
    def disconnect(*args, **kwargs):
        pass
    
    
    def registerUserData(*args, **kwargs):
        pass
    
    
    __new__ = None
    
    
    destroyed = None
    
    
    objectNameChanged = None
    
    
    staticMetaObject = None


class QJsonDocument(_Object):
    def __copy__(*args, **kwargs):
        pass
    
    
    def __eq__(*args, **kwargs):
        """
        x.__eq__(y) <==> x==y
        """
    
        pass
    
    
    def __ge__(*args, **kwargs):
        """
        x.__ge__(y) <==> x>=y
        """
    
        pass
    
    
    def __gt__(*args, **kwargs):
        """
        x.__gt__(y) <==> x>y
        """
    
        pass
    
    
    def __init__(*args, **kwargs):
        """
        x.__init__(...) initializes x; see help(type(x)) for signature
        """
    
        pass
    
    
    def __le__(*args, **kwargs):
        """
        x.__le__(y) <==> x<=y
        """
    
        pass
    
    
    def __lt__(*args, **kwargs):
        """
        x.__lt__(y) <==> x<y
        """
    
        pass
    
    
    def __ne__(*args, **kwargs):
        """
        x.__ne__(y) <==> x!=y
        """
    
        pass
    
    
    def __nonzero__(*args, **kwargs):
        """
        x.__nonzero__() <==> x != 0
        """
    
        pass
    
    
    def __repr__(*args, **kwargs):
        """
        x.__repr__() <==> repr(x)
        """
    
        pass
    
    
    def array(*args, **kwargs):
        pass
    
    
    def isArray(*args, **kwargs):
        pass
    
    
    def isEmpty(*args, **kwargs):
        pass
    
    
    def isNull(*args, **kwargs):
        pass
    
    
    def isObject(*args, **kwargs):
        pass
    
    
    def object(*args, **kwargs):
        pass
    
    
    def rawData(*args, **kwargs):
        pass
    
    
    def setArray(*args, **kwargs):
        pass
    
    
    def setObject(*args, **kwargs):
        pass
    
    
    def toBinaryData(*args, **kwargs):
        pass
    
    
    def toJson(*args, **kwargs):
        pass
    
    
    def toVariant(*args, **kwargs):
        pass
    
    
    def fromBinaryData(*args, **kwargs):
        pass
    
    
    def fromJson(*args, **kwargs):
        pass
    
    
    def fromRawData(*args, **kwargs):
        pass
    
    
    def fromVariant(*args, **kwargs):
        pass
    
    
    BypassValidation = None
    
    
    Compact = None
    
    
    DataValidation = None
    
    
    Indented = None
    
    
    JsonFormat = None
    
    
    Validate = None
    
    
    __new__ = None


class QXmlStreamAttributes(_Object):
    def __add__(*args, **kwargs):
        """
        x.__add__(y) <==> x+y
        """
    
        pass
    
    
    def __copy__(*args, **kwargs):
        pass
    
    
    def __delitem__(*args, **kwargs):
        """
        x.__delitem__(y) <==> del x[y]
        """
    
        pass
    
    
    def __eq__(*args, **kwargs):
        """
        x.__eq__(y) <==> x==y
        """
    
        pass
    
    
    def __ge__(*args, **kwargs):
        """
        x.__ge__(y) <==> x>=y
        """
    
        pass
    
    
    def __getitem__(*args, **kwargs):
        """
        x.__getitem__(y) <==> x[y]
        """
    
        pass
    
    
    def __gt__(*args, **kwargs):
        """
        x.__gt__(y) <==> x>y
        """
    
        pass
    
    
    def __iadd__(*args, **kwargs):
        """
        x.__iadd__(y) <==> x+=y
        """
    
        pass
    
    
    def __init__(*args, **kwargs):
        """
        x.__init__(...) initializes x; see help(type(x)) for signature
        """
    
        pass
    
    
    def __le__(*args, **kwargs):
        """
        x.__le__(y) <==> x<=y
        """
    
        pass
    
    
    def __len__(*args, **kwargs):
        """
        x.__len__() <==> len(x)
        """
    
        pass
    
    
    def __lshift__(*args, **kwargs):
        """
        x.__lshift__(y) <==> x<<y
        """
    
        pass
    
    
    def __lt__(*args, **kwargs):
        """
        x.__lt__(y) <==> x<y
        """
    
        pass
    
    
    def __ne__(*args, **kwargs):
        """
        x.__ne__(y) <==> x!=y
        """
    
        pass
    
    
    def __radd__(*args, **kwargs):
        """
        x.__radd__(y) <==> y+x
        """
    
        pass
    
    
    def __rlshift__(*args, **kwargs):
        """
        x.__rlshift__(y) <==> y<<x
        """
    
        pass
    
    
    def __setitem__(*args, **kwargs):
        """
        x.__setitem__(i, y) <==> x[i]=y
        """
    
        pass
    
    
    def append(*args, **kwargs):
        pass
    
    
    def at(*args, **kwargs):
        pass
    
    
    def capacity(*args, **kwargs):
        pass
    
    
    def clear(*args, **kwargs):
        pass
    
    
    def constData(*args, **kwargs):
        pass
    
    
    def constFirst(*args, **kwargs):
        pass
    
    
    def constLast(*args, **kwargs):
        pass
    
    
    def contains(*args, **kwargs):
        pass
    
    
    def count(*args, **kwargs):
        pass
    
    
    def data(*args, **kwargs):
        pass
    
    
    def empty(*args, **kwargs):
        pass
    
    
    def endsWith(*args, **kwargs):
        pass
    
    
    def fill(*args, **kwargs):
        pass
    
    
    def first(*args, **kwargs):
        pass
    
    
    def front(*args, **kwargs):
        pass
    
    
    def hasAttribute(*args, **kwargs):
        pass
    
    
    def indexOf(*args, **kwargs):
        pass
    
    
    def insert(*args, **kwargs):
        pass
    
    
    def isEmpty(*args, **kwargs):
        pass
    
    
    def isSharedWith(*args, **kwargs):
        pass
    
    
    def last(*args, **kwargs):
        pass
    
    
    def lastIndexOf(*args, **kwargs):
        pass
    
    
    def length(*args, **kwargs):
        pass
    
    
    def mid(*args, **kwargs):
        pass
    
    
    def move(*args, **kwargs):
        pass
    
    
    def prepend(*args, **kwargs):
        pass
    
    
    def remove(*args, **kwargs):
        pass
    
    
    def removeAll(*args, **kwargs):
        pass
    
    
    def removeAt(*args, **kwargs):
        pass
    
    
    def removeFirst(*args, **kwargs):
        pass
    
    
    def removeLast(*args, **kwargs):
        pass
    
    
    def removeOne(*args, **kwargs):
        pass
    
    
    def replace(*args, **kwargs):
        pass
    
    
    def reserve(*args, **kwargs):
        pass
    
    
    def resize(*args, **kwargs):
        pass
    
    
    def setSharable(*args, **kwargs):
        pass
    
    
    def size(*args, **kwargs):
        pass
    
    
    def squeeze(*args, **kwargs):
        pass
    
    
    def startsWith(*args, **kwargs):
        pass
    
    
    def swap(*args, **kwargs):
        pass
    
    
    def takeAt(*args, **kwargs):
        pass
    
    
    def takeFirst(*args, **kwargs):
        pass
    
    
    def takeLast(*args, **kwargs):
        pass
    
    
    def value(*args, **kwargs):
        pass
    
    
    __new__ = None


class QTextCodec(_Object):
    def __init__(*args, **kwargs):
        """
        x.__init__(...) initializes x; see help(type(x)) for signature
        """
    
        pass
    
    
    def aliases(*args, **kwargs):
        pass
    
    
    def canEncode(*args, **kwargs):
        pass
    
    
    def convertToUnicode(*args, **kwargs):
        pass
    
    
    def fromUnicode(*args, **kwargs):
        pass
    
    
    def makeDecoder(*args, **kwargs):
        pass
    
    
    def makeEncoder(*args, **kwargs):
        pass
    
    
    def mibEnum(*args, **kwargs):
        pass
    
    
    def name(*args, **kwargs):
        pass
    
    
    def toUnicode(*args, **kwargs):
        pass
    
    
    def availableCodecs(*args, **kwargs):
        pass
    
    
    def availableMibs(*args, **kwargs):
        pass
    
    
    def codecForHtml(*args, **kwargs):
        pass
    
    
    def codecForLocale(*args, **kwargs):
        pass
    
    
    def codecForMib(*args, **kwargs):
        pass
    
    
    def codecForName(*args, **kwargs):
        pass
    
    
    def codecForUtfText(*args, **kwargs):
        pass
    
    
    def setCodecForLocale(*args, **kwargs):
        pass
    
    
    ConversionFlag = None
    
    
    ConversionFlags = None
    
    
    ConvertInvalidToNull = None
    
    
    ConverterState = None
    
    
    DefaultConversion = None
    
    
    FreeFunction = None
    
    
    IgnoreHeader = None
    
    
    __new__ = None


class QItemSelectionRange(_Object):
    def __copy__(*args, **kwargs):
        pass
    
    
    def __eq__(*args, **kwargs):
        """
        x.__eq__(y) <==> x==y
        """
    
        pass
    
    
    def __ge__(*args, **kwargs):
        """
        x.__ge__(y) <==> x>=y
        """
    
        pass
    
    
    def __gt__(*args, **kwargs):
        """
        x.__gt__(y) <==> x>y
        """
    
        pass
    
    
    def __hash__(*args, **kwargs):
        """
        x.__hash__() <==> hash(x)
        """
    
        pass
    
    
    def __init__(*args, **kwargs):
        """
        x.__init__(...) initializes x; see help(type(x)) for signature
        """
    
        pass
    
    
    def __le__(*args, **kwargs):
        """
        x.__le__(y) <==> x<=y
        """
    
        pass
    
    
    def __lt__(*args, **kwargs):
        """
        x.__lt__(y) <==> x<y
        """
    
        pass
    
    
    def __ne__(*args, **kwargs):
        """
        x.__ne__(y) <==> x!=y
        """
    
        pass
    
    
    def __repr__(*args, **kwargs):
        """
        x.__repr__() <==> repr(x)
        """
    
        pass
    
    
    def bottom(*args, **kwargs):
        pass
    
    
    def bottomRight(*args, **kwargs):
        pass
    
    
    def contains(*args, **kwargs):
        pass
    
    
    def height(*args, **kwargs):
        pass
    
    
    def indexes(*args, **kwargs):
        pass
    
    
    def intersected(*args, **kwargs):
        pass
    
    
    def intersects(*args, **kwargs):
        pass
    
    
    def isEmpty(*args, **kwargs):
        pass
    
    
    def isValid(*args, **kwargs):
        pass
    
    
    def left(*args, **kwargs):
        pass
    
    
    def model(*args, **kwargs):
        pass
    
    
    def parent(*args, **kwargs):
        pass
    
    
    def right(*args, **kwargs):
        pass
    
    
    def swap(*args, **kwargs):
        pass
    
    
    def top(*args, **kwargs):
        pass
    
    
    def topLeft(*args, **kwargs):
        pass
    
    
    def width(*args, **kwargs):
        pass
    
    
    __new__ = None


class QSizeF(_Object):
    def __add__(*args, **kwargs):
        """
        x.__add__(y) <==> x+y
        """
    
        pass
    
    
    def __copy__(*args, **kwargs):
        pass
    
    
    def __div__(*args, **kwargs):
        """
        x.__div__(y) <==> x/y
        """
    
        pass
    
    
    def __eq__(*args, **kwargs):
        """
        x.__eq__(y) <==> x==y
        """
    
        pass
    
    
    def __ge__(*args, **kwargs):
        """
        x.__ge__(y) <==> x>=y
        """
    
        pass
    
    
    def __gt__(*args, **kwargs):
        """
        x.__gt__(y) <==> x>y
        """
    
        pass
    
    
    def __iadd__(*args, **kwargs):
        """
        x.__iadd__(y) <==> x+=y
        """
    
        pass
    
    
    def __init__(*args, **kwargs):
        """
        x.__init__(...) initializes x; see help(type(x)) for signature
        """
    
        pass
    
    
    def __isub__(*args, **kwargs):
        """
        x.__isub__(y) <==> x-=y
        """
    
        pass
    
    
    def __le__(*args, **kwargs):
        """
        x.__le__(y) <==> x<=y
        """
    
        pass
    
    
    def __lt__(*args, **kwargs):
        """
        x.__lt__(y) <==> x<y
        """
    
        pass
    
    
    def __mul__(*args, **kwargs):
        """
        x.__mul__(y) <==> x*y
        """
    
        pass
    
    
    def __ne__(*args, **kwargs):
        """
        x.__ne__(y) <==> x!=y
        """
    
        pass
    
    
    def __nonzero__(*args, **kwargs):
        """
        x.__nonzero__() <==> x != 0
        """
    
        pass
    
    
    def __radd__(*args, **kwargs):
        """
        x.__radd__(y) <==> y+x
        """
    
        pass
    
    
    def __rdiv__(*args, **kwargs):
        """
        x.__rdiv__(y) <==> y/x
        """
    
        pass
    
    
    def __reduce__(*args, **kwargs):
        pass
    
    
    def __repr__(*args, **kwargs):
        """
        x.__repr__() <==> repr(x)
        """
    
        pass
    
    
    def __rmul__(*args, **kwargs):
        """
        x.__rmul__(y) <==> y*x
        """
    
        pass
    
    
    def __rsub__(*args, **kwargs):
        """
        x.__rsub__(y) <==> y-x
        """
    
        pass
    
    
    def __rtruediv__(*args, **kwargs):
        """
        x.__rtruediv__(y) <==> y/x
        """
    
        pass
    
    
    def __sub__(*args, **kwargs):
        """
        x.__sub__(y) <==> x-y
        """
    
        pass
    
    
    def __truediv__(*args, **kwargs):
        """
        x.__truediv__(y) <==> x/y
        """
    
        pass
    
    
    def boundedTo(*args, **kwargs):
        pass
    
    
    def expandedTo(*args, **kwargs):
        pass
    
    
    def height(*args, **kwargs):
        pass
    
    
    def isEmpty(*args, **kwargs):
        pass
    
    
    def isNull(*args, **kwargs):
        pass
    
    
    def isValid(*args, **kwargs):
        pass
    
    
    def scale(*args, **kwargs):
        pass
    
    
    def scaled(*args, **kwargs):
        pass
    
    
    def setHeight(*args, **kwargs):
        pass
    
    
    def setWidth(*args, **kwargs):
        pass
    
    
    def toSize(*args, **kwargs):
        pass
    
    
    def toTuple(*args, **kwargs):
        pass
    
    
    def transpose(*args, **kwargs):
        pass
    
    
    def transposed(*args, **kwargs):
        pass
    
    
    def width(*args, **kwargs):
        pass
    
    
    __new__ = None


class QXmlStreamWriter(_Object):
    def __init__(*args, **kwargs):
        """
        x.__init__(...) initializes x; see help(type(x)) for signature
        """
    
        pass
    
    
    def autoFormatting(*args, **kwargs):
        pass
    
    
    def autoFormattingIndent(*args, **kwargs):
        pass
    
    
    def codec(*args, **kwargs):
        pass
    
    
    def device(*args, **kwargs):
        pass
    
    
    def hasError(*args, **kwargs):
        pass
    
    
    def setAutoFormatting(*args, **kwargs):
        pass
    
    
    def setAutoFormattingIndent(*args, **kwargs):
        pass
    
    
    def setCodec(*args, **kwargs):
        pass
    
    
    def setDevice(*args, **kwargs):
        pass
    
    
    def writeAttribute(*args, **kwargs):
        pass
    
    
    def writeAttributes(*args, **kwargs):
        pass
    
    
    def writeCDATA(*args, **kwargs):
        pass
    
    
    def writeCharacters(*args, **kwargs):
        pass
    
    
    def writeComment(*args, **kwargs):
        pass
    
    
    def writeCurrentToken(*args, **kwargs):
        pass
    
    
    def writeDTD(*args, **kwargs):
        pass
    
    
    def writeDefaultNamespace(*args, **kwargs):
        pass
    
    
    def writeEmptyElement(*args, **kwargs):
        pass
    
    
    def writeEndDocument(*args, **kwargs):
        pass
    
    
    def writeEndElement(*args, **kwargs):
        pass
    
    
    def writeEntityReference(*args, **kwargs):
        pass
    
    
    def writeNamespace(*args, **kwargs):
        pass
    
    
    def writeProcessingInstruction(*args, **kwargs):
        pass
    
    
    def writeStartDocument(*args, **kwargs):
        pass
    
    
    def writeStartElement(*args, **kwargs):
        pass
    
    
    def writeTextElement(*args, **kwargs):
        pass
    
    
    __new__ = None


class QSemaphore(_Object):
    def __init__(*args, **kwargs):
        """
        x.__init__(...) initializes x; see help(type(x)) for signature
        """
    
        pass
    
    
    def acquire(*args, **kwargs):
        pass
    
    
    def available(*args, **kwargs):
        pass
    
    
    def release(*args, **kwargs):
        pass
    
    
    def tryAcquire(*args, **kwargs):
        pass
    
    
    __new__ = None


class QMetaObject(_Object):
    def __init__(*args, **kwargs):
        """
        x.__init__(...) initializes x; see help(type(x)) for signature
        """
    
        pass
    
    
    def cast(*args, **kwargs):
        pass
    
    
    def classInfo(*args, **kwargs):
        pass
    
    
    def classInfoCount(*args, **kwargs):
        pass
    
    
    def classInfoOffset(*args, **kwargs):
        pass
    
    
    def className(*args, **kwargs):
        pass
    
    
    def constructor(*args, **kwargs):
        pass
    
    
    def constructorCount(*args, **kwargs):
        pass
    
    
    def enumerator(*args, **kwargs):
        pass
    
    
    def enumeratorCount(*args, **kwargs):
        pass
    
    
    def enumeratorOffset(*args, **kwargs):
        pass
    
    
    def indexOfClassInfo(*args, **kwargs):
        pass
    
    
    def indexOfConstructor(*args, **kwargs):
        pass
    
    
    def indexOfEnumerator(*args, **kwargs):
        pass
    
    
    def indexOfMethod(*args, **kwargs):
        pass
    
    
    def indexOfProperty(*args, **kwargs):
        pass
    
    
    def indexOfSignal(*args, **kwargs):
        pass
    
    
    def indexOfSlot(*args, **kwargs):
        pass
    
    
    def method(*args, **kwargs):
        pass
    
    
    def methodCount(*args, **kwargs):
        pass
    
    
    def methodOffset(*args, **kwargs):
        pass
    
    
    def newInstance(*args, **kwargs):
        pass
    
    
    def property(*args, **kwargs):
        pass
    
    
    def propertyCount(*args, **kwargs):
        pass
    
    
    def propertyOffset(*args, **kwargs):
        pass
    
    
    def superClass(*args, **kwargs):
        pass
    
    
    def userProperty(*args, **kwargs):
        pass
    
    
    def checkConnectArgs(*args, **kwargs):
        pass
    
    
    def connectSlotsByName(*args, **kwargs):
        pass
    
    
    def disconnect(*args, **kwargs):
        pass
    
    
    def disconnectOne(*args, **kwargs):
        pass
    
    
    def invokeMethod(*args, **kwargs):
        pass
    
    
    def normalizedSignature(*args, **kwargs):
        pass
    
    
    def normalizedType(*args, **kwargs):
        pass
    
    
    Call = None
    
    
    CreateInstance = None
    
    
    IndexOfMethod = None
    
    
    InvokeMetaMethod = None
    
    
    QueryPropertyDesignable = None
    
    
    QueryPropertyEditable = None
    
    
    QueryPropertyScriptable = None
    
    
    QueryPropertyStored = None
    
    
    QueryPropertyUser = None
    
    
    ReadProperty = None
    
    
    RegisterMethodArgumentMetaType = None
    
    
    RegisterPropertyMetaType = None
    
    
    ResetProperty = None
    
    
    WriteProperty = None
    
    
    __new__ = None


class QGenericArgument(_Object):
    def __copy__(*args, **kwargs):
        pass
    
    
    def __init__(*args, **kwargs):
        """
        x.__init__(...) initializes x; see help(type(x)) for signature
        """
    
        pass
    
    
    def data(*args, **kwargs):
        pass
    
    
    def name(*args, **kwargs):
        pass
    
    
    __new__ = None


class QRect(_Object):
    def __add__(*args, **kwargs):
        """
        x.__add__(y) <==> x+y
        """
    
        pass
    
    
    def __and__(*args, **kwargs):
        """
        x.__and__(y) <==> x&y
        """
    
        pass
    
    
    def __copy__(*args, **kwargs):
        pass
    
    
    def __eq__(*args, **kwargs):
        """
        x.__eq__(y) <==> x==y
        """
    
        pass
    
    
    def __ge__(*args, **kwargs):
        """
        x.__ge__(y) <==> x>=y
        """
    
        pass
    
    
    def __gt__(*args, **kwargs):
        """
        x.__gt__(y) <==> x>y
        """
    
        pass
    
    
    def __hash__(*args, **kwargs):
        """
        x.__hash__() <==> hash(x)
        """
    
        pass
    
    
    def __iadd__(*args, **kwargs):
        """
        x.__iadd__(y) <==> x+=y
        """
    
        pass
    
    
    def __iand__(*args, **kwargs):
        """
        x.__iand__(y) <==> x&=y
        """
    
        pass
    
    
    def __init__(*args, **kwargs):
        """
        x.__init__(...) initializes x; see help(type(x)) for signature
        """
    
        pass
    
    
    def __ior__(*args, **kwargs):
        """
        x.__ior__(y) <==> x|=y
        """
    
        pass
    
    
    def __isub__(*args, **kwargs):
        """
        x.__isub__(y) <==> x-=y
        """
    
        pass
    
    
    def __le__(*args, **kwargs):
        """
        x.__le__(y) <==> x<=y
        """
    
        pass
    
    
    def __lt__(*args, **kwargs):
        """
        x.__lt__(y) <==> x<y
        """
    
        pass
    
    
    def __ne__(*args, **kwargs):
        """
        x.__ne__(y) <==> x!=y
        """
    
        pass
    
    
    def __nonzero__(*args, **kwargs):
        """
        x.__nonzero__() <==> x != 0
        """
    
        pass
    
    
    def __or__(*args, **kwargs):
        """
        x.__or__(y) <==> x|y
        """
    
        pass
    
    
    def __radd__(*args, **kwargs):
        """
        x.__radd__(y) <==> y+x
        """
    
        pass
    
    
    def __rand__(*args, **kwargs):
        """
        x.__rand__(y) <==> y&x
        """
    
        pass
    
    
    def __reduce__(*args, **kwargs):
        pass
    
    
    def __repr__(*args, **kwargs):
        """
        x.__repr__() <==> repr(x)
        """
    
        pass
    
    
    def __ror__(*args, **kwargs):
        """
        x.__ror__(y) <==> y|x
        """
    
        pass
    
    
    def __rsub__(*args, **kwargs):
        """
        x.__rsub__(y) <==> y-x
        """
    
        pass
    
    
    def __sub__(*args, **kwargs):
        """
        x.__sub__(y) <==> x-y
        """
    
        pass
    
    
    def adjust(*args, **kwargs):
        pass
    
    
    def adjusted(*args, **kwargs):
        pass
    
    
    def bottom(*args, **kwargs):
        pass
    
    
    def bottomLeft(*args, **kwargs):
        pass
    
    
    def bottomRight(*args, **kwargs):
        pass
    
    
    def center(*args, **kwargs):
        pass
    
    
    def contains(*args, **kwargs):
        pass
    
    
    def getCoords(*args, **kwargs):
        pass
    
    
    def getRect(*args, **kwargs):
        pass
    
    
    def height(*args, **kwargs):
        pass
    
    
    def intersected(*args, **kwargs):
        pass
    
    
    def intersects(*args, **kwargs):
        pass
    
    
    def isEmpty(*args, **kwargs):
        pass
    
    
    def isNull(*args, **kwargs):
        pass
    
    
    def isValid(*args, **kwargs):
        pass
    
    
    def left(*args, **kwargs):
        pass
    
    
    def marginsAdded(*args, **kwargs):
        pass
    
    
    def marginsRemoved(*args, **kwargs):
        pass
    
    
    def moveBottom(*args, **kwargs):
        pass
    
    
    def moveBottomLeft(*args, **kwargs):
        pass
    
    
    def moveBottomRight(*args, **kwargs):
        pass
    
    
    def moveCenter(*args, **kwargs):
        pass
    
    
    def moveLeft(*args, **kwargs):
        pass
    
    
    def moveRight(*args, **kwargs):
        pass
    
    
    def moveTo(*args, **kwargs):
        pass
    
    
    def moveTop(*args, **kwargs):
        pass
    
    
    def moveTopLeft(*args, **kwargs):
        pass
    
    
    def moveTopRight(*args, **kwargs):
        pass
    
    
    def normalized(*args, **kwargs):
        pass
    
    
    def right(*args, **kwargs):
        pass
    
    
    def setBottom(*args, **kwargs):
        pass
    
    
    def setBottomLeft(*args, **kwargs):
        pass
    
    
    def setBottomRight(*args, **kwargs):
        pass
    
    
    def setCoords(*args, **kwargs):
        pass
    
    
    def setHeight(*args, **kwargs):
        pass
    
    
    def setLeft(*args, **kwargs):
        pass
    
    
    def setRect(*args, **kwargs):
        pass
    
    
    def setRight(*args, **kwargs):
        pass
    
    
    def setSize(*args, **kwargs):
        pass
    
    
    def setTop(*args, **kwargs):
        pass
    
    
    def setTopLeft(*args, **kwargs):
        pass
    
    
    def setTopRight(*args, **kwargs):
        pass
    
    
    def setWidth(*args, **kwargs):
        pass
    
    
    def setX(*args, **kwargs):
        pass
    
    
    def setY(*args, **kwargs):
        pass
    
    
    def size(*args, **kwargs):
        pass
    
    
    def top(*args, **kwargs):
        pass
    
    
    def topLeft(*args, **kwargs):
        pass
    
    
    def topRight(*args, **kwargs):
        pass
    
    
    def translate(*args, **kwargs):
        pass
    
    
    def translated(*args, **kwargs):
        pass
    
    
    def united(*args, **kwargs):
        pass
    
    
    def width(*args, **kwargs):
        pass
    
    
    def x(*args, **kwargs):
        pass
    
    
    def y(*args, **kwargs):
        pass
    
    
    __new__ = None


class QMargins(_Object):
    def __add__(*args, **kwargs):
        """
        x.__add__(y) <==> x+y
        """
    
        pass
    
    
    def __copy__(*args, **kwargs):
        pass
    
    
    def __div__(*args, **kwargs):
        """
        x.__div__(y) <==> x/y
        """
    
        pass
    
    
    def __eq__(*args, **kwargs):
        """
        x.__eq__(y) <==> x==y
        """
    
        pass
    
    
    def __ge__(*args, **kwargs):
        """
        x.__ge__(y) <==> x>=y
        """
    
        pass
    
    
    def __gt__(*args, **kwargs):
        """
        x.__gt__(y) <==> x>y
        """
    
        pass
    
    
    def __iadd__(*args, **kwargs):
        """
        x.__iadd__(y) <==> x+=y
        """
    
        pass
    
    
    def __init__(*args, **kwargs):
        """
        x.__init__(...) initializes x; see help(type(x)) for signature
        """
    
        pass
    
    
    def __isub__(*args, **kwargs):
        """
        x.__isub__(y) <==> x-=y
        """
    
        pass
    
    
    def __le__(*args, **kwargs):
        """
        x.__le__(y) <==> x<=y
        """
    
        pass
    
    
    def __lt__(*args, **kwargs):
        """
        x.__lt__(y) <==> x<y
        """
    
        pass
    
    
    def __mul__(*args, **kwargs):
        """
        x.__mul__(y) <==> x*y
        """
    
        pass
    
    
    def __ne__(*args, **kwargs):
        """
        x.__ne__(y) <==> x!=y
        """
    
        pass
    
    
    def __neg__(*args, **kwargs):
        """
        x.__neg__() <==> -x
        """
    
        pass
    
    
    def __nonzero__(*args, **kwargs):
        """
        x.__nonzero__() <==> x != 0
        """
    
        pass
    
    
    def __pos__(*args, **kwargs):
        """
        x.__pos__() <==> +x
        """
    
        pass
    
    
    def __radd__(*args, **kwargs):
        """
        x.__radd__(y) <==> y+x
        """
    
        pass
    
    
    def __rdiv__(*args, **kwargs):
        """
        x.__rdiv__(y) <==> y/x
        """
    
        pass
    
    
    def __repr__(*args, **kwargs):
        """
        x.__repr__() <==> repr(x)
        """
    
        pass
    
    
    def __rmul__(*args, **kwargs):
        """
        x.__rmul__(y) <==> y*x
        """
    
        pass
    
    
    def __rsub__(*args, **kwargs):
        """
        x.__rsub__(y) <==> y-x
        """
    
        pass
    
    
    def __rtruediv__(*args, **kwargs):
        """
        x.__rtruediv__(y) <==> y/x
        """
    
        pass
    
    
    def __sub__(*args, **kwargs):
        """
        x.__sub__(y) <==> x-y
        """
    
        pass
    
    
    def __truediv__(*args, **kwargs):
        """
        x.__truediv__(y) <==> x/y
        """
    
        pass
    
    
    def bottom(*args, **kwargs):
        pass
    
    
    def isNull(*args, **kwargs):
        pass
    
    
    def left(*args, **kwargs):
        pass
    
    
    def right(*args, **kwargs):
        pass
    
    
    def setBottom(*args, **kwargs):
        pass
    
    
    def setLeft(*args, **kwargs):
        pass
    
    
    def setRight(*args, **kwargs):
        pass
    
    
    def setTop(*args, **kwargs):
        pass
    
    
    def top(*args, **kwargs):
        pass
    
    
    __new__ = None


class QJsonParseError(_Object):
    def __copy__(*args, **kwargs):
        pass
    
    
    def __init__(*args, **kwargs):
        """
        x.__init__(...) initializes x; see help(type(x)) for signature
        """
    
        pass
    
    
    def errorString(*args, **kwargs):
        pass
    
    
    offset = None
    
    __new__ = None


class QTextDecoder(_Object):
    def __init__(*args, **kwargs):
        """
        x.__init__(...) initializes x; see help(type(x)) for signature
        """
    
        pass
    
    
    def hasFailure(*args, **kwargs):
        pass
    
    
    def toUnicode(*args, **kwargs):
        pass
    
    
    __new__ = None


class QXmlStreamEntityDeclaration(_Object):
    def __copy__(*args, **kwargs):
        pass
    
    
    def __eq__(*args, **kwargs):
        """
        x.__eq__(y) <==> x==y
        """
    
        pass
    
    
    def __ge__(*args, **kwargs):
        """
        x.__ge__(y) <==> x>=y
        """
    
        pass
    
    
    def __gt__(*args, **kwargs):
        """
        x.__gt__(y) <==> x>y
        """
    
        pass
    
    
    def __init__(*args, **kwargs):
        """
        x.__init__(...) initializes x; see help(type(x)) for signature
        """
    
        pass
    
    
    def __le__(*args, **kwargs):
        """
        x.__le__(y) <==> x<=y
        """
    
        pass
    
    
    def __lt__(*args, **kwargs):
        """
        x.__lt__(y) <==> x<y
        """
    
        pass
    
    
    def __ne__(*args, **kwargs):
        """
        x.__ne__(y) <==> x!=y
        """
    
        pass
    
    
    def name(*args, **kwargs):
        pass
    
    
    def notationName(*args, **kwargs):
        pass
    
    
    def publicId(*args, **kwargs):
        pass
    
    
    def systemId(*args, **kwargs):
        pass
    
    
    def value(*args, **kwargs):
        pass
    
    
    __new__ = None


class QPersistentModelIndex(_Object):
    def __copy__(*args, **kwargs):
        pass
    
    
    def __eq__(*args, **kwargs):
        """
        x.__eq__(y) <==> x==y
        """
    
        pass
    
    
    def __ge__(*args, **kwargs):
        """
        x.__ge__(y) <==> x>=y
        """
    
        pass
    
    
    def __gt__(*args, **kwargs):
        """
        x.__gt__(y) <==> x>y
        """
    
        pass
    
    
    def __hash__(*args, **kwargs):
        """
        x.__hash__() <==> hash(x)
        """
    
        pass
    
    
    def __init__(*args, **kwargs):
        """
        x.__init__(...) initializes x; see help(type(x)) for signature
        """
    
        pass
    
    
    def __le__(*args, **kwargs):
        """
        x.__le__(y) <==> x<=y
        """
    
        pass
    
    
    def __lt__(*args, **kwargs):
        """
        x.__lt__(y) <==> x<y
        """
    
        pass
    
    
    def __ne__(*args, **kwargs):
        """
        x.__ne__(y) <==> x!=y
        """
    
        pass
    
    
    def __repr__(*args, **kwargs):
        """
        x.__repr__() <==> repr(x)
        """
    
        pass
    
    
    def child(*args, **kwargs):
        pass
    
    
    def column(*args, **kwargs):
        pass
    
    
    def data(*args, **kwargs):
        pass
    
    
    def flags(*args, **kwargs):
        pass
    
    
    def internalId(*args, **kwargs):
        pass
    
    
    def internalPointer(*args, **kwargs):
        pass
    
    
    def isValid(*args, **kwargs):
        pass
    
    
    def model(*args, **kwargs):
        pass
    
    
    def parent(*args, **kwargs):
        pass
    
    
    def row(*args, **kwargs):
        pass
    
    
    def sibling(*args, **kwargs):
        pass
    
    
    def swap(*args, **kwargs):
        pass
    
    
    __new__ = None


class QTime(_Object):
    def __copy__(*args, **kwargs):
        pass
    
    
    def __eq__(*args, **kwargs):
        """
        x.__eq__(y) <==> x==y
        """
    
        pass
    
    
    def __ge__(*args, **kwargs):
        """
        x.__ge__(y) <==> x>=y
        """
    
        pass
    
    
    def __getattribute__(*args, **kwargs):
        """
        x.__getattribute__('name') <==> x.name
        """
    
        pass
    
    
    def __gt__(*args, **kwargs):
        """
        x.__gt__(y) <==> x>y
        """
    
        pass
    
    
    def __hash__(*args, **kwargs):
        """
        x.__hash__() <==> hash(x)
        """
    
        pass
    
    
    def __init__(*args, **kwargs):
        """
        x.__init__(...) initializes x; see help(type(x)) for signature
        """
    
        pass
    
    
    def __le__(*args, **kwargs):
        """
        x.__le__(y) <==> x<=y
        """
    
        pass
    
    
    def __lt__(*args, **kwargs):
        """
        x.__lt__(y) <==> x<y
        """
    
        pass
    
    
    def __ne__(*args, **kwargs):
        """
        x.__ne__(y) <==> x!=y
        """
    
        pass
    
    
    def __nonzero__(*args, **kwargs):
        """
        x.__nonzero__() <==> x != 0
        """
    
        pass
    
    
    def __reduce__(*args, **kwargs):
        pass
    
    
    def __repr__(*args, **kwargs):
        """
        x.__repr__() <==> repr(x)
        """
    
        pass
    
    
    def addMSecs(*args, **kwargs):
        pass
    
    
    def addSecs(*args, **kwargs):
        pass
    
    
    def elapsed(*args, **kwargs):
        pass
    
    
    def hour(*args, **kwargs):
        pass
    
    
    def isNull(*args, **kwargs):
        pass
    
    
    def minute(*args, **kwargs):
        pass
    
    
    def msec(*args, **kwargs):
        pass
    
    
    def msecsSinceStartOfDay(*args, **kwargs):
        pass
    
    
    def msecsTo(*args, **kwargs):
        pass
    
    
    def restart(*args, **kwargs):
        pass
    
    
    def second(*args, **kwargs):
        pass
    
    
    def secsTo(*args, **kwargs):
        pass
    
    
    def setHMS(*args, **kwargs):
        pass
    
    
    def start(*args, **kwargs):
        pass
    
    
    def toPython(*args, **kwargs):
        pass
    
    
    def toString(*args, **kwargs):
        pass
    
    
    def currentTime(*args, **kwargs):
        pass
    
    
    def fromMSecsSinceStartOfDay(*args, **kwargs):
        pass
    
    
    def fromString(*args, **kwargs):
        pass
    
    
    def isValid(*args, **kwargs):
        pass
    
    
    __new__ = None


class QDirIterator(_Object):
    def __init__(*args, **kwargs):
        """
        x.__init__(...) initializes x; see help(type(x)) for signature
        """
    
        pass
    
    
    def fileInfo(*args, **kwargs):
        pass
    
    
    def fileName(*args, **kwargs):
        pass
    
    
    def filePath(*args, **kwargs):
        pass
    
    
    def hasNext(*args, **kwargs):
        pass
    
    
    def next(*args, **kwargs):
        pass
    
    
    def path(*args, **kwargs):
        pass
    
    
    FollowSymlinks = None
    
    
    IteratorFlag = None
    
    
    IteratorFlags = None
    
    
    NoIteratorFlags = None
    
    
    Subdirectories = None
    
    
    __new__ = None


class QCryptographicHash(_Object):
    def __init__(*args, **kwargs):
        """
        x.__init__(...) initializes x; see help(type(x)) for signature
        """
    
        pass
    
    
    def addData(*args, **kwargs):
        pass
    
    
    def reset(*args, **kwargs):
        pass
    
    
    def result(*args, **kwargs):
        pass
    
    
    def hash(*args, **kwargs):
        pass
    
    
    Algorithm = None
    
    
    Md4 = None
    
    
    Md5 = None
    
    
    Sha1 = None
    
    
    Sha224 = None
    
    
    Sha256 = None
    
    
    Sha384 = None
    
    
    Sha3_224 = None
    
    
    Sha3_256 = None
    
    
    Sha3_384 = None
    
    
    Sha3_512 = None
    
    
    Sha512 = None
    
    
    __new__ = None


class QLibraryInfo(_Object):
    def build(*args, **kwargs):
        pass
    
    
    def buildDate(*args, **kwargs):
        pass
    
    
    def isDebugBuild(*args, **kwargs):
        pass
    
    
    def licensedProducts(*args, **kwargs):
        pass
    
    
    def licensee(*args, **kwargs):
        pass
    
    
    def location(*args, **kwargs):
        pass
    
    
    def platformPluginArguments(*args, **kwargs):
        pass
    
    
    ArchDataPath = None
    
    
    BinariesPath = None
    
    
    DataPath = None
    
    
    DocumentationPath = None
    
    
    ExamplesPath = None
    
    
    HeadersPath = None
    
    
    ImportsPath = None
    
    
    LibrariesPath = None
    
    
    LibraryExecutablesPath = None
    
    
    LibraryLocation = None
    
    
    PluginsPath = None
    
    
    PrefixPath = None
    
    
    Qml2ImportsPath = None
    
    
    SettingsPath = None
    
    
    TestsPath = None
    
    
    TranslationsPath = None


class QSysInfo(_Object):
    def __init__(*args, **kwargs):
        """
        x.__init__(...) initializes x; see help(type(x)) for signature
        """
    
        pass
    
    
    def buildAbi(*args, **kwargs):
        pass
    
    
    def buildCpuArchitecture(*args, **kwargs):
        pass
    
    
    def currentCpuArchitecture(*args, **kwargs):
        pass
    
    
    def kernelType(*args, **kwargs):
        pass
    
    
    def kernelVersion(*args, **kwargs):
        pass
    
    
    def macVersion(*args, **kwargs):
        pass
    
    
    def machineHostName(*args, **kwargs):
        pass
    
    
    def prettyProductName(*args, **kwargs):
        pass
    
    
    def productType(*args, **kwargs):
        pass
    
    
    def productVersion(*args, **kwargs):
        pass
    
    
    BigEndian = None
    
    
    ByteOrder = None
    
    
    Endian = None
    
    
    LittleEndian = None
    
    
    MV_10_0 = None
    
    
    MV_10_1 = None
    
    
    MV_10_10 = None
    
    
    MV_10_11 = None
    
    
    MV_10_2 = None
    
    
    MV_10_3 = None
    
    
    MV_10_4 = None
    
    
    MV_10_5 = None
    
    
    MV_10_6 = None
    
    
    MV_10_7 = None
    
    
    MV_10_8 = None
    
    
    MV_10_9 = None
    
    
    MV_9 = None
    
    
    MV_CHEETAH = None
    
    
    MV_ELCAPITAN = None
    
    
    MV_IOS = None
    
    
    MV_IOS_4_3 = None
    
    
    MV_IOS_5_0 = None
    
    
    MV_IOS_5_1 = None
    
    
    MV_IOS_6_0 = None
    
    
    MV_IOS_6_1 = None
    
    
    MV_IOS_7_0 = None
    
    
    MV_IOS_7_1 = None
    
    
    MV_IOS_8_0 = None
    
    
    MV_IOS_8_1 = None
    
    
    MV_IOS_8_2 = None
    
    
    MV_IOS_8_3 = None
    
    
    MV_IOS_8_4 = None
    
    
    MV_IOS_9_0 = None
    
    
    MV_JAGUAR = None
    
    
    MV_LEOPARD = None
    
    
    MV_LION = None
    
    
    MV_MAVERICKS = None
    
    
    MV_MOUNTAINLION = None
    
    
    MV_None = None
    
    
    MV_PANTHER = None
    
    
    MV_PUMA = None
    
    
    MV_SNOWLEOPARD = None
    
    
    MV_TIGER = None
    
    
    MV_Unknown = None
    
    
    MV_YOSEMITE = None
    
    
    MacVersion = None
    
    
    MacintoshVersion = None
    
    
    Sizes = None
    
    
    WordSize = None
    
    
    __new__ = None


class QFactoryInterface(_Object):
    def __init__(*args, **kwargs):
        """
        x.__init__(...) initializes x; see help(type(x)) for signature
        """
    
        pass
    
    
    def keys(*args, **kwargs):
        pass
    
    
    __new__ = None


class QDataStream(_Object):
    def __init__(*args, **kwargs):
        """
        x.__init__(...) initializes x; see help(type(x)) for signature
        """
    
        pass
    
    
    def __lshift__(*args, **kwargs):
        """
        x.__lshift__(y) <==> x<<y
        """
    
        pass
    
    
    def __rlshift__(*args, **kwargs):
        """
        x.__rlshift__(y) <==> y<<x
        """
    
        pass
    
    
    def __rrshift__(*args, **kwargs):
        """
        x.__rrshift__(y) <==> y>>x
        """
    
        pass
    
    
    def __rshift__(*args, **kwargs):
        """
        x.__rshift__(y) <==> x>>y
        """
    
        pass
    
    
    def atEnd(*args, **kwargs):
        pass
    
    
    def byteOrder(*args, **kwargs):
        pass
    
    
    def device(*args, **kwargs):
        pass
    
    
    def floatingPointPrecision(*args, **kwargs):
        pass
    
    
    def readBool(*args, **kwargs):
        pass
    
    
    def readDouble(*args, **kwargs):
        pass
    
    
    def readFloat(*args, **kwargs):
        pass
    
    
    def readInt16(*args, **kwargs):
        pass
    
    
    def readInt32(*args, **kwargs):
        pass
    
    
    def readInt64(*args, **kwargs):
        pass
    
    
    def readInt8(*args, **kwargs):
        pass
    
    
    def readQChar(*args, **kwargs):
        pass
    
    
    def readQString(*args, **kwargs):
        pass
    
    
    def readQStringList(*args, **kwargs):
        pass
    
    
    def readQVariant(*args, **kwargs):
        pass
    
    
    def readRawData(*args, **kwargs):
        pass
    
    
    def readString(*args, **kwargs):
        pass
    
    
    def readUInt16(*args, **kwargs):
        pass
    
    
    def readUInt32(*args, **kwargs):
        pass
    
    
    def readUInt64(*args, **kwargs):
        pass
    
    
    def readUInt8(*args, **kwargs):
        pass
    
    
    def resetStatus(*args, **kwargs):
        pass
    
    
    def setByteOrder(*args, **kwargs):
        pass
    
    
    def setDevice(*args, **kwargs):
        pass
    
    
    def setFloatingPointPrecision(*args, **kwargs):
        pass
    
    
    def setStatus(*args, **kwargs):
        pass
    
    
    def setVersion(*args, **kwargs):
        pass
    
    
    def skipRawData(*args, **kwargs):
        pass
    
    
    def status(*args, **kwargs):
        pass
    
    
    def unsetDevice(*args, **kwargs):
        pass
    
    
    def version(*args, **kwargs):
        pass
    
    
    def writeBool(*args, **kwargs):
        pass
    
    
    def writeDouble(*args, **kwargs):
        pass
    
    
    def writeFloat(*args, **kwargs):
        pass
    
    
    def writeInt16(*args, **kwargs):
        pass
    
    
    def writeInt32(*args, **kwargs):
        pass
    
    
    def writeInt64(*args, **kwargs):
        pass
    
    
    def writeInt8(*args, **kwargs):
        pass
    
    
    def writeQChar(*args, **kwargs):
        pass
    
    
    def writeQString(*args, **kwargs):
        pass
    
    
    def writeQStringList(*args, **kwargs):
        pass
    
    
    def writeQVariant(*args, **kwargs):
        pass
    
    
    def writeRawData(*args, **kwargs):
        pass
    
    
    def writeString(*args, **kwargs):
        pass
    
    
    def writeUInt16(*args, **kwargs):
        pass
    
    
    def writeUInt32(*args, **kwargs):
        pass
    
    
    def writeUInt64(*args, **kwargs):
        pass
    
    
    def writeUInt8(*args, **kwargs):
        pass
    
    
    BigEndian = None
    
    
    ByteOrder = None
    
    
    DoublePrecision = None
    
    
    FloatingPointPrecision = None
    
    
    LittleEndian = None
    
    
    Ok = None
    
    
    Qt_1_0 = None
    
    
    Qt_2_0 = None
    
    
    Qt_2_1 = None
    
    
    Qt_3_0 = None
    
    
    Qt_3_1 = None
    
    
    Qt_3_3 = None
    
    
    Qt_4_0 = None
    
    
    Qt_4_1 = None
    
    
    Qt_4_2 = None
    
    
    Qt_4_3 = None
    
    
    Qt_4_4 = None
    
    
    Qt_4_5 = None
    
    
    Qt_4_6 = None
    
    
    Qt_4_7 = None
    
    
    Qt_4_8 = None
    
    
    Qt_4_9 = None
    
    
    Qt_5_0 = None
    
    
    Qt_5_1 = None
    
    
    Qt_5_2 = None
    
    
    Qt_5_3 = None
    
    
    Qt_5_4 = None
    
    
    Qt_5_5 = None
    
    
    Qt_5_6 = None
    
    
    Qt_DefaultCompiledVersion = None
    
    
    ReadCorruptData = None
    
    
    ReadPastEnd = None
    
    
    SinglePrecision = None
    
    
    Status = None
    
    
    Version = None
    
    
    WriteFailed = None
    
    
    __new__ = None


class QMessageLogContext(_Object):
    def __init__(*args, **kwargs):
        """
        x.__init__(...) initializes x; see help(type(x)) for signature
        """
    
        pass
    
    
    category = None
    
    file = None
    
    function = None
    
    line = None
    
    version = None
    
    __new__ = None


class QTextEncoder(_Object):
    def __init__(*args, **kwargs):
        """
        x.__init__(...) initializes x; see help(type(x)) for signature
        """
    
        pass
    
    
    def fromUnicode(*args, **kwargs):
        pass
    
    
    def hasFailure(*args, **kwargs):
        pass
    
    
    __new__ = None


class QByteArray(_Object):
    def __add__(*args, **kwargs):
        """
        x.__add__(y) <==> x+y
        """
    
        pass
    
    
    def __copy__(*args, **kwargs):
        pass
    
    
    def __delitem__(*args, **kwargs):
        """
        x.__delitem__(y) <==> del x[y]
        """
    
        pass
    
    
    def __eq__(*args, **kwargs):
        """
        x.__eq__(y) <==> x==y
        """
    
        pass
    
    
    def __ge__(*args, **kwargs):
        """
        x.__ge__(y) <==> x>=y
        """
    
        pass
    
    
    def __getitem__(*args, **kwargs):
        """
        x.__getitem__(y) <==> x[y]
        """
    
        pass
    
    
    def __getslice__(*args, **kwargs):
        """
        x.__getslice__(i, j) <==> x[i:j]
        
        Use of negative indices is not supported.
        """
    
        pass
    
    
    def __gt__(*args, **kwargs):
        """
        x.__gt__(y) <==> x>y
        """
    
        pass
    
    
    def __hash__(*args, **kwargs):
        """
        x.__hash__() <==> hash(x)
        """
    
        pass
    
    
    def __iadd__(*args, **kwargs):
        """
        x.__iadd__(y) <==> x+=y
        """
    
        pass
    
    
    def __init__(*args, **kwargs):
        """
        x.__init__(...) initializes x; see help(type(x)) for signature
        """
    
        pass
    
    
    def __le__(*args, **kwargs):
        """
        x.__le__(y) <==> x<=y
        """
    
        pass
    
    
    def __len__(*args, **kwargs):
        """
        x.__len__() <==> len(x)
        """
    
        pass
    
    
    def __lt__(*args, **kwargs):
        """
        x.__lt__(y) <==> x<y
        """
    
        pass
    
    
    def __ne__(*args, **kwargs):
        """
        x.__ne__(y) <==> x!=y
        """
    
        pass
    
    
    def __nonzero__(*args, **kwargs):
        """
        x.__nonzero__() <==> x != 0
        """
    
        pass
    
    
    def __radd__(*args, **kwargs):
        """
        x.__radd__(y) <==> y+x
        """
    
        pass
    
    
    def __reduce__(*args, **kwargs):
        pass
    
    
    def __repr__(*args, **kwargs):
        """
        x.__repr__() <==> repr(x)
        """
    
        pass
    
    
    def __setitem__(*args, **kwargs):
        """
        x.__setitem__(i, y) <==> x[i]=y
        """
    
        pass
    
    
    def __str__(*args, **kwargs):
        """
        x.__str__() <==> str(x)
        """
    
        pass
    
    
    def append(*args, **kwargs):
        pass
    
    
    def at(*args, **kwargs):
        pass
    
    
    def capacity(*args, **kwargs):
        pass
    
    
    def cbegin(*args, **kwargs):
        pass
    
    
    def cend(*args, **kwargs):
        pass
    
    
    def chop(*args, **kwargs):
        pass
    
    
    def clear(*args, **kwargs):
        pass
    
    
    def contains(*args, **kwargs):
        pass
    
    
    def count(*args, **kwargs):
        pass
    
    
    def data(*args, **kwargs):
        pass
    
    
    def endsWith(*args, **kwargs):
        pass
    
    
    def fill(*args, **kwargs):
        pass
    
    
    def indexOf(*args, **kwargs):
        pass
    
    
    def insert(*args, **kwargs):
        pass
    
    
    def isEmpty(*args, **kwargs):
        pass
    
    
    def isNull(*args, **kwargs):
        pass
    
    
    def isSharedWith(*args, **kwargs):
        pass
    
    
    def lastIndexOf(*args, **kwargs):
        pass
    
    
    def left(*args, **kwargs):
        pass
    
    
    def leftJustified(*args, **kwargs):
        pass
    
    
    def length(*args, **kwargs):
        pass
    
    
    def mid(*args, **kwargs):
        pass
    
    
    def prepend(*args, **kwargs):
        pass
    
    
    def remove(*args, **kwargs):
        pass
    
    
    def repeated(*args, **kwargs):
        pass
    
    
    def replace(*args, **kwargs):
        pass
    
    
    def reserve(*args, **kwargs):
        pass
    
    
    def resize(*args, **kwargs):
        pass
    
    
    def right(*args, **kwargs):
        pass
    
    
    def rightJustified(*args, **kwargs):
        pass
    
    
    def setNum(*args, **kwargs):
        pass
    
    
    def setRawData(*args, **kwargs):
        pass
    
    
    def simplified(*args, **kwargs):
        pass
    
    
    def size(*args, **kwargs):
        pass
    
    
    def split(*args, **kwargs):
        pass
    
    
    def squeeze(*args, **kwargs):
        pass
    
    
    def startsWith(*args, **kwargs):
        pass
    
    
    def swap(*args, **kwargs):
        pass
    
    
    def toBase64(*args, **kwargs):
        pass
    
    
    def toDouble(*args, **kwargs):
        pass
    
    
    def toFloat(*args, **kwargs):
        pass
    
    
    def toHex(*args, **kwargs):
        pass
    
    
    def toInt(*args, **kwargs):
        pass
    
    
    def toLong(*args, **kwargs):
        pass
    
    
    def toLongLong(*args, **kwargs):
        pass
    
    
    def toLower(*args, **kwargs):
        pass
    
    
    def toPercentEncoding(*args, **kwargs):
        pass
    
    
    def toShort(*args, **kwargs):
        pass
    
    
    def toUInt(*args, **kwargs):
        pass
    
    
    def toULong(*args, **kwargs):
        pass
    
    
    def toULongLong(*args, **kwargs):
        pass
    
    
    def toUShort(*args, **kwargs):
        pass
    
    
    def toUpper(*args, **kwargs):
        pass
    
    
    def trimmed(*args, **kwargs):
        pass
    
    
    def truncate(*args, **kwargs):
        pass
    
    
    def fromBase64(*args, **kwargs):
        pass
    
    
    def fromHex(*args, **kwargs):
        pass
    
    
    def fromPercentEncoding(*args, **kwargs):
        pass
    
    
    def fromRawData(*args, **kwargs):
        pass
    
    
    def number(*args, **kwargs):
        pass
    
    
    Base64Encoding = None
    
    
    Base64Option = None
    
    
    Base64Options = None
    
    
    Base64UrlEncoding = None
    
    
    KeepTrailingEquals = None
    
    
    OmitTrailingEquals = None
    
    
    __new__ = None


class QXmlStreamEntityResolver(_Object):
    def __init__(*args, **kwargs):
        """
        x.__init__(...) initializes x; see help(type(x)) for signature
        """
    
        pass
    
    
    def resolveEntity(*args, **kwargs):
        pass
    
    
    def resolveUndeclaredEntity(*args, **kwargs):
        pass
    
    
    __new__ = None


class QDynamicPropertyChangeEvent(QEvent):
    def __init__(*args, **kwargs):
        """
        x.__init__(...) initializes x; see help(type(x)) for signature
        """
    
        pass
    
    
    def propertyName(*args, **kwargs):
        pass
    
    
    __new__ = None


class QAbstractItemModel(QObject):
    def __init__(*args, **kwargs):
        """
        x.__init__(...) initializes x; see help(type(x)) for signature
        """
    
        pass
    
    
    def beginInsertColumns(*args, **kwargs):
        pass
    
    
    def beginInsertRows(*args, **kwargs):
        pass
    
    
    def beginMoveColumns(*args, **kwargs):
        pass
    
    
    def beginMoveRows(*args, **kwargs):
        pass
    
    
    def beginRemoveColumns(*args, **kwargs):
        pass
    
    
    def beginRemoveRows(*args, **kwargs):
        pass
    
    
    def beginResetModel(*args, **kwargs):
        pass
    
    
    def buddy(*args, **kwargs):
        pass
    
    
    def canDropMimeData(*args, **kwargs):
        pass
    
    
    def canFetchMore(*args, **kwargs):
        pass
    
    
    def changePersistentIndex(*args, **kwargs):
        pass
    
    
    def changePersistentIndexList(*args, **kwargs):
        pass
    
    
    def columnCount(*args, **kwargs):
        pass
    
    
    def createIndex(*args, **kwargs):
        pass
    
    
    def data(*args, **kwargs):
        pass
    
    
    def decodeData(*args, **kwargs):
        pass
    
    
    def dropMimeData(*args, **kwargs):
        pass
    
    
    def encodeData(*args, **kwargs):
        pass
    
    
    def endInsertColumns(*args, **kwargs):
        pass
    
    
    def endInsertRows(*args, **kwargs):
        pass
    
    
    def endMoveColumns(*args, **kwargs):
        pass
    
    
    def endMoveRows(*args, **kwargs):
        pass
    
    
    def endRemoveColumns(*args, **kwargs):
        pass
    
    
    def endRemoveRows(*args, **kwargs):
        pass
    
    
    def endResetModel(*args, **kwargs):
        pass
    
    
    def fetchMore(*args, **kwargs):
        pass
    
    
    def flags(*args, **kwargs):
        pass
    
    
    def hasChildren(*args, **kwargs):
        pass
    
    
    def hasIndex(*args, **kwargs):
        pass
    
    
    def headerData(*args, **kwargs):
        pass
    
    
    def index(*args, **kwargs):
        pass
    
    
    def insertColumn(*args, **kwargs):
        pass
    
    
    def insertColumns(*args, **kwargs):
        pass
    
    
    def insertRow(*args, **kwargs):
        pass
    
    
    def insertRows(*args, **kwargs):
        pass
    
    
    def itemData(*args, **kwargs):
        pass
    
    
    def match(*args, **kwargs):
        pass
    
    
    def mimeData(*args, **kwargs):
        pass
    
    
    def mimeTypes(*args, **kwargs):
        pass
    
    
    def moveColumn(*args, **kwargs):
        pass
    
    
    def moveColumns(*args, **kwargs):
        pass
    
    
    def moveRow(*args, **kwargs):
        pass
    
    
    def moveRows(*args, **kwargs):
        pass
    
    
    def parent(*args, **kwargs):
        pass
    
    
    def persistentIndexList(*args, **kwargs):
        pass
    
    
    def removeColumn(*args, **kwargs):
        pass
    
    
    def removeColumns(*args, **kwargs):
        pass
    
    
    def removeRow(*args, **kwargs):
        pass
    
    
    def removeRows(*args, **kwargs):
        pass
    
    
    def resetInternalData(*args, **kwargs):
        pass
    
    
    def revert(*args, **kwargs):
        pass
    
    
    def roleNames(*args, **kwargs):
        pass
    
    
    def rowCount(*args, **kwargs):
        pass
    
    
    def setData(*args, **kwargs):
        pass
    
    
    def setHeaderData(*args, **kwargs):
        pass
    
    
    def setItemData(*args, **kwargs):
        pass
    
    
    def sibling(*args, **kwargs):
        pass
    
    
    def sort(*args, **kwargs):
        pass
    
    
    def span(*args, **kwargs):
        pass
    
    
    def submit(*args, **kwargs):
        pass
    
    
    def supportedDragActions(*args, **kwargs):
        pass
    
    
    def supportedDropActions(*args, **kwargs):
        pass
    
    
    HorizontalSortHint = None
    
    
    LayoutChangeHint = None
    
    
    NoLayoutChangeHint = None
    
    
    VerticalSortHint = None
    
    
    __new__ = None
    
    
    columnsAboutToBeInserted = None
    
    
    columnsAboutToBeMoved = None
    
    
    columnsAboutToBeRemoved = None
    
    
    columnsInserted = None
    
    
    columnsMoved = None
    
    
    columnsRemoved = None
    
    
    dataChanged = None
    
    
    headerDataChanged = None
    
    
    layoutAboutToBeChanged = None
    
    
    layoutChanged = None
    
    
    modelAboutToBeReset = None
    
    
    modelReset = None
    
    
    rowsAboutToBeInserted = None
    
    
    rowsAboutToBeMoved = None
    
    
    rowsAboutToBeRemoved = None
    
    
    rowsInserted = None
    
    
    rowsMoved = None
    
    
    rowsRemoved = None
    
    
    staticMetaObject = None


class QTimeLine(QObject):
    def __init__(*args, **kwargs):
        """
        x.__init__(...) initializes x; see help(type(x)) for signature
        """
    
        pass
    
    
    def currentFrame(*args, **kwargs):
        pass
    
    
    def currentTime(*args, **kwargs):
        pass
    
    
    def currentValue(*args, **kwargs):
        pass
    
    
    def curveShape(*args, **kwargs):
        pass
    
    
    def direction(*args, **kwargs):
        pass
    
    
    def duration(*args, **kwargs):
        pass
    
    
    def easingCurve(*args, **kwargs):
        pass
    
    
    def endFrame(*args, **kwargs):
        pass
    
    
    def frameForTime(*args, **kwargs):
        pass
    
    
    def loopCount(*args, **kwargs):
        pass
    
    
    def resume(*args, **kwargs):
        pass
    
    
    def setCurrentTime(*args, **kwargs):
        pass
    
    
    def setCurveShape(*args, **kwargs):
        pass
    
    
    def setDirection(*args, **kwargs):
        pass
    
    
    def setDuration(*args, **kwargs):
        pass
    
    
    def setEasingCurve(*args, **kwargs):
        pass
    
    
    def setEndFrame(*args, **kwargs):
        pass
    
    
    def setFrameRange(*args, **kwargs):
        pass
    
    
    def setLoopCount(*args, **kwargs):
        pass
    
    
    def setPaused(*args, **kwargs):
        pass
    
    
    def setStartFrame(*args, **kwargs):
        pass
    
    
    def setUpdateInterval(*args, **kwargs):
        pass
    
    
    def start(*args, **kwargs):
        pass
    
    
    def startFrame(*args, **kwargs):
        pass
    
    
    def state(*args, **kwargs):
        pass
    
    
    def stop(*args, **kwargs):
        pass
    
    
    def timerEvent(*args, **kwargs):
        pass
    
    
    def toggleDirection(*args, **kwargs):
        pass
    
    
    def updateInterval(*args, **kwargs):
        pass
    
    
    def valueForTime(*args, **kwargs):
        pass
    
    
    Backward = None
    
    
    CosineCurve = None
    
    
    CurveShape = None
    
    
    Direction = None
    
    
    EaseInCurve = None
    
    
    EaseInOutCurve = None
    
    
    EaseOutCurve = None
    
    
    Forward = None
    
    
    LinearCurve = None
    
    
    NotRunning = None
    
    
    Paused = None
    
    
    Running = None
    
    
    SineCurve = None
    
    
    State = None
    
    
    __new__ = None
    
    
    finished = None
    
    
    frameChanged = None
    
    
    stateChanged = None
    
    
    staticMetaObject = None
    
    
    valueChanged = None


class QSettings(QObject):
    def __init__(*args, **kwargs):
        """
        x.__init__(...) initializes x; see help(type(x)) for signature
        """
    
        pass
    
    
    def allKeys(*args, **kwargs):
        pass
    
    
    def applicationName(*args, **kwargs):
        pass
    
    
    def beginGroup(*args, **kwargs):
        pass
    
    
    def beginReadArray(*args, **kwargs):
        pass
    
    
    def beginWriteArray(*args, **kwargs):
        pass
    
    
    def childGroups(*args, **kwargs):
        pass
    
    
    def childKeys(*args, **kwargs):
        pass
    
    
    def clear(*args, **kwargs):
        pass
    
    
    def contains(*args, **kwargs):
        pass
    
    
    def endArray(*args, **kwargs):
        pass
    
    
    def endGroup(*args, **kwargs):
        pass
    
    
    def event(*args, **kwargs):
        pass
    
    
    def fallbacksEnabled(*args, **kwargs):
        pass
    
    
    def fileName(*args, **kwargs):
        pass
    
    
    def format(*args, **kwargs):
        pass
    
    
    def group(*args, **kwargs):
        pass
    
    
    def iniCodec(*args, **kwargs):
        pass
    
    
    def isWritable(*args, **kwargs):
        pass
    
    
    def organizationName(*args, **kwargs):
        pass
    
    
    def remove(*args, **kwargs):
        pass
    
    
    def scope(*args, **kwargs):
        pass
    
    
    def setArrayIndex(*args, **kwargs):
        pass
    
    
    def setFallbacksEnabled(*args, **kwargs):
        pass
    
    
    def setIniCodec(*args, **kwargs):
        pass
    
    
    def setValue(*args, **kwargs):
        pass
    
    
    def status(*args, **kwargs):
        pass
    
    
    def sync(*args, **kwargs):
        pass
    
    
    def value(*args, **kwargs):
        pass
    
    
    def defaultFormat(*args, **kwargs):
        pass
    
    
    def setDefaultFormat(*args, **kwargs):
        pass
    
    
    def setPath(*args, **kwargs):
        pass
    
    
    AccessError = None
    
    
    CustomFormat1 = None
    
    
    CustomFormat10 = None
    
    
    CustomFormat11 = None
    
    
    CustomFormat12 = None
    
    
    CustomFormat13 = None
    
    
    CustomFormat14 = None
    
    
    CustomFormat15 = None
    
    
    CustomFormat16 = None
    
    
    CustomFormat2 = None
    
    
    CustomFormat3 = None
    
    
    CustomFormat4 = None
    
    
    CustomFormat5 = None
    
    
    CustomFormat6 = None
    
    
    CustomFormat7 = None
    
    
    CustomFormat8 = None
    
    
    CustomFormat9 = None
    
    
    Format = None
    
    
    FormatError = None
    
    
    IniFormat = None
    
    
    InvalidFormat = None
    
    
    NativeFormat = None
    
    
    NoError = None
    
    
    Scope = None
    
    
    Status = None
    
    
    SystemScope = None
    
    
    UserScope = None
    
    
    __new__ = None
    
    
    staticMetaObject = None


class QTimer(QObject):
    def __init__(*args, **kwargs):
        """
        x.__init__(...) initializes x; see help(type(x)) for signature
        """
    
        pass
    
    
    def interval(*args, **kwargs):
        pass
    
    
    def isActive(*args, **kwargs):
        pass
    
    
    def isSingleShot(*args, **kwargs):
        pass
    
    
    def killTimer(*args, **kwargs):
        pass
    
    
    def remainingTime(*args, **kwargs):
        pass
    
    
    def setInterval(*args, **kwargs):
        pass
    
    
    def setSingleShot(*args, **kwargs):
        pass
    
    
    def setTimerType(*args, **kwargs):
        pass
    
    
    def start(*args, **kwargs):
        pass
    
    
    def stop(*args, **kwargs):
        pass
    
    
    def timerEvent(*args, **kwargs):
        pass
    
    
    def timerId(*args, **kwargs):
        pass
    
    
    def timerType(*args, **kwargs):
        pass
    
    
    def singleShot(*args, **kwargs):
        pass
    
    
    __new__ = None
    
    
    staticMetaObject = None
    
    
    timeout = None


class QMimeData(QObject):
    def __init__(*args, **kwargs):
        """
        x.__init__(...) initializes x; see help(type(x)) for signature
        """
    
        pass
    
    
    def clear(*args, **kwargs):
        pass
    
    
    def colorData(*args, **kwargs):
        pass
    
    
    def data(*args, **kwargs):
        pass
    
    
    def formats(*args, **kwargs):
        pass
    
    
    def hasColor(*args, **kwargs):
        pass
    
    
    def hasFormat(*args, **kwargs):
        pass
    
    
    def hasHtml(*args, **kwargs):
        pass
    
    
    def hasImage(*args, **kwargs):
        pass
    
    
    def hasText(*args, **kwargs):
        pass
    
    
    def hasUrls(*args, **kwargs):
        pass
    
    
    def html(*args, **kwargs):
        pass
    
    
    def imageData(*args, **kwargs):
        pass
    
    
    def removeFormat(*args, **kwargs):
        pass
    
    
    def retrieveData(*args, **kwargs):
        pass
    
    
    def setColorData(*args, **kwargs):
        pass
    
    
    def setData(*args, **kwargs):
        pass
    
    
    def setHtml(*args, **kwargs):
        pass
    
    
    def setImageData(*args, **kwargs):
        pass
    
    
    def setText(*args, **kwargs):
        pass
    
    
    def setUrls(*args, **kwargs):
        pass
    
    
    def text(*args, **kwargs):
        pass
    
    
    def urls(*args, **kwargs):
        pass
    
    
    __new__ = None
    
    
    staticMetaObject = None


class QChildEvent(QEvent):
    def __init__(*args, **kwargs):
        """
        x.__init__(...) initializes x; see help(type(x)) for signature
        """
    
        pass
    
    
    def added(*args, **kwargs):
        pass
    
    
    def child(*args, **kwargs):
        pass
    
    
    def polished(*args, **kwargs):
        pass
    
    
    def removed(*args, **kwargs):
        pass
    
    
    __new__ = None


class QSignalMapper(QObject):
    def __init__(*args, **kwargs):
        """
        x.__init__(...) initializes x; see help(type(x)) for signature
        """
    
        pass
    
    
    def map(*args, **kwargs):
        pass
    
    
    def mapping(*args, **kwargs):
        pass
    
    
    def removeMappings(*args, **kwargs):
        pass
    
    
    def setMapping(*args, **kwargs):
        pass
    
    
    __new__ = None
    
    
    mapped = None
    
    
    staticMetaObject = None


class QPluginLoader(QObject):
    def __init__(*args, **kwargs):
        """
        x.__init__(...) initializes x; see help(type(x)) for signature
        """
    
        pass
    
    
    def errorString(*args, **kwargs):
        pass
    
    
    def fileName(*args, **kwargs):
        pass
    
    
    def instance(*args, **kwargs):
        pass
    
    
    def isLoaded(*args, **kwargs):
        pass
    
    
    def load(*args, **kwargs):
        pass
    
    
    def metaData(*args, **kwargs):
        pass
    
    
    def setFileName(*args, **kwargs):
        pass
    
    
    def unload(*args, **kwargs):
        pass
    
    
    def staticInstances(*args, **kwargs):
        pass
    
    
    __new__ = None
    
    
    staticMetaObject = None


class QIODevice(QObject):
    def __init__(*args, **kwargs):
        """
        x.__init__(...) initializes x; see help(type(x)) for signature
        """
    
        pass
    
    
    def atEnd(*args, **kwargs):
        pass
    
    
    def bytesAvailable(*args, **kwargs):
        pass
    
    
    def bytesToWrite(*args, **kwargs):
        pass
    
    
    def canReadLine(*args, **kwargs):
        pass
    
    
    def close(*args, **kwargs):
        pass
    
    
    def errorString(*args, **kwargs):
        pass
    
    
    def getChar(*args, **kwargs):
        pass
    
    
    def isOpen(*args, **kwargs):
        pass
    
    
    def isReadable(*args, **kwargs):
        pass
    
    
    def isSequential(*args, **kwargs):
        pass
    
    
    def isTextModeEnabled(*args, **kwargs):
        pass
    
    
    def isWritable(*args, **kwargs):
        pass
    
    
    def open(*args, **kwargs):
        pass
    
    
    def openMode(*args, **kwargs):
        pass
    
    
    def peek(*args, **kwargs):
        pass
    
    
    def pos(*args, **kwargs):
        pass
    
    
    def putChar(*args, **kwargs):
        pass
    
    
    def read(*args, **kwargs):
        pass
    
    
    def readAll(*args, **kwargs):
        pass
    
    
    def readData(*args, **kwargs):
        pass
    
    
    def readLine(*args, **kwargs):
        pass
    
    
    def readLineData(*args, **kwargs):
        pass
    
    
    def reset(*args, **kwargs):
        pass
    
    
    def seek(*args, **kwargs):
        pass
    
    
    def setErrorString(*args, **kwargs):
        pass
    
    
    def setOpenMode(*args, **kwargs):
        pass
    
    
    def setTextModeEnabled(*args, **kwargs):
        pass
    
    
    def size(*args, **kwargs):
        pass
    
    
    def ungetChar(*args, **kwargs):
        pass
    
    
    def waitForBytesWritten(*args, **kwargs):
        pass
    
    
    def waitForReadyRead(*args, **kwargs):
        pass
    
    
    def write(*args, **kwargs):
        pass
    
    
    def writeData(*args, **kwargs):
        pass
    
    
    Append = None
    
    
    NotOpen = None
    
    
    OpenMode = None
    
    
    OpenModeFlag = None
    
    
    ReadOnly = None
    
    
    ReadWrite = None
    
    
    Text = None
    
    
    Truncate = None
    
    
    Unbuffered = None
    
    
    WriteOnly = None
    
    
    __new__ = None
    
    
    aboutToClose = None
    
    
    bytesWritten = None
    
    
    readChannelFinished = None
    
    
    readyRead = None
    
    
    staticMetaObject = None


class QAbstractAnimation(QObject):
    def __init__(*args, **kwargs):
        """
        x.__init__(...) initializes x; see help(type(x)) for signature
        """
    
        pass
    
    
    def currentLoop(*args, **kwargs):
        pass
    
    
    def currentLoopTime(*args, **kwargs):
        pass
    
    
    def currentTime(*args, **kwargs):
        pass
    
    
    def direction(*args, **kwargs):
        pass
    
    
    def duration(*args, **kwargs):
        pass
    
    
    def event(*args, **kwargs):
        pass
    
    
    def group(*args, **kwargs):
        pass
    
    
    def loopCount(*args, **kwargs):
        pass
    
    
    def pause(*args, **kwargs):
        pass
    
    
    def resume(*args, **kwargs):
        pass
    
    
    def setCurrentTime(*args, **kwargs):
        pass
    
    
    def setDirection(*args, **kwargs):
        pass
    
    
    def setLoopCount(*args, **kwargs):
        pass
    
    
    def setPaused(*args, **kwargs):
        pass
    
    
    def start(*args, **kwargs):
        pass
    
    
    def state(*args, **kwargs):
        pass
    
    
    def stop(*args, **kwargs):
        pass
    
    
    def totalDuration(*args, **kwargs):
        pass
    
    
    def updateCurrentTime(*args, **kwargs):
        pass
    
    
    def updateDirection(*args, **kwargs):
        pass
    
    
    def updateState(*args, **kwargs):
        pass
    
    
    Backward = None
    
    
    DeleteWhenStopped = None
    
    
    DeletionPolicy = None
    
    
    Direction = None
    
    
    Forward = None
    
    
    KeepWhenStopped = None
    
    
    Paused = None
    
    
    Running = None
    
    
    State = None
    
    
    Stopped = None
    
    
    __new__ = None
    
    
    currentLoopChanged = None
    
    
    directionChanged = None
    
    
    finished = None
    
    
    stateChanged = None
    
    
    staticMetaObject = None


class QTimerEvent(QEvent):
    def __init__(*args, **kwargs):
        """
        x.__init__(...) initializes x; see help(type(x)) for signature
        """
    
        pass
    
    
    def timerId(*args, **kwargs):
        pass
    
    
    __new__ = None


class QMutex(QBasicMutex):
    def __init__(*args, **kwargs):
        """
        x.__init__(...) initializes x; see help(type(x)) for signature
        """
    
        pass
    
    
    def lock(*args, **kwargs):
        pass
    
    
    def tryLock(*args, **kwargs):
        pass
    
    
    def unlock(*args, **kwargs):
        pass
    
    
    NonRecursive = None
    
    
    RecursionMode = None
    
    
    Recursive = None
    
    
    __new__ = None


class QTranslator(QObject):
    def __init__(*args, **kwargs):
        """
        x.__init__(...) initializes x; see help(type(x)) for signature
        """
    
        pass
    
    
    def isEmpty(*args, **kwargs):
        pass
    
    
    def load(*args, **kwargs):
        pass
    
    
    def translate(*args, **kwargs):
        pass
    
    
    __new__ = None
    
    
    staticMetaObject = None


class QCoreApplication(QObject):
    def __init__(*args, **kwargs):
        """
        x.__init__(...) initializes x; see help(type(x)) for signature
        """
    
        pass
    
    
    def event(*args, **kwargs):
        pass
    
    
    def notify(*args, **kwargs):
        pass
    
    
    def addLibraryPath(*args, **kwargs):
        pass
    
    
    def applicationDirPath(*args, **kwargs):
        pass
    
    
    def applicationFilePath(*args, **kwargs):
        pass
    
    
    def applicationName(*args, **kwargs):
        pass
    
    
    def applicationPid(*args, **kwargs):
        pass
    
    
    def applicationVersion(*args, **kwargs):
        pass
    
    
    def arguments(*args, **kwargs):
        pass
    
    
    def closingDown(*args, **kwargs):
        pass
    
    
    def eventDispatcher(*args, **kwargs):
        pass
    
    
    def exec_(*args, **kwargs):
        pass
    
    
    def exit(*args, **kwargs):
        pass
    
    
    def flush(*args, **kwargs):
        pass
    
    
    def hasPendingEvents(*args, **kwargs):
        pass
    
    
    def installTranslator(*args, **kwargs):
        pass
    
    
    def instance(*args, **kwargs):
        pass
    
    
    def isQuitLockEnabled(*args, **kwargs):
        pass
    
    
    def isSetuidAllowed(*args, **kwargs):
        pass
    
    
    def libraryPaths(*args, **kwargs):
        pass
    
    
    def organizationDomain(*args, **kwargs):
        pass
    
    
    def organizationName(*args, **kwargs):
        pass
    
    
    def postEvent(*args, **kwargs):
        pass
    
    
    def processEvents(*args, **kwargs):
        pass
    
    
    def quit(*args, **kwargs):
        pass
    
    
    def removeLibraryPath(*args, **kwargs):
        pass
    
    
    def removePostedEvents(*args, **kwargs):
        pass
    
    
    def removeTranslator(*args, **kwargs):
        pass
    
    
    def sendEvent(*args, **kwargs):
        pass
    
    
    def sendPostedEvents(*args, **kwargs):
        pass
    
    
    def setApplicationName(*args, **kwargs):
        pass
    
    
    def setApplicationVersion(*args, **kwargs):
        pass
    
    
    def setAttribute(*args, **kwargs):
        pass
    
    
    def setEventDispatcher(*args, **kwargs):
        pass
    
    
    def setLibraryPaths(*args, **kwargs):
        pass
    
    
    def setOrganizationDomain(*args, **kwargs):
        pass
    
    
    def setOrganizationName(*args, **kwargs):
        pass
    
    
    def setQuitLockEnabled(*args, **kwargs):
        pass
    
    
    def setSetuidAllowed(*args, **kwargs):
        pass
    
    
    def startingUp(*args, **kwargs):
        pass
    
    
    def testAttribute(*args, **kwargs):
        pass
    
    
    def translate(*args, **kwargs):
        pass
    
    
    ApplicationFlags = 329216
    
    
    __new__ = None
    
    
    aboutToQuit = None
    
    
    applicationNameChanged = None
    
    
    applicationVersionChanged = None
    
    
    organizationDomainChanged = None
    
    
    organizationNameChanged = None
    
    
    staticMetaObject = None


class QAbstractState(QObject):
    def __init__(*args, **kwargs):
        """
        x.__init__(...) initializes x; see help(type(x)) for signature
        """
    
        pass
    
    
    def active(*args, **kwargs):
        pass
    
    
    def event(*args, **kwargs):
        pass
    
    
    def machine(*args, **kwargs):
        pass
    
    
    def onEntry(*args, **kwargs):
        pass
    
    
    def onExit(*args, **kwargs):
        pass
    
    
    def parentState(*args, **kwargs):
        pass
    
    
    __new__ = None
    
    
    activeChanged = None
    
    
    entered = None
    
    
    exited = None
    
    
    staticMetaObject = None


class QSocketNotifier(QObject):
    def __init__(*args, **kwargs):
        """
        x.__init__(...) initializes x; see help(type(x)) for signature
        """
    
        pass
    
    
    def event(*args, **kwargs):
        pass
    
    
    def isEnabled(*args, **kwargs):
        pass
    
    
    def setEnabled(*args, **kwargs):
        pass
    
    
    def socket(*args, **kwargs):
        pass
    
    
    def type(*args, **kwargs):
        pass
    
    
    Exception = None
    
    
    Read = None
    
    
    Type = None
    
    
    Write = None
    
    
    __new__ = None
    
    
    activated = None
    
    
    staticMetaObject = None


class QFileSystemWatcher(QObject):
    def __init__(*args, **kwargs):
        """
        x.__init__(...) initializes x; see help(type(x)) for signature
        """
    
        pass
    
    
    def addPath(*args, **kwargs):
        pass
    
    
    def addPaths(*args, **kwargs):
        pass
    
    
    def directories(*args, **kwargs):
        pass
    
    
    def files(*args, **kwargs):
        pass
    
    
    def removePath(*args, **kwargs):
        pass
    
    
    def removePaths(*args, **kwargs):
        pass
    
    
    __new__ = None
    
    
    directoryChanged = None
    
    
    fileChanged = None
    
    
    staticMetaObject = None


class QItemSelectionModel(QObject):
    def __init__(*args, **kwargs):
        """
        x.__init__(...) initializes x; see help(type(x)) for signature
        """
    
        pass
    
    
    def clear(*args, **kwargs):
        pass
    
    
    def clearCurrentIndex(*args, **kwargs):
        pass
    
    
    def clearSelection(*args, **kwargs):
        pass
    
    
    def columnIntersectsSelection(*args, **kwargs):
        pass
    
    
    def currentIndex(*args, **kwargs):
        pass
    
    
    def emitSelectionChanged(*args, **kwargs):
        pass
    
    
    def hasSelection(*args, **kwargs):
        pass
    
    
    def isColumnSelected(*args, **kwargs):
        pass
    
    
    def isRowSelected(*args, **kwargs):
        pass
    
    
    def isSelected(*args, **kwargs):
        pass
    
    
    def model(*args, **kwargs):
        pass
    
    
    def reset(*args, **kwargs):
        pass
    
    
    def rowIntersectsSelection(*args, **kwargs):
        pass
    
    
    def select(*args, **kwargs):
        pass
    
    
    def selectedColumns(*args, **kwargs):
        pass
    
    
    def selectedIndexes(*args, **kwargs):
        pass
    
    
    def selectedRows(*args, **kwargs):
        pass
    
    
    def selection(*args, **kwargs):
        pass
    
    
    def setCurrentIndex(*args, **kwargs):
        pass
    
    
    def setModel(*args, **kwargs):
        pass
    
    
    Clear = None
    
    
    ClearAndSelect = None
    
    
    Columns = None
    
    
    Current = None
    
    
    Deselect = None
    
    
    NoUpdate = None
    
    
    Rows = None
    
    
    Select = None
    
    
    SelectCurrent = None
    
    
    SelectionFlag = None
    
    
    SelectionFlags = None
    
    
    Toggle = None
    
    
    ToggleCurrent = None
    
    
    __new__ = None
    
    
    currentChanged = None
    
    
    currentColumnChanged = None
    
    
    currentRowChanged = None
    
    
    modelChanged = None
    
    
    selectionChanged = None
    
    
    staticMetaObject = None


class QThread(QObject):
    def __init__(*args, **kwargs):
        """
        x.__init__(...) initializes x; see help(type(x)) for signature
        """
    
        pass
    
    
    def event(*args, **kwargs):
        pass
    
    
    def eventDispatcher(*args, **kwargs):
        pass
    
    
    def exec_(*args, **kwargs):
        pass
    
    
    def exit(*args, **kwargs):
        pass
    
    
    def isFinished(*args, **kwargs):
        pass
    
    
    def isInterruptionRequested(*args, **kwargs):
        pass
    
    
    def isRunning(*args, **kwargs):
        pass
    
    
    def loopLevel(*args, **kwargs):
        pass
    
    
    def priority(*args, **kwargs):
        pass
    
    
    def quit(*args, **kwargs):
        pass
    
    
    def requestInterruption(*args, **kwargs):
        pass
    
    
    def run(*args, **kwargs):
        pass
    
    
    def setEventDispatcher(*args, **kwargs):
        pass
    
    
    def setPriority(*args, **kwargs):
        pass
    
    
    def setStackSize(*args, **kwargs):
        pass
    
    
    def stackSize(*args, **kwargs):
        pass
    
    
    def start(*args, **kwargs):
        pass
    
    
    def terminate(*args, **kwargs):
        pass
    
    
    def wait(*args, **kwargs):
        pass
    
    
    def currentThread(*args, **kwargs):
        pass
    
    
    def currentThreadId(*args, **kwargs):
        pass
    
    
    def idealThreadCount(*args, **kwargs):
        pass
    
    
    def msleep(*args, **kwargs):
        pass
    
    
    def setTerminationEnabled(*args, **kwargs):
        pass
    
    
    def sleep(*args, **kwargs):
        pass
    
    
    def usleep(*args, **kwargs):
        pass
    
    
    def yieldCurrentThread(*args, **kwargs):
        pass
    
    
    HighPriority = None
    
    
    HighestPriority = None
    
    
    IdlePriority = None
    
    
    InheritPriority = None
    
    
    LowPriority = None
    
    
    LowestPriority = None
    
    
    NormalPriority = None
    
    
    Priority = None
    
    
    TimeCriticalPriority = None
    
    
    __new__ = None
    
    
    finished = None
    
    
    started = None
    
    
    staticMetaObject = None


class QAbstractEventDispatcher(QObject):
    def __init__(*args, **kwargs):
        """
        x.__init__(...) initializes x; see help(type(x)) for signature
        """
    
        pass
    
    
    def closingDown(*args, **kwargs):
        pass
    
    
    def flush(*args, **kwargs):
        pass
    
    
    def hasPendingEvents(*args, **kwargs):
        pass
    
    
    def interrupt(*args, **kwargs):
        pass
    
    
    def processEvents(*args, **kwargs):
        pass
    
    
    def registerSocketNotifier(*args, **kwargs):
        pass
    
    
    def registerTimer(*args, **kwargs):
        pass
    
    
    def registeredTimers(*args, **kwargs):
        pass
    
    
    def remainingTime(*args, **kwargs):
        pass
    
    
    def startingUp(*args, **kwargs):
        pass
    
    
    def unregisterSocketNotifier(*args, **kwargs):
        pass
    
    
    def unregisterTimer(*args, **kwargs):
        pass
    
    
    def unregisterTimers(*args, **kwargs):
        pass
    
    
    def wakeUp(*args, **kwargs):
        pass
    
    
    def instance(*args, **kwargs):
        pass
    
    
    TimerInfo = None
    
    
    __new__ = None
    
    
    aboutToBlock = None
    
    
    awake = None
    
    
    staticMetaObject = None


class QThreadPool(QObject):
    def __init__(*args, **kwargs):
        """
        x.__init__(...) initializes x; see help(type(x)) for signature
        """
    
        pass
    
    
    def activeThreadCount(*args, **kwargs):
        pass
    
    
    def cancel(*args, **kwargs):
        pass
    
    
    def clear(*args, **kwargs):
        pass
    
    
    def expiryTimeout(*args, **kwargs):
        pass
    
    
    def maxThreadCount(*args, **kwargs):
        pass
    
    
    def releaseThread(*args, **kwargs):
        pass
    
    
    def reserveThread(*args, **kwargs):
        pass
    
    
    def setExpiryTimeout(*args, **kwargs):
        pass
    
    
    def setMaxThreadCount(*args, **kwargs):
        pass
    
    
    def start(*args, **kwargs):
        pass
    
    
    def tryStart(*args, **kwargs):
        pass
    
    
    def waitForDone(*args, **kwargs):
        pass
    
    
    def globalInstance(*args, **kwargs):
        pass
    
    
    __new__ = None
    
    
    staticMetaObject = None


class QAbstractTransition(QObject):
    def __init__(*args, **kwargs):
        """
        x.__init__(...) initializes x; see help(type(x)) for signature
        """
    
        pass
    
    
    def addAnimation(*args, **kwargs):
        pass
    
    
    def animations(*args, **kwargs):
        pass
    
    
    def event(*args, **kwargs):
        pass
    
    
    def eventTest(*args, **kwargs):
        pass
    
    
    def machine(*args, **kwargs):
        pass
    
    
    def onTransition(*args, **kwargs):
        pass
    
    
    def removeAnimation(*args, **kwargs):
        pass
    
    
    def setTargetState(*args, **kwargs):
        pass
    
    
    def setTargetStates(*args, **kwargs):
        pass
    
    
    def setTransitionType(*args, **kwargs):
        pass
    
    
    def sourceState(*args, **kwargs):
        pass
    
    
    def targetState(*args, **kwargs):
        pass
    
    
    def targetStates(*args, **kwargs):
        pass
    
    
    def transitionType(*args, **kwargs):
        pass
    
    
    ExternalTransition = None
    
    
    InternalTransition = None
    
    
    TransitionType = None
    
    
    __new__ = None
    
    
    staticMetaObject = None
    
    
    targetStateChanged = None
    
    
    targetStatesChanged = None
    
    
    triggered = None


class QGenericReturnArgument(QGenericArgument):
    def __copy__(*args, **kwargs):
        pass
    
    
    def __init__(*args, **kwargs):
        """
        x.__init__(...) initializes x; see help(type(x)) for signature
        """
    
        pass
    
    
    __new__ = None


class QEventLoop(QObject):
    def __init__(*args, **kwargs):
        """
        x.__init__(...) initializes x; see help(type(x)) for signature
        """
    
        pass
    
    
    def event(*args, **kwargs):
        pass
    
    
    def exec_(*args, **kwargs):
        pass
    
    
    def exit(*args, **kwargs):
        pass
    
    
    def isRunning(*args, **kwargs):
        pass
    
    
    def processEvents(*args, **kwargs):
        pass
    
    
    def quit(*args, **kwargs):
        pass
    
    
    def wakeUp(*args, **kwargs):
        pass
    
    
    AllEvents = None
    
    
    DialogExec = None
    
    
    EventLoopExec = None
    
    
    ExcludeSocketNotifiers = None
    
    
    ExcludeUserInputEvents = None
    
    
    ProcessEventsFlag = None
    
    
    ProcessEventsFlags = None
    
    
    WaitForMoreEvents = None
    
    
    X11ExcludeTimers = None
    
    
    __new__ = None
    
    
    staticMetaObject = None


class QVariantAnimation(QAbstractAnimation):
    def __init__(*args, **kwargs):
        """
        x.__init__(...) initializes x; see help(type(x)) for signature
        """
    
        pass
    
    
    def currentValue(*args, **kwargs):
        pass
    
    
    def duration(*args, **kwargs):
        pass
    
    
    def easingCurve(*args, **kwargs):
        pass
    
    
    def endValue(*args, **kwargs):
        pass
    
    
    def event(*args, **kwargs):
        pass
    
    
    def interpolated(*args, **kwargs):
        pass
    
    
    def keyValueAt(*args, **kwargs):
        pass
    
    
    def keyValues(*args, **kwargs):
        pass
    
    
    def setDuration(*args, **kwargs):
        pass
    
    
    def setEasingCurve(*args, **kwargs):
        pass
    
    
    def setEndValue(*args, **kwargs):
        pass
    
    
    def setKeyValueAt(*args, **kwargs):
        pass
    
    
    def setKeyValues(*args, **kwargs):
        pass
    
    
    def setStartValue(*args, **kwargs):
        pass
    
    
    def startValue(*args, **kwargs):
        pass
    
    
    def updateCurrentTime(*args, **kwargs):
        pass
    
    
    def updateCurrentValue(*args, **kwargs):
        pass
    
    
    def updateState(*args, **kwargs):
        pass
    
    
    __new__ = None
    
    
    staticMetaObject = None
    
    
    valueChanged = None


class QFileDevice(QIODevice):
    def __init__(*args, **kwargs):
        """
        x.__init__(...) initializes x; see help(type(x)) for signature
        """
    
        pass
    
    
    def atEnd(*args, **kwargs):
        pass
    
    
    def close(*args, **kwargs):
        pass
    
    
    def error(*args, **kwargs):
        pass
    
    
    def fileName(*args, **kwargs):
        pass
    
    
    def flush(*args, **kwargs):
        pass
    
    
    def handle(*args, **kwargs):
        pass
    
    
    def isSequential(*args, **kwargs):
        pass
    
    
    def map(*args, **kwargs):
        pass
    
    
    def permissions(*args, **kwargs):
        pass
    
    
    def pos(*args, **kwargs):
        pass
    
    
    def readData(*args, **kwargs):
        pass
    
    
    def readLineData(*args, **kwargs):
        pass
    
    
    def resize(*args, **kwargs):
        pass
    
    
    def seek(*args, **kwargs):
        pass
    
    
    def setPermissions(*args, **kwargs):
        pass
    
    
    def size(*args, **kwargs):
        pass
    
    
    def unmap(*args, **kwargs):
        pass
    
    
    def unsetError(*args, **kwargs):
        pass
    
    
    def writeData(*args, **kwargs):
        pass
    
    
    AbortError = None
    
    
    AutoCloseHandle = None
    
    
    CopyError = None
    
    
    DontCloseHandle = None
    
    
    ExeGroup = None
    
    
    ExeOther = None
    
    
    ExeOwner = None
    
    
    ExeUser = None
    
    
    FatalError = None
    
    
    FileError = None
    
    
    FileHandleFlag = None
    
    
    FileHandleFlags = None
    
    
    MapPrivateOption = None
    
    
    MemoryMapFlags = None
    
    
    NoError = None
    
    
    NoOptions = None
    
    
    OpenError = None
    
    
    Permission = None
    
    
    Permissions = None
    
    
    PermissionsError = None
    
    
    PositionError = None
    
    
    ReadError = None
    
    
    ReadGroup = None
    
    
    ReadOther = None
    
    
    ReadOwner = None
    
    
    ReadUser = None
    
    
    RemoveError = None
    
    
    RenameError = None
    
    
    ResizeError = None
    
    
    ResourceError = None
    
    
    TimeOutError = None
    
    
    UnspecifiedError = None
    
    
    WriteError = None
    
    
    WriteGroup = None
    
    
    WriteOther = None
    
    
    WriteOwner = None
    
    
    WriteUser = None
    
    
    __new__ = None
    
    
    staticMetaObject = None


class QHistoryState(QAbstractState):
    def __init__(*args, **kwargs):
        """
        x.__init__(...) initializes x; see help(type(x)) for signature
        """
    
        pass
    
    
    def defaultState(*args, **kwargs):
        pass
    
    
    def defaultTransition(*args, **kwargs):
        pass
    
    
    def event(*args, **kwargs):
        pass
    
    
    def historyType(*args, **kwargs):
        pass
    
    
    def onEntry(*args, **kwargs):
        pass
    
    
    def onExit(*args, **kwargs):
        pass
    
    
    def setDefaultState(*args, **kwargs):
        pass
    
    
    def setDefaultTransition(*args, **kwargs):
        pass
    
    
    def setHistoryType(*args, **kwargs):
        pass
    
    
    DeepHistory = None
    
    
    HistoryType = None
    
    
    ShallowHistory = None
    
    
    __new__ = None
    
    
    defaultStateChanged = None
    
    
    defaultTransitionChanged = None
    
    
    historyTypeChanged = None
    
    
    staticMetaObject = None


class QEventTransition(QAbstractTransition):
    def __init__(*args, **kwargs):
        """
        x.__init__(...) initializes x; see help(type(x)) for signature
        """
    
        pass
    
    
    def event(*args, **kwargs):
        pass
    
    
    def eventSource(*args, **kwargs):
        pass
    
    
    def eventTest(*args, **kwargs):
        pass
    
    
    def eventType(*args, **kwargs):
        pass
    
    
    def onTransition(*args, **kwargs):
        pass
    
    
    def setEventSource(*args, **kwargs):
        pass
    
    
    def setEventType(*args, **kwargs):
        pass
    
    
    __new__ = None
    
    
    staticMetaObject = None


class QBuffer(QIODevice):
    def __init__(*args, **kwargs):
        """
        x.__init__(...) initializes x; see help(type(x)) for signature
        """
    
        pass
    
    
    def atEnd(*args, **kwargs):
        pass
    
    
    def buffer(*args, **kwargs):
        pass
    
    
    def canReadLine(*args, **kwargs):
        pass
    
    
    def close(*args, **kwargs):
        pass
    
    
    def connectNotify(*args, **kwargs):
        pass
    
    
    def data(*args, **kwargs):
        pass
    
    
    def disconnectNotify(*args, **kwargs):
        pass
    
    
    def open(*args, **kwargs):
        pass
    
    
    def pos(*args, **kwargs):
        pass
    
    
    def readData(*args, **kwargs):
        pass
    
    
    def seek(*args, **kwargs):
        pass
    
    
    def setBuffer(*args, **kwargs):
        pass
    
    
    def setData(*args, **kwargs):
        pass
    
    
    def size(*args, **kwargs):
        pass
    
    
    def writeData(*args, **kwargs):
        pass
    
    
    __new__ = None
    
    
    staticMetaObject = None


class QState(QAbstractState):
    def __init__(*args, **kwargs):
        """
        x.__init__(...) initializes x; see help(type(x)) for signature
        """
    
        pass
    
    
    def addTransition(*args, **kwargs):
        pass
    
    
    def assignProperty(*args, **kwargs):
        pass
    
    
    def childMode(*args, **kwargs):
        pass
    
    
    def errorState(*args, **kwargs):
        pass
    
    
    def event(*args, **kwargs):
        pass
    
    
    def initialState(*args, **kwargs):
        pass
    
    
    def onEntry(*args, **kwargs):
        pass
    
    
    def onExit(*args, **kwargs):
        pass
    
    
    def removeTransition(*args, **kwargs):
        pass
    
    
    def setChildMode(*args, **kwargs):
        pass
    
    
    def setErrorState(*args, **kwargs):
        pass
    
    
    def setInitialState(*args, **kwargs):
        pass
    
    
    def transitions(*args, **kwargs):
        pass
    
    
    ChildMode = None
    
    
    DontRestoreProperties = None
    
    
    ExclusiveStates = None
    
    
    ParallelStates = None
    
    
    RestorePolicy = None
    
    
    RestoreProperties = None
    
    
    __new__ = None
    
    
    childModeChanged = None
    
    
    errorStateChanged = None
    
    
    finished = None
    
    
    initialStateChanged = None
    
    
    propertiesAssigned = None
    
    
    staticMetaObject = None


class QAbstractProxyModel(QAbstractItemModel):
    def __init__(*args, **kwargs):
        """
        x.__init__(...) initializes x; see help(type(x)) for signature
        """
    
        pass
    
    
    def buddy(*args, **kwargs):
        pass
    
    
    def canDropMimeData(*args, **kwargs):
        pass
    
    
    def canFetchMore(*args, **kwargs):
        pass
    
    
    def data(*args, **kwargs):
        pass
    
    
    def dropMimeData(*args, **kwargs):
        pass
    
    
    def fetchMore(*args, **kwargs):
        pass
    
    
    def flags(*args, **kwargs):
        pass
    
    
    def hasChildren(*args, **kwargs):
        pass
    
    
    def headerData(*args, **kwargs):
        pass
    
    
    def itemData(*args, **kwargs):
        pass
    
    
    def mapFromSource(*args, **kwargs):
        pass
    
    
    def mapSelectionFromSource(*args, **kwargs):
        pass
    
    
    def mapSelectionToSource(*args, **kwargs):
        pass
    
    
    def mapToSource(*args, **kwargs):
        pass
    
    
    def mimeData(*args, **kwargs):
        pass
    
    
    def mimeTypes(*args, **kwargs):
        pass
    
    
    def resetInternalData(*args, **kwargs):
        pass
    
    
    def revert(*args, **kwargs):
        pass
    
    
    def setData(*args, **kwargs):
        pass
    
    
    def setHeaderData(*args, **kwargs):
        pass
    
    
    def setItemData(*args, **kwargs):
        pass
    
    
    def setSourceModel(*args, **kwargs):
        pass
    
    
    def sibling(*args, **kwargs):
        pass
    
    
    def sort(*args, **kwargs):
        pass
    
    
    def sourceModel(*args, **kwargs):
        pass
    
    
    def span(*args, **kwargs):
        pass
    
    
    def submit(*args, **kwargs):
        pass
    
    
    def supportedDragActions(*args, **kwargs):
        pass
    
    
    def supportedDropActions(*args, **kwargs):
        pass
    
    
    __new__ = None
    
    
    sourceModelChanged = None
    
    
    staticMetaObject = None


class QSignalTransition(QAbstractTransition):
    def __init__(*args, **kwargs):
        """
        x.__init__(...) initializes x; see help(type(x)) for signature
        """
    
        pass
    
    
    def event(*args, **kwargs):
        pass
    
    
    def eventTest(*args, **kwargs):
        pass
    
    
    def onTransition(*args, **kwargs):
        pass
    
    
    def senderObject(*args, **kwargs):
        pass
    
    
    def setSenderObject(*args, **kwargs):
        pass
    
    
    def setSignal(*args, **kwargs):
        pass
    
    
    def signal(*args, **kwargs):
        pass
    
    
    __new__ = None
    
    
    senderObjectChanged = None
    
    
    signalChanged = None
    
    
    staticMetaObject = None


class QFinalState(QAbstractState):
    def __init__(*args, **kwargs):
        """
        x.__init__(...) initializes x; see help(type(x)) for signature
        """
    
        pass
    
    
    def event(*args, **kwargs):
        pass
    
    
    def onEntry(*args, **kwargs):
        pass
    
    
    def onExit(*args, **kwargs):
        pass
    
    
    __new__ = None
    
    
    staticMetaObject = None


class QAbstractTableModel(QAbstractItemModel):
    def __init__(*args, **kwargs):
        """
        x.__init__(...) initializes x; see help(type(x)) for signature
        """
    
        pass
    
    
    def dropMimeData(*args, **kwargs):
        pass
    
    
    def flags(*args, **kwargs):
        pass
    
    
    def hasChildren(*args, **kwargs):
        pass
    
    
    def index(*args, **kwargs):
        pass
    
    
    def parent(*args, **kwargs):
        pass
    
    
    def sibling(*args, **kwargs):
        pass
    
    
    __new__ = None
    
    
    staticMetaObject = None


class QAbstractListModel(QAbstractItemModel):
    def __init__(*args, **kwargs):
        """
        x.__init__(...) initializes x; see help(type(x)) for signature
        """
    
        pass
    
    
    def columnCount(*args, **kwargs):
        pass
    
    
    def dropMimeData(*args, **kwargs):
        pass
    
    
    def flags(*args, **kwargs):
        pass
    
    
    def hasChildren(*args, **kwargs):
        pass
    
    
    def index(*args, **kwargs):
        pass
    
    
    def parent(*args, **kwargs):
        pass
    
    
    def sibling(*args, **kwargs):
        pass
    
    
    __new__ = None
    
    
    staticMetaObject = None


class QPauseAnimation(QAbstractAnimation):
    def __init__(*args, **kwargs):
        """
        x.__init__(...) initializes x; see help(type(x)) for signature
        """
    
        pass
    
    
    def duration(*args, **kwargs):
        pass
    
    
    def event(*args, **kwargs):
        pass
    
    
    def setDuration(*args, **kwargs):
        pass
    
    
    def updateCurrentTime(*args, **kwargs):
        pass
    
    
    __new__ = None
    
    
    staticMetaObject = None


class QAnimationGroup(QAbstractAnimation):
    def __init__(*args, **kwargs):
        """
        x.__init__(...) initializes x; see help(type(x)) for signature
        """
    
        pass
    
    
    def addAnimation(*args, **kwargs):
        pass
    
    
    def animationAt(*args, **kwargs):
        pass
    
    
    def animationCount(*args, **kwargs):
        pass
    
    
    def clear(*args, **kwargs):
        pass
    
    
    def event(*args, **kwargs):
        pass
    
    
    def indexOfAnimation(*args, **kwargs):
        pass
    
    
    def insertAnimation(*args, **kwargs):
        pass
    
    
    def removeAnimation(*args, **kwargs):
        pass
    
    
    def takeAnimation(*args, **kwargs):
        pass
    
    
    __new__ = None
    
    
    staticMetaObject = None


class QProcess(QIODevice):
    def __init__(*args, **kwargs):
        """
        x.__init__(...) initializes x; see help(type(x)) for signature
        """
    
        pass
    
    
    def arguments(*args, **kwargs):
        pass
    
    
    def atEnd(*args, **kwargs):
        pass
    
    
    def bytesAvailable(*args, **kwargs):
        pass
    
    
    def bytesToWrite(*args, **kwargs):
        pass
    
    
    def canReadLine(*args, **kwargs):
        pass
    
    
    def close(*args, **kwargs):
        pass
    
    
    def closeReadChannel(*args, **kwargs):
        pass
    
    
    def closeWriteChannel(*args, **kwargs):
        pass
    
    
    def environment(*args, **kwargs):
        pass
    
    
    def exitCode(*args, **kwargs):
        pass
    
    
    def exitStatus(*args, **kwargs):
        pass
    
    
    def inputChannelMode(*args, **kwargs):
        pass
    
    
    def isSequential(*args, **kwargs):
        pass
    
    
    def kill(*args, **kwargs):
        pass
    
    
    def open(*args, **kwargs):
        pass
    
    
    def pid(*args, **kwargs):
        pass
    
    
    def processChannelMode(*args, **kwargs):
        pass
    
    
    def processEnvironment(*args, **kwargs):
        pass
    
    
    def processId(*args, **kwargs):
        pass
    
    
    def program(*args, **kwargs):
        pass
    
    
    def readAllStandardError(*args, **kwargs):
        pass
    
    
    def readAllStandardOutput(*args, **kwargs):
        pass
    
    
    def readChannel(*args, **kwargs):
        pass
    
    
    def readData(*args, **kwargs):
        pass
    
    
    def setArguments(*args, **kwargs):
        pass
    
    
    def setEnvironment(*args, **kwargs):
        pass
    
    
    def setInputChannelMode(*args, **kwargs):
        pass
    
    
    def setProcessChannelMode(*args, **kwargs):
        pass
    
    
    def setProcessEnvironment(*args, **kwargs):
        pass
    
    
    def setProcessState(*args, **kwargs):
        pass
    
    
    def setProgram(*args, **kwargs):
        pass
    
    
    def setReadChannel(*args, **kwargs):
        pass
    
    
    def setStandardErrorFile(*args, **kwargs):
        pass
    
    
    def setStandardInputFile(*args, **kwargs):
        pass
    
    
    def setStandardOutputFile(*args, **kwargs):
        pass
    
    
    def setStandardOutputProcess(*args, **kwargs):
        pass
    
    
    def setWorkingDirectory(*args, **kwargs):
        pass
    
    
    def setupChildProcess(*args, **kwargs):
        pass
    
    
    def start(*args, **kwargs):
        pass
    
    
    def state(*args, **kwargs):
        pass
    
    
    def terminate(*args, **kwargs):
        pass
    
    
    def waitForBytesWritten(*args, **kwargs):
        pass
    
    
    def waitForFinished(*args, **kwargs):
        pass
    
    
    def waitForReadyRead(*args, **kwargs):
        pass
    
    
    def waitForStarted(*args, **kwargs):
        pass
    
    
    def workingDirectory(*args, **kwargs):
        pass
    
    
    def writeData(*args, **kwargs):
        pass
    
    
    def execute(*args, **kwargs):
        pass
    
    
    def nullDevice(*args, **kwargs):
        pass
    
    
    def startDetached(*args, **kwargs):
        pass
    
    
    def systemEnvironment(*args, **kwargs):
        pass
    
    
    CrashExit = None
    
    
    Crashed = None
    
    
    ExitStatus = None
    
    
    FailedToStart = None
    
    
    ForwardedChannels = None
    
    
    ForwardedErrorChannel = None
    
    
    ForwardedInputChannel = None
    
    
    ForwardedOutputChannel = None
    
    
    InputChannelMode = None
    
    
    ManagedInputChannel = None
    
    
    MergedChannels = None
    
    
    NormalExit = None
    
    
    NotRunning = None
    
    
    ProcessChannel = None
    
    
    ProcessChannelMode = None
    
    
    ProcessError = None
    
    
    ProcessState = None
    
    
    ReadError = None
    
    
    Running = None
    
    
    SeparateChannels = None
    
    
    StandardError = None
    
    
    StandardOutput = None
    
    
    Starting = None
    
    
    Timedout = None
    
    
    UnknownError = None
    
    
    WriteError = None
    
    
    __new__ = None
    
    
    error = None
    
    
    errorOccurred = None
    
    
    finished = None
    
    
    readyReadStandardError = None
    
    
    readyReadStandardOutput = None
    
    
    started = None
    
    
    stateChanged = None
    
    
    staticMetaObject = None


class QFile(QFileDevice):
    def __getattribute__(*args, **kwargs):
        """
        x.__getattribute__('name') <==> x.name
        """
    
        pass
    
    
    def __init__(*args, **kwargs):
        """
        x.__init__(...) initializes x; see help(type(x)) for signature
        """
    
        pass
    
    
    def fileName(*args, **kwargs):
        pass
    
    
    def open(*args, **kwargs):
        pass
    
    
    def setFileName(*args, **kwargs):
        pass
    
    
    def size(*args, **kwargs):
        pass
    
    
    def copy(*args, **kwargs):
        pass
    
    
    def decodeName(*args, **kwargs):
        pass
    
    
    def encodeName(*args, **kwargs):
        pass
    
    
    def exists(*args, **kwargs):
        pass
    
    
    def link(*args, **kwargs):
        pass
    
    
    def permissions(*args, **kwargs):
        pass
    
    
    def readLink(*args, **kwargs):
        pass
    
    
    def remove(*args, **kwargs):
        pass
    
    
    def rename(*args, **kwargs):
        pass
    
    
    def resize(*args, **kwargs):
        pass
    
    
    def setPermissions(*args, **kwargs):
        pass
    
    
    def symLinkTarget(*args, **kwargs):
        pass
    
    
    __new__ = None
    
    
    staticMetaObject = None


class QParallelAnimationGroup(QAnimationGroup):
    def __init__(*args, **kwargs):
        """
        x.__init__(...) initializes x; see help(type(x)) for signature
        """
    
        pass
    
    
    def duration(*args, **kwargs):
        pass
    
    
    def event(*args, **kwargs):
        pass
    
    
    def updateCurrentTime(*args, **kwargs):
        pass
    
    
    def updateDirection(*args, **kwargs):
        pass
    
    
    def updateState(*args, **kwargs):
        pass
    
    
    __new__ = None
    
    
    staticMetaObject = None


class QStateMachine(QState):
    def __init__(*args, **kwargs):
        """
        x.__init__(...) initializes x; see help(type(x)) for signature
        """
    
        pass
    
    
    def addDefaultAnimation(*args, **kwargs):
        pass
    
    
    def addState(*args, **kwargs):
        pass
    
    
    def beginMicrostep(*args, **kwargs):
        pass
    
    
    def beginSelectTransitions(*args, **kwargs):
        pass
    
    
    def cancelDelayedEvent(*args, **kwargs):
        pass
    
    
    def clearError(*args, **kwargs):
        pass
    
    
    def configuration(*args, **kwargs):
        pass
    
    
    def defaultAnimations(*args, **kwargs):
        pass
    
    
    def endMicrostep(*args, **kwargs):
        pass
    
    
    def endSelectTransitions(*args, **kwargs):
        pass
    
    
    def error(*args, **kwargs):
        pass
    
    
    def errorString(*args, **kwargs):
        pass
    
    
    def event(*args, **kwargs):
        pass
    
    
    def eventFilter(*args, **kwargs):
        pass
    
    
    def globalRestorePolicy(*args, **kwargs):
        pass
    
    
    def isAnimated(*args, **kwargs):
        pass
    
    
    def isRunning(*args, **kwargs):
        pass
    
    
    def onEntry(*args, **kwargs):
        pass
    
    
    def onExit(*args, **kwargs):
        pass
    
    
    def postDelayedEvent(*args, **kwargs):
        pass
    
    
    def postEvent(*args, **kwargs):
        pass
    
    
    def removeDefaultAnimation(*args, **kwargs):
        pass
    
    
    def removeState(*args, **kwargs):
        pass
    
    
    def setAnimated(*args, **kwargs):
        pass
    
    
    def setGlobalRestorePolicy(*args, **kwargs):
        pass
    
    
    def setRunning(*args, **kwargs):
        pass
    
    
    def start(*args, **kwargs):
        pass
    
    
    def stop(*args, **kwargs):
        pass
    
    
    Error = None
    
    
    EventPriority = None
    
    
    HighPriority = None
    
    
    NoCommonAncestorForTransitionError = None
    
    
    NoDefaultStateInHistoryStateError = None
    
    
    NoError = None
    
    
    NoInitialStateError = None
    
    
    NormalPriority = None
    
    
    SignalEvent = None
    
    
    WrappedEvent = None
    
    
    __new__ = None
    
    
    runningChanged = None
    
    
    started = None
    
    
    staticMetaObject = None
    
    
    stopped = None


class QSequentialAnimationGroup(QAnimationGroup):
    def __init__(*args, **kwargs):
        """
        x.__init__(...) initializes x; see help(type(x)) for signature
        """
    
        pass
    
    
    def addPause(*args, **kwargs):
        pass
    
    
    def currentAnimation(*args, **kwargs):
        pass
    
    
    def duration(*args, **kwargs):
        pass
    
    
    def event(*args, **kwargs):
        pass
    
    
    def insertPause(*args, **kwargs):
        pass
    
    
    def updateCurrentTime(*args, **kwargs):
        pass
    
    
    def updateDirection(*args, **kwargs):
        pass
    
    
    def updateState(*args, **kwargs):
        pass
    
    
    __new__ = None
    
    
    currentAnimationChanged = None
    
    
    staticMetaObject = None


class QPropertyAnimation(QVariantAnimation):
    def __init__(*args, **kwargs):
        """
        x.__init__(...) initializes x; see help(type(x)) for signature
        """
    
        pass
    
    
    def event(*args, **kwargs):
        pass
    
    
    def propertyName(*args, **kwargs):
        pass
    
    
    def setPropertyName(*args, **kwargs):
        pass
    
    
    def setTargetObject(*args, **kwargs):
        pass
    
    
    def targetObject(*args, **kwargs):
        pass
    
    
    def updateCurrentValue(*args, **kwargs):
        pass
    
    
    def updateState(*args, **kwargs):
        pass
    
    
    __new__ = None
    
    
    staticMetaObject = None


class QSortFilterProxyModel(QAbstractProxyModel):
    def __init__(*args, **kwargs):
        """
        x.__init__(...) initializes x; see help(type(x)) for signature
        """
    
        pass
    
    
    def buddy(*args, **kwargs):
        pass
    
    
    def canFetchMore(*args, **kwargs):
        pass
    
    
    def columnCount(*args, **kwargs):
        pass
    
    
    def data(*args, **kwargs):
        pass
    
    
    def dropMimeData(*args, **kwargs):
        pass
    
    
    def dynamicSortFilter(*args, **kwargs):
        pass
    
    
    def fetchMore(*args, **kwargs):
        pass
    
    
    def filterAcceptsColumn(*args, **kwargs):
        pass
    
    
    def filterAcceptsRow(*args, **kwargs):
        pass
    
    
    def filterCaseSensitivity(*args, **kwargs):
        pass
    
    
    def filterKeyColumn(*args, **kwargs):
        pass
    
    
    def filterRegExp(*args, **kwargs):
        pass
    
    
    def filterRole(*args, **kwargs):
        pass
    
    
    def flags(*args, **kwargs):
        pass
    
    
    def hasChildren(*args, **kwargs):
        pass
    
    
    def headerData(*args, **kwargs):
        pass
    
    
    def index(*args, **kwargs):
        pass
    
    
    def insertColumns(*args, **kwargs):
        pass
    
    
    def insertRows(*args, **kwargs):
        pass
    
    
    def invalidate(*args, **kwargs):
        pass
    
    
    def invalidateFilter(*args, **kwargs):
        pass
    
    
    def isSortLocaleAware(*args, **kwargs):
        pass
    
    
    def lessThan(*args, **kwargs):
        pass
    
    
    def mapFromSource(*args, **kwargs):
        pass
    
    
    def mapSelectionFromSource(*args, **kwargs):
        pass
    
    
    def mapSelectionToSource(*args, **kwargs):
        pass
    
    
    def mapToSource(*args, **kwargs):
        pass
    
    
    def match(*args, **kwargs):
        pass
    
    
    def mimeData(*args, **kwargs):
        pass
    
    
    def mimeTypes(*args, **kwargs):
        pass
    
    
    def parent(*args, **kwargs):
        pass
    
    
    def removeColumns(*args, **kwargs):
        pass
    
    
    def removeRows(*args, **kwargs):
        pass
    
    
    def rowCount(*args, **kwargs):
        pass
    
    
    def setData(*args, **kwargs):
        pass
    
    
    def setDynamicSortFilter(*args, **kwargs):
        pass
    
    
    def setFilterCaseSensitivity(*args, **kwargs):
        pass
    
    
    def setFilterFixedString(*args, **kwargs):
        pass
    
    
    def setFilterKeyColumn(*args, **kwargs):
        pass
    
    
    def setFilterRegExp(*args, **kwargs):
        pass
    
    
    def setFilterRole(*args, **kwargs):
        pass
    
    
    def setFilterWildcard(*args, **kwargs):
        pass
    
    
    def setHeaderData(*args, **kwargs):
        pass
    
    
    def setSortCaseSensitivity(*args, **kwargs):
        pass
    
    
    def setSortLocaleAware(*args, **kwargs):
        pass
    
    
    def setSortRole(*args, **kwargs):
        pass
    
    
    def setSourceModel(*args, **kwargs):
        pass
    
    
    def sibling(*args, **kwargs):
        pass
    
    
    def sort(*args, **kwargs):
        pass
    
    
    def sortCaseSensitivity(*args, **kwargs):
        pass
    
    
    def sortColumn(*args, **kwargs):
        pass
    
    
    def sortOrder(*args, **kwargs):
        pass
    
    
    def sortRole(*args, **kwargs):
        pass
    
    
    def span(*args, **kwargs):
        pass
    
    
    def supportedDropActions(*args, **kwargs):
        pass
    
    
    __new__ = None
    
    
    staticMetaObject = None


class QTemporaryFile(QFile):
    def __init__(*args, **kwargs):
        """
        x.__init__(...) initializes x; see help(type(x)) for signature
        """
    
        pass
    
    
    def autoRemove(*args, **kwargs):
        pass
    
    
    def fileName(*args, **kwargs):
        pass
    
    
    def fileTemplate(*args, **kwargs):
        pass
    
    
    def open(*args, **kwargs):
        pass
    
    
    def setAutoRemove(*args, **kwargs):
        pass
    
    
    def setFileTemplate(*args, **kwargs):
        pass
    
    
    def createLocalFile(*args, **kwargs):
        pass
    
    
    def createNativeFile(*args, **kwargs):
        pass
    
    
    __new__ = None
    
    
    staticMetaObject = None



def QT_TRANSLATE_NOOP3(*args, **kwargs):
    pass


def qVersion(*args, **kwargs):
    pass


def qAtan2(*args, **kwargs):
    pass


def qAtan(*args, **kwargs):
    pass


def qrand(*args, **kwargs):
    pass


def QT_TRANSLATE_NOOP_UTF8(*args, **kwargs):
    pass


def qIsNull(*args, **kwargs):
    pass


def qDebug(*args, **kwargs):
    pass


def qFastSin(*args, **kwargs):
    pass


def qAsin(*args, **kwargs):
    pass


def qIsFinite(*args, **kwargs):
    pass


def QT_TR_NOOP_UTF8(*args, **kwargs):
    pass


def qtTrId(*args, **kwargs):
    pass


def qsrand(*args, **kwargs):
    pass


def qFabs(*args, **kwargs):
    pass


def qAcos(*args, **kwargs):
    pass


def qUnregisterResourceData(*args, **kwargs):
    pass


def SIGNAL(*args, **kwargs):
    pass


def __moduleShutdown(*args, **kwargs):
    pass


def qAbs(*args, **kwargs):
    pass


def qFastCos(*args, **kwargs):
    pass


def qFuzzyCompare(*args, **kwargs):
    pass


def qIsNaN(*args, **kwargs):
    pass


def QT_TRANSLATE_NOOP(*args, **kwargs):
    pass


def qCritical(*args, **kwargs):
    pass


def SLOT(*args, **kwargs):
    pass


def qIsInf(*args, **kwargs):
    pass


def qExp(*args, **kwargs):
    pass


def qInstallMessageHandler(*args, **kwargs):
    pass


def qTan(*args, **kwargs):
    pass


def qFuzzyIsNull(*args, **kwargs):
    pass


def QT_TR_NOOP(*args, **kwargs):
    pass


def qChecksum(*args, **kwargs):
    pass


def qRegisterResourceData(*args, **kwargs):
    pass


def qWarning(*args, **kwargs):
    pass


def qFatal(*args, **kwargs):
    pass


def qAddPostRoutine(*args, **kwargs):
    pass



QtCriticalMsg = None

QtWarningMsg = None

__version__ = '5.6.0'

QtDebugMsg = None

QtFatalMsg = None

QtSystemMsg = None

QtInfoMsg = None


