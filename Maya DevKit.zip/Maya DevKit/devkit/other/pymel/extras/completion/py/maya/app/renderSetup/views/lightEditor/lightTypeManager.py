def findLightTransformObject(shapeObj):
    pass


def mayaLights():
    pass


def isValidLightTransformObject(mayaObj):
    pass


def _getAttributesFromViewTemplate(nodeType, viewName):
    pass


def isValidLightShapeObject(mayaObj):
    pass


def isGroup(mayaObj):
    pass


def lights():
    pass


def rebuild():
    pass


def pluginLights():
    pass


def _getDataTypeFromTemplateType(typeName):
    pass


def _isPluginLight(nodeType):
    pass


def excludeFromUI(nodeType):
    pass


def getAttributes():
    pass


def findLightShapeObject(transformObj):
    pass


def getIcon(lightType):
    pass


def getCreateCmd(lightType):
    pass


def isLight(mayaObj):
    pass


def findAllLightTransforms():
    pass



lightTypes = []

lightAttributeList = []

lightAttributeByLabel = {}

uiExcludedLightTypes = []

mayaLightTypes = []

lightConstructionData = {}

excludedLightTypes = []

pluginLightTypes = []

dataTypeConversionTable = {}


