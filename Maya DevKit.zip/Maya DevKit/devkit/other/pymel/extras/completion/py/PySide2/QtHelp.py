from PySide2.QtWidgets import QWidget as _QWidget
from PySide2.QtGui import QStringListModel as _QStringListModel
from PySide2.QtCore import QObject as _QObject

class _Object(object):
    __dict__ = None


from . import QtWidgets as _QtWidgets

class QHelpContentWidget(_QtWidgets.QTreeView):
    def indexOf(*args, **kwargs):
        pass
    
    
    linkActivated = None
    
    
    staticMetaObject = None


from . import QtCore as _QtCore

class QHelpContentModel(_QtCore.QAbstractItemModel):
    def columnCount(*args, **kwargs):
        pass
    
    
    def contentItemAt(*args, **kwargs):
        pass
    
    
    def createContents(*args, **kwargs):
        pass
    
    
    def data(*args, **kwargs):
        pass
    
    
    def index(*args, **kwargs):
        pass
    
    
    def isCreatingContents(*args, **kwargs):
        pass
    
    
    def parent(*args, **kwargs):
        pass
    
    
    def rowCount(*args, **kwargs):
        pass
    
    
    contentsCreated = None
    
    
    contentsCreationStarted = None
    
    
    staticMetaObject = None


class QHelpSearchQueryWidget(_QWidget):
    def __init__(*args, **kwargs):
        """
        x.__init__(...) initializes x; see help(type(x)) for signature
        """
    
        pass
    
    
    def changeEvent(*args, **kwargs):
        pass
    
    
    def collapseExtendedSearch(*args, **kwargs):
        pass
    
    
    def expandExtendedSearch(*args, **kwargs):
        pass
    
    
    def focusInEvent(*args, **kwargs):
        pass
    
    
    def isCompactMode(*args, **kwargs):
        pass
    
    
    def query(*args, **kwargs):
        pass
    
    
    def setCompactMode(*args, **kwargs):
        pass
    
    
    def setQuery(*args, **kwargs):
        pass
    
    
    __new__ = None
    
    
    search = None
    
    
    staticMetaObject = None


class QHelpSearchQuery(_Object):
    def __copy__(*args, **kwargs):
        pass
    
    
    def __init__(*args, **kwargs):
        """
        x.__init__(...) initializes x; see help(type(x)) for signature
        """
    
        pass
    
    
    fieldName = None
    
    wordList = None
    
    ALL = None
    
    
    ATLEAST = None
    
    
    DEFAULT = None
    
    
    FUZZY = None
    
    
    FieldName = None
    
    
    PHRASE = None
    
    
    WITHOUT = None
    
    
    __new__ = None


class QHelpSearchResultWidget(_QWidget):
    def changeEvent(*args, **kwargs):
        pass
    
    
    def linkAt(*args, **kwargs):
        pass
    
    
    requestShowLink = None
    
    
    staticMetaObject = None


class QHelpEngineCore(_QObject):
    def __init__(*args, **kwargs):
        """
        x.__init__(...) initializes x; see help(type(x)) for signature
        """
    
        pass
    
    
    def addCustomFilter(*args, **kwargs):
        pass
    
    
    def autoSaveFilter(*args, **kwargs):
        pass
    
    
    def collectionFile(*args, **kwargs):
        pass
    
    
    def copyCollectionFile(*args, **kwargs):
        pass
    
    
    def currentFilter(*args, **kwargs):
        pass
    
    
    def customFilters(*args, **kwargs):
        pass
    
    
    def customValue(*args, **kwargs):
        pass
    
    
    def documentationFileName(*args, **kwargs):
        pass
    
    
    def error(*args, **kwargs):
        pass
    
    
    def fileData(*args, **kwargs):
        pass
    
    
    def files(*args, **kwargs):
        pass
    
    
    def filterAttributeSets(*args, **kwargs):
        pass
    
    
    def filterAttributes(*args, **kwargs):
        pass
    
    
    def findFile(*args, **kwargs):
        pass
    
    
    def linksForIdentifier(*args, **kwargs):
        pass
    
    
    def registerDocumentation(*args, **kwargs):
        pass
    
    
    def registeredDocumentations(*args, **kwargs):
        pass
    
    
    def removeCustomFilter(*args, **kwargs):
        pass
    
    
    def removeCustomValue(*args, **kwargs):
        pass
    
    
    def setAutoSaveFilter(*args, **kwargs):
        pass
    
    
    def setCollectionFile(*args, **kwargs):
        pass
    
    
    def setCurrentFilter(*args, **kwargs):
        pass
    
    
    def setCustomValue(*args, **kwargs):
        pass
    
    
    def setupData(*args, **kwargs):
        pass
    
    
    def unregisterDocumentation(*args, **kwargs):
        pass
    
    
    def metaData(*args, **kwargs):
        pass
    
    
    def namespaceName(*args, **kwargs):
        pass
    
    
    __new__ = None
    
    
    currentFilterChanged = None
    
    
    readersAboutToBeInvalidated = None
    
    
    setupFinished = None
    
    
    setupStarted = None
    
    
    staticMetaObject = None
    
    
    warning = None


class QHelpIndexWidget(_QtWidgets.QListView):
    def activateCurrentItem(*args, **kwargs):
        pass
    
    
    def filterIndices(*args, **kwargs):
        pass
    
    
    linkActivated = None
    
    
    linksActivated = None
    
    
    staticMetaObject = None


class QHelpIndexModel(_QStringListModel):
    def createIndex(*args, **kwargs):
        pass
    
    
    def filter(*args, **kwargs):
        pass
    
    
    def isCreatingIndex(*args, **kwargs):
        pass
    
    
    def linksForKeyword(*args, **kwargs):
        pass
    
    
    indexCreated = None
    
    
    indexCreationStarted = None
    
    
    staticMetaObject = None


class QHelpContentItem(_Object):
    def __copy__(*args, **kwargs):
        pass
    
    
    def child(*args, **kwargs):
        pass
    
    
    def childCount(*args, **kwargs):
        pass
    
    
    def childPosition(*args, **kwargs):
        pass
    
    
    def parent(*args, **kwargs):
        pass
    
    
    def row(*args, **kwargs):
        pass
    
    
    def title(*args, **kwargs):
        pass
    
    
    def url(*args, **kwargs):
        pass


class QHelpSearchEngine(_QObject):
    def __init__(*args, **kwargs):
        """
        x.__init__(...) initializes x; see help(type(x)) for signature
        """
    
        pass
    
    
    def cancelIndexing(*args, **kwargs):
        pass
    
    
    def cancelSearching(*args, **kwargs):
        pass
    
    
    def hitCount(*args, **kwargs):
        pass
    
    
    def hits(*args, **kwargs):
        pass
    
    
    def hitsCount(*args, **kwargs):
        pass
    
    
    def query(*args, **kwargs):
        pass
    
    
    def queryWidget(*args, **kwargs):
        pass
    
    
    def reindexDocumentation(*args, **kwargs):
        pass
    
    
    def resultWidget(*args, **kwargs):
        pass
    
    
    def search(*args, **kwargs):
        pass
    
    
    __new__ = None
    
    
    indexingFinished = None
    
    
    indexingStarted = None
    
    
    searchingFinished = None
    
    
    searchingStarted = None
    
    
    staticMetaObject = None


class QHelpEngine(QHelpEngineCore):
    def __init__(*args, **kwargs):
        """
        x.__init__(...) initializes x; see help(type(x)) for signature
        """
    
        pass
    
    
    def contentModel(*args, **kwargs):
        pass
    
    
    def contentWidget(*args, **kwargs):
        pass
    
    
    def indexModel(*args, **kwargs):
        pass
    
    
    def indexWidget(*args, **kwargs):
        pass
    
    
    def searchEngine(*args, **kwargs):
        pass
    
    
    __new__ = None
    
    
    staticMetaObject = None



