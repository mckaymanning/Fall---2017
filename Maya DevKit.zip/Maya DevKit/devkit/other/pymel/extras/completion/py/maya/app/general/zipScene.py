def pyError(errorString):
    """
    print an error message
    """

    pass


def zipScene(archiveUnloadedReferences):
    pass


def pyResult(resultString):
    """
    print a result message
    """

    pass



