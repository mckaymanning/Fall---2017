from PySide2.QtWidgets import QFileDialog
from PySide2.QtCore import QTimer
from functools import partial
from PySide2.QtCore import QFileInfo

def _fileDialogTimerExpired(fileName):
    pass


def acceptFileDialog(fileName, interval=200):
    """
    Set up a timer-based event to accept a file dialog with the argument
    file name.
    
    The timer interval is optionally specified in milliseconds.
    """

    pass


def wrapInstance(*args, **kwargs):
    pass


def _findFileDialog():
    pass



