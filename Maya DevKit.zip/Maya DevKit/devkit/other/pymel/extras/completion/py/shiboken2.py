def isValid(*args, **kwargs):
    pass


def invalidate(*args, **kwargs):
    pass


def dump(*args, **kwargs):
    pass


def createdByPython(*args, **kwargs):
    pass


def delete(*args, **kwargs):
    pass


def wrapInstance(*args, **kwargs):
    pass


def getCppPointer(*args, **kwargs):
    pass


def ownedByPython(*args, **kwargs):
    pass



__version__ = '2.0.0'


