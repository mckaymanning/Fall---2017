kDragAttributeFromAE = []

kIncompatibleAttribute = []

kInvalidAttribute = []

kLayer = []


