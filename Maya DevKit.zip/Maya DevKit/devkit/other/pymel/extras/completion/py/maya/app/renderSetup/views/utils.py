from PySide2.QtGui import QPixmap

def dpiScale(value):
    pass


def createPixmap(imageName, width=0, height=0):
    pass


def wrapInstance(*args, **kwargs):
    pass



_DPI_SCALE = 1.0


