class _Object(object):
    __dict__ = None


class WebCore(_Object):
    pass



