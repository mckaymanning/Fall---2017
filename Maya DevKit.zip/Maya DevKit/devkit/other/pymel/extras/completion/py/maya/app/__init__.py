def finalize(*args, **kwargs):
    """
    Finalization function for Maya functionality when the interpreter shuts down
    """

    pass



