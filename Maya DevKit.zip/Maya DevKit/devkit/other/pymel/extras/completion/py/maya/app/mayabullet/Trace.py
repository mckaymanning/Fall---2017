def Trace(tag=''):
    pass


def TracePrint(strMsg):
    pass



_traceIndent = 0

_traceEnabled = False


