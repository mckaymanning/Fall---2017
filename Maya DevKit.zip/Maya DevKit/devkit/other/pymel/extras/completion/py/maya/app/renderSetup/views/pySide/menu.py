from PySide2.QtGui import QCursor
from PySide2.QtWidgets import QToolTip
from PySide2.QtWidgets import QMenu

class Menu(QMenu):
    def __init__(self, title, parent=None):
        pass
    
    
    def handleMenuHovered(self, action):
        pass
    
    
    staticMetaObject = None



