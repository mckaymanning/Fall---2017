import threading

class TimerObj(threading.Thread):
    def __init__(self, runTime, command):
        pass
    
    
    def run(self):
        pass



def prepMelCommand(commandString):
    """
    ######################
    #       functions
    ######################
    """

    pass


def startTimer(runTime, command):
    pass



