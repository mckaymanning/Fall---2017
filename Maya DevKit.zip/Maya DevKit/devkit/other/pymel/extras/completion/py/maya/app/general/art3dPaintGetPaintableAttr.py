def attributeToPaint_uiToMel(value):
    pass


def art3dPaintGetPaintableAttr(allowCustomAttrs=True):
    """
    Return list of all the names of 
    all color attrs common (to all selected shader) paintable attributes.
    This includes custom attributes.
    """

    pass


def attributeToPaint_melToUI(value):
    pass



k = 'transparency'

_dict_attributeToPaint_melToUI = {}

v = []

_dict_attributeToPaint_uiToMel = {}


