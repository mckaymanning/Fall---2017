def initialize(*args, **kwargs):
    pass



