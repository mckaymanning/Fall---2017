from maya.app.renderSetup.views.propertyEditor.expressionLabels import *

from maya.app.renderSetup.views.propertyEditor.layout import Layout
from PySide2.QtWidgets import QTextEdit
from maya.app.general.mayaMixin import MayaQWidgetBaseMixin
from PySide2.QtWidgets import QWidget
from PySide2.QtGui import QIcon
from PySide2.QtWidgets import QGroupBox
from PySide2.QtWidgets import QPushButton
from PySide2.QtWidgets import QListWidget
from PySide2.QtWidgets import QFormLayout
from PySide2.QtWidgets import QHBoxLayout
from PySide2.QtGui import QFont
from PySide2.QtWidgets import QVBoxLayout
from PySide2.QtWidgets import QLineEdit

class StaticCollection(MayaQWidgetBaseMixin, QGroupBox):
    """
    This class represents the property editor view of a static collection.
    A static selection is read-only and only contains a list of selected nodes.
    """
    
    
    
    def __init__(self, item, treeView, parent):
        pass
    
    
    def paintEvent(self, event):
        pass
    
    
    EXPRESSION_BUTTON_WIDTH = 50.0
    
    
    LIST_BOX_HEIGHT = 100.0
    
    
    staticMetaObject = None



