from PySide2.QtCore import QObject as _QObject

class QWebChannelAbstractTransport(_QObject):
    def __init__(*args, **kwargs):
        """
        x.__init__(...) initializes x; see help(type(x)) for signature
        """
    
        pass
    
    
    def sendMessage(*args, **kwargs):
        pass
    
    
    __new__ = None
    
    
    messageReceived = None
    
    
    staticMetaObject = None


class QWebChannel(_QObject):
    def __init__(*args, **kwargs):
        """
        x.__init__(...) initializes x; see help(type(x)) for signature
        """
    
        pass
    
    
    def blockUpdates(*args, **kwargs):
        pass
    
    
    def connectTo(*args, **kwargs):
        pass
    
    
    def deregisterObject(*args, **kwargs):
        pass
    
    
    def disconnectFrom(*args, **kwargs):
        pass
    
    
    def registerObject(*args, **kwargs):
        pass
    
    
    def registerObjects(*args, **kwargs):
        pass
    
    
    def registeredObjects(*args, **kwargs):
        pass
    
    
    def setBlockUpdates(*args, **kwargs):
        pass
    
    
    __new__ = None
    
    
    blockUpdatesChanged = None
    
    
    staticMetaObject = None



