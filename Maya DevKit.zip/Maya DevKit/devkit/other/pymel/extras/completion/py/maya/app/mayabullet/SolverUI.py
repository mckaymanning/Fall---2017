"""
SolverUI - Module containing functions for managing the solver node
        related UI elements.
"""

from maya.app.mayabullet.Trace import Trace

class AEOptionsChanged:
    def __call__(*args, **kw):
        pass
    
    
    def __init__(*args, **kw):
        pass


class AEDeleteControl:
    def __call__(*args, **kw):
        pass
    
    
    def __init__(*args, **kw):
        pass



def AEOptions(*args, **kw):
    pass


def attrName(attr):
    pass


def optionsFormCtrl(*args, **kw):
    pass


def optionsColumnCtrl(*args, **kw):
    pass


def optionsExist(*args, **kw):
    pass



solverDisplayOptionsMap = {}


