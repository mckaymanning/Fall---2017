def createDynamicAttribute(nodeName, attrName, attrType, value):
    pass


def findNodeFromMaya(nodeName):
    pass


def findSelectedNodeFromMaya():
    pass


def resolveIconFile(filename):
    """
    Resolve filenames using the XBMLANGPATH icon searchpath or look
    through the embedded Qt resources (if the path starts with a ':').
    
    :Parameters:
            filename (string)
                    filename path or resource path (uses embedded Qt resources if starts with a ':'
    
    :Return: (string)
            Fully resolved filename, or empty string if file is not resolved.
    """

    pass



