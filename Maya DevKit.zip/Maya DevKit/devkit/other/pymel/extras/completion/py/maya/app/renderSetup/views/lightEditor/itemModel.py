from maya.app.renderSetup.views.lightEditor.lightSource import *

from maya.app.renderSetup.views.lightEditor.group import GroupAttributes
from maya.app.renderSetup.views.lightEditor.group import Group

import PySide2.QtCore as _QtCore

class ItemModel(_QtCore.QAbstractItemModel):
    """
    This class defines the view's model which is represented by a tree of items.
    """
    
    
    
    def __del__(self):
        pass
    
    
    def __init__(self):
        pass
    
    
    def addGroup(self, mayaObj, parentIndex='<PySide2.QtCore.QModelIndex(-1,-1,0x0,QObject(0x0)) >'):
        pass
    
    
    def addLightSource(self, transformObj, shapeObj, parentIndex='<PySide2.QtCore.QModelIndex(-1,-1,0x0,QObject(0x0)) >'):
        pass
    
    
    def allowOverride(self):
        pass
    
    
    def columnCount(self, parent='<PySide2.QtCore.QModelIndex(-1,-1,0x0,QObject(0x0)) >'):
        pass
    
    
    def data(self, index, role):
        """
        Returns the data stored under the given role for the item referred to by the index.
        """
    
        pass
    
    
    def dispose(self):
        pass
    
    
    def dropMimeData(self, data, action, row, column, parentIndex):
        """
        Handles the data supplied by a drag and drop operation that ended with the given action.
        """
    
        pass
    
    
    def emitDataChanged(self, idx1, idx2):
        pass
    
    
    def findNode(self, mayaObj):
        pass
    
    
    def flags(self, index):
        """
        Returns the item flags for the given index.
        """
    
        pass
    
    
    def getRenderLayer(self):
        pass
    
    
    def headerData(self, section, orientation, role=PySide2.QtCore.Qt.ItemDataRole.DisplayRole):
        pass
    
    
    def index(self, row, column, parentIndex='<PySide2.QtCore.QModelIndex(-1,-1,0x0,QObject(0x0)) >'):
        """
        Returns the index of the item in the model specified by the given row, column and parent index.
        """
    
        pass
    
    
    def indexFromNode(self, node):
        pass
    
    
    def isResetting(self):
        pass
    
    
    def loadScene(self):
        pass
    
    
    def mimeData(self, indexes):
        """
        Returns an object that contains serialized items of data corresponding to the list of indexes specified.
        """
    
        pass
    
    
    def mimeTypes(self):
        """
        Returns the list of allowed MIME types.
        """
    
        pass
    
    
    def nodeFromIndex(self, index):
        """
        Returns the node specified by index, if the index is invalid, returns the root node.
        """
    
        pass
    
    
    def parent(self, index):
        """
        Returns the parent index of the model item with the given index. If the item has no parent, an invalid QModelIndex is returned.
        """
    
        pass
    
    
    def rowCount(self, parentIndex='<PySide2.QtCore.QModelIndex(-1,-1,0x0,QObject(0x0)) >'):
        """
        Returns the number of rows under the given parent
        """
    
        pass
    
    
    def setData(self, index, value, role=PySide2.QtCore.Qt.ItemDataRole.EditRole):
        """
        Sets a new value for this index.
        """
    
        pass
    
    
    def setModelContext(self, layer, canOverride):
        pass
    
    
    def startReset(self):
        pass
    
    
    def supportedDropActions(self):
        """
        Returns the drop actions supported by this model.
        """
    
        pass
    
    
    staticMetaObject = None
    
    
    valueEditedByUser = None



ENABLE_LIGHT_EDITOR_GROUP_CMD = []

MODEL_ROOT_NODE_NAME = 'lightEditorRoot'


