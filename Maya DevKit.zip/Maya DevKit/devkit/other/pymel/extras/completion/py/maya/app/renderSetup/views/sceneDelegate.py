from maya.app.renderSetup.views.baseDelegate import *

class SceneDelegate(BaseDelegate):
    """
    This class provides customization of the appearance of items in the Model.
    """
    
    
    
    def __init__(self, treeView):
        pass
    
    
    CURRENT_FRAME = []
    
    
    FRAME_INFO_OFFSET = 90.0
    
    
    FRAME_RANGE = []
    
    
    QUICK_SETTINGS_IMAGE = None
    
    
    kTooltips = {}
    
    
    staticMetaObject = None



