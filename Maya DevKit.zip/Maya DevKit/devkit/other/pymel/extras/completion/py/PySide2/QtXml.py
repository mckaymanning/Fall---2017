class _Object(object):
    __dict__ = None


class QXmlDeclHandler(_Object):
    def __init__(*args, **kwargs):
        """
        x.__init__(...) initializes x; see help(type(x)) for signature
        """
    
        pass
    
    
    def attributeDecl(*args, **kwargs):
        pass
    
    
    def errorString(*args, **kwargs):
        pass
    
    
    def externalEntityDecl(*args, **kwargs):
        pass
    
    
    def internalEntityDecl(*args, **kwargs):
        pass
    
    
    __new__ = None


class QXmlLocator(_Object):
    def __init__(*args, **kwargs):
        """
        x.__init__(...) initializes x; see help(type(x)) for signature
        """
    
        pass
    
    
    def columnNumber(*args, **kwargs):
        pass
    
    
    def lineNumber(*args, **kwargs):
        pass
    
    
    __new__ = None


class QDomImplementation(_Object):
    def __copy__(*args, **kwargs):
        pass
    
    
    def __eq__(*args, **kwargs):
        """
        x.__eq__(y) <==> x==y
        """
    
        pass
    
    
    def __ge__(*args, **kwargs):
        """
        x.__ge__(y) <==> x>=y
        """
    
        pass
    
    
    def __gt__(*args, **kwargs):
        """
        x.__gt__(y) <==> x>y
        """
    
        pass
    
    
    def __init__(*args, **kwargs):
        """
        x.__init__(...) initializes x; see help(type(x)) for signature
        """
    
        pass
    
    
    def __le__(*args, **kwargs):
        """
        x.__le__(y) <==> x<=y
        """
    
        pass
    
    
    def __lt__(*args, **kwargs):
        """
        x.__lt__(y) <==> x<y
        """
    
        pass
    
    
    def __ne__(*args, **kwargs):
        """
        x.__ne__(y) <==> x!=y
        """
    
        pass
    
    
    def createDocument(*args, **kwargs):
        pass
    
    
    def createDocumentType(*args, **kwargs):
        pass
    
    
    def hasFeature(*args, **kwargs):
        pass
    
    
    def isNull(*args, **kwargs):
        pass
    
    
    def invalidDataPolicy(*args, **kwargs):
        pass
    
    
    def setInvalidDataPolicy(*args, **kwargs):
        pass
    
    
    AcceptInvalidChars = None
    
    
    DropInvalidChars = None
    
    
    InvalidDataPolicy = None
    
    
    ReturnNullNode = None
    
    
    __new__ = None


class QXmlParseException(_Object):
    def __init__(*args, **kwargs):
        """
        x.__init__(...) initializes x; see help(type(x)) for signature
        """
    
        pass
    
    
    def columnNumber(*args, **kwargs):
        pass
    
    
    def lineNumber(*args, **kwargs):
        pass
    
    
    def message(*args, **kwargs):
        pass
    
    
    def publicId(*args, **kwargs):
        pass
    
    
    def systemId(*args, **kwargs):
        pass
    
    
    __new__ = None


class QDomNode(_Object):
    def __copy__(*args, **kwargs):
        pass
    
    
    def __eq__(*args, **kwargs):
        """
        x.__eq__(y) <==> x==y
        """
    
        pass
    
    
    def __ge__(*args, **kwargs):
        """
        x.__ge__(y) <==> x>=y
        """
    
        pass
    
    
    def __gt__(*args, **kwargs):
        """
        x.__gt__(y) <==> x>y
        """
    
        pass
    
    
    def __init__(*args, **kwargs):
        """
        x.__init__(...) initializes x; see help(type(x)) for signature
        """
    
        pass
    
    
    def __le__(*args, **kwargs):
        """
        x.__le__(y) <==> x<=y
        """
    
        pass
    
    
    def __lshift__(*args, **kwargs):
        """
        x.__lshift__(y) <==> x<<y
        """
    
        pass
    
    
    def __lt__(*args, **kwargs):
        """
        x.__lt__(y) <==> x<y
        """
    
        pass
    
    
    def __ne__(*args, **kwargs):
        """
        x.__ne__(y) <==> x!=y
        """
    
        pass
    
    
    def __nonzero__(*args, **kwargs):
        """
        x.__nonzero__() <==> x != 0
        """
    
        pass
    
    
    def __rlshift__(*args, **kwargs):
        """
        x.__rlshift__(y) <==> y<<x
        """
    
        pass
    
    
    def appendChild(*args, **kwargs):
        pass
    
    
    def attributes(*args, **kwargs):
        pass
    
    
    def childNodes(*args, **kwargs):
        pass
    
    
    def clear(*args, **kwargs):
        pass
    
    
    def cloneNode(*args, **kwargs):
        pass
    
    
    def columnNumber(*args, **kwargs):
        pass
    
    
    def firstChild(*args, **kwargs):
        pass
    
    
    def firstChildElement(*args, **kwargs):
        pass
    
    
    def hasAttributes(*args, **kwargs):
        pass
    
    
    def hasChildNodes(*args, **kwargs):
        pass
    
    
    def insertAfter(*args, **kwargs):
        pass
    
    
    def insertBefore(*args, **kwargs):
        pass
    
    
    def isAttr(*args, **kwargs):
        pass
    
    
    def isCDATASection(*args, **kwargs):
        pass
    
    
    def isCharacterData(*args, **kwargs):
        pass
    
    
    def isComment(*args, **kwargs):
        pass
    
    
    def isDocument(*args, **kwargs):
        pass
    
    
    def isDocumentFragment(*args, **kwargs):
        pass
    
    
    def isDocumentType(*args, **kwargs):
        pass
    
    
    def isElement(*args, **kwargs):
        pass
    
    
    def isEntity(*args, **kwargs):
        pass
    
    
    def isEntityReference(*args, **kwargs):
        pass
    
    
    def isNotation(*args, **kwargs):
        pass
    
    
    def isNull(*args, **kwargs):
        pass
    
    
    def isProcessingInstruction(*args, **kwargs):
        pass
    
    
    def isSupported(*args, **kwargs):
        pass
    
    
    def isText(*args, **kwargs):
        pass
    
    
    def lastChild(*args, **kwargs):
        pass
    
    
    def lastChildElement(*args, **kwargs):
        pass
    
    
    def lineNumber(*args, **kwargs):
        pass
    
    
    def localName(*args, **kwargs):
        pass
    
    
    def namedItem(*args, **kwargs):
        pass
    
    
    def namespaceURI(*args, **kwargs):
        pass
    
    
    def nextSibling(*args, **kwargs):
        pass
    
    
    def nextSiblingElement(*args, **kwargs):
        pass
    
    
    def nodeName(*args, **kwargs):
        pass
    
    
    def nodeType(*args, **kwargs):
        pass
    
    
    def nodeValue(*args, **kwargs):
        pass
    
    
    def normalize(*args, **kwargs):
        pass
    
    
    def ownerDocument(*args, **kwargs):
        pass
    
    
    def parentNode(*args, **kwargs):
        pass
    
    
    def prefix(*args, **kwargs):
        pass
    
    
    def previousSibling(*args, **kwargs):
        pass
    
    
    def previousSiblingElement(*args, **kwargs):
        pass
    
    
    def removeChild(*args, **kwargs):
        pass
    
    
    def replaceChild(*args, **kwargs):
        pass
    
    
    def save(*args, **kwargs):
        pass
    
    
    def setNodeValue(*args, **kwargs):
        pass
    
    
    def setPrefix(*args, **kwargs):
        pass
    
    
    def toAttr(*args, **kwargs):
        pass
    
    
    def toCDATASection(*args, **kwargs):
        pass
    
    
    def toCharacterData(*args, **kwargs):
        pass
    
    
    def toComment(*args, **kwargs):
        pass
    
    
    def toDocument(*args, **kwargs):
        pass
    
    
    def toDocumentFragment(*args, **kwargs):
        pass
    
    
    def toDocumentType(*args, **kwargs):
        pass
    
    
    def toElement(*args, **kwargs):
        pass
    
    
    def toEntity(*args, **kwargs):
        pass
    
    
    def toEntityReference(*args, **kwargs):
        pass
    
    
    def toNotation(*args, **kwargs):
        pass
    
    
    def toProcessingInstruction(*args, **kwargs):
        pass
    
    
    def toText(*args, **kwargs):
        pass
    
    
    AttributeNode = None
    
    
    BaseNode = None
    
    
    CDATASectionNode = None
    
    
    CharacterDataNode = None
    
    
    CommentNode = None
    
    
    DocumentFragmentNode = None
    
    
    DocumentNode = None
    
    
    DocumentTypeNode = None
    
    
    ElementNode = None
    
    
    EncodingFromDocument = None
    
    
    EncodingFromTextStream = None
    
    
    EncodingPolicy = None
    
    
    EntityNode = None
    
    
    EntityReferenceNode = None
    
    
    NodeType = None
    
    
    NotationNode = None
    
    
    ProcessingInstructionNode = None
    
    
    TextNode = None
    
    
    __new__ = None


class QXmlErrorHandler(_Object):
    def __init__(*args, **kwargs):
        """
        x.__init__(...) initializes x; see help(type(x)) for signature
        """
    
        pass
    
    
    def error(*args, **kwargs):
        pass
    
    
    def errorString(*args, **kwargs):
        pass
    
    
    def fatalError(*args, **kwargs):
        pass
    
    
    def warning(*args, **kwargs):
        pass
    
    
    __new__ = None


class QXmlDTDHandler(_Object):
    def __init__(*args, **kwargs):
        """
        x.__init__(...) initializes x; see help(type(x)) for signature
        """
    
        pass
    
    
    def errorString(*args, **kwargs):
        pass
    
    
    def notationDecl(*args, **kwargs):
        pass
    
    
    def unparsedEntityDecl(*args, **kwargs):
        pass
    
    
    __new__ = None


class QXmlContentHandler(_Object):
    def __init__(*args, **kwargs):
        """
        x.__init__(...) initializes x; see help(type(x)) for signature
        """
    
        pass
    
    
    def characters(*args, **kwargs):
        pass
    
    
    def endDocument(*args, **kwargs):
        pass
    
    
    def endElement(*args, **kwargs):
        pass
    
    
    def endPrefixMapping(*args, **kwargs):
        pass
    
    
    def errorString(*args, **kwargs):
        pass
    
    
    def ignorableWhitespace(*args, **kwargs):
        pass
    
    
    def processingInstruction(*args, **kwargs):
        pass
    
    
    def setDocumentLocator(*args, **kwargs):
        pass
    
    
    def skippedEntity(*args, **kwargs):
        pass
    
    
    def startDocument(*args, **kwargs):
        pass
    
    
    def startElement(*args, **kwargs):
        pass
    
    
    def startPrefixMapping(*args, **kwargs):
        pass
    
    
    __new__ = None


class QXmlEntityResolver(_Object):
    def __init__(*args, **kwargs):
        """
        x.__init__(...) initializes x; see help(type(x)) for signature
        """
    
        pass
    
    
    def errorString(*args, **kwargs):
        pass
    
    
    def resolveEntity(*args, **kwargs):
        pass
    
    
    __new__ = None


class QXmlLexicalHandler(_Object):
    def __init__(*args, **kwargs):
        """
        x.__init__(...) initializes x; see help(type(x)) for signature
        """
    
        pass
    
    
    def comment(*args, **kwargs):
        pass
    
    
    def endCDATA(*args, **kwargs):
        pass
    
    
    def endDTD(*args, **kwargs):
        pass
    
    
    def endEntity(*args, **kwargs):
        pass
    
    
    def errorString(*args, **kwargs):
        pass
    
    
    def startCDATA(*args, **kwargs):
        pass
    
    
    def startDTD(*args, **kwargs):
        pass
    
    
    def startEntity(*args, **kwargs):
        pass
    
    
    __new__ = None


class QXmlNamespaceSupport(_Object):
    def __init__(*args, **kwargs):
        """
        x.__init__(...) initializes x; see help(type(x)) for signature
        """
    
        pass
    
    
    def popContext(*args, **kwargs):
        pass
    
    
    def prefix(*args, **kwargs):
        pass
    
    
    def prefixes(*args, **kwargs):
        pass
    
    
    def processName(*args, **kwargs):
        pass
    
    
    def pushContext(*args, **kwargs):
        pass
    
    
    def reset(*args, **kwargs):
        pass
    
    
    def setPrefix(*args, **kwargs):
        pass
    
    
    def splitName(*args, **kwargs):
        pass
    
    
    def uri(*args, **kwargs):
        pass
    
    
    __new__ = None


class QDomNodeList(_Object):
    def __copy__(*args, **kwargs):
        pass
    
    
    def __eq__(*args, **kwargs):
        """
        x.__eq__(y) <==> x==y
        """
    
        pass
    
    
    def __ge__(*args, **kwargs):
        """
        x.__ge__(y) <==> x>=y
        """
    
        pass
    
    
    def __gt__(*args, **kwargs):
        """
        x.__gt__(y) <==> x>y
        """
    
        pass
    
    
    def __init__(*args, **kwargs):
        """
        x.__init__(...) initializes x; see help(type(x)) for signature
        """
    
        pass
    
    
    def __le__(*args, **kwargs):
        """
        x.__le__(y) <==> x<=y
        """
    
        pass
    
    
    def __lt__(*args, **kwargs):
        """
        x.__lt__(y) <==> x<y
        """
    
        pass
    
    
    def __ne__(*args, **kwargs):
        """
        x.__ne__(y) <==> x!=y
        """
    
        pass
    
    
    def at(*args, **kwargs):
        pass
    
    
    def count(*args, **kwargs):
        pass
    
    
    def isEmpty(*args, **kwargs):
        pass
    
    
    def item(*args, **kwargs):
        pass
    
    
    def length(*args, **kwargs):
        pass
    
    
    def size(*args, **kwargs):
        pass
    
    
    __new__ = None


class QDomNamedNodeMap(_Object):
    def __copy__(*args, **kwargs):
        pass
    
    
    def __eq__(*args, **kwargs):
        """
        x.__eq__(y) <==> x==y
        """
    
        pass
    
    
    def __ge__(*args, **kwargs):
        """
        x.__ge__(y) <==> x>=y
        """
    
        pass
    
    
    def __gt__(*args, **kwargs):
        """
        x.__gt__(y) <==> x>y
        """
    
        pass
    
    
    def __init__(*args, **kwargs):
        """
        x.__init__(...) initializes x; see help(type(x)) for signature
        """
    
        pass
    
    
    def __le__(*args, **kwargs):
        """
        x.__le__(y) <==> x<=y
        """
    
        pass
    
    
    def __lt__(*args, **kwargs):
        """
        x.__lt__(y) <==> x<y
        """
    
        pass
    
    
    def __ne__(*args, **kwargs):
        """
        x.__ne__(y) <==> x!=y
        """
    
        pass
    
    
    def contains(*args, **kwargs):
        pass
    
    
    def count(*args, **kwargs):
        pass
    
    
    def isEmpty(*args, **kwargs):
        pass
    
    
    def item(*args, **kwargs):
        pass
    
    
    def length(*args, **kwargs):
        pass
    
    
    def namedItem(*args, **kwargs):
        pass
    
    
    def namedItemNS(*args, **kwargs):
        pass
    
    
    def removeNamedItem(*args, **kwargs):
        pass
    
    
    def removeNamedItemNS(*args, **kwargs):
        pass
    
    
    def setNamedItem(*args, **kwargs):
        pass
    
    
    def setNamedItemNS(*args, **kwargs):
        pass
    
    
    def size(*args, **kwargs):
        pass
    
    
    __new__ = None


class QXmlAttributes(_Object):
    def __copy__(*args, **kwargs):
        pass
    
    
    def __init__(*args, **kwargs):
        """
        x.__init__(...) initializes x; see help(type(x)) for signature
        """
    
        pass
    
    
    def append(*args, **kwargs):
        pass
    
    
    def clear(*args, **kwargs):
        pass
    
    
    def count(*args, **kwargs):
        pass
    
    
    def index(*args, **kwargs):
        pass
    
    
    def length(*args, **kwargs):
        pass
    
    
    def localName(*args, **kwargs):
        pass
    
    
    def qName(*args, **kwargs):
        pass
    
    
    def type(*args, **kwargs):
        pass
    
    
    def uri(*args, **kwargs):
        pass
    
    
    def value(*args, **kwargs):
        pass
    
    
    __new__ = None


class QXmlReader(_Object):
    def DTDHandler(*args, **kwargs):
        pass
    
    
    def __init__(*args, **kwargs):
        """
        x.__init__(...) initializes x; see help(type(x)) for signature
        """
    
        pass
    
    
    def contentHandler(*args, **kwargs):
        pass
    
    
    def declHandler(*args, **kwargs):
        pass
    
    
    def entityResolver(*args, **kwargs):
        pass
    
    
    def errorHandler(*args, **kwargs):
        pass
    
    
    def feature(*args, **kwargs):
        pass
    
    
    def hasFeature(*args, **kwargs):
        pass
    
    
    def hasProperty(*args, **kwargs):
        pass
    
    
    def lexicalHandler(*args, **kwargs):
        pass
    
    
    def parse(*args, **kwargs):
        pass
    
    
    def property(*args, **kwargs):
        pass
    
    
    def setContentHandler(*args, **kwargs):
        pass
    
    
    def setDTDHandler(*args, **kwargs):
        pass
    
    
    def setDeclHandler(*args, **kwargs):
        pass
    
    
    def setEntityResolver(*args, **kwargs):
        pass
    
    
    def setErrorHandler(*args, **kwargs):
        pass
    
    
    def setFeature(*args, **kwargs):
        pass
    
    
    def setLexicalHandler(*args, **kwargs):
        pass
    
    
    def setProperty(*args, **kwargs):
        pass
    
    
    __new__ = None


class QXmlInputSource(_Object):
    def __init__(*args, **kwargs):
        """
        x.__init__(...) initializes x; see help(type(x)) for signature
        """
    
        pass
    
    
    def data(*args, **kwargs):
        pass
    
    
    def fetchData(*args, **kwargs):
        pass
    
    
    def fromRawData(*args, **kwargs):
        pass
    
    
    def next(*args, **kwargs):
        pass
    
    
    def reset(*args, **kwargs):
        pass
    
    
    def setData(*args, **kwargs):
        pass
    
    
    __new__ = None


class QDomEntity(QDomNode):
    def __copy__(*args, **kwargs):
        pass
    
    
    def __init__(*args, **kwargs):
        """
        x.__init__(...) initializes x; see help(type(x)) for signature
        """
    
        pass
    
    
    def __nonzero__(*args, **kwargs):
        """
        x.__nonzero__() <==> x != 0
        """
    
        pass
    
    
    def nodeType(*args, **kwargs):
        pass
    
    
    def notationName(*args, **kwargs):
        pass
    
    
    def publicId(*args, **kwargs):
        pass
    
    
    def systemId(*args, **kwargs):
        pass
    
    
    __new__ = None


class QDomElement(QDomNode):
    def __copy__(*args, **kwargs):
        pass
    
    
    def __init__(*args, **kwargs):
        """
        x.__init__(...) initializes x; see help(type(x)) for signature
        """
    
        pass
    
    
    def __nonzero__(*args, **kwargs):
        """
        x.__nonzero__() <==> x != 0
        """
    
        pass
    
    
    def attribute(*args, **kwargs):
        pass
    
    
    def attributeNS(*args, **kwargs):
        pass
    
    
    def attributeNode(*args, **kwargs):
        pass
    
    
    def attributeNodeNS(*args, **kwargs):
        pass
    
    
    def attributes(*args, **kwargs):
        pass
    
    
    def elementsByTagName(*args, **kwargs):
        pass
    
    
    def elementsByTagNameNS(*args, **kwargs):
        pass
    
    
    def hasAttribute(*args, **kwargs):
        pass
    
    
    def hasAttributeNS(*args, **kwargs):
        pass
    
    
    def nodeType(*args, **kwargs):
        pass
    
    
    def removeAttribute(*args, **kwargs):
        pass
    
    
    def removeAttributeNS(*args, **kwargs):
        pass
    
    
    def removeAttributeNode(*args, **kwargs):
        pass
    
    
    def setAttribute(*args, **kwargs):
        pass
    
    
    def setAttributeNS(*args, **kwargs):
        pass
    
    
    def setAttributeNode(*args, **kwargs):
        pass
    
    
    def setAttributeNodeNS(*args, **kwargs):
        pass
    
    
    def setTagName(*args, **kwargs):
        pass
    
    
    def tagName(*args, **kwargs):
        pass
    
    
    def text(*args, **kwargs):
        pass
    
    
    __new__ = None


class QDomDocumentFragment(QDomNode):
    def __copy__(*args, **kwargs):
        pass
    
    
    def __init__(*args, **kwargs):
        """
        x.__init__(...) initializes x; see help(type(x)) for signature
        """
    
        pass
    
    
    def __nonzero__(*args, **kwargs):
        """
        x.__nonzero__() <==> x != 0
        """
    
        pass
    
    
    def nodeType(*args, **kwargs):
        pass
    
    
    __new__ = None


class QDomNotation(QDomNode):
    def __copy__(*args, **kwargs):
        pass
    
    
    def __init__(*args, **kwargs):
        """
        x.__init__(...) initializes x; see help(type(x)) for signature
        """
    
        pass
    
    
    def __nonzero__(*args, **kwargs):
        """
        x.__nonzero__() <==> x != 0
        """
    
        pass
    
    
    def nodeType(*args, **kwargs):
        pass
    
    
    def publicId(*args, **kwargs):
        pass
    
    
    def systemId(*args, **kwargs):
        pass
    
    
    __new__ = None


class QDomAttr(QDomNode):
    def __copy__(*args, **kwargs):
        pass
    
    
    def __init__(*args, **kwargs):
        """
        x.__init__(...) initializes x; see help(type(x)) for signature
        """
    
        pass
    
    
    def __nonzero__(*args, **kwargs):
        """
        x.__nonzero__() <==> x != 0
        """
    
        pass
    
    
    def name(*args, **kwargs):
        pass
    
    
    def nodeType(*args, **kwargs):
        pass
    
    
    def ownerElement(*args, **kwargs):
        pass
    
    
    def setValue(*args, **kwargs):
        pass
    
    
    def specified(*args, **kwargs):
        pass
    
    
    def value(*args, **kwargs):
        pass
    
    
    __new__ = None


class QDomCharacterData(QDomNode):
    def __copy__(*args, **kwargs):
        pass
    
    
    def __init__(*args, **kwargs):
        """
        x.__init__(...) initializes x; see help(type(x)) for signature
        """
    
        pass
    
    
    def __nonzero__(*args, **kwargs):
        """
        x.__nonzero__() <==> x != 0
        """
    
        pass
    
    
    def appendData(*args, **kwargs):
        pass
    
    
    def data(*args, **kwargs):
        pass
    
    
    def deleteData(*args, **kwargs):
        pass
    
    
    def insertData(*args, **kwargs):
        pass
    
    
    def length(*args, **kwargs):
        pass
    
    
    def nodeType(*args, **kwargs):
        pass
    
    
    def replaceData(*args, **kwargs):
        pass
    
    
    def setData(*args, **kwargs):
        pass
    
    
    def substringData(*args, **kwargs):
        pass
    
    
    __new__ = None


class QDomEntityReference(QDomNode):
    def __copy__(*args, **kwargs):
        pass
    
    
    def __init__(*args, **kwargs):
        """
        x.__init__(...) initializes x; see help(type(x)) for signature
        """
    
        pass
    
    
    def __nonzero__(*args, **kwargs):
        """
        x.__nonzero__() <==> x != 0
        """
    
        pass
    
    
    def nodeType(*args, **kwargs):
        pass
    
    
    __new__ = None


class QXmlSimpleReader(QXmlReader):
    def DTDHandler(*args, **kwargs):
        pass
    
    
    def __init__(*args, **kwargs):
        """
        x.__init__(...) initializes x; see help(type(x)) for signature
        """
    
        pass
    
    
    def contentHandler(*args, **kwargs):
        pass
    
    
    def declHandler(*args, **kwargs):
        pass
    
    
    def entityResolver(*args, **kwargs):
        pass
    
    
    def errorHandler(*args, **kwargs):
        pass
    
    
    def feature(*args, **kwargs):
        pass
    
    
    def hasFeature(*args, **kwargs):
        pass
    
    
    def hasProperty(*args, **kwargs):
        pass
    
    
    def lexicalHandler(*args, **kwargs):
        pass
    
    
    def parse(*args, **kwargs):
        pass
    
    
    def parseContinue(*args, **kwargs):
        pass
    
    
    def property(*args, **kwargs):
        pass
    
    
    def setContentHandler(*args, **kwargs):
        pass
    
    
    def setDTDHandler(*args, **kwargs):
        pass
    
    
    def setDeclHandler(*args, **kwargs):
        pass
    
    
    def setEntityResolver(*args, **kwargs):
        pass
    
    
    def setErrorHandler(*args, **kwargs):
        pass
    
    
    def setFeature(*args, **kwargs):
        pass
    
    
    def setLexicalHandler(*args, **kwargs):
        pass
    
    
    def setProperty(*args, **kwargs):
        pass
    
    
    __new__ = None


class QDomDocument(QDomNode):
    def __copy__(*args, **kwargs):
        pass
    
    
    def __init__(*args, **kwargs):
        """
        x.__init__(...) initializes x; see help(type(x)) for signature
        """
    
        pass
    
    
    def __nonzero__(*args, **kwargs):
        """
        x.__nonzero__() <==> x != 0
        """
    
        pass
    
    
    def createAttribute(*args, **kwargs):
        pass
    
    
    def createAttributeNS(*args, **kwargs):
        pass
    
    
    def createCDATASection(*args, **kwargs):
        pass
    
    
    def createComment(*args, **kwargs):
        pass
    
    
    def createDocumentFragment(*args, **kwargs):
        pass
    
    
    def createElement(*args, **kwargs):
        pass
    
    
    def createElementNS(*args, **kwargs):
        pass
    
    
    def createEntityReference(*args, **kwargs):
        pass
    
    
    def createProcessingInstruction(*args, **kwargs):
        pass
    
    
    def createTextNode(*args, **kwargs):
        pass
    
    
    def doctype(*args, **kwargs):
        pass
    
    
    def documentElement(*args, **kwargs):
        pass
    
    
    def elementById(*args, **kwargs):
        pass
    
    
    def elementsByTagName(*args, **kwargs):
        pass
    
    
    def elementsByTagNameNS(*args, **kwargs):
        pass
    
    
    def implementation(*args, **kwargs):
        pass
    
    
    def importNode(*args, **kwargs):
        pass
    
    
    def nodeType(*args, **kwargs):
        pass
    
    
    def setContent(*args, **kwargs):
        pass
    
    
    def toByteArray(*args, **kwargs):
        pass
    
    
    def toString(*args, **kwargs):
        pass
    
    
    __new__ = None


class QDomProcessingInstruction(QDomNode):
    def __copy__(*args, **kwargs):
        pass
    
    
    def __init__(*args, **kwargs):
        """
        x.__init__(...) initializes x; see help(type(x)) for signature
        """
    
        pass
    
    
    def __nonzero__(*args, **kwargs):
        """
        x.__nonzero__() <==> x != 0
        """
    
        pass
    
    
    def data(*args, **kwargs):
        pass
    
    
    def nodeType(*args, **kwargs):
        pass
    
    
    def setData(*args, **kwargs):
        pass
    
    
    def target(*args, **kwargs):
        pass
    
    
    __new__ = None


class QDomDocumentType(QDomNode):
    def __copy__(*args, **kwargs):
        pass
    
    
    def __init__(*args, **kwargs):
        """
        x.__init__(...) initializes x; see help(type(x)) for signature
        """
    
        pass
    
    
    def __nonzero__(*args, **kwargs):
        """
        x.__nonzero__() <==> x != 0
        """
    
        pass
    
    
    def entities(*args, **kwargs):
        pass
    
    
    def internalSubset(*args, **kwargs):
        pass
    
    
    def name(*args, **kwargs):
        pass
    
    
    def nodeType(*args, **kwargs):
        pass
    
    
    def notations(*args, **kwargs):
        pass
    
    
    def publicId(*args, **kwargs):
        pass
    
    
    def systemId(*args, **kwargs):
        pass
    
    
    __new__ = None


class QXmlDefaultHandler(QXmlContentHandler, QXmlErrorHandler, QXmlDTDHandler, QXmlEntityResolver, QXmlLexicalHandler, QXmlDeclHandler):
    def __init__(*args, **kwargs):
        """
        x.__init__(...) initializes x; see help(type(x)) for signature
        """
    
        pass
    
    
    def attributeDecl(*args, **kwargs):
        pass
    
    
    def characters(*args, **kwargs):
        pass
    
    
    def comment(*args, **kwargs):
        pass
    
    
    def endCDATA(*args, **kwargs):
        pass
    
    
    def endDTD(*args, **kwargs):
        pass
    
    
    def endDocument(*args, **kwargs):
        pass
    
    
    def endElement(*args, **kwargs):
        pass
    
    
    def endEntity(*args, **kwargs):
        pass
    
    
    def endPrefixMapping(*args, **kwargs):
        pass
    
    
    def error(*args, **kwargs):
        pass
    
    
    def errorString(*args, **kwargs):
        pass
    
    
    def externalEntityDecl(*args, **kwargs):
        pass
    
    
    def fatalError(*args, **kwargs):
        pass
    
    
    def ignorableWhitespace(*args, **kwargs):
        pass
    
    
    def internalEntityDecl(*args, **kwargs):
        pass
    
    
    def notationDecl(*args, **kwargs):
        pass
    
    
    def processingInstruction(*args, **kwargs):
        pass
    
    
    def resolveEntity(*args, **kwargs):
        pass
    
    
    def setDocumentLocator(*args, **kwargs):
        pass
    
    
    def skippedEntity(*args, **kwargs):
        pass
    
    
    def startCDATA(*args, **kwargs):
        pass
    
    
    def startDTD(*args, **kwargs):
        pass
    
    
    def startDocument(*args, **kwargs):
        pass
    
    
    def startElement(*args, **kwargs):
        pass
    
    
    def startEntity(*args, **kwargs):
        pass
    
    
    def startPrefixMapping(*args, **kwargs):
        pass
    
    
    def unparsedEntityDecl(*args, **kwargs):
        pass
    
    
    def warning(*args, **kwargs):
        pass
    
    
    __new__ = None


class QDomComment(QDomCharacterData):
    def __copy__(*args, **kwargs):
        pass
    
    
    def __init__(*args, **kwargs):
        """
        x.__init__(...) initializes x; see help(type(x)) for signature
        """
    
        pass
    
    
    def __nonzero__(*args, **kwargs):
        """
        x.__nonzero__() <==> x != 0
        """
    
        pass
    
    
    def nodeType(*args, **kwargs):
        pass
    
    
    __new__ = None


class QDomText(QDomCharacterData):
    def __copy__(*args, **kwargs):
        pass
    
    
    def __init__(*args, **kwargs):
        """
        x.__init__(...) initializes x; see help(type(x)) for signature
        """
    
        pass
    
    
    def __nonzero__(*args, **kwargs):
        """
        x.__nonzero__() <==> x != 0
        """
    
        pass
    
    
    def nodeType(*args, **kwargs):
        pass
    
    
    def splitText(*args, **kwargs):
        pass
    
    
    __new__ = None


class QDomCDATASection(QDomText):
    def __copy__(*args, **kwargs):
        pass
    
    
    def __init__(*args, **kwargs):
        """
        x.__init__(...) initializes x; see help(type(x)) for signature
        """
    
        pass
    
    
    def __nonzero__(*args, **kwargs):
        """
        x.__nonzero__() <==> x != 0
        """
    
        pass
    
    
    def nodeType(*args, **kwargs):
        pass
    
    
    __new__ = None



