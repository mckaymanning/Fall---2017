from PySide2.QtCore import QObject as _QObject

class _Object(object):
    __dict__ = None


class QNetworkCacheMetaData(_Object):
    def __copy__(*args, **kwargs):
        pass
    
    
    def __eq__(*args, **kwargs):
        """
        x.__eq__(y) <==> x==y
        """
    
        pass
    
    
    def __ge__(*args, **kwargs):
        """
        x.__ge__(y) <==> x>=y
        """
    
        pass
    
    
    def __gt__(*args, **kwargs):
        """
        x.__gt__(y) <==> x>y
        """
    
        pass
    
    
    def __init__(*args, **kwargs):
        """
        x.__init__(...) initializes x; see help(type(x)) for signature
        """
    
        pass
    
    
    def __le__(*args, **kwargs):
        """
        x.__le__(y) <==> x<=y
        """
    
        pass
    
    
    def __lshift__(*args, **kwargs):
        """
        x.__lshift__(y) <==> x<<y
        """
    
        pass
    
    
    def __lt__(*args, **kwargs):
        """
        x.__lt__(y) <==> x<y
        """
    
        pass
    
    
    def __ne__(*args, **kwargs):
        """
        x.__ne__(y) <==> x!=y
        """
    
        pass
    
    
    def __rlshift__(*args, **kwargs):
        """
        x.__rlshift__(y) <==> y<<x
        """
    
        pass
    
    
    def __rrshift__(*args, **kwargs):
        """
        x.__rrshift__(y) <==> y>>x
        """
    
        pass
    
    
    def __rshift__(*args, **kwargs):
        """
        x.__rshift__(y) <==> x>>y
        """
    
        pass
    
    
    def attributes(*args, **kwargs):
        pass
    
    
    def expirationDate(*args, **kwargs):
        pass
    
    
    def isValid(*args, **kwargs):
        pass
    
    
    def lastModified(*args, **kwargs):
        pass
    
    
    def rawHeaders(*args, **kwargs):
        pass
    
    
    def saveToDisk(*args, **kwargs):
        pass
    
    
    def setAttributes(*args, **kwargs):
        pass
    
    
    def setExpirationDate(*args, **kwargs):
        pass
    
    
    def setLastModified(*args, **kwargs):
        pass
    
    
    def setRawHeaders(*args, **kwargs):
        pass
    
    
    def setSaveToDisk(*args, **kwargs):
        pass
    
    
    def setUrl(*args, **kwargs):
        pass
    
    
    def swap(*args, **kwargs):
        pass
    
    
    def url(*args, **kwargs):
        pass
    
    
    __new__ = None


class QLocalServer(_QObject):
    def __init__(*args, **kwargs):
        """
        x.__init__(...) initializes x; see help(type(x)) for signature
        """
    
        pass
    
    
    def close(*args, **kwargs):
        pass
    
    
    def errorString(*args, **kwargs):
        pass
    
    
    def fullServerName(*args, **kwargs):
        pass
    
    
    def hasPendingConnections(*args, **kwargs):
        pass
    
    
    def incomingConnection(*args, **kwargs):
        pass
    
    
    def isListening(*args, **kwargs):
        pass
    
    
    def listen(*args, **kwargs):
        pass
    
    
    def maxPendingConnections(*args, **kwargs):
        pass
    
    
    def nextPendingConnection(*args, **kwargs):
        pass
    
    
    def serverError(*args, **kwargs):
        pass
    
    
    def serverName(*args, **kwargs):
        pass
    
    
    def setMaxPendingConnections(*args, **kwargs):
        pass
    
    
    def setSocketOptions(*args, **kwargs):
        pass
    
    
    def socketOptions(*args, **kwargs):
        pass
    
    
    def waitForNewConnection(*args, **kwargs):
        pass
    
    
    def removeServer(*args, **kwargs):
        pass
    
    
    GroupAccessOption = None
    
    
    NoOptions = None
    
    
    OtherAccessOption = None
    
    
    SocketOption = None
    
    
    SocketOptions = None
    
    
    UserAccessOption = None
    
    
    WorldAccessOption = None
    
    
    __new__ = None
    
    
    newConnection = None
    
    
    staticMetaObject = None


class QHostAddress(_Object):
    def __copy__(*args, **kwargs):
        pass
    
    
    def __eq__(*args, **kwargs):
        """
        x.__eq__(y) <==> x==y
        """
    
        pass
    
    
    def __ge__(*args, **kwargs):
        """
        x.__ge__(y) <==> x>=y
        """
    
        pass
    
    
    def __gt__(*args, **kwargs):
        """
        x.__gt__(y) <==> x>y
        """
    
        pass
    
    
    def __hash__(*args, **kwargs):
        """
        x.__hash__() <==> hash(x)
        """
    
        pass
    
    
    def __init__(*args, **kwargs):
        """
        x.__init__(...) initializes x; see help(type(x)) for signature
        """
    
        pass
    
    
    def __le__(*args, **kwargs):
        """
        x.__le__(y) <==> x<=y
        """
    
        pass
    
    
    def __lshift__(*args, **kwargs):
        """
        x.__lshift__(y) <==> x<<y
        """
    
        pass
    
    
    def __lt__(*args, **kwargs):
        """
        x.__lt__(y) <==> x<y
        """
    
        pass
    
    
    def __ne__(*args, **kwargs):
        """
        x.__ne__(y) <==> x!=y
        """
    
        pass
    
    
    def __nonzero__(*args, **kwargs):
        """
        x.__nonzero__() <==> x != 0
        """
    
        pass
    
    
    def __repr__(*args, **kwargs):
        """
        x.__repr__() <==> repr(x)
        """
    
        pass
    
    
    def __rlshift__(*args, **kwargs):
        """
        x.__rlshift__(y) <==> y<<x
        """
    
        pass
    
    
    def __rrshift__(*args, **kwargs):
        """
        x.__rrshift__(y) <==> y>>x
        """
    
        pass
    
    
    def __rshift__(*args, **kwargs):
        """
        x.__rshift__(y) <==> x>>y
        """
    
        pass
    
    
    def clear(*args, **kwargs):
        pass
    
    
    def isInSubnet(*args, **kwargs):
        pass
    
    
    def isLoopback(*args, **kwargs):
        pass
    
    
    def isMulticast(*args, **kwargs):
        pass
    
    
    def isNull(*args, **kwargs):
        pass
    
    
    def protocol(*args, **kwargs):
        pass
    
    
    def scopeId(*args, **kwargs):
        pass
    
    
    def setAddress(*args, **kwargs):
        pass
    
    
    def setScopeId(*args, **kwargs):
        pass
    
    
    def swap(*args, **kwargs):
        pass
    
    
    def toIPv4Address(*args, **kwargs):
        pass
    
    
    def toIPv6Address(*args, **kwargs):
        pass
    
    
    def toString(*args, **kwargs):
        pass
    
    
    def parseSubnet(*args, **kwargs):
        pass
    
    
    Any = None
    
    
    AnyIPv4 = None
    
    
    AnyIPv6 = None
    
    
    Broadcast = None
    
    
    LocalHost = None
    
    
    LocalHostIPv6 = None
    
    
    Null = None
    
    
    SpecialAddress = None
    
    
    __new__ = None


class QTcpServer(_QObject):
    def __init__(*args, **kwargs):
        """
        x.__init__(...) initializes x; see help(type(x)) for signature
        """
    
        pass
    
    
    def addPendingConnection(*args, **kwargs):
        pass
    
    
    def close(*args, **kwargs):
        pass
    
    
    def errorString(*args, **kwargs):
        pass
    
    
    def hasPendingConnections(*args, **kwargs):
        pass
    
    
    def incomingConnection(*args, **kwargs):
        pass
    
    
    def isListening(*args, **kwargs):
        pass
    
    
    def listen(*args, **kwargs):
        pass
    
    
    def maxPendingConnections(*args, **kwargs):
        pass
    
    
    def nextPendingConnection(*args, **kwargs):
        pass
    
    
    def pauseAccepting(*args, **kwargs):
        pass
    
    
    def proxy(*args, **kwargs):
        pass
    
    
    def resumeAccepting(*args, **kwargs):
        pass
    
    
    def serverAddress(*args, **kwargs):
        pass
    
    
    def serverError(*args, **kwargs):
        pass
    
    
    def serverPort(*args, **kwargs):
        pass
    
    
    def setMaxPendingConnections(*args, **kwargs):
        pass
    
    
    def setProxy(*args, **kwargs):
        pass
    
    
    def setSocketDescriptor(*args, **kwargs):
        pass
    
    
    def socketDescriptor(*args, **kwargs):
        pass
    
    
    def waitForNewConnection(*args, **kwargs):
        pass
    
    
    __new__ = None
    
    
    acceptError = None
    
    
    newConnection = None
    
    
    staticMetaObject = None


class QAbstractNetworkCache(_QObject):
    def __init__(*args, **kwargs):
        """
        x.__init__(...) initializes x; see help(type(x)) for signature
        """
    
        pass
    
    
    def cacheSize(*args, **kwargs):
        pass
    
    
    def clear(*args, **kwargs):
        pass
    
    
    def data(*args, **kwargs):
        pass
    
    
    def insert(*args, **kwargs):
        pass
    
    
    def metaData(*args, **kwargs):
        pass
    
    
    def prepare(*args, **kwargs):
        pass
    
    
    def remove(*args, **kwargs):
        pass
    
    
    def updateMetaData(*args, **kwargs):
        pass
    
    
    __new__ = None
    
    
    staticMetaObject = None


class QNetworkSession(_QObject):
    def __init__(*args, **kwargs):
        """
        x.__init__(...) initializes x; see help(type(x)) for signature
        """
    
        pass
    
    
    def accept(*args, **kwargs):
        pass
    
    
    def activeTime(*args, **kwargs):
        pass
    
    
    def bytesReceived(*args, **kwargs):
        pass
    
    
    def bytesWritten(*args, **kwargs):
        pass
    
    
    def close(*args, **kwargs):
        pass
    
    
    def configuration(*args, **kwargs):
        pass
    
    
    def connectNotify(*args, **kwargs):
        pass
    
    
    def disconnectNotify(*args, **kwargs):
        pass
    
    
    def errorString(*args, **kwargs):
        pass
    
    
    def ignore(*args, **kwargs):
        pass
    
    
    def interface(*args, **kwargs):
        pass
    
    
    def isOpen(*args, **kwargs):
        pass
    
    
    def migrate(*args, **kwargs):
        pass
    
    
    def open(*args, **kwargs):
        pass
    
    
    def reject(*args, **kwargs):
        pass
    
    
    def sessionProperty(*args, **kwargs):
        pass
    
    
    def setSessionProperty(*args, **kwargs):
        pass
    
    
    def state(*args, **kwargs):
        pass
    
    
    def stop(*args, **kwargs):
        pass
    
    
    def usagePolicies(*args, **kwargs):
        pass
    
    
    def waitForOpened(*args, **kwargs):
        pass
    
    
    Closing = None
    
    
    Connected = None
    
    
    Connecting = None
    
    
    Disconnected = None
    
    
    Invalid = None
    
    
    InvalidConfigurationError = None
    
    
    NoBackgroundTrafficPolicy = None
    
    
    NoPolicy = None
    
    
    NotAvailable = None
    
    
    OperationNotSupportedError = None
    
    
    Roaming = None
    
    
    RoamingError = None
    
    
    SessionAbortedError = None
    
    
    SessionError = None
    
    
    State = None
    
    
    UnknownSessionError = None
    
    
    UsagePolicies = None
    
    
    UsagePolicy = None
    
    
    __new__ = None
    
    
    closed = None
    
    
    error = None
    
    
    newConfigurationActivated = None
    
    
    opened = None
    
    
    preferredConfigurationChanged = None
    
    
    stateChanged = None
    
    
    staticMetaObject = None
    
    
    usagePoliciesChanged = None


class QNetworkInterface(_Object):
    def __copy__(*args, **kwargs):
        pass
    
    
    def __init__(*args, **kwargs):
        """
        x.__init__(...) initializes x; see help(type(x)) for signature
        """
    
        pass
    
    
    def __repr__(*args, **kwargs):
        """
        x.__repr__() <==> repr(x)
        """
    
        pass
    
    
    def addressEntries(*args, **kwargs):
        pass
    
    
    def flags(*args, **kwargs):
        pass
    
    
    def hardwareAddress(*args, **kwargs):
        pass
    
    
    def humanReadableName(*args, **kwargs):
        pass
    
    
    def index(*args, **kwargs):
        pass
    
    
    def isValid(*args, **kwargs):
        pass
    
    
    def name(*args, **kwargs):
        pass
    
    
    def swap(*args, **kwargs):
        pass
    
    
    def allAddresses(*args, **kwargs):
        pass
    
    
    def allInterfaces(*args, **kwargs):
        pass
    
    
    def interfaceFromIndex(*args, **kwargs):
        pass
    
    
    def interfaceFromName(*args, **kwargs):
        pass
    
    
    CanBroadcast = None
    
    
    CanMulticast = None
    
    
    InterfaceFlag = None
    
    
    InterfaceFlags = None
    
    
    IsLoopBack = None
    
    
    IsPointToPoint = None
    
    
    IsRunning = None
    
    
    IsUp = None
    
    
    __new__ = None


class QNetworkRequest(_Object):
    def __copy__(*args, **kwargs):
        pass
    
    
    def __eq__(*args, **kwargs):
        """
        x.__eq__(y) <==> x==y
        """
    
        pass
    
    
    def __ge__(*args, **kwargs):
        """
        x.__ge__(y) <==> x>=y
        """
    
        pass
    
    
    def __gt__(*args, **kwargs):
        """
        x.__gt__(y) <==> x>y
        """
    
        pass
    
    
    def __init__(*args, **kwargs):
        """
        x.__init__(...) initializes x; see help(type(x)) for signature
        """
    
        pass
    
    
    def __le__(*args, **kwargs):
        """
        x.__le__(y) <==> x<=y
        """
    
        pass
    
    
    def __lt__(*args, **kwargs):
        """
        x.__lt__(y) <==> x<y
        """
    
        pass
    
    
    def __ne__(*args, **kwargs):
        """
        x.__ne__(y) <==> x!=y
        """
    
        pass
    
    
    def attribute(*args, **kwargs):
        pass
    
    
    def hasRawHeader(*args, **kwargs):
        pass
    
    
    def header(*args, **kwargs):
        pass
    
    
    def maximumRedirectsAllowed(*args, **kwargs):
        pass
    
    
    def originatingObject(*args, **kwargs):
        pass
    
    
    def priority(*args, **kwargs):
        pass
    
    
    def rawHeader(*args, **kwargs):
        pass
    
    
    def rawHeaderList(*args, **kwargs):
        pass
    
    
    def setAttribute(*args, **kwargs):
        pass
    
    
    def setHeader(*args, **kwargs):
        pass
    
    
    def setMaximumRedirectsAllowed(*args, **kwargs):
        pass
    
    
    def setOriginatingObject(*args, **kwargs):
        pass
    
    
    def setPriority(*args, **kwargs):
        pass
    
    
    def setRawHeader(*args, **kwargs):
        pass
    
    
    def setUrl(*args, **kwargs):
        pass
    
    
    def swap(*args, **kwargs):
        pass
    
    
    def url(*args, **kwargs):
        pass
    
    
    AlwaysCache = None
    
    
    AlwaysNetwork = None
    
    
    Attribute = None
    
    
    AuthenticationReuseAttribute = None
    
    
    Automatic = None
    
    
    BackgroundRequestAttribute = None
    
    
    CacheLoadControl = None
    
    
    CacheLoadControlAttribute = None
    
    
    CacheSaveControlAttribute = None
    
    
    ConnectionEncryptedAttribute = None
    
    
    ContentDispositionHeader = None
    
    
    ContentLengthHeader = None
    
    
    ContentTypeHeader = None
    
    
    CookieHeader = None
    
    
    CookieLoadControlAttribute = None
    
    
    CookieSaveControlAttribute = None
    
    
    CustomVerbAttribute = None
    
    
    DoNotBufferUploadDataAttribute = None
    
    
    DownloadBufferAttribute = None
    
    
    EmitAllUploadProgressSignalsAttribute = None
    
    
    FollowRedirectsAttribute = None
    
    
    HighPriority = None
    
    
    HttpPipeliningAllowedAttribute = None
    
    
    HttpPipeliningWasUsedAttribute = None
    
    
    HttpReasonPhraseAttribute = None
    
    
    HttpStatusCodeAttribute = None
    
    
    KnownHeaders = None
    
    
    LastModifiedHeader = None
    
    
    LoadControl = None
    
    
    LocationHeader = None
    
    
    LowPriority = None
    
    
    Manual = None
    
    
    MaximumDownloadBufferSizeAttribute = None
    
    
    NormalPriority = None
    
    
    PreferCache = None
    
    
    PreferNetwork = None
    
    
    Priority = None
    
    
    RedirectionTargetAttribute = None
    
    
    ServerHeader = None
    
    
    SetCookieHeader = None
    
    
    SourceIsFromCacheAttribute = None
    
    
    SpdyAllowedAttribute = None
    
    
    SpdyWasUsedAttribute = None
    
    
    SynchronousRequestAttribute = None
    
    
    User = None
    
    
    UserAgentHeader = None
    
    
    UserMax = None
    
    
    __new__ = None


class QIPv6Address(_Object):
    def __copy__(*args, **kwargs):
        pass
    
    
    def __delitem__(*args, **kwargs):
        """
        x.__delitem__(y) <==> del x[y]
        """
    
        pass
    
    
    def __getitem__(*args, **kwargs):
        """
        x.__getitem__(y) <==> x[y]
        """
    
        pass
    
    
    def __init__(*args, **kwargs):
        """
        x.__init__(...) initializes x; see help(type(x)) for signature
        """
    
        pass
    
    
    def __len__(*args, **kwargs):
        """
        x.__len__() <==> len(x)
        """
    
        pass
    
    
    def __setitem__(*args, **kwargs):
        """
        x.__setitem__(i, y) <==> x[i]=y
        """
    
        pass
    
    
    __new__ = None


class QNetworkCookie(_Object):
    def __copy__(*args, **kwargs):
        pass
    
    
    def __eq__(*args, **kwargs):
        """
        x.__eq__(y) <==> x==y
        """
    
        pass
    
    
    def __ge__(*args, **kwargs):
        """
        x.__ge__(y) <==> x>=y
        """
    
        pass
    
    
    def __gt__(*args, **kwargs):
        """
        x.__gt__(y) <==> x>y
        """
    
        pass
    
    
    def __init__(*args, **kwargs):
        """
        x.__init__(...) initializes x; see help(type(x)) for signature
        """
    
        pass
    
    
    def __le__(*args, **kwargs):
        """
        x.__le__(y) <==> x<=y
        """
    
        pass
    
    
    def __lt__(*args, **kwargs):
        """
        x.__lt__(y) <==> x<y
        """
    
        pass
    
    
    def __ne__(*args, **kwargs):
        """
        x.__ne__(y) <==> x!=y
        """
    
        pass
    
    
    def __repr__(*args, **kwargs):
        """
        x.__repr__() <==> repr(x)
        """
    
        pass
    
    
    def domain(*args, **kwargs):
        pass
    
    
    def expirationDate(*args, **kwargs):
        pass
    
    
    def hasSameIdentifier(*args, **kwargs):
        pass
    
    
    def isHttpOnly(*args, **kwargs):
        pass
    
    
    def isSecure(*args, **kwargs):
        pass
    
    
    def isSessionCookie(*args, **kwargs):
        pass
    
    
    def name(*args, **kwargs):
        pass
    
    
    def normalize(*args, **kwargs):
        pass
    
    
    def path(*args, **kwargs):
        pass
    
    
    def setDomain(*args, **kwargs):
        pass
    
    
    def setExpirationDate(*args, **kwargs):
        pass
    
    
    def setHttpOnly(*args, **kwargs):
        pass
    
    
    def setName(*args, **kwargs):
        pass
    
    
    def setPath(*args, **kwargs):
        pass
    
    
    def setSecure(*args, **kwargs):
        pass
    
    
    def setValue(*args, **kwargs):
        pass
    
    
    def swap(*args, **kwargs):
        pass
    
    
    def toRawForm(*args, **kwargs):
        pass
    
    
    def value(*args, **kwargs):
        pass
    
    
    def parseCookies(*args, **kwargs):
        pass
    
    
    Full = None
    
    
    NameAndValueOnly = None
    
    
    RawForm = None
    
    
    __new__ = None


class QNetworkAddressEntry(_Object):
    def __copy__(*args, **kwargs):
        pass
    
    
    def __eq__(*args, **kwargs):
        """
        x.__eq__(y) <==> x==y
        """
    
        pass
    
    
    def __ge__(*args, **kwargs):
        """
        x.__ge__(y) <==> x>=y
        """
    
        pass
    
    
    def __gt__(*args, **kwargs):
        """
        x.__gt__(y) <==> x>y
        """
    
        pass
    
    
    def __init__(*args, **kwargs):
        """
        x.__init__(...) initializes x; see help(type(x)) for signature
        """
    
        pass
    
    
    def __le__(*args, **kwargs):
        """
        x.__le__(y) <==> x<=y
        """
    
        pass
    
    
    def __lt__(*args, **kwargs):
        """
        x.__lt__(y) <==> x<y
        """
    
        pass
    
    
    def __ne__(*args, **kwargs):
        """
        x.__ne__(y) <==> x!=y
        """
    
        pass
    
    
    def broadcast(*args, **kwargs):
        pass
    
    
    def ip(*args, **kwargs):
        pass
    
    
    def netmask(*args, **kwargs):
        pass
    
    
    def prefixLength(*args, **kwargs):
        pass
    
    
    def setBroadcast(*args, **kwargs):
        pass
    
    
    def setIp(*args, **kwargs):
        pass
    
    
    def setNetmask(*args, **kwargs):
        pass
    
    
    def setPrefixLength(*args, **kwargs):
        pass
    
    
    def swap(*args, **kwargs):
        pass
    
    
    __new__ = None


class QAuthenticator(_Object):
    def __copy__(*args, **kwargs):
        pass
    
    
    def __eq__(*args, **kwargs):
        """
        x.__eq__(y) <==> x==y
        """
    
        pass
    
    
    def __ge__(*args, **kwargs):
        """
        x.__ge__(y) <==> x>=y
        """
    
        pass
    
    
    def __gt__(*args, **kwargs):
        """
        x.__gt__(y) <==> x>y
        """
    
        pass
    
    
    def __init__(*args, **kwargs):
        """
        x.__init__(...) initializes x; see help(type(x)) for signature
        """
    
        pass
    
    
    def __le__(*args, **kwargs):
        """
        x.__le__(y) <==> x<=y
        """
    
        pass
    
    
    def __lt__(*args, **kwargs):
        """
        x.__lt__(y) <==> x<y
        """
    
        pass
    
    
    def __ne__(*args, **kwargs):
        """
        x.__ne__(y) <==> x!=y
        """
    
        pass
    
    
    def __nonzero__(*args, **kwargs):
        """
        x.__nonzero__() <==> x != 0
        """
    
        pass
    
    
    def isNull(*args, **kwargs):
        pass
    
    
    def option(*args, **kwargs):
        pass
    
    
    def options(*args, **kwargs):
        pass
    
    
    def password(*args, **kwargs):
        pass
    
    
    def realm(*args, **kwargs):
        pass
    
    
    def setOption(*args, **kwargs):
        pass
    
    
    def setPassword(*args, **kwargs):
        pass
    
    
    def setRealm(*args, **kwargs):
        pass
    
    
    def setUser(*args, **kwargs):
        pass
    
    
    def user(*args, **kwargs):
        pass
    
    
    __new__ = None


from . import QtCore as _QtCore

class QNetworkReply(_QtCore.QIODevice):
    def __init__(*args, **kwargs):
        """
        x.__init__(...) initializes x; see help(type(x)) for signature
        """
    
        pass
    
    
    def abort(*args, **kwargs):
        pass
    
    
    def attribute(*args, **kwargs):
        pass
    
    
    def close(*args, **kwargs):
        pass
    
    
    def hasRawHeader(*args, **kwargs):
        pass
    
    
    def header(*args, **kwargs):
        pass
    
    
    def ignoreSslErrors(*args, **kwargs):
        pass
    
    
    def isFinished(*args, **kwargs):
        pass
    
    
    def isRunning(*args, **kwargs):
        pass
    
    
    def isSequential(*args, **kwargs):
        pass
    
    
    def manager(*args, **kwargs):
        pass
    
    
    def operation(*args, **kwargs):
        pass
    
    
    def rawHeader(*args, **kwargs):
        pass
    
    
    def rawHeaderList(*args, **kwargs):
        pass
    
    
    def rawHeaderPairs(*args, **kwargs):
        pass
    
    
    def readBufferSize(*args, **kwargs):
        pass
    
    
    def request(*args, **kwargs):
        pass
    
    
    def setAttribute(*args, **kwargs):
        pass
    
    
    def setError(*args, **kwargs):
        pass
    
    
    def setFinished(*args, **kwargs):
        pass
    
    
    def setHeader(*args, **kwargs):
        pass
    
    
    def setOperation(*args, **kwargs):
        pass
    
    
    def setRawHeader(*args, **kwargs):
        pass
    
    
    def setReadBufferSize(*args, **kwargs):
        pass
    
    
    def setRequest(*args, **kwargs):
        pass
    
    
    def setUrl(*args, **kwargs):
        pass
    
    
    def url(*args, **kwargs):
        pass
    
    
    def writeData(*args, **kwargs):
        pass
    
    
    AuthenticationRequiredError = None
    
    
    BackgroundRequestNotAllowedError = None
    
    
    ConnectionRefusedError = None
    
    
    ContentAccessDenied = None
    
    
    ContentConflictError = None
    
    
    ContentGoneError = None
    
    
    ContentNotFoundError = None
    
    
    ContentOperationNotPermittedError = None
    
    
    ContentReSendError = None
    
    
    HostNotFoundError = None
    
    
    InsecureRedirectError = None
    
    
    InternalServerError = None
    
    
    NetworkError = None
    
    
    NetworkSessionFailedError = None
    
    
    NoError = None
    
    
    OperationCanceledError = None
    
    
    OperationNotImplementedError = None
    
    
    ProtocolFailure = None
    
    
    ProtocolInvalidOperationError = None
    
    
    ProtocolUnknownError = None
    
    
    ProxyAuthenticationRequiredError = None
    
    
    ProxyConnectionClosedError = None
    
    
    ProxyConnectionRefusedError = None
    
    
    ProxyNotFoundError = None
    
    
    ProxyTimeoutError = None
    
    
    RemoteHostClosedError = None
    
    
    ServiceUnavailableError = None
    
    
    SslHandshakeFailedError = None
    
    
    TemporaryNetworkFailureError = None
    
    
    TimeoutError = None
    
    
    TooManyRedirectsError = None
    
    
    UnknownContentError = None
    
    
    UnknownNetworkError = None
    
    
    UnknownProxyError = None
    
    
    UnknownServerError = None
    
    
    __new__ = None
    
    
    downloadProgress = None
    
    
    encrypted = None
    
    
    error = None
    
    
    finished = None
    
    
    metaDataChanged = None
    
    
    preSharedKeyAuthenticationRequired = None
    
    
    redirected = None
    
    
    sslErrors = None
    
    
    staticMetaObject = None
    
    
    uploadProgress = None


class QNetworkConfigurationManager(_QObject):
    def __init__(*args, **kwargs):
        """
        x.__init__(...) initializes x; see help(type(x)) for signature
        """
    
        pass
    
    
    def allConfigurations(*args, **kwargs):
        pass
    
    
    def capabilities(*args, **kwargs):
        pass
    
    
    def configurationFromIdentifier(*args, **kwargs):
        pass
    
    
    def defaultConfiguration(*args, **kwargs):
        pass
    
    
    def isOnline(*args, **kwargs):
        pass
    
    
    def updateConfigurations(*args, **kwargs):
        pass
    
    
    ApplicationLevelRoaming = None
    
    
    CanStartAndStopInterfaces = None
    
    
    Capabilities = None
    
    
    Capability = None
    
    
    DataStatistics = None
    
    
    DirectConnectionRouting = None
    
    
    ForcedRoaming = None
    
    
    NetworkSessionRequired = None
    
    
    SystemSessionSupport = None
    
    
    __new__ = None
    
    
    configurationAdded = None
    
    
    configurationChanged = None
    
    
    configurationRemoved = None
    
    
    onlineStateChanged = None
    
    
    staticMetaObject = None
    
    
    updateCompleted = None


class QNetworkProxyQuery(_Object):
    def __copy__(*args, **kwargs):
        pass
    
    
    def __eq__(*args, **kwargs):
        """
        x.__eq__(y) <==> x==y
        """
    
        pass
    
    
    def __ge__(*args, **kwargs):
        """
        x.__ge__(y) <==> x>=y
        """
    
        pass
    
    
    def __gt__(*args, **kwargs):
        """
        x.__gt__(y) <==> x>y
        """
    
        pass
    
    
    def __init__(*args, **kwargs):
        """
        x.__init__(...) initializes x; see help(type(x)) for signature
        """
    
        pass
    
    
    def __le__(*args, **kwargs):
        """
        x.__le__(y) <==> x<=y
        """
    
        pass
    
    
    def __lt__(*args, **kwargs):
        """
        x.__lt__(y) <==> x<y
        """
    
        pass
    
    
    def __ne__(*args, **kwargs):
        """
        x.__ne__(y) <==> x!=y
        """
    
        pass
    
    
    def localPort(*args, **kwargs):
        pass
    
    
    def networkConfiguration(*args, **kwargs):
        pass
    
    
    def peerHostName(*args, **kwargs):
        pass
    
    
    def peerPort(*args, **kwargs):
        pass
    
    
    def protocolTag(*args, **kwargs):
        pass
    
    
    def queryType(*args, **kwargs):
        pass
    
    
    def setLocalPort(*args, **kwargs):
        pass
    
    
    def setNetworkConfiguration(*args, **kwargs):
        pass
    
    
    def setPeerHostName(*args, **kwargs):
        pass
    
    
    def setPeerPort(*args, **kwargs):
        pass
    
    
    def setProtocolTag(*args, **kwargs):
        pass
    
    
    def setQueryType(*args, **kwargs):
        pass
    
    
    def setUrl(*args, **kwargs):
        pass
    
    
    def swap(*args, **kwargs):
        pass
    
    
    def url(*args, **kwargs):
        pass
    
    
    QueryType = None
    
    
    TcpServer = None
    
    
    TcpSocket = None
    
    
    UdpSocket = None
    
    
    UrlRequest = None
    
    
    __new__ = None


class QNetworkConfiguration(_Object):
    def __copy__(*args, **kwargs):
        pass
    
    
    def __eq__(*args, **kwargs):
        """
        x.__eq__(y) <==> x==y
        """
    
        pass
    
    
    def __ge__(*args, **kwargs):
        """
        x.__ge__(y) <==> x>=y
        """
    
        pass
    
    
    def __gt__(*args, **kwargs):
        """
        x.__gt__(y) <==> x>y
        """
    
        pass
    
    
    def __init__(*args, **kwargs):
        """
        x.__init__(...) initializes x; see help(type(x)) for signature
        """
    
        pass
    
    
    def __le__(*args, **kwargs):
        """
        x.__le__(y) <==> x<=y
        """
    
        pass
    
    
    def __lt__(*args, **kwargs):
        """
        x.__lt__(y) <==> x<y
        """
    
        pass
    
    
    def __ne__(*args, **kwargs):
        """
        x.__ne__(y) <==> x!=y
        """
    
        pass
    
    
    def bearerType(*args, **kwargs):
        pass
    
    
    def bearerTypeFamily(*args, **kwargs):
        pass
    
    
    def bearerTypeName(*args, **kwargs):
        pass
    
    
    def children(*args, **kwargs):
        pass
    
    
    def identifier(*args, **kwargs):
        pass
    
    
    def isRoamingAvailable(*args, **kwargs):
        pass
    
    
    def isValid(*args, **kwargs):
        pass
    
    
    def name(*args, **kwargs):
        pass
    
    
    def purpose(*args, **kwargs):
        pass
    
    
    def state(*args, **kwargs):
        pass
    
    
    def swap(*args, **kwargs):
        pass
    
    
    def type(*args, **kwargs):
        pass
    
    
    Active = None
    
    
    Bearer2G = None
    
    
    Bearer3G = None
    
    
    Bearer4G = None
    
    
    BearerBluetooth = None
    
    
    BearerCDMA2000 = None
    
    
    BearerEVDO = None
    
    
    BearerEthernet = None
    
    
    BearerHSPA = None
    
    
    BearerLTE = None
    
    
    BearerType = None
    
    
    BearerUnknown = None
    
    
    BearerWCDMA = None
    
    
    BearerWLAN = None
    
    
    BearerWiMAX = None
    
    
    Defined = None
    
    
    Discovered = None
    
    
    InternetAccessPoint = None
    
    
    Invalid = None
    
    
    PrivatePurpose = None
    
    
    PublicPurpose = None
    
    
    Purpose = None
    
    
    ServiceNetwork = None
    
    
    ServiceSpecificPurpose = None
    
    
    StateFlag = None
    
    
    StateFlags = None
    
    
    Type = None
    
    
    Undefined = None
    
    
    UnknownPurpose = None
    
    
    UserChoice = None
    
    
    __new__ = None


class QSsl(_Object):
    AlternativeNameEntryType = None
    
    
    AnyProtocol = None
    
    
    Der = None
    
    
    DnsEntry = None
    
    
    Dsa = None
    
    
    Ec = None
    
    
    EmailEntry = None
    
    
    EncodingFormat = None
    
    
    KeyAlgorithm = None
    
    
    KeyType = None
    
    
    Opaque = None
    
    
    Pem = None
    
    
    PrivateKey = None
    
    
    PublicKey = None
    
    
    Rsa = None
    
    
    SecureProtocols = None
    
    
    SslOption = None
    
    
    SslOptionDisableCompression = None
    
    
    SslOptionDisableEmptyFragments = None
    
    
    SslOptionDisableLegacyRenegotiation = None
    
    
    SslOptionDisableServerCipherPreference = None
    
    
    SslOptionDisableServerNameIndication = None
    
    
    SslOptionDisableSessionPersistence = None
    
    
    SslOptionDisableSessionSharing = None
    
    
    SslOptionDisableSessionTickets = None
    
    
    SslOptions = None
    
    
    SslProtocol = None
    
    
    SslV2 = None
    
    
    SslV3 = None
    
    
    TlsV1SslV3 = None
    
    
    TlsV1_0 = None
    
    
    TlsV1_0OrLater = None
    
    
    TlsV1_1 = None
    
    
    TlsV1_1OrLater = None
    
    
    TlsV1_2 = None
    
    
    TlsV1_2OrLater = None
    
    
    UnknownProtocol = None


class QNetworkAccessManager(_QObject):
    def __init__(*args, **kwargs):
        """
        x.__init__(...) initializes x; see help(type(x)) for signature
        """
    
        pass
    
    
    def activeConfiguration(*args, **kwargs):
        pass
    
    
    def cache(*args, **kwargs):
        pass
    
    
    def clearAccessCache(*args, **kwargs):
        pass
    
    
    def configuration(*args, **kwargs):
        pass
    
    
    def connectToHost(*args, **kwargs):
        pass
    
    
    def cookieJar(*args, **kwargs):
        pass
    
    
    def createRequest(*args, **kwargs):
        pass
    
    
    def deleteResource(*args, **kwargs):
        pass
    
    
    def get(*args, **kwargs):
        pass
    
    
    def head(*args, **kwargs):
        pass
    
    
    def networkAccessible(*args, **kwargs):
        pass
    
    
    def post(*args, **kwargs):
        pass
    
    
    def proxy(*args, **kwargs):
        pass
    
    
    def proxyFactory(*args, **kwargs):
        pass
    
    
    def put(*args, **kwargs):
        pass
    
    
    def sendCustomRequest(*args, **kwargs):
        pass
    
    
    def setCache(*args, **kwargs):
        pass
    
    
    def setConfiguration(*args, **kwargs):
        pass
    
    
    def setCookieJar(*args, **kwargs):
        pass
    
    
    def setNetworkAccessible(*args, **kwargs):
        pass
    
    
    def setProxy(*args, **kwargs):
        pass
    
    
    def setProxyFactory(*args, **kwargs):
        pass
    
    
    def supportedSchemes(*args, **kwargs):
        pass
    
    
    def supportedSchemesImplementation(*args, **kwargs):
        pass
    
    
    Accessible = None
    
    
    CustomOperation = None
    
    
    DeleteOperation = None
    
    
    GetOperation = None
    
    
    HeadOperation = None
    
    
    NetworkAccessibility = None
    
    
    NotAccessible = None
    
    
    Operation = None
    
    
    PostOperation = None
    
    
    PutOperation = None
    
    
    UnknownAccessibility = None
    
    
    UnknownOperation = None
    
    
    __new__ = None
    
    
    authenticationRequired = None
    
    
    encrypted = None
    
    
    finished = None
    
    
    networkAccessibleChanged = None
    
    
    networkSessionConnected = None
    
    
    preSharedKeyAuthenticationRequired = None
    
    
    proxyAuthenticationRequired = None
    
    
    sslErrors = None
    
    
    staticMetaObject = None


class QHostInfo(_Object):
    def __copy__(*args, **kwargs):
        pass
    
    
    def __init__(*args, **kwargs):
        """
        x.__init__(...) initializes x; see help(type(x)) for signature
        """
    
        pass
    
    
    def addresses(*args, **kwargs):
        pass
    
    
    def error(*args, **kwargs):
        pass
    
    
    def errorString(*args, **kwargs):
        pass
    
    
    def hostName(*args, **kwargs):
        pass
    
    
    def lookupId(*args, **kwargs):
        pass
    
    
    def setAddresses(*args, **kwargs):
        pass
    
    
    def setError(*args, **kwargs):
        pass
    
    
    def setErrorString(*args, **kwargs):
        pass
    
    
    def setHostName(*args, **kwargs):
        pass
    
    
    def setLookupId(*args, **kwargs):
        pass
    
    
    def abortHostLookup(*args, **kwargs):
        pass
    
    
    def fromName(*args, **kwargs):
        pass
    
    
    def localDomainName(*args, **kwargs):
        pass
    
    
    def localHostName(*args, **kwargs):
        pass
    
    
    HostInfoError = None
    
    
    HostNotFound = None
    
    
    NoError = None
    
    
    UnknownError = None
    
    
    __new__ = None


class QAbstractSocket(_QtCore.QIODevice):
    def __init__(*args, **kwargs):
        """
        x.__init__(...) initializes x; see help(type(x)) for signature
        """
    
        pass
    
    
    def abort(*args, **kwargs):
        pass
    
    
    def atEnd(*args, **kwargs):
        pass
    
    
    def bind(*args, **kwargs):
        pass
    
    
    def bytesAvailable(*args, **kwargs):
        pass
    
    
    def bytesToWrite(*args, **kwargs):
        pass
    
    
    def canReadLine(*args, **kwargs):
        pass
    
    
    def close(*args, **kwargs):
        pass
    
    
    def connectToHost(*args, **kwargs):
        pass
    
    
    def disconnectFromHost(*args, **kwargs):
        pass
    
    
    def flush(*args, **kwargs):
        pass
    
    
    def isSequential(*args, **kwargs):
        pass
    
    
    def isValid(*args, **kwargs):
        pass
    
    
    def localAddress(*args, **kwargs):
        pass
    
    
    def localPort(*args, **kwargs):
        pass
    
    
    def pauseMode(*args, **kwargs):
        pass
    
    
    def peerAddress(*args, **kwargs):
        pass
    
    
    def peerName(*args, **kwargs):
        pass
    
    
    def peerPort(*args, **kwargs):
        pass
    
    
    def proxy(*args, **kwargs):
        pass
    
    
    def readBufferSize(*args, **kwargs):
        pass
    
    
    def readData(*args, **kwargs):
        pass
    
    
    def readLineData(*args, **kwargs):
        pass
    
    
    def resume(*args, **kwargs):
        pass
    
    
    def setLocalAddress(*args, **kwargs):
        pass
    
    
    def setLocalPort(*args, **kwargs):
        pass
    
    
    def setPauseMode(*args, **kwargs):
        pass
    
    
    def setPeerAddress(*args, **kwargs):
        pass
    
    
    def setPeerName(*args, **kwargs):
        pass
    
    
    def setPeerPort(*args, **kwargs):
        pass
    
    
    def setProxy(*args, **kwargs):
        pass
    
    
    def setReadBufferSize(*args, **kwargs):
        pass
    
    
    def setSocketDescriptor(*args, **kwargs):
        pass
    
    
    def setSocketError(*args, **kwargs):
        pass
    
    
    def setSocketOption(*args, **kwargs):
        pass
    
    
    def setSocketState(*args, **kwargs):
        pass
    
    
    def socketDescriptor(*args, **kwargs):
        pass
    
    
    def socketOption(*args, **kwargs):
        pass
    
    
    def socketType(*args, **kwargs):
        pass
    
    
    def state(*args, **kwargs):
        pass
    
    
    def waitForBytesWritten(*args, **kwargs):
        pass
    
    
    def waitForConnected(*args, **kwargs):
        pass
    
    
    def waitForDisconnected(*args, **kwargs):
        pass
    
    
    def waitForReadyRead(*args, **kwargs):
        pass
    
    
    def writeData(*args, **kwargs):
        pass
    
    
    AddressInUseError = None
    
    
    AnyIPProtocol = None
    
    
    BindFlag = None
    
    
    BindMode = None
    
    
    BoundState = None
    
    
    ClosingState = None
    
    
    ConnectedState = None
    
    
    ConnectingState = None
    
    
    ConnectionRefusedError = None
    
    
    DatagramTooLargeError = None
    
    
    DefaultForPlatform = None
    
    
    DontShareAddress = None
    
    
    HostLookupState = None
    
    
    HostNotFoundError = None
    
    
    IPv4Protocol = None
    
    
    IPv6Protocol = None
    
    
    KeepAliveOption = None
    
    
    ListeningState = None
    
    
    LowDelayOption = None
    
    
    MulticastLoopbackOption = None
    
    
    MulticastTtlOption = None
    
    
    NetworkError = None
    
    
    NetworkLayerProtocol = None
    
    
    OperationError = None
    
    
    PauseMode = None
    
    
    PauseModes = None
    
    
    PauseNever = None
    
    
    PauseOnSslErrors = None
    
    
    ProxyAuthenticationRequiredError = None
    
    
    ProxyConnectionClosedError = None
    
    
    ProxyConnectionRefusedError = None
    
    
    ProxyConnectionTimeoutError = None
    
    
    ProxyNotFoundError = None
    
    
    ProxyProtocolError = None
    
    
    ReceiveBufferSizeSocketOption = None
    
    
    RemoteHostClosedError = None
    
    
    ReuseAddressHint = None
    
    
    SendBufferSizeSocketOption = None
    
    
    ShareAddress = None
    
    
    SocketAccessError = None
    
    
    SocketAddressNotAvailableError = None
    
    
    SocketError = None
    
    
    SocketOption = None
    
    
    SocketResourceError = None
    
    
    SocketState = None
    
    
    SocketTimeoutError = None
    
    
    SocketType = None
    
    
    SslHandshakeFailedError = None
    
    
    SslInternalError = None
    
    
    SslInvalidUserDataError = None
    
    
    TcpSocket = None
    
    
    TemporaryError = None
    
    
    TypeOfServiceOption = None
    
    
    UdpSocket = None
    
    
    UnconnectedState = None
    
    
    UnfinishedSocketOperationError = None
    
    
    UnknownNetworkLayerProtocol = None
    
    
    UnknownSocketError = None
    
    
    UnknownSocketType = None
    
    
    UnsupportedSocketOperationError = None
    
    
    __new__ = None
    
    
    connected = None
    
    
    disconnected = None
    
    
    error = None
    
    
    hostFound = None
    
    
    proxyAuthenticationRequired = None
    
    
    stateChanged = None
    
    
    staticMetaObject = None


class QNetworkProxyFactory(_Object):
    def __init__(*args, **kwargs):
        """
        x.__init__(...) initializes x; see help(type(x)) for signature
        """
    
        pass
    
    
    def queryProxy(*args, **kwargs):
        pass
    
    
    def proxyForQuery(*args, **kwargs):
        pass
    
    
    def setApplicationProxyFactory(*args, **kwargs):
        pass
    
    
    def setUseSystemConfiguration(*args, **kwargs):
        pass
    
    
    def systemProxyForQuery(*args, **kwargs):
        pass
    
    
    __new__ = None


class QNetworkCookieJar(_QObject):
    def __init__(*args, **kwargs):
        """
        x.__init__(...) initializes x; see help(type(x)) for signature
        """
    
        pass
    
    
    def allCookies(*args, **kwargs):
        pass
    
    
    def cookiesForUrl(*args, **kwargs):
        pass
    
    
    def deleteCookie(*args, **kwargs):
        pass
    
    
    def insertCookie(*args, **kwargs):
        pass
    
    
    def setAllCookies(*args, **kwargs):
        pass
    
    
    def setCookiesFromUrl(*args, **kwargs):
        pass
    
    
    def updateCookie(*args, **kwargs):
        pass
    
    
    def validateCookie(*args, **kwargs):
        pass
    
    
    __new__ = None
    
    
    staticMetaObject = None


class QLocalSocket(_QtCore.QIODevice):
    def __init__(*args, **kwargs):
        """
        x.__init__(...) initializes x; see help(type(x)) for signature
        """
    
        pass
    
    
    def abort(*args, **kwargs):
        pass
    
    
    def bytesAvailable(*args, **kwargs):
        pass
    
    
    def bytesToWrite(*args, **kwargs):
        pass
    
    
    def canReadLine(*args, **kwargs):
        pass
    
    
    def close(*args, **kwargs):
        pass
    
    
    def connectToServer(*args, **kwargs):
        pass
    
    
    def disconnectFromServer(*args, **kwargs):
        pass
    
    
    def flush(*args, **kwargs):
        pass
    
    
    def fullServerName(*args, **kwargs):
        pass
    
    
    def isSequential(*args, **kwargs):
        pass
    
    
    def isValid(*args, **kwargs):
        pass
    
    
    def open(*args, **kwargs):
        pass
    
    
    def readBufferSize(*args, **kwargs):
        pass
    
    
    def readData(*args, **kwargs):
        pass
    
    
    def serverName(*args, **kwargs):
        pass
    
    
    def setReadBufferSize(*args, **kwargs):
        pass
    
    
    def setServerName(*args, **kwargs):
        pass
    
    
    def setSocketDescriptor(*args, **kwargs):
        pass
    
    
    def socketDescriptor(*args, **kwargs):
        pass
    
    
    def state(*args, **kwargs):
        pass
    
    
    def waitForBytesWritten(*args, **kwargs):
        pass
    
    
    def waitForConnected(*args, **kwargs):
        pass
    
    
    def waitForDisconnected(*args, **kwargs):
        pass
    
    
    def waitForReadyRead(*args, **kwargs):
        pass
    
    
    def writeData(*args, **kwargs):
        pass
    
    
    ClosingState = None
    
    
    ConnectedState = None
    
    
    ConnectingState = None
    
    
    ConnectionError = None
    
    
    ConnectionRefusedError = None
    
    
    DatagramTooLargeError = None
    
    
    LocalSocketError = None
    
    
    LocalSocketState = None
    
    
    OperationError = None
    
    
    PeerClosedError = None
    
    
    ServerNotFoundError = None
    
    
    SocketAccessError = None
    
    
    SocketResourceError = None
    
    
    SocketTimeoutError = None
    
    
    UnconnectedState = None
    
    
    UnknownSocketError = None
    
    
    UnsupportedSocketOperationError = None
    
    
    __new__ = None
    
    
    connected = None
    
    
    disconnected = None
    
    
    error = None
    
    
    stateChanged = None
    
    
    staticMetaObject = None


class QNetworkProxy(_Object):
    def __copy__(*args, **kwargs):
        pass
    
    
    def __eq__(*args, **kwargs):
        """
        x.__eq__(y) <==> x==y
        """
    
        pass
    
    
    def __ge__(*args, **kwargs):
        """
        x.__ge__(y) <==> x>=y
        """
    
        pass
    
    
    def __gt__(*args, **kwargs):
        """
        x.__gt__(y) <==> x>y
        """
    
        pass
    
    
    def __init__(*args, **kwargs):
        """
        x.__init__(...) initializes x; see help(type(x)) for signature
        """
    
        pass
    
    
    def __le__(*args, **kwargs):
        """
        x.__le__(y) <==> x<=y
        """
    
        pass
    
    
    def __lt__(*args, **kwargs):
        """
        x.__lt__(y) <==> x<y
        """
    
        pass
    
    
    def __ne__(*args, **kwargs):
        """
        x.__ne__(y) <==> x!=y
        """
    
        pass
    
    
    def __repr__(*args, **kwargs):
        """
        x.__repr__() <==> repr(x)
        """
    
        pass
    
    
    def capabilities(*args, **kwargs):
        pass
    
    
    def hasRawHeader(*args, **kwargs):
        pass
    
    
    def header(*args, **kwargs):
        pass
    
    
    def hostName(*args, **kwargs):
        pass
    
    
    def isCachingProxy(*args, **kwargs):
        pass
    
    
    def isTransparentProxy(*args, **kwargs):
        pass
    
    
    def password(*args, **kwargs):
        pass
    
    
    def port(*args, **kwargs):
        pass
    
    
    def rawHeader(*args, **kwargs):
        pass
    
    
    def rawHeaderList(*args, **kwargs):
        pass
    
    
    def setCapabilities(*args, **kwargs):
        pass
    
    
    def setHeader(*args, **kwargs):
        pass
    
    
    def setHostName(*args, **kwargs):
        pass
    
    
    def setPassword(*args, **kwargs):
        pass
    
    
    def setPort(*args, **kwargs):
        pass
    
    
    def setRawHeader(*args, **kwargs):
        pass
    
    
    def setType(*args, **kwargs):
        pass
    
    
    def setUser(*args, **kwargs):
        pass
    
    
    def swap(*args, **kwargs):
        pass
    
    
    def type(*args, **kwargs):
        pass
    
    
    def user(*args, **kwargs):
        pass
    
    
    def applicationProxy(*args, **kwargs):
        pass
    
    
    def setApplicationProxy(*args, **kwargs):
        pass
    
    
    CachingCapability = None
    
    
    Capabilities = None
    
    
    Capability = None
    
    
    DefaultProxy = None
    
    
    FtpCachingProxy = None
    
    
    HostNameLookupCapability = None
    
    
    HttpCachingProxy = None
    
    
    HttpProxy = None
    
    
    ListeningCapability = None
    
    
    NoProxy = None
    
    
    ProxyType = None
    
    
    Socks5Proxy = None
    
    
    TunnelingCapability = None
    
    
    UdpTunnelingCapability = None
    
    
    __new__ = None


class QUdpSocket(QAbstractSocket):
    def __init__(*args, **kwargs):
        """
        x.__init__(...) initializes x; see help(type(x)) for signature
        """
    
        pass
    
    
    def hasPendingDatagrams(*args, **kwargs):
        pass
    
    
    def joinMulticastGroup(*args, **kwargs):
        pass
    
    
    def leaveMulticastGroup(*args, **kwargs):
        pass
    
    
    def multicastInterface(*args, **kwargs):
        pass
    
    
    def pendingDatagramSize(*args, **kwargs):
        pass
    
    
    def readDatagram(*args, **kwargs):
        pass
    
    
    def setMulticastInterface(*args, **kwargs):
        pass
    
    
    def writeDatagram(*args, **kwargs):
        pass
    
    
    __new__ = None
    
    
    staticMetaObject = None


class QNetworkDiskCache(QAbstractNetworkCache):
    def __init__(*args, **kwargs):
        """
        x.__init__(...) initializes x; see help(type(x)) for signature
        """
    
        pass
    
    
    def cacheDirectory(*args, **kwargs):
        pass
    
    
    def cacheSize(*args, **kwargs):
        pass
    
    
    def clear(*args, **kwargs):
        pass
    
    
    def data(*args, **kwargs):
        pass
    
    
    def expire(*args, **kwargs):
        pass
    
    
    def fileMetaData(*args, **kwargs):
        pass
    
    
    def insert(*args, **kwargs):
        pass
    
    
    def maximumCacheSize(*args, **kwargs):
        pass
    
    
    def metaData(*args, **kwargs):
        pass
    
    
    def prepare(*args, **kwargs):
        pass
    
    
    def remove(*args, **kwargs):
        pass
    
    
    def setCacheDirectory(*args, **kwargs):
        pass
    
    
    def setMaximumCacheSize(*args, **kwargs):
        pass
    
    
    def updateMetaData(*args, **kwargs):
        pass
    
    
    __new__ = None
    
    
    staticMetaObject = None


class QTcpSocket(QAbstractSocket):
    def __init__(*args, **kwargs):
        """
        x.__init__(...) initializes x; see help(type(x)) for signature
        """
    
        pass
    
    
    __new__ = None
    
    
    staticMetaObject = None



