from PySide2.QtWidgets import QWidget as _QWidget

class QQuickWidget(_QWidget):
    def __init__(*args, **kwargs):
        """
        x.__init__(...) initializes x; see help(type(x)) for signature
        """
    
        pass
    
    
    def dragEnterEvent(*args, **kwargs):
        pass
    
    
    def dragLeaveEvent(*args, **kwargs):
        pass
    
    
    def dragMoveEvent(*args, **kwargs):
        pass
    
    
    def dropEvent(*args, **kwargs):
        pass
    
    
    def engine(*args, **kwargs):
        pass
    
    
    def errors(*args, **kwargs):
        pass
    
    
    def event(*args, **kwargs):
        pass
    
    
    def focusInEvent(*args, **kwargs):
        pass
    
    
    def focusOutEvent(*args, **kwargs):
        pass
    
    
    def format(*args, **kwargs):
        pass
    
    
    def grabFramebuffer(*args, **kwargs):
        pass
    
    
    def hideEvent(*args, **kwargs):
        pass
    
    
    def initialSize(*args, **kwargs):
        pass
    
    
    def keyPressEvent(*args, **kwargs):
        pass
    
    
    def keyReleaseEvent(*args, **kwargs):
        pass
    
    
    def mouseDoubleClickEvent(*args, **kwargs):
        pass
    
    
    def mouseMoveEvent(*args, **kwargs):
        pass
    
    
    def mousePressEvent(*args, **kwargs):
        pass
    
    
    def mouseReleaseEvent(*args, **kwargs):
        pass
    
    
    def quickWindow(*args, **kwargs):
        pass
    
    
    def resizeEvent(*args, **kwargs):
        pass
    
    
    def resizeMode(*args, **kwargs):
        pass
    
    
    def rootContext(*args, **kwargs):
        pass
    
    
    def rootObject(*args, **kwargs):
        pass
    
    
    def setClearColor(*args, **kwargs):
        pass
    
    
    def setFormat(*args, **kwargs):
        pass
    
    
    def setResizeMode(*args, **kwargs):
        pass
    
    
    def setSource(*args, **kwargs):
        pass
    
    
    def showEvent(*args, **kwargs):
        pass
    
    
    def sizeHint(*args, **kwargs):
        pass
    
    
    def source(*args, **kwargs):
        pass
    
    
    def status(*args, **kwargs):
        pass
    
    
    def timerEvent(*args, **kwargs):
        pass
    
    
    def wheelEvent(*args, **kwargs):
        pass
    
    
    Error = None
    
    
    Loading = None
    
    
    Null = None
    
    
    Ready = None
    
    
    ResizeMode = None
    
    
    SizeRootObjectToView = None
    
    
    SizeViewToRootObject = None
    
    
    Status = None
    
    
    __new__ = None
    
    
    sceneGraphError = None
    
    
    staticMetaObject = None
    
    
    statusChanged = None



