from PySide2.QtGui import QStandardItem

class StandardItem(QStandardItem):
    def __eq__(self, o):
        pass
    
    
    def __ne__(self, o):
        pass
    
    
    def depth(self):
        pass



