def new_MAnimUtil(*args, **kwargs):
    pass


def MAnimCurveClipboardItem_swigregister(*args, **kwargs):
    pass


def new_MFnKeyframeDeltaScale(*args, **kwargs):
    pass


def MFnHikEffector_setEffColor(*args, **kwargs):
    pass


def new_MFnLattice(*args, **kwargs):
    pass


def MFnKeyframeDeltaMove_previousValue(*args, **kwargs):
    pass


def MFnMotionPath_numPositionMarkers(*args, **kwargs):
    pass


def MAnimControl_weightedTangents(*args, **kwargs):
    pass


def MFnMotionPath_setUTimeStart(*args, **kwargs):
    pass


def MAnimControl_setAutoKeyMode(*args, **kwargs):
    pass


def MAnimControl_setCurrentTime(*args, **kwargs):
    pass


def MFnKeyframeDeltaBlockAddRemove_getValues(*args, **kwargs):
    pass


def MFnKeyframeDeltaBlockAddRemove_startTime(*args, **kwargs):
    pass


def MAnimControl_autoKeyMode(*args, **kwargs):
    pass


def delete_MFnClip(*args, **kwargs):
    pass


def MItKeyframe_setInTangentType(*args, **kwargs):
    pass


def MAnimCurveClipboard_endTime(*args, **kwargs):
    pass


def MFnCharacter_getSourceClipCount(*args, **kwargs):
    pass


def MFnSkinCluster_setWeights(*args, **kwargs):
    pass


def MItKeyframe_swigregister(*args, **kwargs):
    pass


def MFnWireDeformer_addGeometry(*args, **kwargs):
    pass


def MFnKeyframeDeltaScale_className(*args, **kwargs):
    pass


def MFnAnimCurve_inTangentType(*args, **kwargs):
    pass


def MAnimMessage_addAnimCurveEditedCallback(*args, **kwargs):
    pass


def MFnKeyframeDeltaMove_className(*args, **kwargs):
    pass


def MAnimCurveClipboard_swigregister(*args, **kwargs):
    pass


def MFnIkJoint_getStiffness(*args, **kwargs):
    pass


def MFnKeyframeDeltaScale_currentStartTime(*args, **kwargs):
    pass


def MAnimCurveClipboardItemArray_sizeIncrement(*args, **kwargs):
    pass


def MFnLatticeDeformer_getAffectedGeometry(*args, **kwargs):
    pass


def MAnimControl_playbackMode(*args, **kwargs):
    pass


def MFnHikEffector_className(*args, **kwargs):
    pass


def MFnLattice_swiginit(*args, **kwargs):
    pass


def MFnMotionPath_getOrientationMarker(*args, **kwargs):
    pass


def MFnAnimCurve_weightsLocked(*args, **kwargs):
    pass


def delete_MAnimCurveClipboard(*args, **kwargs):
    pass


def MFnKeyframeDeltaBreakdown_swigregister(*args, **kwargs):
    pass


def MFnMotionPath_setUpAxis(*args, **kwargs):
    pass


def MFnIkHandle_setWeight(*args, **kwargs):
    pass


def MFnIkSolver_swigregister(*args, **kwargs):
    pass


def MFnClip_sourceClip(*args, **kwargs):
    pass


def MFnClip_isInstancedClip(*args, **kwargs):
    pass


def MFnIkJoint_setMaxRotateDampXStrength(*args, **kwargs):
    pass


def MFnKeyframeDeltaAddRemove_deltaType(*args, **kwargs):
    pass


def MFnIkJoint_getDegreesOfFreedom(*args, **kwargs):
    pass


def MFnBlendShapeDeformer_setWeight(*args, **kwargs):
    pass


def MFnIkJoint_setScaleOrientation(*args, **kwargs):
    pass


def MIkHandleGroup_handle(*args, **kwargs):
    pass


def MFnClip_getMemberAnimCurves(*args, **kwargs):
    pass


def MAnimUtil_findConstraint(*args, **kwargs):
    pass


def new_MIkHandleGroup(*args, **kwargs):
    pass


def new_MFnIkJoint(*args, **kwargs):
    pass


def MIkSystem_isGlobalSolve(*args, **kwargs):
    pass


def MFnWeightGeometryFilter_weightPlugStrings(*args, **kwargs):
    pass


def MFnWireDeformer_addWire(*args, **kwargs):
    pass


def new_MFnAnimCurve(*args, **kwargs):
    pass


def MFnKeyframeDeltaMove_currentValue(*args, **kwargs):
    pass


def MAnimUtil_className(*args, **kwargs):
    pass


def MAnimUtil_findAnimatedPlugs(*args, **kwargs):
    pass


def MFnAnimCurve_find(*args, **kwargs):
    pass


def MFnLatticeDeformer_addGeometry(*args, **kwargs):
    pass


def MAnimCurveClipboardItemArray___getitem__(*args, **kwargs):
    pass


def MFnKeyframeDeltaScale_currentEndTime(*args, **kwargs):
    pass


def MAnimCurveClipboardItem_assign(*args, **kwargs):
    pass


def MFnKeyframeDeltaBreakdown_swiginit(*args, **kwargs):
    pass


def MFnLattice_point(*args, **kwargs):
    pass


def MFnClip_setWeight(*args, **kwargs):
    pass


def MFnMotionPath_create(*args, **kwargs):
    pass


def MFnLattice_swigregister(*args, **kwargs):
    pass


def MAnimCurveClipboardItem_nodeName(*args, **kwargs):
    pass


def MAnimControl_swigregister(*args, **kwargs):
    pass


def MFnMotionPath_setFollowAxis(*args, **kwargs):
    pass


def MFnClip_setEnabled(*args, **kwargs):
    pass


def MAnimMessage_addPreBakeResultsCallback(*args, **kwargs):
    pass


def MFnBlendShapeDeformer_setEnvelope(*args, **kwargs):
    pass


def MFnAnimCurve_setUnitlessInput(*args, **kwargs):
    pass


def MFnClip_getCycle(*args, **kwargs):
    pass


def MFnKeyframeDeltaBlockAddRemove_className(*args, **kwargs):
    pass


def MFnGeometryFilter_numOutputConnections(*args, **kwargs):
    pass


def MFnBlendShapeDeformer_getTargets(*args, **kwargs):
    pass


def MFnIkJoint_setMaxRotateDampXRange(*args, **kwargs):
    pass


def MFnCharacter_getSourceClip(*args, **kwargs):
    pass


def MIkHandleGroup_setSolverID(*args, **kwargs):
    pass


def delete_MFnIkJoint(*args, **kwargs):
    pass


def MFnWireDeformer_setRotation(*args, **kwargs):
    pass


def MFnAnimCurve_getTangent(*args, **kwargs):
    pass


def MFnWireDeformer_holdingShape(*args, **kwargs):
    pass


def MFnAnimCurve_isBreakdown(*args, **kwargs):
    pass


def MFnKeyframeDeltaMove_swiginit(*args, **kwargs):
    pass


def delete_MFnKeyframeDeltaInfType(*args, **kwargs):
    pass


def MFnAnimCurve_setAngle(*args, **kwargs):
    pass


def MAnimCurveClipboardItemArray_swiginit(*args, **kwargs):
    pass


def MFnKeyframeDeltaTangent_className(*args, **kwargs):
    pass


def MAnimCurveClipboardItemArray_swigregister(*args, **kwargs):
    pass


def MFnKeyframeDeltaMove_previousIndex(*args, **kwargs):
    pass


def MFnHikEffector_create(*args, **kwargs):
    pass


def MAnimMessage_flushAnimKeyframeEditedCallbacks(*args, **kwargs):
    pass


def MFnGeometryFilter_getOutputGeometry(*args, **kwargs):
    pass


def MAnimCurveClipboard_theAPIClipboard(*args, **kwargs):
    pass


def MFnClip_getEnabled(*args, **kwargs):
    pass


def delete_MFnLattice(*args, **kwargs):
    pass


def MAnimControl_setMaxTime(*args, **kwargs):
    pass


def MFnMotionPath_followAxis(*args, **kwargs):
    pass


def MAnimControl_setPlaybackBy(*args, **kwargs):
    pass


def MFnAnimCurve_numKeys(*args, **kwargs):
    pass


def MFnLattice_create(*args, **kwargs):
    pass


def MFnKeyframeDelta_className(*args, **kwargs):
    pass


def MFnBlendShapeDeformer_numWeights(*args, **kwargs):
    pass


def MFnKeyframeDelta_keyIndex(*args, **kwargs):
    pass


def MFnAnimCurve_unitlessInput(*args, **kwargs):
    pass


def MFnBlendShapeDeformer_origin(*args, **kwargs):
    pass


def new_MFnKeyframeDeltaBlockAddRemove(*args, **kwargs):
    pass


def MFnIkHandle_priority(*args, **kwargs):
    pass


def MFnIkJoint_minRotateDampYStrength(*args, **kwargs):
    pass


def MFnIkHandle_swiginit(*args, **kwargs):
    pass


def MIkSystem_setGlobalSolve(*args, **kwargs):
    pass


def MFnWeightGeometryFilter_swigregister(*args, **kwargs):
    pass


def MFnIkHandle_setStickiness(*args, **kwargs):
    pass


def MFnAnimCurve_postInfinityType(*args, **kwargs):
    pass


def MIkSystem_swiginit(*args, **kwargs):
    pass


def MFnAnimCurve_unitlessAnimCurveTypeForPlug(*args, **kwargs):
    pass


def new_MFnWireDeformer(*args, **kwargs):
    pass


def new_MFnKeyframeDeltaAddRemove(*args, **kwargs):
    pass


def MFnKeyframeDeltaMove_currentTime(*args, **kwargs):
    pass


def MFnAnimCurve_className(*args, **kwargs):
    pass


def MAnimUtil_findSetDrivenKeyAnimation(*args, **kwargs):
    pass


def MFnKeyframeDeltaScale_swigregister(*args, **kwargs):
    pass


def delete_MAnimMessage(*args, **kwargs):
    pass


def MFnKeyframeDeltaTangent_getPreviousPosition(*args, **kwargs):
    pass


def MFnGeometryFilter_outputShapeAtIndex(*args, **kwargs):
    pass


def MAnimCurveClipboardItem_setNameInfo(*args, **kwargs):
    pass


def MFnIkEffector_className(*args, **kwargs):
    pass


def MFnMotionPath_setBankScale(*args, **kwargs):
    pass


def MAnimControl_setMinMaxTime(*args, **kwargs):
    pass


def MFnGeometryFilter_inputShapeAtIndex(*args, **kwargs):
    pass


def MFnIkJoint_minRotateDampXRange(*args, **kwargs):
    pass


def delete_MFnIkEffector(*args, **kwargs):
    pass


def MFnLatticeDeformer_baseLattice(*args, **kwargs):
    pass


def MFnMotionPath_setUTimeEnd(*args, **kwargs):
    pass


def MAnimControl_animationStartTime(*args, **kwargs):
    pass


def MFnAnimCurve_addKeyframe(*args, **kwargs):
    pass


def MFnMotionPath_setInverseNormal(*args, **kwargs):
    pass


def MFnIkJoint_minRotateDampZStrength(*args, **kwargs):
    pass


def MFnCharacter_getScheduledClipCount(*args, **kwargs):
    pass


def MAnimControl_playbackBy(*args, **kwargs):
    pass


def delete_MFnKeyframeDeltaBlockAddRemove(*args, **kwargs):
    pass


def MFnKeyframeDeltaBlockAddRemove_numKeys(*args, **kwargs):
    pass


def MFnIkJoint_setSegmentScale(*args, **kwargs):
    pass


def MFnIkEffector_swiginit(*args, **kwargs):
    pass


def MItKeyframe_setTangentsLocked(*args, **kwargs):
    pass


def new_MFnWeightGeometryFilter(*args, **kwargs):
    pass


def MItKeyframe_time(*args, **kwargs):
    pass


def MFnSkinCluster_getBlendWeights(*args, **kwargs):
    pass


def MItKeyframe_isDone(*args, **kwargs):
    pass


def MFnCharacter_getMemberPlugs(*args, **kwargs):
    pass


def MFnKeyframeDeltaTangent_swigregister(*args, **kwargs):
    pass


def MAnimCurveClipboardItemArray_insert(*args, **kwargs):
    pass


def MFnKeyframeDeltaMove_previousTime(*args, **kwargs):
    pass


def MFnKeyframeDeltaMove_swigregister(*args, **kwargs):
    pass


def MAnimCurveClipboardItem___eq__(*args, **kwargs):
    pass


def MAnimUtil_isAnimated(*args, **kwargs):
    pass


def MFnLatticeDeformer_className(*args, **kwargs):
    pass


def MFnMotionPath_setBank(*args, **kwargs):
    pass


def MAnimCurveClipboardItem_setAddressingInfo(*args, **kwargs):
    pass


def MFnMotionPath_setBankThreshold(*args, **kwargs):
    pass


def MFnMotionPath_numOrientationMarkers(*args, **kwargs):
    pass


def MFnAnimCurve_addKeys(*args, **kwargs):
    pass


def MAnimControl_currentTime(*args, **kwargs):
    pass


def new_MFnBlendShapeDeformer(*args, **kwargs):
    pass


def MFnIkJoint_maxRotateDampXStrength(*args, **kwargs):
    pass


def MFnIkJoint_minRotateDampZRange(*args, **kwargs):
    pass


def MAnimMessage_addDisableImplicitControlCallback(*args, **kwargs):
    pass


def MFnKeyframeDelta_paramCurve(*args, **kwargs):
    pass


def MFnCharacter_blendExists(*args, **kwargs):
    pass


def delete_MFnKeyframeDeltaBreakdown(*args, **kwargs):
    pass


def new_MFnIkHandle(*args, **kwargs):
    pass


def new_MFnClip(*args, **kwargs):
    pass


def MFnIkJoint_create(*args, **kwargs):
    pass


def MFnWireDeformer_getDropoffLocator(*args, **kwargs):
    pass


def MFnIkHandle_solver(*args, **kwargs):
    pass


def MFnClip_getScale(*args, **kwargs):
    pass


def MFnWeightGeometryFilter_setWeight(*args, **kwargs):
    pass


def MFnSkinCluster_indexForInfluenceObject(*args, **kwargs):
    pass


def delete_MFnKeyframeDeltaTangent(*args, **kwargs):
    pass


def MAnimMessage_swiginit(*args, **kwargs):
    pass


def MFnLatticeDeformer_create(*args, **kwargs):
    pass


def MAnimCurveClipboardItemArray_copy(*args, **kwargs):
    pass


def MFnKeyframeDeltaInfType_isPreInfinity(*args, **kwargs):
    pass


def MAnimMessage_className(*args, **kwargs):
    pass


def delete_MFnGeometryFilter(*args, **kwargs):
    pass


def MFnSkinCluster_className(*args, **kwargs):
    pass


def MFnAnimCurve_tangentsLocked(*args, **kwargs):
    pass


def MAnimControl_setViewMode(*args, **kwargs):
    pass


def MFnHikEffector_swiginit(*args, **kwargs):
    pass


def new_MFnMotionPath(*args, **kwargs):
    pass


def MAnimControl_setGlobalOutTangentType(*args, **kwargs):
    pass


def MFnIkJoint_swigregister(*args, **kwargs):
    pass


def delete_MAnimControl(*args, **kwargs):
    pass


def MAnimControl_setPlaybackSpeed(*args, **kwargs):
    pass


def MFnCharacter_getBlendCount(*args, **kwargs):
    pass


def MFnClip_createSourceClip(*args, **kwargs):
    pass


def MFnKeyframeDeltaAddRemove_swigregister(*args, **kwargs):
    pass


def MFnClip_getAbsolute(*args, **kwargs):
    pass


def MFnBlendShapeDeformer_targetItemIndexList(*args, **kwargs):
    pass


def delete_MFnKeyframeDelta(*args, **kwargs):
    pass


def MFnIkHandle_className(*args, **kwargs):
    pass


def delete_MFnCharacter(*args, **kwargs):
    pass


def MIkSystem_isGlobalSnap(*args, **kwargs):
    pass


def MFnSkinCluster_swigregister(*args, **kwargs):
    pass


def MAnimCurveClipboardItemArray_setLength(*args, **kwargs):
    pass


def MIkSystem_swigregister(*args, **kwargs):
    pass


def MFnWireDeformer_getAffectedGeometry(*args, **kwargs):
    pass


def MAnimUtil_swiginit(*args, **kwargs):
    pass


def MFnKeyframeDeltaTangent_previousTangentType(*args, **kwargs):
    pass


def MIkHandleGroup_solverPriority(*args, **kwargs):
    pass


def MFnKeyframeDeltaInfType_currentInfinityType(*args, **kwargs):
    pass


def delete_MFnAnimCurve(*args, **kwargs):
    pass


def new_MFnKeyframeDeltaMove(*args, **kwargs):
    pass


def MFnClip_className(*args, **kwargs):
    pass


def MAnimCurveClipboardItemArray_append(*args, **kwargs):
    pass


def new_MFnKeyframeDeltaInfType(*args, **kwargs):
    pass


def delete_MFnHikEffector(*args, **kwargs):
    pass


def MFnAnimCurve_setWeightsLocked(*args, **kwargs):
    pass


def MAnimControl_maxTime(*args, **kwargs):
    pass


def MFnClip_getSourceDuration(*args, **kwargs):
    pass


def MFnMotionPath_follow(*args, **kwargs):
    pass


def MAnimCurveChange_undoIt(*args, **kwargs):
    pass


def MFnAnimCurve_setTime(*args, **kwargs):
    pass


def delete_MFnMotionPath(*args, **kwargs):
    pass


def MFnHikEffector_getEffColor(*args, **kwargs):
    pass


def delete_MFnBlendShapeDeformer(*args, **kwargs):
    pass


def MAnimCurveChange_redoIt(*args, **kwargs):
    pass


def MFnIkJoint_setStiffness(*args, **kwargs):
    pass


def MFnCharacter_getBlendClips(*args, **kwargs):
    pass


def MFnIkEffector_swigregister(*args, **kwargs):
    pass


def MFnIkJoint_getOrientation(*args, **kwargs):
    pass


def MIkSystem_getSolvers(*args, **kwargs):
    pass


def MFnWireDeformer_numDropoffLocators(*args, **kwargs):
    pass


def new_MItKeyframe(*args, **kwargs):
    pass


def MFnWireDeformer_setDropoffLocator(*args, **kwargs):
    pass


def MFnAnimCurve_create(*args, **kwargs):
    pass


def MFnAnimCurve_value(*args, **kwargs):
    pass


def MFnKeyframeDeltaWeighted_swiginit(*args, **kwargs):
    pass


def MFnAnimCurve_evaluate(*args, **kwargs):
    pass


def delete_MAnimCurveClipboardItemArray(*args, **kwargs):
    pass


def MFnIkJoint_maxRotateDampYStrength(*args, **kwargs):
    pass


def MAnimCurveClipboardItem_animCurveType(*args, **kwargs):
    pass


def MAnimMessage_addNodeAnimKeyframeEditedCallback(*args, **kwargs):
    pass


def delete_MFnKeyframeDeltaScale(*args, **kwargs):
    pass


def MFnGeometryFilter_groupIdAtIndex(*args, **kwargs):
    pass


def MAnimMessage_addPostBakeResultsCallback(*args, **kwargs):
    pass


def MFnCharacter_getClipScheduler(*args, **kwargs):
    pass


def MFnGeometryFilter_getPathAtIndex(*args, **kwargs):
    pass


def delete_MFnSkinCluster(*args, **kwargs):
    pass


def MFnClip_setStartFrame(*args, **kwargs):
    pass


def MFnMotionPath_setUEnd(*args, **kwargs):
    pass


def MFnHikEffector_setPivotOffset(*args, **kwargs):
    pass


def MFnIkSolver_maxIterations(*args, **kwargs):
    pass


def MFnMotionPath_useNormal(*args, **kwargs):
    pass


def MFnCharacter_addCurveToClip(*args, **kwargs):
    pass


def MFnIkJoint_maxRotateDampZStrength(*args, **kwargs):
    pass


def MFnWireDeformer_rotation(*args, **kwargs):
    pass


def MFnBlendShapeDeformer_removeTarget(*args, **kwargs):
    pass


def MFnKeyframeDelta_swigregister(*args, **kwargs):
    pass


def MFnIkHandle_weight(*args, **kwargs):
    pass


def MFnClip_getPostCycle(*args, **kwargs):
    pass


def MFnKeyframeDeltaAddRemove_value(*args, **kwargs):
    pass


def MFnAnimCurve_setValue(*args, **kwargs):
    pass


def MFnWeightGeometryFilter_getWeightPlugStrings(*args, **kwargs):
    pass


def MFnIkJoint_maxRotateDampYRange(*args, **kwargs):
    pass


def MIkHandleGroup_solve(*args, **kwargs):
    pass


def MFnWeightGeometryFilter_getWeights(*args, **kwargs):
    pass


def MIkHandleGroup_className(*args, **kwargs):
    pass


def delete_MIkHandleGroup(*args, **kwargs):
    pass


def MAnimUtil_findAnimationLayers(*args, **kwargs):
    pass


def MFnSkinCluster_getPointsAffectedByInfluence(*args, **kwargs):
    pass


def MFnAnimCurve_setTangent(*args, **kwargs):
    pass


def MFnBlendShapeDeformer_create(*args, **kwargs):
    pass


def MFnKeyframeDeltaWeighted_swigregister(*args, **kwargs):
    pass


def MFnAnimCurve_animCurveType(*args, **kwargs):
    pass


def MAnimCurveClipboard_startUnitlessInput(*args, **kwargs):
    pass


def MFnCharacter_createBlend(*args, **kwargs):
    pass


def MAnimUtil_swigregister(*args, **kwargs):
    pass


def MFnKeyframeDeltaTangent_isInTangent(*args, **kwargs):
    pass


def MFnKeyframeDeltaScale_startTime(*args, **kwargs):
    pass


def MAnimCurveClipboardItemArray_length(*args, **kwargs):
    pass


def MAnimControl_setWeightedTangents(*args, **kwargs):
    pass


def MFnMotionPath_bank(*args, **kwargs):
    pass


def MAnimCurveClipboard_set(*args, **kwargs):
    pass


def MFnGeometryFilter_indexForGroupId(*args, **kwargs):
    pass


def MFnMotionPath_swigregister(*args, **kwargs):
    pass


def MAnimCurveClipboard_endUnitlessInput(*args, **kwargs):
    pass


def MAnimCurveClipboardItemArray_assign(*args, **kwargs):
    pass


def MAnimControl_globalInTangentType(*args, **kwargs):
    pass


def MFnWireDeformer_localIntensity(*args, **kwargs):
    pass


def MFnMotionPath_uEnd(*args, **kwargs):
    pass


def MAnimControl_isScrubbing(*args, **kwargs):
    pass


def MFnBlendShapeDeformer_swigregister(*args, **kwargs):
    pass


def MFnKeyframeDeltaBlockAddRemove_swigregister(*args, **kwargs):
    pass


def MFnCharacter_getCharacterThatOwnsPlug(*args, **kwargs):
    pass


def MFnKeyframeDeltaBlockAddRemove_swiginit(*args, **kwargs):
    pass


def MFnIkJoint_setOrientation(*args, **kwargs):
    pass


def MAnimControl_globalOutTangentType(*args, **kwargs):
    pass


def new_MFnCharacter(*args, **kwargs):
    pass


def MFnIkJoint_getScaleOrientation(*args, **kwargs):
    pass


def MFnWireDeformer_numWires(*args, **kwargs):
    pass


def MFnIkJoint_getSegmentScale(*args, **kwargs):
    pass


def delete_MIkSystem(*args, **kwargs):
    pass


def MFnWireDeformer_setEnvelope(*args, **kwargs):
    pass


def MIkHandleGroup_handleCount(*args, **kwargs):
    pass


def MFnWireDeformer_create(*args, **kwargs):
    pass


def MItKeyframe_inTangentType(*args, **kwargs):
    pass


def MFnHikEffector_getPivotOffset(*args, **kwargs):
    pass


def MFnLatticeDeformer_removeGeometry(*args, **kwargs):
    pass


def MFnCharacter_getBlend(*args, **kwargs):
    pass


def MFnKeyframeDeltaTangent_currentTangentType(*args, **kwargs):
    pass


def MAnimCurveClipboardItem_className(*args, **kwargs):
    pass


def new_MFnKeyframeDeltaWeighted(*args, **kwargs):
    pass


def MFnClip_setScale(*args, **kwargs):
    pass


def MFnAnimCurve_isStatic(*args, **kwargs):
    pass


def MAnimCurveClipboardItem_leafAttributeName(*args, **kwargs):
    pass


def MFnWireDeformer_setHoldingShape(*args, **kwargs):
    pass


def MFnGeometryFilter_indexForOutputShape(*args, **kwargs):
    pass


def MAnimCurveClipboardItem_fullAttributeName(*args, **kwargs):
    pass


def new_MFnGeometryFilter(*args, **kwargs):
    pass


def MFnMotionPath_pathObject(*args, **kwargs):
    pass


def MFnIkSolver_className(*args, **kwargs):
    pass


def MAnimCurveClipboard_startTime(*args, **kwargs):
    pass


def MFnLattice_setDivisions(*args, **kwargs):
    pass


def MAnimCurveClipboard_clipboardItems(*args, **kwargs):
    pass


def MFnBlendShapeDeformer_envelope(*args, **kwargs):
    pass


def new_MFnKeyframeDeltaBreakdown(*args, **kwargs):
    pass


def MFnBlendShapeDeformer_weight(*args, **kwargs):
    pass


def MFnBlendShapeDeformer_swiginit(*args, **kwargs):
    pass


def MFnClip_getWeight(*args, **kwargs):
    pass


def MFnKeyframeDelta_swiginit(*args, **kwargs):
    pass


def MFnIkJoint_minRotateDampYRange(*args, **kwargs):
    pass


def MFnWireDeformer_wire(*args, **kwargs):
    pass


def MFnIkJoint_className(*args, **kwargs):
    pass


def MItKeyframe_swiginit(*args, **kwargs):
    pass


def delete_MFnWireDeformer(*args, **kwargs):
    pass


def MIkSystem_setGlobalSnap(*args, **kwargs):
    pass


def MFnClip_getTrack(*args, **kwargs):
    pass


def MFnAnimCurve_setWeight(*args, **kwargs):
    pass


def MIkHandleGroup_checkEffectorAtGoal(*args, **kwargs):
    pass


def MFnAnimCurve_setTangentTypes(*args, **kwargs):
    pass


def MFnKeyframeDeltaWeighted_className(*args, **kwargs):
    pass


def MAnimCurveChange_setInteractive(*args, **kwargs):
    pass


def MFnAnimCurve_addKey(*args, **kwargs):
    pass


def delete_MAnimCurveClipboardItem(*args, **kwargs):
    pass


def MFnKeyframeDeltaWeighted_wasWeighted(*args, **kwargs):
    pass


def MFnGeometryFilter_setEnvelope(*args, **kwargs):
    pass


def MAnimCurveClipboardItem_swiginit(*args, **kwargs):
    pass


def MFnLatticeDeformer_getDivisions(*args, **kwargs):
    pass


def MAnimCurveClipboardItemArray_clear(*args, **kwargs):
    pass


def MAnimCurveClipboardItem_setAnimCurve(*args, **kwargs):
    pass


def MFnCharacter_removeBlend(*args, **kwargs):
    pass


def MFnHikEffector_swigregister(*args, **kwargs):
    pass


def MFnMotionPath_swiginit(*args, **kwargs):
    pass


def MFnCharacter_attachInstanceToCharacter(*args, **kwargs):
    pass


def MFnHikEffector_getAuxiliaryEffectors(*args, **kwargs):
    pass


def MFnMotionPath_setPathObject(*args, **kwargs):
    pass


def delete_MAnimCurveChange(*args, **kwargs):
    pass


def MFnLattice_className(*args, **kwargs):
    pass


def MFnCharacter_getSubCharacters(*args, **kwargs):
    pass


def MFnIkJoint_setMinRotateDampZStrength(*args, **kwargs):
    pass


def MIkHandleGroup_priority(*args, **kwargs):
    pass


def MFnKeyframeDeltaBlockAddRemove_deltaType(*args, **kwargs):
    pass


def MFnClip_getPreCycle(*args, **kwargs):
    pass


def MFnKeyframeDeltaBreakdown_wasBreakdown(*args, **kwargs):
    pass


def MFnIkHandle_setSolver(*args, **kwargs):
    pass


def MFnBlendShapeDeformer_addBaseObject(*args, **kwargs):
    pass


def MFnKeyframeDeltaAddRemove_time(*args, **kwargs):
    pass


def MFnIkHandle_getEffector(*args, **kwargs):
    pass


def MFnWireDeformer_wireDropOffDistance(*args, **kwargs):
    pass


def MFnIkJoint_setMinRotateDampYRange(*args, **kwargs):
    pass


def MFnWireDeformer_swiginit(*args, **kwargs):
    pass


def MFnWireDeformer_wireScale(*args, **kwargs):
    pass


def MItKeyframe_getTangentOut(*args, **kwargs):
    pass


def MFnAnimCurve_time(*args, **kwargs):
    pass


def MAnimCurveClipboardItem_getAddressingInfo(*args, **kwargs):
    pass


def MFnWireDeformer_envelope(*args, **kwargs):
    pass


def MFnAnimCurve_setPreInfinityType(*args, **kwargs):
    pass


def MItKeyframe_setTime(*args, **kwargs):
    pass


def MAnimCurveClipboard_swiginit(*args, **kwargs):
    pass


def MFnAnimCurve_setPostInfinityType(*args, **kwargs):
    pass


def MAnimCurveClipboardItemArray_className(*args, **kwargs):
    pass


def new_MFnHikEffector(*args, **kwargs):
    pass


def MFnClip_setTrack(*args, **kwargs):
    pass


def MFnClip_getSourceStart(*args, **kwargs):
    pass


def MFnKeyframeDeltaScale_pivotTime(*args, **kwargs):
    pass


def MFnGeometryFilter_className(*args, **kwargs):
    pass


def MFnClip_setAbsolute(*args, **kwargs):
    pass


def MFnMotionPath_uStart(*args, **kwargs):
    pass


def MFnGeometryFilter_getInputGeometry(*args, **kwargs):
    pass


def MFnMotionPath_className(*args, **kwargs):
    pass


def MItKeyframe_next(*args, **kwargs):
    pass


def MFnMotionPath_addAnimatedObject(*args, **kwargs):
    pass


def MAnimControl_animationEndTime(*args, **kwargs):
    pass


def MFnIkJoint_setMinRotateDampXStrength(*args, **kwargs):
    pass


def MFnKeyframeDeltaAddRemove_className(*args, **kwargs):
    pass


def MFnKeyframeDeltaAddRemove_replacedValue(*args, **kwargs):
    pass


def delete_MFnIkHandle(*args, **kwargs):
    pass


def MFnBlendShapeDeformer_setOrigin(*args, **kwargs):
    pass


def MFnIkJoint_swiginit(*args, **kwargs):
    pass


def MFnIkHandle_poWeight(*args, **kwargs):
    pass


def MFnWireDeformer_setLocalIntensity(*args, **kwargs):
    pass


def MFnWireDeformer_swigregister(*args, **kwargs):
    pass


def MFnIkJoint_setPreferedAngle(*args, **kwargs):
    pass


def MFnIkJoint_minRotateDampXStrength(*args, **kwargs):
    pass


def MFnWireDeformer_removeGeometry(*args, **kwargs):
    pass


def MFnCharacter_getScheduledClip(*args, **kwargs):
    pass


def MFnWireDeformer_setWireDropOffDistance(*args, **kwargs):
    pass


def MFnAnimCurve_setIsBreakdown(*args, **kwargs):
    pass


def MFnAnimCurve_outTangentType(*args, **kwargs):
    pass


def MFnClip_swiginit(*args, **kwargs):
    pass


def delete_MFnKeyframeDeltaMove(*args, **kwargs):
    pass


def MFnAnimCurve_preInfinityType(*args, **kwargs):
    pass


def MFnKeyframeDeltaInfType_previousInfinityType(*args, **kwargs):
    pass


def MFnIkHandle_create(*args, **kwargs):
    pass


def MFnIkEffector_create(*args, **kwargs):
    pass


def new_MFnKeyframeDeltaTangent(*args, **kwargs):
    pass


def MFnClip_setSourceData(*args, **kwargs):
    pass


def MIkHandleGroup_swigregister(*args, **kwargs):
    pass


def MAnimCurveChange_isInteractive(*args, **kwargs):
    pass


def new_MFnIkEffector(*args, **kwargs):
    pass


def MFnMotionPath_uTimeEnd(*args, **kwargs):
    pass


def new_MAnimMessage(*args, **kwargs):
    pass


def MAnimCurveChange_swigregister(*args, **kwargs):
    pass


def MFnMotionPath_setUseNormal(*args, **kwargs):
    pass


def MAnimControl_playbackSpeed(*args, **kwargs):
    pass


def MFnIkHandle_swigregister(*args, **kwargs):
    pass


def MAnimControl_setAnimationStartTime(*args, **kwargs):
    pass


def MFnClip_isPose(*args, **kwargs):
    pass


def delete_MItKeyframe(*args, **kwargs):
    pass


def MFnKeyframeDeltaBreakdown_isBreakdown(*args, **kwargs):
    pass


def MFnIkHandle_setStartJointAndEffector(*args, **kwargs):
    pass


def MFnKeyframeDeltaAddRemove_swiginit(*args, **kwargs):
    pass


def MFnIkJoint_getPreferedAngle(*args, **kwargs):
    pass


def MFnSkinCluster_setBlendWeights(*args, **kwargs):
    pass


def MAnimControl_playForward(*args, **kwargs):
    pass


def MFnIkJoint_maxRotateDampXRange(*args, **kwargs):
    pass


def MItKeyframe_tangentsLocked(*args, **kwargs):
    pass


def MFnWireDeformer_setCrossingEffect(*args, **kwargs):
    pass


def MFnIkJoint_setMinRotateDampZRange(*args, **kwargs):
    pass


def MFnSkinCluster_getWeights(*args, **kwargs):
    pass


def MItKeyframe_className(*args, **kwargs):
    pass


def MFnAnimCurve_swigregister(*args, **kwargs):
    pass


def MFnCharacter_attachSourceToCharacter(*args, **kwargs):
    pass


def MFnKeyframeDeltaInfType_swiginit(*args, **kwargs):
    pass


def MFnIkSolver_swiginit(*args, **kwargs):
    pass


def MFnLatticeDeformer_setDivisions(*args, **kwargs):
    pass


def MAnimControl_setAnimationEndTime(*args, **kwargs):
    pass


def MAnimCurveClipboardItemArray_isValid(*args, **kwargs):
    pass


def SWIG_PyInstanceMethod_New(*args, **kwargs):
    pass


def MFnKeyframeDeltaScale_endTime(*args, **kwargs):
    pass


def MFnClip_setAbsoluteChannelSettings(*args, **kwargs):
    pass


def MAnimControl_isPlaying(*args, **kwargs):
    pass


def MFnLatticeDeformer_swiginit(*args, **kwargs):
    pass


def new_MAnimCurveClipboard(*args, **kwargs):
    pass


def MAnimCurveClipboard_clear(*args, **kwargs):
    pass


def MFnLattice_getDivisions(*args, **kwargs):
    pass


def MAnimControl_setGlobalInTangentType(*args, **kwargs):
    pass


def MFnAnimCurve_isUnitlessInput(*args, **kwargs):
    pass


def MFnMotionPath_inverseNormal(*args, **kwargs):
    pass


def delete_MFnIkSolver(*args, **kwargs):
    pass


def MFnKeyframeDeltaBlockAddRemove_endTime(*args, **kwargs):
    pass


def MFnKeyframeDeltaBreakdown_className(*args, **kwargs):
    pass


def MFnIkHandle_setPriority(*args, **kwargs):
    pass


def MAnimMessage_addAnimKeyframeEditedCallback(*args, **kwargs):
    pass


def MFnIkSolver_setTolerance(*args, **kwargs):
    pass


def MFnIkJoint_setMaxRotateDampYRange(*args, **kwargs):
    pass


def MFnWeightGeometryFilter_className(*args, **kwargs):
    pass


def MFnIkHandle_getStartJoint(*args, **kwargs):
    pass


def MItKeyframe_outTangentType(*args, **kwargs):
    pass


def new_MFnSkinCluster(*args, **kwargs):
    pass


def MAnimControl_setMinTime(*args, **kwargs):
    pass


def MFnKeyframeDeltaBlockAddRemove_getTimes(*args, **kwargs):
    pass


def MFnWireDeformer_crossingEffect(*args, **kwargs):
    pass


def MItKeyframe_getTangentIn(*args, **kwargs):
    pass


def MAnimControl_setPlaybackMode(*args, **kwargs):
    pass


def MAnimCurveClipboardItem_animCurve(*args, **kwargs):
    pass


def new_MAnimControl(*args, **kwargs):
    pass


def MAnimCurveClipboardItemArray_set(*args, **kwargs):
    pass


def MFnKeyframeDeltaInfType_swigregister(*args, **kwargs):
    pass


def MFnAnimCurve_swiginit(*args, **kwargs):
    pass


def MFnMotionPath_setUStart(*args, **kwargs):
    pass


def MFnLatticeDeformer_resetLattice(*args, **kwargs):
    pass


def MFnGeometryFilter_envelope(*args, **kwargs):
    pass


def new_MAnimCurveChange(*args, **kwargs):
    pass


def MFnMotionPath_upAxis(*args, **kwargs):
    pass


def MAnimCurveChange_className(*args, **kwargs):
    pass


def MAnimUtil_findAnimatablePlugs(*args, **kwargs):
    pass


def MFnLattice_reset(*args, **kwargs):
    pass


def new_MAnimCurveClipboardItem(*args, **kwargs):
    pass


def MAnimCurveChange_swiginit(*args, **kwargs):
    pass


def MFnMotionPath_bankThreshold(*args, **kwargs):
    pass


def MFnIkSolver_setMaxIterations(*args, **kwargs):
    pass


def new_MFnKeyframeDelta(*args, **kwargs):
    pass


def MFnCharacter_className(*args, **kwargs):
    pass


def new_MFnIkSolver(*args, **kwargs):
    pass


def MFnIkHandle_setEffector(*args, **kwargs):
    pass


def MFnCharacter_swigregister(*args, **kwargs):
    pass


def MAnimUtil_findAnimation(*args, **kwargs):
    pass


def MFnIkJoint_setMaxRotateDampYStrength(*args, **kwargs):
    pass


def MFnIkHandle_setStartJoint(*args, **kwargs):
    pass


def MIkHandleGroup_solverID(*args, **kwargs):
    pass


def MIkSystem_findSolver(*args, **kwargs):
    pass


def MAnimControl_setAnimationStartEndTime(*args, **kwargs):
    pass


def MFnWireDeformer_className(*args, **kwargs):
    pass


def MFnAnimCurve_setOutTangentType(*args, **kwargs):
    pass


def MIkHandleGroup_setPriority(*args, **kwargs):
    pass


def MFnAnimCurve_setTangentsLocked(*args, **kwargs):
    pass


def MFnIkJoint_hikJointName(*args, **kwargs):
    pass


def MAnimMessage_addAnimKeyframeEditCheckCallback(*args, **kwargs):
    pass


def MFnMotionPath_getAnimatedObjects(*args, **kwargs):
    pass


def MAnimMessage_swigregister(*args, **kwargs):
    pass


def MFnKeyframeDeltaInfType_className(*args, **kwargs):
    pass


def MFnAnimCurve_isTimeInput(*args, **kwargs):
    pass


def new_MAnimCurveClipboardItemArray(*args, **kwargs):
    pass


def MFnKeyframeDeltaTangent_getCurrentPosition(*args, **kwargs):
    pass


def MFnClip_setPoseClip(*args, **kwargs):
    pass


def MItKeyframe_setOutTangentType(*args, **kwargs):
    pass


def new_MFnLatticeDeformer(*args, **kwargs):
    pass


def MFnClip_getStartFrame(*args, **kwargs):
    pass


def MAnimControl_swiginit(*args, **kwargs):
    pass


def MFnClip_setPostCycle(*args, **kwargs):
    pass


def MFnLatticeDeformer_deformLattice(*args, **kwargs):
    pass


def MFnBlendShapeDeformer_className(*args, **kwargs):
    pass


def MFnAnimCurve_remove(*args, **kwargs):
    pass


def MFnLatticeDeformer_swigregister(*args, **kwargs):
    pass


def MAnimControl_viewMode(*args, **kwargs):
    pass


def MFnMotionPath_getPositionMarker(*args, **kwargs):
    pass


def MFnIkJoint_setMaxRotateDampZStrength(*args, **kwargs):
    pass


def MFnIkSolver_tolerance(*args, **kwargs):
    pass


def MFnClip_setCycle(*args, **kwargs):
    pass


def MFnBlendShapeDeformer_getBaseObjects(*args, **kwargs):
    pass


def delete_MFnKeyframeDeltaAddRemove(*args, **kwargs):
    pass


def MFnIkJoint_maxRotateDampZRange(*args, **kwargs):
    pass


def MAnimControl_playBackward(*args, **kwargs):
    pass


def MFnIkHandle_stickiness(*args, **kwargs):
    pass


def new_MIkSystem(*args, **kwargs):
    pass


def MFnAnimCurve_numKeyframes(*args, **kwargs):
    pass


def MFnWireDeformer_setWireScale(*args, **kwargs):
    pass


def MFnGeometryFilter_swiginit(*args, **kwargs):
    pass


def MFnSkinCluster_influenceObjects(*args, **kwargs):
    pass


def MIkSystem_className(*args, **kwargs):
    pass


def delete_MFnWeightGeometryFilter(*args, **kwargs):
    pass


def MFnAnimCurve_timedAnimCurveTypeForPlug(*args, **kwargs):
    pass


def MFnIkJoint_setMaxRotateDampZRange(*args, **kwargs):
    pass


def MFnIkHandle_setPOWeight(*args, **kwargs):
    pass


def MItKeyframe_setValue(*args, **kwargs):
    pass


def MFnAnimCurve_findClosest(*args, **kwargs):
    pass


def delete_MFnLatticeDeformer(*args, **kwargs):
    pass


def MFnAnimCurve_isWeighted(*args, **kwargs):
    pass


def MAnimCurveClipboardItemArray_setSizeIncrement(*args, **kwargs):
    pass


def MFnKeyframeDeltaTangent_swiginit(*args, **kwargs):
    pass


def MFnClip_getAbsoluteChannelSettings(*args, **kwargs):
    pass


def delete_MFnKeyframeDeltaWeighted(*args, **kwargs):
    pass


def MFnClip_setPreCycle(*args, **kwargs):
    pass


def MFnBlendShapeDeformer_historyLocation(*args, **kwargs):
    pass


def MAnimControl_stop(*args, **kwargs):
    pass


def MFnGeometryFilter_indexForOutputConnection(*args, **kwargs):
    pass


def MFnMotionPath_setFollow(*args, **kwargs):
    pass


def MFnMotionPath_uTimeStart(*args, **kwargs):
    pass


def MAnimCurveClipboard_isEmpty(*args, **kwargs):
    pass


def MFnMotionPath_bankScale(*args, **kwargs):
    pass


def MAnimControl_minTime(*args, **kwargs):
    pass


def MFnIkJoint_setMinRotateDampYStrength(*args, **kwargs):
    pass


def MFnBlendShapeDeformer_addTarget(*args, **kwargs):
    pass


def MFnIkJoint_setMinRotateDampXRange(*args, **kwargs):
    pass


def MFnBlendShapeDeformer_weightIndexList(*args, **kwargs):
    pass


def MFnGeometryFilter_deformerSet(*args, **kwargs):
    pass


def MFnClip_swigregister(*args, **kwargs):
    pass


def MFnClip_createInstancedClip(*args, **kwargs):
    pass


def MItKeyframe_reset(*args, **kwargs):
    pass


def MFnSkinCluster_swiginit(*args, **kwargs):
    pass


def MFnGeometryFilter_swigregister(*args, **kwargs):
    pass


def MFnIkJoint_setDegreesOfFreedom(*args, **kwargs):
    pass


def MItKeyframe_value(*args, **kwargs):
    pass


def MFnWeightGeometryFilter_swiginit(*args, **kwargs):
    pass


def MFnCharacter_swiginit(*args, **kwargs):
    pass


def MIkHandleGroup_dofCount(*args, **kwargs):
    pass


def MFnAnimCurve_setIsWeighted(*args, **kwargs):
    pass


def MIkHandleGroup_swiginit(*args, **kwargs):
    pass


def MFnAnimCurve_setInTangentType(*args, **kwargs):
    pass


def MAnimCurveClipboardItemArray_remove(*args, **kwargs):
    pass


def MFnKeyframeDeltaScale_swiginit(*args, **kwargs):
    pass



MFnAnimCurve_kTangentShared8 = 26

MFnAnimCurve_kTangentShared7 = 25

MFnAnimCurve_kTangentShared5 = 23

MFnAnimCurve_kTangentShared4 = 22

MFnAnimCurve_kTangentShared3 = 21

MFnAnimCurve_kTangentShared2 = 20

MFnAnimCurve_kTangentShared1 = 19

MFnAnimCurve_kAnimCurveUT = 6

MFnAnimCurve_kTangentAuto = 11

MFnAnimCurve_kTangentStepNext = 10

MFnAnimCurve_kTangentPlateau = 9

MFnAnimCurve_kAnimCurveUnknown = 8

MFnAnimCurve_kAnimCurveUU = 7

MFnAnimCurve_kAnimCurveTU = 3

MFnAnimCurve_kAnimCurveUL = 5

MFnAnimCurve_kAnimCurveUA = 4

MAnimControl_kPlaybackOscillate = 2

MAnimControl_kPlaybackLoop = 1

MAnimControl_kPlaybackOnce = 0

MFnAnimCurve_kTangentCustomEnd = 32767

MFnAnimCurve_kTangentCustomStart = 64

MFnAnimCurve_kTangentTypeCount = 32768

MFnAnimCurve_kTangentShared6 = 24


