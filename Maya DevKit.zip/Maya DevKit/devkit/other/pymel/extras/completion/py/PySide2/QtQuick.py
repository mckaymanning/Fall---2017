from PySide2.QtGui import QWindow as _QWindow
from PySide2.QtCore import QObject as _QObject

class _Object(object):
    __dict__ = None


class QQuickTextDocument(_QObject):
    def __init__(*args, **kwargs):
        """
        x.__init__(...) initializes x; see help(type(x)) for signature
        """
    
        pass
    
    
    def textDocument(*args, **kwargs):
        pass
    
    
    __new__ = None
    
    
    staticMetaObject = None


class QQuickItem(_QObject):
    def __init__(*args, **kwargs):
        """
        x.__init__(...) initializes x; see help(type(x)) for signature
        """
    
        pass
    
    
    def acceptHoverEvents(*args, **kwargs):
        pass
    
    
    def acceptedMouseButtons(*args, **kwargs):
        pass
    
    
    def activeFocusOnTab(*args, **kwargs):
        pass
    
    
    def antialiasing(*args, **kwargs):
        pass
    
    
    def baselineOffset(*args, **kwargs):
        pass
    
    
    def boundingRect(*args, **kwargs):
        pass
    
    
    def childAt(*args, **kwargs):
        pass
    
    
    def childItems(*args, **kwargs):
        pass
    
    
    def childMouseEventFilter(*args, **kwargs):
        pass
    
    
    def childrenRect(*args, **kwargs):
        pass
    
    
    def classBegin(*args, **kwargs):
        pass
    
    
    def clip(*args, **kwargs):
        pass
    
    
    def clipRect(*args, **kwargs):
        pass
    
    
    def componentComplete(*args, **kwargs):
        pass
    
    
    def contains(*args, **kwargs):
        pass
    
    
    def cursor(*args, **kwargs):
        pass
    
    
    def dragEnterEvent(*args, **kwargs):
        pass
    
    
    def dragLeaveEvent(*args, **kwargs):
        pass
    
    
    def dragMoveEvent(*args, **kwargs):
        pass
    
    
    def dropEvent(*args, **kwargs):
        pass
    
    
    def event(*args, **kwargs):
        pass
    
    
    def filtersChildMouseEvents(*args, **kwargs):
        pass
    
    
    def flags(*args, **kwargs):
        pass
    
    
    def focusInEvent(*args, **kwargs):
        pass
    
    
    def focusOutEvent(*args, **kwargs):
        pass
    
    
    def forceActiveFocus(*args, **kwargs):
        pass
    
    
    def geometryChanged(*args, **kwargs):
        pass
    
    
    def grabMouse(*args, **kwargs):
        pass
    
    
    def grabTouchPoints(*args, **kwargs):
        pass
    
    
    def hasActiveFocus(*args, **kwargs):
        pass
    
    
    def hasFocus(*args, **kwargs):
        pass
    
    
    def height(*args, **kwargs):
        pass
    
    
    def heightValid(*args, **kwargs):
        pass
    
    
    def hoverEnterEvent(*args, **kwargs):
        pass
    
    
    def hoverLeaveEvent(*args, **kwargs):
        pass
    
    
    def hoverMoveEvent(*args, **kwargs):
        pass
    
    
    def implicitHeight(*args, **kwargs):
        pass
    
    
    def implicitWidth(*args, **kwargs):
        pass
    
    
    def inputMethodEvent(*args, **kwargs):
        pass
    
    
    def inputMethodQuery(*args, **kwargs):
        pass
    
    
    def isComponentComplete(*args, **kwargs):
        pass
    
    
    def isEnabled(*args, **kwargs):
        pass
    
    
    def isFocusScope(*args, **kwargs):
        pass
    
    
    def isTextureProvider(*args, **kwargs):
        pass
    
    
    def isUnderMouse(*args, **kwargs):
        pass
    
    
    def isVisible(*args, **kwargs):
        pass
    
    
    def itemTransform(*args, **kwargs):
        pass
    
    
    def keepMouseGrab(*args, **kwargs):
        pass
    
    
    def keepTouchGrab(*args, **kwargs):
        pass
    
    
    def keyPressEvent(*args, **kwargs):
        pass
    
    
    def keyReleaseEvent(*args, **kwargs):
        pass
    
    
    def mapFromItem(*args, **kwargs):
        pass
    
    
    def mapFromScene(*args, **kwargs):
        pass
    
    
    def mapRectFromItem(*args, **kwargs):
        pass
    
    
    def mapRectFromScene(*args, **kwargs):
        pass
    
    
    def mapRectToItem(*args, **kwargs):
        pass
    
    
    def mapRectToScene(*args, **kwargs):
        pass
    
    
    def mapToItem(*args, **kwargs):
        pass
    
    
    def mapToScene(*args, **kwargs):
        pass
    
    
    def mouseDoubleClickEvent(*args, **kwargs):
        pass
    
    
    def mouseMoveEvent(*args, **kwargs):
        pass
    
    
    def mousePressEvent(*args, **kwargs):
        pass
    
    
    def mouseReleaseEvent(*args, **kwargs):
        pass
    
    
    def mouseUngrabEvent(*args, **kwargs):
        pass
    
    
    def nextItemInFocusChain(*args, **kwargs):
        pass
    
    
    def opacity(*args, **kwargs):
        pass
    
    
    def parentItem(*args, **kwargs):
        pass
    
    
    def polish(*args, **kwargs):
        pass
    
    
    def position(*args, **kwargs):
        pass
    
    
    def releaseResources(*args, **kwargs):
        pass
    
    
    def resetAntialiasing(*args, **kwargs):
        pass
    
    
    def resetHeight(*args, **kwargs):
        pass
    
    
    def resetWidth(*args, **kwargs):
        pass
    
    
    def rotation(*args, **kwargs):
        pass
    
    
    def scale(*args, **kwargs):
        pass
    
    
    def scopedFocusItem(*args, **kwargs):
        pass
    
    
    def setAcceptHoverEvents(*args, **kwargs):
        pass
    
    
    def setAcceptedMouseButtons(*args, **kwargs):
        pass
    
    
    def setActiveFocusOnTab(*args, **kwargs):
        pass
    
    
    def setAntialiasing(*args, **kwargs):
        pass
    
    
    def setBaselineOffset(*args, **kwargs):
        pass
    
    
    def setClip(*args, **kwargs):
        pass
    
    
    def setCursor(*args, **kwargs):
        pass
    
    
    def setEnabled(*args, **kwargs):
        pass
    
    
    def setFiltersChildMouseEvents(*args, **kwargs):
        pass
    
    
    def setFlag(*args, **kwargs):
        pass
    
    
    def setFlags(*args, **kwargs):
        pass
    
    
    def setFocus(*args, **kwargs):
        pass
    
    
    def setHeight(*args, **kwargs):
        pass
    
    
    def setImplicitHeight(*args, **kwargs):
        pass
    
    
    def setImplicitSize(*args, **kwargs):
        pass
    
    
    def setImplicitWidth(*args, **kwargs):
        pass
    
    
    def setKeepMouseGrab(*args, **kwargs):
        pass
    
    
    def setKeepTouchGrab(*args, **kwargs):
        pass
    
    
    def setOpacity(*args, **kwargs):
        pass
    
    
    def setParentItem(*args, **kwargs):
        pass
    
    
    def setPosition(*args, **kwargs):
        pass
    
    
    def setRotation(*args, **kwargs):
        pass
    
    
    def setScale(*args, **kwargs):
        pass
    
    
    def setSize(*args, **kwargs):
        pass
    
    
    def setSmooth(*args, **kwargs):
        pass
    
    
    def setState(*args, **kwargs):
        pass
    
    
    def setTransformOrigin(*args, **kwargs):
        pass
    
    
    def setTransformOriginPoint(*args, **kwargs):
        pass
    
    
    def setVisible(*args, **kwargs):
        pass
    
    
    def setWidth(*args, **kwargs):
        pass
    
    
    def setX(*args, **kwargs):
        pass
    
    
    def setY(*args, **kwargs):
        pass
    
    
    def setZ(*args, **kwargs):
        pass
    
    
    def smooth(*args, **kwargs):
        pass
    
    
    def stackAfter(*args, **kwargs):
        pass
    
    
    def stackBefore(*args, **kwargs):
        pass
    
    
    def state(*args, **kwargs):
        pass
    
    
    def touchEvent(*args, **kwargs):
        pass
    
    
    def touchUngrabEvent(*args, **kwargs):
        pass
    
    
    def transformOrigin(*args, **kwargs):
        pass
    
    
    def transformOriginPoint(*args, **kwargs):
        pass
    
    
    def ungrabMouse(*args, **kwargs):
        pass
    
    
    def ungrabTouchPoints(*args, **kwargs):
        pass
    
    
    def unsetCursor(*args, **kwargs):
        pass
    
    
    def update(*args, **kwargs):
        pass
    
    
    def updatePolish(*args, **kwargs):
        pass
    
    
    def wheelEvent(*args, **kwargs):
        pass
    
    
    def width(*args, **kwargs):
        pass
    
    
    def widthValid(*args, **kwargs):
        pass
    
    
    def window(*args, **kwargs):
        pass
    
    
    def windowDeactivateEvent(*args, **kwargs):
        pass
    
    
    def x(*args, **kwargs):
        pass
    
    
    def y(*args, **kwargs):
        pass
    
    
    def z(*args, **kwargs):
        pass
    
    
    Bottom = None
    
    
    BottomLeft = None
    
    
    BottomRight = None
    
    
    Center = None
    
    
    Flag = None
    
    
    Flags = None
    
    
    ItemAcceptsDrops = None
    
    
    ItemAcceptsInputMethod = None
    
    
    ItemActiveFocusHasChanged = None
    
    
    ItemAntialiasingHasChanged = None
    
    
    ItemChange = None
    
    
    ItemChildAddedChange = None
    
    
    ItemChildRemovedChange = None
    
    
    ItemClipsChildrenToShape = None
    
    
    ItemDevicePixelRatioHasChanged = None
    
    
    ItemHasContents = None
    
    
    ItemIsFocusScope = None
    
    
    ItemOpacityHasChanged = None
    
    
    ItemParentHasChanged = None
    
    
    ItemRotationHasChanged = None
    
    
    ItemSceneChange = None
    
    
    ItemVisibleHasChanged = None
    
    
    Left = None
    
    
    Right = None
    
    
    Top = None
    
    
    TopLeft = None
    
    
    TopRight = None
    
    
    TransformOrigin = None
    
    
    __new__ = None
    
    
    activeFocusChanged = None
    
    
    activeFocusOnTabChanged = None
    
    
    antialiasingChanged = None
    
    
    baselineOffsetChanged = None
    
    
    childrenChanged = None
    
    
    childrenRectChanged = None
    
    
    clipChanged = None
    
    
    enabledChanged = None
    
    
    focusChanged = None
    
    
    heightChanged = None
    
    
    implicitHeightChanged = None
    
    
    implicitWidthChanged = None
    
    
    opacityChanged = None
    
    
    parentChanged = None
    
    
    rotationChanged = None
    
    
    scaleChanged = None
    
    
    smoothChanged = None
    
    
    stateChanged = None
    
    
    staticMetaObject = None
    
    
    transformOriginChanged = None
    
    
    visibleChanged = None
    
    
    visibleChildrenChanged = None
    
    
    widthChanged = None
    
    
    windowChanged = None
    
    
    xChanged = None
    
    
    yChanged = None
    
    
    zChanged = None


class QQuickWindow(_QWindow):
    def __init__(*args, **kwargs):
        """
        x.__init__(...) initializes x; see help(type(x)) for signature
        """
    
        pass
    
    
    def activeFocusItem(*args, **kwargs):
        pass
    
    
    def clearBeforeRendering(*args, **kwargs):
        pass
    
    
    def color(*args, **kwargs):
        pass
    
    
    def contentItem(*args, **kwargs):
        pass
    
    
    def effectiveDevicePixelRatio(*args, **kwargs):
        pass
    
    
    def event(*args, **kwargs):
        pass
    
    
    def focusInEvent(*args, **kwargs):
        pass
    
    
    def focusObject(*args, **kwargs):
        pass
    
    
    def focusOutEvent(*args, **kwargs):
        pass
    
    
    def grabWindow(*args, **kwargs):
        pass
    
    
    def hideEvent(*args, **kwargs):
        pass
    
    
    def isPersistentOpenGLContext(*args, **kwargs):
        pass
    
    
    def isPersistentSceneGraph(*args, **kwargs):
        pass
    
    
    def isSceneGraphInitialized(*args, **kwargs):
        pass
    
    
    def keyPressEvent(*args, **kwargs):
        pass
    
    
    def keyReleaseEvent(*args, **kwargs):
        pass
    
    
    def mouseDoubleClickEvent(*args, **kwargs):
        pass
    
    
    def mouseGrabberItem(*args, **kwargs):
        pass
    
    
    def mouseMoveEvent(*args, **kwargs):
        pass
    
    
    def mousePressEvent(*args, **kwargs):
        pass
    
    
    def mouseReleaseEvent(*args, **kwargs):
        pass
    
    
    def releaseResources(*args, **kwargs):
        pass
    
    
    def renderTargetId(*args, **kwargs):
        pass
    
    
    def renderTargetSize(*args, **kwargs):
        pass
    
    
    def resetOpenGLState(*args, **kwargs):
        pass
    
    
    def resizeEvent(*args, **kwargs):
        pass
    
    
    def scheduleRenderJob(*args, **kwargs):
        pass
    
    
    def sendEvent(*args, **kwargs):
        pass
    
    
    def setClearBeforeRendering(*args, **kwargs):
        pass
    
    
    def setColor(*args, **kwargs):
        pass
    
    
    def setPersistentOpenGLContext(*args, **kwargs):
        pass
    
    
    def setPersistentSceneGraph(*args, **kwargs):
        pass
    
    
    def setRenderTarget(*args, **kwargs):
        pass
    
    
    def showEvent(*args, **kwargs):
        pass
    
    
    def update(*args, **kwargs):
        pass
    
    
    def wheelEvent(*args, **kwargs):
        pass
    
    
    def hasDefaultAlphaBuffer(*args, **kwargs):
        pass
    
    
    def setDefaultAlphaBuffer(*args, **kwargs):
        pass
    
    
    AfterRenderingStage = None
    
    
    AfterSwapStage = None
    
    
    AfterSynchronizingStage = None
    
    
    BeforeRenderingStage = None
    
    
    BeforeSynchronizingStage = None
    
    
    ContextNotAvailable = None
    
    
    CreateTextureOption = None
    
    
    CreateTextureOptions = None
    
    
    NoStage = None
    
    
    RenderStage = None
    
    
    SceneGraphError = None
    
    
    TextureCanUseAtlas = None
    
    
    TextureHasAlphaChannel = None
    
    
    TextureHasMipmaps = None
    
    
    TextureIsOpaque = None
    
    
    TextureOwnsGLTexture = None
    
    
    __new__ = None
    
    
    activeFocusItemChanged = None
    
    
    afterAnimating = None
    
    
    afterRendering = None
    
    
    afterSynchronizing = None
    
    
    beforeRendering = None
    
    
    beforeSynchronizing = None
    
    
    closing = None
    
    
    colorChanged = None
    
    
    frameSwapped = None
    
    
    openglContextCreated = None
    
    
    sceneGraphAboutToStop = None
    
    
    sceneGraphError = None
    
    
    sceneGraphInitialized = None
    
    
    sceneGraphInvalidated = None
    
    
    staticMetaObject = None


class QQuickImageProvider(_Object):
    def requestImage(*args, **kwargs):
        pass
    
    
    def requestPixmap(*args, **kwargs):
        pass


class QQuickView(QQuickWindow):
    def __init__(*args, **kwargs):
        """
        x.__init__(...) initializes x; see help(type(x)) for signature
        """
    
        pass
    
    
    def initialSize(*args, **kwargs):
        pass
    
    
    def keyPressEvent(*args, **kwargs):
        pass
    
    
    def keyReleaseEvent(*args, **kwargs):
        pass
    
    
    def mouseMoveEvent(*args, **kwargs):
        pass
    
    
    def mousePressEvent(*args, **kwargs):
        pass
    
    
    def mouseReleaseEvent(*args, **kwargs):
        pass
    
    
    def resizeEvent(*args, **kwargs):
        pass
    
    
    def resizeMode(*args, **kwargs):
        pass
    
    
    def rootObject(*args, **kwargs):
        pass
    
    
    def setResizeMode(*args, **kwargs):
        pass
    
    
    def setSource(*args, **kwargs):
        pass
    
    
    def sizeHint(*args, **kwargs):
        pass
    
    
    def source(*args, **kwargs):
        pass
    
    
    def status(*args, **kwargs):
        pass
    
    
    def timerEvent(*args, **kwargs):
        pass
    
    
    Error = None
    
    
    Loading = None
    
    
    Null = None
    
    
    Ready = None
    
    
    ResizeMode = None
    
    
    SizeRootObjectToView = None
    
    
    SizeViewToRootObject = None
    
    
    Status = None
    
    
    __new__ = None
    
    
    staticMetaObject = None
    
    
    statusChanged = None



