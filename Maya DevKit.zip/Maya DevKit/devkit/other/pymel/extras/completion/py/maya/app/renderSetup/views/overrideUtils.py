def _getCollectionName():
    """
    Find the selected collection to be used for the override creation
    """

    pass


def createAbsoluteOverride(nodeName, attrName):
    """
    Add an absolute override to the last selected collection part of the visible render layer
    """

    pass


def createRelativeOverride(nodeName, attrName):
    """
    Add a relative override to the last selected collection part of the visible render layer
    """

    pass



