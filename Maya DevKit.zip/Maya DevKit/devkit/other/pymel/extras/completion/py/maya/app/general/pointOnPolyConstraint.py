def assembleCmd():
    pass



