from __builtin__ import object as _object
from __builtin__ import property as _swig_property

from . import OpenMaya

class MFnIkJoint(OpenMaya.MFnTransform):
    def __init__(self, *args):
        pass
    
    
    def __repr__(self):
        pass
    
    
    def create(*args, **kwargs):
        pass
    
    
    def getDegreesOfFreedom(*args, **kwargs):
        pass
    
    
    def getOrientation(*args, **kwargs):
        pass
    
    
    def getPreferedAngle(*args, **kwargs):
        pass
    
    
    def getScaleOrientation(*args, **kwargs):
        pass
    
    
    def getSegmentScale(*args, **kwargs):
        pass
    
    
    def getStiffness(*args, **kwargs):
        pass
    
    
    def hikJointName(*args, **kwargs):
        pass
    
    
    def maxRotateDampXRange(*args, **kwargs):
        pass
    
    
    def maxRotateDampXStrength(*args, **kwargs):
        pass
    
    
    def maxRotateDampYRange(*args, **kwargs):
        pass
    
    
    def maxRotateDampYStrength(*args, **kwargs):
        pass
    
    
    def maxRotateDampZRange(*args, **kwargs):
        pass
    
    
    def maxRotateDampZStrength(*args, **kwargs):
        pass
    
    
    def minRotateDampXRange(*args, **kwargs):
        pass
    
    
    def minRotateDampXStrength(*args, **kwargs):
        pass
    
    
    def minRotateDampYRange(*args, **kwargs):
        pass
    
    
    def minRotateDampYStrength(*args, **kwargs):
        pass
    
    
    def minRotateDampZRange(*args, **kwargs):
        pass
    
    
    def minRotateDampZStrength(*args, **kwargs):
        pass
    
    
    def setDegreesOfFreedom(*args, **kwargs):
        pass
    
    
    def setMaxRotateDampXRange(*args, **kwargs):
        pass
    
    
    def setMaxRotateDampXStrength(*args, **kwargs):
        pass
    
    
    def setMaxRotateDampYRange(*args, **kwargs):
        pass
    
    
    def setMaxRotateDampYStrength(*args, **kwargs):
        pass
    
    
    def setMaxRotateDampZRange(*args, **kwargs):
        pass
    
    
    def setMaxRotateDampZStrength(*args, **kwargs):
        pass
    
    
    def setMinRotateDampXRange(*args, **kwargs):
        pass
    
    
    def setMinRotateDampXStrength(*args, **kwargs):
        pass
    
    
    def setMinRotateDampYRange(*args, **kwargs):
        pass
    
    
    def setMinRotateDampYStrength(*args, **kwargs):
        pass
    
    
    def setMinRotateDampZRange(*args, **kwargs):
        pass
    
    
    def setMinRotateDampZStrength(*args, **kwargs):
        pass
    
    
    def setOrientation(*args, **kwargs):
        pass
    
    
    def setPreferedAngle(*args, **kwargs):
        pass
    
    
    def setScaleOrientation(*args, **kwargs):
        pass
    
    
    def setSegmentScale(*args, **kwargs):
        pass
    
    
    def setStiffness(*args, **kwargs):
        pass
    
    
    def className(*args, **kwargs):
        pass
    
    
    thisown = None
    
    __swig_destroy__ = None
    
    
    kNone = 3
    
    
    kXAxis = 0
    
    
    kYAxis = 1
    
    
    kZAxis = 2


class MIkSystem(_object):
    def __init__(self, *args):
        pass
    
    
    def __repr__(self):
        pass
    
    
    def className(*args, **kwargs):
        pass
    
    
    def findSolver(*args, **kwargs):
        pass
    
    
    def getSolvers(*args, **kwargs):
        pass
    
    
    def isGlobalSnap(*args, **kwargs):
        pass
    
    
    def isGlobalSolve(*args, **kwargs):
        pass
    
    
    def setGlobalSnap(*args, **kwargs):
        pass
    
    
    def setGlobalSolve(*args, **kwargs):
        pass
    
    
    __dict__ = None
    
    __weakref__ = None
    
    thisown = None
    
    __swig_destroy__ = None


class new_instancemethod(_object):
    """
    instancemethod(function, instance, class)
    
    Create an instance method object.
    """
    
    
    
    def __call__(*args, **kwargs):
        """
        x.__call__(...) <==> x(...)
        """
    
        pass
    
    
    def __cmp__(*args, **kwargs):
        """
        x.__cmp__(y) <==> cmp(x,y)
        """
    
        pass
    
    
    def __delattr__(*args, **kwargs):
        """
        x.__delattr__('name') <==> del x.name
        """
    
        pass
    
    
    def __get__(*args, **kwargs):
        """
        descr.__get__(obj[, type]) -> value
        """
    
        pass
    
    
    def __getattribute__(*args, **kwargs):
        """
        x.__getattribute__('name') <==> x.name
        """
    
        pass
    
    
    def __hash__(*args, **kwargs):
        """
        x.__hash__() <==> hash(x)
        """
    
        pass
    
    
    def __repr__(*args, **kwargs):
        """
        x.__repr__() <==> repr(x)
        """
    
        pass
    
    
    def __setattr__(*args, **kwargs):
        """
        x.__setattr__('name', value) <==> x.name = value
        """
    
        pass
    
    
    __func__ = None
    
    __self__ = None
    
    im_class = None
    
    im_func = None
    
    im_self = None
    
    __new__ = None


class MFnIkEffector(OpenMaya.MFnTransform):
    def __init__(self, *args):
        pass
    
    
    def __repr__(self):
        pass
    
    
    def create(*args, **kwargs):
        pass
    
    
    def className(*args, **kwargs):
        pass
    
    
    thisown = None
    
    __swig_destroy__ = None


class MFnWireDeformer(OpenMaya.MFnDependencyNode):
    def __init__(self, *args):
        pass
    
    
    def __repr__(self):
        pass
    
    
    def addGeometry(*args, **kwargs):
        pass
    
    
    def addWire(*args, **kwargs):
        pass
    
    
    def create(*args, **kwargs):
        pass
    
    
    def crossingEffect(*args, **kwargs):
        pass
    
    
    def envelope(*args, **kwargs):
        pass
    
    
    def getAffectedGeometry(*args, **kwargs):
        pass
    
    
    def getDropoffLocator(*args, **kwargs):
        pass
    
    
    def holdingShape(*args, **kwargs):
        pass
    
    
    def localIntensity(*args, **kwargs):
        pass
    
    
    def numDropoffLocators(*args, **kwargs):
        pass
    
    
    def numWires(*args, **kwargs):
        pass
    
    
    def removeGeometry(*args, **kwargs):
        pass
    
    
    def rotation(*args, **kwargs):
        pass
    
    
    def setCrossingEffect(*args, **kwargs):
        pass
    
    
    def setDropoffLocator(*args, **kwargs):
        pass
    
    
    def setEnvelope(*args, **kwargs):
        pass
    
    
    def setHoldingShape(*args, **kwargs):
        pass
    
    
    def setLocalIntensity(*args, **kwargs):
        pass
    
    
    def setRotation(*args, **kwargs):
        pass
    
    
    def setWireDropOffDistance(*args, **kwargs):
        pass
    
    
    def setWireScale(*args, **kwargs):
        pass
    
    
    def wire(*args, **kwargs):
        pass
    
    
    def wireDropOffDistance(*args, **kwargs):
        pass
    
    
    def wireScale(*args, **kwargs):
        pass
    
    
    def className(*args, **kwargs):
        pass
    
    
    thisown = None
    
    __swig_destroy__ = None


class MFnGeometryFilter(OpenMaya.MFnDependencyNode):
    def __init__(self, *args):
        pass
    
    
    def __repr__(self):
        pass
    
    
    def deformerSet(*args, **kwargs):
        pass
    
    
    def envelope(*args, **kwargs):
        pass
    
    
    def getInputGeometry(*args, **kwargs):
        pass
    
    
    def getOutputGeometry(*args, **kwargs):
        pass
    
    
    def getPathAtIndex(*args, **kwargs):
        pass
    
    
    def groupIdAtIndex(*args, **kwargs):
        pass
    
    
    def indexForGroupId(*args, **kwargs):
        pass
    
    
    def indexForOutputConnection(*args, **kwargs):
        pass
    
    
    def indexForOutputShape(*args, **kwargs):
        pass
    
    
    def inputShapeAtIndex(*args, **kwargs):
        pass
    
    
    def numOutputConnections(*args, **kwargs):
        pass
    
    
    def outputShapeAtIndex(*args, **kwargs):
        pass
    
    
    def setEnvelope(*args, **kwargs):
        pass
    
    
    def className(*args, **kwargs):
        pass
    
    
    thisown = None
    
    __swig_destroy__ = None


class MAnimCurveClipboardItem(_object):
    def __eq__(*args, **kwargs):
        pass
    
    
    def __init__(self, *args):
        pass
    
    
    def __repr__(self):
        pass
    
    
    def animCurve(*args, **kwargs):
        pass
    
    
    def animCurveType(*args, **kwargs):
        pass
    
    
    def assign(*args, **kwargs):
        pass
    
    
    def fullAttributeName(*args, **kwargs):
        pass
    
    
    def getAddressingInfo(*args, **kwargs):
        pass
    
    
    def leafAttributeName(*args, **kwargs):
        pass
    
    
    def nodeName(*args, **kwargs):
        pass
    
    
    def setAddressingInfo(*args, **kwargs):
        pass
    
    
    def setAnimCurve(*args, **kwargs):
        pass
    
    
    def setNameInfo(*args, **kwargs):
        pass
    
    
    def className(*args, **kwargs):
        pass
    
    
    __dict__ = None
    
    __weakref__ = None
    
    thisown = None
    
    __swig_destroy__ = None


class MFnCharacter(OpenMaya.MFnSet):
    def __init__(self, *args):
        pass
    
    
    def __repr__(self):
        pass
    
    
    def addCurveToClip(*args, **kwargs):
        pass
    
    
    def attachInstanceToCharacter(*args, **kwargs):
        pass
    
    
    def attachSourceToCharacter(*args, **kwargs):
        pass
    
    
    def blendExists(*args, **kwargs):
        pass
    
    
    def createBlend(*args, **kwargs):
        pass
    
    
    def getBlend(*args, **kwargs):
        pass
    
    
    def getBlendClips(*args, **kwargs):
        pass
    
    
    def getBlendCount(*args, **kwargs):
        pass
    
    
    def getCharacterThatOwnsPlug(*args, **kwargs):
        pass
    
    
    def getClipScheduler(*args, **kwargs):
        pass
    
    
    def getMemberPlugs(*args, **kwargs):
        pass
    
    
    def getScheduledClip(*args, **kwargs):
        pass
    
    
    def getScheduledClipCount(*args, **kwargs):
        pass
    
    
    def getSourceClip(*args, **kwargs):
        pass
    
    
    def getSourceClipCount(*args, **kwargs):
        pass
    
    
    def getSubCharacters(*args, **kwargs):
        pass
    
    
    def removeBlend(*args, **kwargs):
        pass
    
    
    def className(*args, **kwargs):
        pass
    
    
    thisown = None
    
    __swig_destroy__ = None


class MAnimCurveClipboard(_object):
    def __init__(self, *args):
        pass
    
    
    def __repr__(self):
        pass
    
    
    def clear(*args, **kwargs):
        pass
    
    
    def clipboardItems(*args, **kwargs):
        pass
    
    
    def endTime(*args, **kwargs):
        pass
    
    
    def endUnitlessInput(*args, **kwargs):
        pass
    
    
    def isEmpty(*args, **kwargs):
        pass
    
    
    def set(*args, **kwargs):
        pass
    
    
    def startTime(*args, **kwargs):
        pass
    
    
    def startUnitlessInput(*args, **kwargs):
        pass
    
    
    def theAPIClipboard(*args, **kwargs):
        pass
    
    
    __dict__ = None
    
    __weakref__ = None
    
    thisown = None
    
    __swig_destroy__ = None


class MFnLattice(OpenMaya.MFnDagNode):
    def __init__(self, *args):
        pass
    
    
    def __repr__(self):
        pass
    
    
    def create(*args, **kwargs):
        pass
    
    
    def getDivisions(*args, **kwargs):
        pass
    
    
    def point(*args, **kwargs):
        pass
    
    
    def reset(*args, **kwargs):
        pass
    
    
    def setDivisions(*args, **kwargs):
        pass
    
    
    def className(*args, **kwargs):
        pass
    
    
    thisown = None
    
    __swig_destroy__ = None


class MFnAnimCurve(OpenMaya.MFnDependencyNode):
    def __init__(self, *args):
        pass
    
    
    def __repr__(self):
        pass
    
    
    def addKey(*args, **kwargs):
        pass
    
    
    def addKeyframe(*args, **kwargs):
        pass
    
    
    def addKeys(*args, **kwargs):
        pass
    
    
    def animCurveType(*args, **kwargs):
        pass
    
    
    def create(*args, **kwargs):
        pass
    
    
    def evaluate(*args, **kwargs):
        pass
    
    
    def find(*args, **kwargs):
        pass
    
    
    def findClosest(*args, **kwargs):
        pass
    
    
    def getTangent(*args, **kwargs):
        pass
    
    
    def inTangentType(*args, **kwargs):
        pass
    
    
    def isBreakdown(*args, **kwargs):
        pass
    
    
    def isStatic(*args, **kwargs):
        pass
    
    
    def isTimeInput(*args, **kwargs):
        pass
    
    
    def isUnitlessInput(*args, **kwargs):
        pass
    
    
    def isWeighted(*args, **kwargs):
        pass
    
    
    def numKeyframes(*args, **kwargs):
        pass
    
    
    def numKeys(*args, **kwargs):
        pass
    
    
    def outTangentType(*args, **kwargs):
        pass
    
    
    def postInfinityType(*args, **kwargs):
        pass
    
    
    def preInfinityType(*args, **kwargs):
        pass
    
    
    def remove(*args, **kwargs):
        pass
    
    
    def setAngle(*args, **kwargs):
        pass
    
    
    def setInTangentType(*args, **kwargs):
        pass
    
    
    def setIsBreakdown(*args, **kwargs):
        pass
    
    
    def setIsWeighted(*args, **kwargs):
        pass
    
    
    def setOutTangentType(*args, **kwargs):
        pass
    
    
    def setPostInfinityType(*args, **kwargs):
        pass
    
    
    def setPreInfinityType(*args, **kwargs):
        pass
    
    
    def setTangent(*args, **kwargs):
        pass
    
    
    def setTangentTypes(*args, **kwargs):
        pass
    
    
    def setTangentsLocked(*args, **kwargs):
        pass
    
    
    def setTime(*args, **kwargs):
        pass
    
    
    def setUnitlessInput(*args, **kwargs):
        pass
    
    
    def setValue(*args, **kwargs):
        pass
    
    
    def setWeight(*args, **kwargs):
        pass
    
    
    def setWeightsLocked(*args, **kwargs):
        pass
    
    
    def tangentsLocked(*args, **kwargs):
        pass
    
    
    def time(*args, **kwargs):
        pass
    
    
    def timedAnimCurveTypeForPlug(*args, **kwargs):
        pass
    
    
    def unitlessAnimCurveTypeForPlug(*args, **kwargs):
        pass
    
    
    def unitlessInput(*args, **kwargs):
        pass
    
    
    def value(*args, **kwargs):
        pass
    
    
    def weightsLocked(*args, **kwargs):
        pass
    
    
    def className(*args, **kwargs):
        pass
    
    
    thisown = None
    
    __swig_destroy__ = None
    
    
    kAnimCurveTA = 0
    
    
    kAnimCurveTL = 1
    
    
    kAnimCurveTT = 2
    
    
    kAnimCurveTU = 3
    
    
    kAnimCurveUA = 4
    
    
    kAnimCurveUL = 5
    
    
    kAnimCurveUT = 6
    
    
    kAnimCurveUU = 7
    
    
    kAnimCurveUnknown = 8
    
    
    kConstant = 0
    
    
    kCycle = 3
    
    
    kCycleRelative = 4
    
    
    kLinear = 1
    
    
    kOscillate = 5
    
    
    kTangentAuto = 11
    
    
    kTangentClamped = 8
    
    
    kTangentCustomEnd = 32767
    
    
    kTangentCustomStart = 64
    
    
    kTangentFast = 7
    
    
    kTangentFixed = 1
    
    
    kTangentFlat = 3
    
    
    kTangentGlobal = 0
    
    
    kTangentLinear = 2
    
    
    kTangentPlateau = 9
    
    
    kTangentShared1 = 19
    
    
    kTangentShared2 = 20
    
    
    kTangentShared3 = 21
    
    
    kTangentShared4 = 22
    
    
    kTangentShared5 = 23
    
    
    kTangentShared6 = 24
    
    
    kTangentShared7 = 25
    
    
    kTangentShared8 = 26
    
    
    kTangentSlow = 6
    
    
    kTangentSmooth = 4
    
    
    kTangentStep = 5
    
    
    kTangentStepNext = 10
    
    
    kTangentTypeCount = 32768


class MFnIkSolver(OpenMaya.MFnDependencyNode):
    def __init__(self, *args):
        pass
    
    
    def __repr__(self):
        pass
    
    
    def maxIterations(*args, **kwargs):
        pass
    
    
    def setMaxIterations(*args, **kwargs):
        pass
    
    
    def setTolerance(*args, **kwargs):
        pass
    
    
    def tolerance(*args, **kwargs):
        pass
    
    
    def className(*args, **kwargs):
        pass
    
    
    thisown = None
    
    __swig_destroy__ = None


class MAnimUtil(_object):
    def __init__(self, *args):
        pass
    
    
    def __repr__(self):
        pass
    
    
    def className(*args, **kwargs):
        pass
    
    
    def findAnimatablePlugs(*args, **kwargs):
        pass
    
    
    def findAnimatedPlugs(*args, **kwargs):
        pass
    
    
    def findAnimation(*args, **kwargs):
        pass
    
    
    def findAnimationLayers(*args, **kwargs):
        pass
    
    
    def findConstraint(*args, **kwargs):
        pass
    
    
    def findSetDrivenKeyAnimation(*args, **kwargs):
        pass
    
    
    def isAnimated(*args, **kwargs):
        pass
    
    
    __dict__ = None
    
    __weakref__ = None
    
    thisown = None


class MFnIkHandle(OpenMaya.MFnTransform):
    def __init__(self, *args):
        pass
    
    
    def __repr__(self):
        pass
    
    
    def create(*args, **kwargs):
        pass
    
    
    def getEffector(*args, **kwargs):
        pass
    
    
    def getStartJoint(*args, **kwargs):
        pass
    
    
    def poWeight(*args, **kwargs):
        pass
    
    
    def priority(*args, **kwargs):
        pass
    
    
    def setEffector(*args, **kwargs):
        pass
    
    
    def setPOWeight(*args, **kwargs):
        pass
    
    
    def setPriority(*args, **kwargs):
        pass
    
    
    def setSolver(*args, **kwargs):
        pass
    
    
    def setStartJoint(*args, **kwargs):
        pass
    
    
    def setStartJointAndEffector(*args, **kwargs):
        pass
    
    
    def setStickiness(*args, **kwargs):
        pass
    
    
    def setWeight(*args, **kwargs):
        pass
    
    
    def solver(*args, **kwargs):
        pass
    
    
    def stickiness(*args, **kwargs):
        pass
    
    
    def weight(*args, **kwargs):
        pass
    
    
    def className(*args, **kwargs):
        pass
    
    
    thisown = None
    
    __swig_destroy__ = None
    
    
    kStickyOff = 0
    
    
    kStickyOn = 1
    
    
    kSuperSticky = 2


class MIkHandleGroup(_object):
    def __init__(self, *args):
        pass
    
    
    def __repr__(self):
        pass
    
    
    def checkEffectorAtGoal(*args, **kwargs):
        pass
    
    
    def dofCount(*args, **kwargs):
        pass
    
    
    def handle(*args, **kwargs):
        pass
    
    
    def handleCount(*args, **kwargs):
        pass
    
    
    def priority(*args, **kwargs):
        pass
    
    
    def setPriority(*args, **kwargs):
        pass
    
    
    def setSolverID(*args, **kwargs):
        pass
    
    
    def solve(*args, **kwargs):
        pass
    
    
    def solverID(*args, **kwargs):
        pass
    
    
    def solverPriority(*args, **kwargs):
        pass
    
    
    def className(*args, **kwargs):
        pass
    
    
    __dict__ = None
    
    __weakref__ = None
    
    thisown = None
    
    __swig_destroy__ = None


class MFnHikEffector(OpenMaya.MFnTransform):
    def __init__(self, *args):
        pass
    
    
    def __repr__(self):
        pass
    
    
    def create(*args, **kwargs):
        pass
    
    
    def getAuxiliaryEffectors(*args, **kwargs):
        pass
    
    
    def getEffColor(*args, **kwargs):
        pass
    
    
    def getPivotOffset(*args, **kwargs):
        pass
    
    
    def setEffColor(*args, **kwargs):
        pass
    
    
    def setPivotOffset(*args, **kwargs):
        pass
    
    
    def className(*args, **kwargs):
        pass
    
    
    thisown = None
    
    __swig_destroy__ = None


class MAnimMessage(OpenMaya.MMessage):
    def __init__(self, *args):
        pass
    
    
    def __repr__(self):
        pass
    
    
    def addAnimCurveEditedCallback(*args, **kwargs):
        pass
    
    
    def addAnimKeyframeEditCheckCallback(*args, **kwargs):
        pass
    
    
    def addAnimKeyframeEditedCallback(*args, **kwargs):
        pass
    
    
    def addDisableImplicitControlCallback(*args, **kwargs):
        pass
    
    
    def addNodeAnimKeyframeEditedCallback(*args, **kwargs):
        pass
    
    
    def addPostBakeResultsCallback(*args, **kwargs):
        pass
    
    
    def addPreBakeResultsCallback(*args, **kwargs):
        pass
    
    
    def className(*args, **kwargs):
        pass
    
    
    def flushAnimKeyframeEditedCallbacks(*args, **kwargs):
        pass
    
    
    thisown = None
    
    __swig_destroy__ = None


class MFnClip(OpenMaya.MFnDependencyNode):
    def __init__(self, *args):
        pass
    
    
    def __repr__(self):
        pass
    
    
    def createInstancedClip(*args, **kwargs):
        pass
    
    
    def createSourceClip(*args, **kwargs):
        pass
    
    
    def getAbsolute(*args, **kwargs):
        pass
    
    
    def getAbsoluteChannelSettings(*args, **kwargs):
        pass
    
    
    def getCycle(*args, **kwargs):
        pass
    
    
    def getEnabled(*args, **kwargs):
        pass
    
    
    def getMemberAnimCurves(*args, **kwargs):
        pass
    
    
    def getPostCycle(*args, **kwargs):
        pass
    
    
    def getPreCycle(*args, **kwargs):
        pass
    
    
    def getScale(*args, **kwargs):
        pass
    
    
    def getSourceDuration(*args, **kwargs):
        pass
    
    
    def getSourceStart(*args, **kwargs):
        pass
    
    
    def getStartFrame(*args, **kwargs):
        pass
    
    
    def getTrack(*args, **kwargs):
        pass
    
    
    def getWeight(*args, **kwargs):
        pass
    
    
    def isInstancedClip(*args, **kwargs):
        pass
    
    
    def isPose(*args, **kwargs):
        pass
    
    
    def setAbsolute(*args, **kwargs):
        pass
    
    
    def setAbsoluteChannelSettings(*args, **kwargs):
        pass
    
    
    def setCycle(*args, **kwargs):
        pass
    
    
    def setEnabled(*args, **kwargs):
        pass
    
    
    def setPoseClip(*args, **kwargs):
        pass
    
    
    def setPostCycle(*args, **kwargs):
        pass
    
    
    def setPreCycle(*args, **kwargs):
        pass
    
    
    def setScale(*args, **kwargs):
        pass
    
    
    def setSourceData(*args, **kwargs):
        pass
    
    
    def setStartFrame(*args, **kwargs):
        pass
    
    
    def setTrack(*args, **kwargs):
        pass
    
    
    def setWeight(*args, **kwargs):
        pass
    
    
    def sourceClip(*args, **kwargs):
        pass
    
    
    def className(*args, **kwargs):
        pass
    
    
    thisown = None
    
    __swig_destroy__ = None


class MAnimCurveClipboardItemArray(_object):
    def __getitem__(*args, **kwargs):
        pass
    
    
    def __init__(self, *args):
        pass
    
    
    def __repr__(self):
        pass
    
    
    def append(*args, **kwargs):
        pass
    
    
    def assign(*args, **kwargs):
        pass
    
    
    def clear(*args, **kwargs):
        pass
    
    
    def copy(*args, **kwargs):
        pass
    
    
    def insert(*args, **kwargs):
        pass
    
    
    def isValid(*args, **kwargs):
        pass
    
    
    def length(*args, **kwargs):
        pass
    
    
    def remove(*args, **kwargs):
        pass
    
    
    def set(*args, **kwargs):
        pass
    
    
    def setLength(*args, **kwargs):
        pass
    
    
    def setSizeIncrement(*args, **kwargs):
        pass
    
    
    def sizeIncrement(*args, **kwargs):
        pass
    
    
    def className(*args, **kwargs):
        pass
    
    
    __dict__ = None
    
    __weakref__ = None
    
    thisown = None
    
    __swig_destroy__ = None


class MFnMotionPath(OpenMaya.MFnDependencyNode):
    def __init__(self, *args):
        pass
    
    
    def __repr__(self):
        pass
    
    
    def addAnimatedObject(*args, **kwargs):
        pass
    
    
    def bank(*args, **kwargs):
        pass
    
    
    def bankScale(*args, **kwargs):
        pass
    
    
    def bankThreshold(*args, **kwargs):
        pass
    
    
    def create(*args, **kwargs):
        pass
    
    
    def follow(*args, **kwargs):
        pass
    
    
    def followAxis(*args, **kwargs):
        pass
    
    
    def getAnimatedObjects(*args, **kwargs):
        pass
    
    
    def getOrientationMarker(*args, **kwargs):
        pass
    
    
    def getPositionMarker(*args, **kwargs):
        pass
    
    
    def inverseNormal(*args, **kwargs):
        pass
    
    
    def numOrientationMarkers(*args, **kwargs):
        pass
    
    
    def numPositionMarkers(*args, **kwargs):
        pass
    
    
    def pathObject(*args, **kwargs):
        pass
    
    
    def setBank(*args, **kwargs):
        pass
    
    
    def setBankScale(*args, **kwargs):
        pass
    
    
    def setBankThreshold(*args, **kwargs):
        pass
    
    
    def setFollow(*args, **kwargs):
        pass
    
    
    def setFollowAxis(*args, **kwargs):
        pass
    
    
    def setInverseNormal(*args, **kwargs):
        pass
    
    
    def setPathObject(*args, **kwargs):
        pass
    
    
    def setUEnd(*args, **kwargs):
        pass
    
    
    def setUStart(*args, **kwargs):
        pass
    
    
    def setUTimeEnd(*args, **kwargs):
        pass
    
    
    def setUTimeStart(*args, **kwargs):
        pass
    
    
    def setUpAxis(*args, **kwargs):
        pass
    
    
    def setUseNormal(*args, **kwargs):
        pass
    
    
    def uEnd(*args, **kwargs):
        pass
    
    
    def uStart(*args, **kwargs):
        pass
    
    
    def uTimeEnd(*args, **kwargs):
        pass
    
    
    def uTimeStart(*args, **kwargs):
        pass
    
    
    def upAxis(*args, **kwargs):
        pass
    
    
    def useNormal(*args, **kwargs):
        pass
    
    
    def className(*args, **kwargs):
        pass
    
    
    thisown = None
    
    __swig_destroy__ = None
    
    
    kXaxis = 0
    
    
    kYaxis = 1
    
    
    kZaxis = 2


class MFnBlendShapeDeformer(OpenMaya.MFnDependencyNode):
    def __init__(self, *args):
        pass
    
    
    def __repr__(self):
        pass
    
    
    def addBaseObject(*args, **kwargs):
        pass
    
    
    def addTarget(*args, **kwargs):
        pass
    
    
    def create(*args, **kwargs):
        pass
    
    
    def envelope(*args, **kwargs):
        pass
    
    
    def getBaseObjects(*args, **kwargs):
        pass
    
    
    def getTargets(*args, **kwargs):
        pass
    
    
    def historyLocation(*args, **kwargs):
        pass
    
    
    def numWeights(*args, **kwargs):
        pass
    
    
    def origin(*args, **kwargs):
        pass
    
    
    def removeTarget(*args, **kwargs):
        pass
    
    
    def setEnvelope(*args, **kwargs):
        pass
    
    
    def setOrigin(*args, **kwargs):
        pass
    
    
    def setWeight(*args, **kwargs):
        pass
    
    
    def targetItemIndexList(*args, **kwargs):
        pass
    
    
    def weight(*args, **kwargs):
        pass
    
    
    def weightIndexList(*args, **kwargs):
        pass
    
    
    def className(*args, **kwargs):
        pass
    
    
    thisown = None
    
    __swig_destroy__ = None
    
    
    kFrontOfChain = 0
    
    
    kLocalOrigin = 0
    
    
    kNormal = 1
    
    
    kObject = 0
    
    
    kOther = 3
    
    
    kPost = 2
    
    
    kTangent = 1
    
    
    kWorldOrigin = 1


class MAnimCurveChange(_object):
    def __init__(self, *args):
        pass
    
    
    def __repr__(self):
        pass
    
    
    def isInteractive(*args, **kwargs):
        pass
    
    
    def redoIt(*args, **kwargs):
        pass
    
    
    def setInteractive(*args, **kwargs):
        pass
    
    
    def undoIt(*args, **kwargs):
        pass
    
    
    def className(*args, **kwargs):
        pass
    
    
    __dict__ = None
    
    __weakref__ = None
    
    thisown = None
    
    __swig_destroy__ = None


class MFnLatticeDeformer(OpenMaya.MFnDependencyNode):
    def __init__(self, *args):
        pass
    
    
    def __repr__(self):
        pass
    
    
    def addGeometry(*args, **kwargs):
        pass
    
    
    def baseLattice(*args, **kwargs):
        pass
    
    
    def create(*args, **kwargs):
        pass
    
    
    def deformLattice(*args, **kwargs):
        pass
    
    
    def getAffectedGeometry(*args, **kwargs):
        pass
    
    
    def getDivisions(*args, **kwargs):
        pass
    
    
    def removeGeometry(*args, **kwargs):
        pass
    
    
    def resetLattice(*args, **kwargs):
        pass
    
    
    def setDivisions(*args, **kwargs):
        pass
    
    
    def className(*args, **kwargs):
        pass
    
    
    thisown = None
    
    __swig_destroy__ = None


class MItKeyframe(_object):
    def __init__(self, *args):
        pass
    
    
    def __repr__(self):
        pass
    
    
    def getTangentIn(*args, **kwargs):
        pass
    
    
    def getTangentOut(*args, **kwargs):
        pass
    
    
    def inTangentType(*args, **kwargs):
        pass
    
    
    def isDone(*args, **kwargs):
        pass
    
    
    def next(*args, **kwargs):
        pass
    
    
    def outTangentType(*args, **kwargs):
        pass
    
    
    def reset(*args, **kwargs):
        pass
    
    
    def setInTangentType(*args, **kwargs):
        pass
    
    
    def setOutTangentType(*args, **kwargs):
        pass
    
    
    def setTangentsLocked(*args, **kwargs):
        pass
    
    
    def setTime(*args, **kwargs):
        pass
    
    
    def setValue(*args, **kwargs):
        pass
    
    
    def tangentsLocked(*args, **kwargs):
        pass
    
    
    def time(*args, **kwargs):
        pass
    
    
    def value(*args, **kwargs):
        pass
    
    
    def className(*args, **kwargs):
        pass
    
    
    __dict__ = None
    
    __weakref__ = None
    
    thisown = None
    
    __swig_destroy__ = None
    
    
    kTangentAuto = 11
    
    
    kTangentClamped = 8
    
    
    kTangentFast = 7
    
    
    kTangentFixed = 1
    
    
    kTangentFlat = 3
    
    
    kTangentGlobal = 0
    
    
    kTangentLinear = 2
    
    
    kTangentPlateau = 9
    
    
    kTangentSlow = 6
    
    
    kTangentSmooth = 4
    
    
    kTangentStep = 5
    
    
    kTangentStepNext = 10


class MFnKeyframeDelta(OpenMaya.MFnBase):
    def __init__(self, *args):
        pass
    
    
    def __repr__(self):
        pass
    
    
    def keyIndex(*args, **kwargs):
        pass
    
    
    def paramCurve(*args, **kwargs):
        pass
    
    
    def className(*args, **kwargs):
        pass
    
    
    thisown = None
    
    __swig_destroy__ = None


class MAnimControl(_object):
    def __init__(self, *args):
        pass
    
    
    def __repr__(self):
        pass
    
    
    def animationEndTime(*args, **kwargs):
        pass
    
    
    def animationStartTime(*args, **kwargs):
        pass
    
    
    def autoKeyMode(*args, **kwargs):
        pass
    
    
    def currentTime(*args, **kwargs):
        pass
    
    
    def globalInTangentType(*args, **kwargs):
        pass
    
    
    def globalOutTangentType(*args, **kwargs):
        pass
    
    
    def isPlaying(*args, **kwargs):
        pass
    
    
    def isScrubbing(*args, **kwargs):
        pass
    
    
    def maxTime(*args, **kwargs):
        pass
    
    
    def minTime(*args, **kwargs):
        pass
    
    
    def playBackward(*args, **kwargs):
        pass
    
    
    def playForward(*args, **kwargs):
        pass
    
    
    def playbackBy(*args, **kwargs):
        pass
    
    
    def playbackMode(*args, **kwargs):
        pass
    
    
    def playbackSpeed(*args, **kwargs):
        pass
    
    
    def setAnimationEndTime(*args, **kwargs):
        pass
    
    
    def setAnimationStartEndTime(*args, **kwargs):
        pass
    
    
    def setAnimationStartTime(*args, **kwargs):
        pass
    
    
    def setAutoKeyMode(*args, **kwargs):
        pass
    
    
    def setCurrentTime(*args, **kwargs):
        pass
    
    
    def setGlobalInTangentType(*args, **kwargs):
        pass
    
    
    def setGlobalOutTangentType(*args, **kwargs):
        pass
    
    
    def setMaxTime(*args, **kwargs):
        pass
    
    
    def setMinMaxTime(*args, **kwargs):
        pass
    
    
    def setMinTime(*args, **kwargs):
        pass
    
    
    def setPlaybackBy(*args, **kwargs):
        pass
    
    
    def setPlaybackMode(*args, **kwargs):
        pass
    
    
    def setPlaybackSpeed(*args, **kwargs):
        pass
    
    
    def setViewMode(*args, **kwargs):
        pass
    
    
    def setWeightedTangents(*args, **kwargs):
        pass
    
    
    def stop(*args, **kwargs):
        pass
    
    
    def viewMode(*args, **kwargs):
        pass
    
    
    def weightedTangents(*args, **kwargs):
        pass
    
    
    __dict__ = None
    
    __weakref__ = None
    
    thisown = None
    
    __swig_destroy__ = None
    
    
    kPlaybackLoop = 1
    
    
    kPlaybackOnce = 0
    
    
    kPlaybackOscillate = 2
    
    
    kPlaybackViewActive = 1
    
    
    kPlaybackViewAll = 0


class MFnKeyframeDeltaInfType(MFnKeyframeDelta):
    def __init__(self, *args):
        pass
    
    
    def __repr__(self):
        pass
    
    
    def currentInfinityType(*args, **kwargs):
        pass
    
    
    def isPreInfinity(*args, **kwargs):
        pass
    
    
    def previousInfinityType(*args, **kwargs):
        pass
    
    
    def className(*args, **kwargs):
        pass
    
    
    thisown = None
    
    __swig_destroy__ = None


class MFnKeyframeDeltaBreakdown(MFnKeyframeDelta):
    def __init__(self, *args):
        pass
    
    
    def __repr__(self):
        pass
    
    
    def isBreakdown(*args, **kwargs):
        pass
    
    
    def wasBreakdown(*args, **kwargs):
        pass
    
    
    def className(*args, **kwargs):
        pass
    
    
    thisown = None
    
    __swig_destroy__ = None


class MFnWeightGeometryFilter(MFnGeometryFilter):
    def __init__(self, *args):
        pass
    
    
    def __repr__(self):
        pass
    
    
    def getWeightPlugStrings(*args, **kwargs):
        pass
    
    
    def getWeights(*args, **kwargs):
        pass
    
    
    def setWeight(*args, **kwargs):
        pass
    
    
    def weightPlugStrings(*args, **kwargs):
        pass
    
    
    def className(*args, **kwargs):
        pass
    
    
    thisown = None
    
    __swig_destroy__ = None


class MFnSkinCluster(MFnGeometryFilter):
    def __init__(self, *args):
        pass
    
    
    def __repr__(self):
        pass
    
    
    def getBlendWeights(*args, **kwargs):
        pass
    
    
    def getPointsAffectedByInfluence(*args, **kwargs):
        pass
    
    
    def getWeights(*args, **kwargs):
        pass
    
    
    def indexForInfluenceObject(*args, **kwargs):
        pass
    
    
    def influenceObjects(*args, **kwargs):
        pass
    
    
    def setBlendWeights(*args, **kwargs):
        pass
    
    
    def setWeights(*args, **kwargs):
        pass
    
    
    def className(*args, **kwargs):
        pass
    
    
    thisown = None
    
    __swig_destroy__ = None


class MFnKeyframeDeltaBlockAddRemove(MFnKeyframeDelta):
    def __init__(self, *args):
        pass
    
    
    def __repr__(self):
        pass
    
    
    def deltaType(*args, **kwargs):
        pass
    
    
    def endTime(*args, **kwargs):
        pass
    
    
    def getTimes(*args, **kwargs):
        pass
    
    
    def getValues(*args, **kwargs):
        pass
    
    
    def numKeys(*args, **kwargs):
        pass
    
    
    def startTime(*args, **kwargs):
        pass
    
    
    def className(*args, **kwargs):
        pass
    
    
    thisown = None
    
    __swig_destroy__ = None
    
    
    kAdded = 0
    
    
    kRemoved = 1


class MFnKeyframeDeltaWeighted(MFnKeyframeDelta):
    def __init__(self, *args):
        pass
    
    
    def __repr__(self):
        pass
    
    
    def wasWeighted(*args, **kwargs):
        pass
    
    
    def className(*args, **kwargs):
        pass
    
    
    thisown = None
    
    __swig_destroy__ = None


class MFnKeyframeDeltaAddRemove(MFnKeyframeDelta):
    def __init__(self, *args):
        pass
    
    
    def __repr__(self):
        pass
    
    
    def deltaType(*args, **kwargs):
        pass
    
    
    def replacedValue(*args, **kwargs):
        pass
    
    
    def time(*args, **kwargs):
        pass
    
    
    def value(*args, **kwargs):
        pass
    
    
    def className(*args, **kwargs):
        pass
    
    
    thisown = None
    
    __swig_destroy__ = None
    
    
    kAdded = 0
    
    
    kRemoved = 1
    
    
    kReplaced = 2


class MFnKeyframeDeltaTangent(MFnKeyframeDelta):
    def __init__(self, *args):
        pass
    
    
    def __repr__(self):
        pass
    
    
    def currentTangentType(*args, **kwargs):
        pass
    
    
    def getCurrentPosition(*args, **kwargs):
        pass
    
    
    def getPreviousPosition(*args, **kwargs):
        pass
    
    
    def isInTangent(*args, **kwargs):
        pass
    
    
    def previousTangentType(*args, **kwargs):
        pass
    
    
    def className(*args, **kwargs):
        pass
    
    
    thisown = None
    
    __swig_destroy__ = None


class MFnKeyframeDeltaScale(MFnKeyframeDelta):
    def __init__(self, *args):
        pass
    
    
    def __repr__(self):
        pass
    
    
    def currentEndTime(*args, **kwargs):
        pass
    
    
    def currentStartTime(*args, **kwargs):
        pass
    
    
    def endTime(*args, **kwargs):
        pass
    
    
    def pivotTime(*args, **kwargs):
        pass
    
    
    def startTime(*args, **kwargs):
        pass
    
    
    def className(*args, **kwargs):
        pass
    
    
    thisown = None
    
    __swig_destroy__ = None


class MFnKeyframeDeltaMove(MFnKeyframeDelta):
    def __init__(self, *args):
        pass
    
    
    def __repr__(self):
        pass
    
    
    def currentTime(*args, **kwargs):
        pass
    
    
    def currentValue(*args, **kwargs):
        pass
    
    
    def previousIndex(*args, **kwargs):
        pass
    
    
    def previousTime(*args, **kwargs):
        pass
    
    
    def previousValue(*args, **kwargs):
        pass
    
    
    def className(*args, **kwargs):
        pass
    
    
    thisown = None
    
    __swig_destroy__ = None



def MAnimControl_autoKeyMode(*args, **kwargs):
    pass


def MAnimUtil_swigregister(*args, **kwargs):
    pass


def MFnCharacter_className(*args, **kwargs):
    pass


def MFnIkHandle_className(*args, **kwargs):
    pass


def MAnimControl_animationEndTime(*args, **kwargs):
    pass


def MFnIkHandle_swigregister(*args, **kwargs):
    pass


def MIkSystem_isGlobalSnap(*args, **kwargs):
    pass


def MAnimUtil_findAnimationLayers(*args, **kwargs):
    pass


def MFnKeyframeDelta_className(*args, **kwargs):
    pass


def MFnIkEffector_className(*args, **kwargs):
    pass


def MFnIkEffector_swigregister(*args, **kwargs):
    pass


def MAnimMessage_addPostBakeResultsCallback(*args, **kwargs):
    pass


def MFnLattice_className(*args, **kwargs):
    pass


def MFnGeometryFilter_swigregister(*args, **kwargs):
    pass


def MAnimControl_setAnimationStartTime(*args, **kwargs):
    pass


def MAnimControl_setAutoKeyMode(*args, **kwargs):
    pass


def MAnimControl_setPlaybackSpeed(*args, **kwargs):
    pass


def MIkSystem_className(*args, **kwargs):
    pass


def MIkHandleGroup_swigregister(*args, **kwargs):
    pass


def MAnimControl_setViewMode(*args, **kwargs):
    pass


def MFnKeyframeDeltaBlockAddRemove_swigregister(*args, **kwargs):
    pass


def MAnimControl_setPlaybackMode(*args, **kwargs):
    pass


def weakref_proxy(*args, **kwargs):
    """
    proxy(object[, callback]) -- create a proxy object that weakly
    references 'object'.  'callback', if given, is called with a
    reference to the proxy when 'object' is about to be finalized.
    """

    pass


def MAnimCurveClipboard_swigregister(*args, **kwargs):
    pass


def MAnimControl_minTime(*args, **kwargs):
    pass


def MAnimControl_swigregister(*args, **kwargs):
    pass


def MAnimUtil_isAnimated(*args, **kwargs):
    pass


def MFnKeyframeDeltaMove_swigregister(*args, **kwargs):
    pass


def MAnimMessage_addDisableImplicitControlCallback(*args, **kwargs):
    pass


def MAnimUtil_findAnimatedPlugs(*args, **kwargs):
    pass


def _swig_setattr_nondynamic_method(set):
    pass


def MFnWireDeformer_className(*args, **kwargs):
    pass


def MAnimControl_globalInTangentType(*args, **kwargs):
    pass


def MFnCharacter_swigregister(*args, **kwargs):
    pass


def MIkSystem_setGlobalSnap(*args, **kwargs):
    pass


def MAnimControl_playForward(*args, **kwargs):
    pass


def MFnLattice_swigregister(*args, **kwargs):
    pass


def MAnimUtil_className(*args, **kwargs):
    pass


def MAnimControl_setAnimationEndTime(*args, **kwargs):
    pass


def MFnBlendShapeDeformer_swigregister(*args, **kwargs):
    pass


def MAnimControl_maxTime(*args, **kwargs):
    pass


def MAnimCurveChange_swigregister(*args, **kwargs):
    pass


def MFnKeyframeDeltaMove_className(*args, **kwargs):
    pass


def MAnimControl_viewMode(*args, **kwargs):
    pass


def MAnimCurveChange_className(*args, **kwargs):
    pass


def MFnSkinCluster_swigregister(*args, **kwargs):
    pass


def MFnAnimCurve_swigregister(*args, **kwargs):
    pass


def MFnIkSolver_className(*args, **kwargs):
    pass


def MAnimMessage_flushAnimKeyframeEditedCallbacks(*args, **kwargs):
    pass


def _swig_setattr_nondynamic(self, class_type, name, value, static=1):
    pass


def MFnKeyframeDeltaAddRemove_className(*args, **kwargs):
    pass


def MAnimMessage_addAnimCurveEditedCallback(*args, **kwargs):
    pass


def MFnKeyframeDeltaBlockAddRemove_className(*args, **kwargs):
    pass


def MFnKeyframeDeltaScale_swigregister(*args, **kwargs):
    pass


def MFnIkSolver_swigregister(*args, **kwargs):
    pass


def MAnimControl_setGlobalInTangentType(*args, **kwargs):
    pass


def MFnKeyframeDeltaInfType_className(*args, **kwargs):
    pass


def MFnKeyframeDeltaTangent_className(*args, **kwargs):
    pass


def _swig_setattr(self, class_type, name, value):
    pass


def MAnimControl_playBackward(*args, **kwargs):
    pass


def MFnLatticeDeformer_swigregister(*args, **kwargs):
    pass


def MAnimControl_setPlaybackBy(*args, **kwargs):
    pass


def MFnWeightGeometryFilter_className(*args, **kwargs):
    pass


def _swig_getattr(self, class_type, name):
    pass


def MFnGeometryFilter_className(*args, **kwargs):
    pass


def MAnimControl_setMinTime(*args, **kwargs):
    pass


def MAnimCurveClipboardItem_swigregister(*args, **kwargs):
    pass


def MAnimMessage_addAnimKeyframeEditedCallback(*args, **kwargs):
    pass


def MAnimCurveClipboardItemArray_swigregister(*args, **kwargs):
    pass


def _swig_repr(self):
    pass


def MIkSystem_isGlobalSolve(*args, **kwargs):
    pass


def MAnimUtil_findAnimation(*args, **kwargs):
    pass


def MAnimMessage_className(*args, **kwargs):
    pass


def MFnMotionPath_className(*args, **kwargs):
    pass


def MFnKeyframeDeltaInfType_swigregister(*args, **kwargs):
    pass


def MFnHikEffector_className(*args, **kwargs):
    pass


def MFnKeyframeDeltaWeighted_swigregister(*args, **kwargs):
    pass


def MFnWireDeformer_swigregister(*args, **kwargs):
    pass


def MAnimControl_globalOutTangentType(*args, **kwargs):
    pass


def MAnimControl_isPlaying(*args, **kwargs):
    pass


def MFnSkinCluster_className(*args, **kwargs):
    pass


def MFnKeyframeDeltaScale_className(*args, **kwargs):
    pass


def MFnWeightGeometryFilter_swigregister(*args, **kwargs):
    pass


def MAnimCurveClipboardItemArray_className(*args, **kwargs):
    pass


def MIkSystem_findSolver(*args, **kwargs):
    pass


def MItKeyframe_className(*args, **kwargs):
    pass


def MAnimControl_setMaxTime(*args, **kwargs):
    pass


def MIkSystem_swigregister(*args, **kwargs):
    pass


def MIkSystem_getSolvers(*args, **kwargs):
    pass


def MFnIkJoint_swigregister(*args, **kwargs):
    pass


def MItKeyframe_swigregister(*args, **kwargs):
    pass


def MAnimUtil_findSetDrivenKeyAnimation(*args, **kwargs):
    pass


def MAnimControl_currentTime(*args, **kwargs):
    pass


def MFnClip_className(*args, **kwargs):
    pass


def MFnHikEffector_swigregister(*args, **kwargs):
    pass


def MFnKeyframeDeltaWeighted_className(*args, **kwargs):
    pass


def MAnimMessage_addNodeAnimKeyframeEditedCallback(*args, **kwargs):
    pass


def MAnimControl_setGlobalOutTangentType(*args, **kwargs):
    pass


def MAnimControl_isScrubbing(*args, **kwargs):
    pass


def MAnimMessage_swigregister(*args, **kwargs):
    pass


def MFnIkJoint_className(*args, **kwargs):
    pass


def MIkSystem_setGlobalSolve(*args, **kwargs):
    pass


def MFnKeyframeDeltaAddRemove_swigregister(*args, **kwargs):
    pass


def MAnimControl_setCurrentTime(*args, **kwargs):
    pass


def MAnimControl_setMinMaxTime(*args, **kwargs):
    pass


def MAnimControl_playbackMode(*args, **kwargs):
    pass


def MFnBlendShapeDeformer_className(*args, **kwargs):
    pass


def MAnimUtil_findConstraint(*args, **kwargs):
    pass


def MFnClip_swigregister(*args, **kwargs):
    pass


def MAnimControl_setAnimationStartEndTime(*args, **kwargs):
    pass


def MAnimMessage_addAnimKeyframeEditCheckCallback(*args, **kwargs):
    pass


def MAnimControl_weightedTangents(*args, **kwargs):
    pass


def MAnimControl_stop(*args, **kwargs):
    pass


def MFnKeyframeDeltaBreakdown_className(*args, **kwargs):
    pass


def MFnKeyframeDeltaBreakdown_swigregister(*args, **kwargs):
    pass


def MAnimControl_playbackSpeed(*args, **kwargs):
    pass


def MAnimControl_animationStartTime(*args, **kwargs):
    pass


def MAnimCurveClipboardItem_className(*args, **kwargs):
    pass


def MFnMotionPath_swigregister(*args, **kwargs):
    pass


def MFnAnimCurve_className(*args, **kwargs):
    pass


def MAnimUtil_findAnimatablePlugs(*args, **kwargs):
    pass


def MIkHandleGroup_className(*args, **kwargs):
    pass


def MAnimCurveClipboard_theAPIClipboard(*args, **kwargs):
    pass


def MAnimMessage_addPreBakeResultsCallback(*args, **kwargs):
    pass


def MAnimControl_playbackBy(*args, **kwargs):
    pass


def MFnKeyframeDelta_swigregister(*args, **kwargs):
    pass


def MAnimControl_setWeightedTangents(*args, **kwargs):
    pass


def MFnKeyframeDeltaTangent_swigregister(*args, **kwargs):
    pass


def MFnLatticeDeformer_className(*args, **kwargs):
    pass



_newclass = 1


