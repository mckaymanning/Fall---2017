def _setupQtDirectories():
    pass



__version__ = '2.0.0~alpha0'


