"""
# module: maya.app.gui
#
# This module is imported during the startup of Maya in GUI mode.
#
"""

