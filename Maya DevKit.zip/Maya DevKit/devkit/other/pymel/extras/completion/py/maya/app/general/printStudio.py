def exportFile():
    pass


def printStudioDownloadURL():
    pass


def printStudioInstalled():
    pass


def downloadPrintStudio(window, tabLayout, progressBar):
    """
    http://stackoverflow.com/questions/22676/how-do-i-download-a-file-over-http-using-python
    """

    pass


def getPrintStudioDialog():
    pass


def printStudio():
    pass



_platform = 'darwin'

downloadInfo = None

printStudioPath = downloadInfo

