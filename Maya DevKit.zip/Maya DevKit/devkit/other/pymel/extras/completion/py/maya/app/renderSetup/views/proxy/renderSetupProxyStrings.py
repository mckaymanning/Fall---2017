"""
# This file exists only to work around a localization script limitation.
# As of April 2016, the script requires that files with localized
# strings have unique names.
"""

kExpandCollapseAction = []

kDragAndDrop = []

kSetEnabledAction = []

kCreateRelativeOverrideAction = []

kNewFilter = []

kAbsoluteType = []

kCameras = []

kRenameAction = []

kNoOverride = []

kFilterAll = []

kCreateMaterialOverrideAction = []

kDragAndDropFailed = []

kFilterSets = []

kFilterTransforms = []

kRelativeType = []

kCreateAbsoluteOverrideAction = []

kDeleteAction = []

kOverrideWarningStr = []

kLights = []

kCreateConnectionOverrideAction = []

kFilterShaders = []

kSetRenderableAction = []

kFilterTransformsAndShapes = []

kSetVisibilityAction = []

kSelectionTypeError = []

kFilterGeometry = []

kRelative = []

kFilterCameras = []

kAOVs = []

kAbsolute = []

kFilterCustom = []

kFilterTransformsShapesShaders = []

kSetIsolateSelectedAction = []

kCreateShaderOverrideAction = []

kCollectionWarningStr = []

kFiltersMenu = []

kRenderLayerWarningStr = []

kRenderSettings = []

kFilterLights = []

kCreateCollectionAction = []


