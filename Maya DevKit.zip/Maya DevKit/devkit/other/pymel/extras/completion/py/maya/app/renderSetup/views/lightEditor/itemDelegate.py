from maya.app.renderSetup.views.lightEditor.itemModel import *

from copy import deepcopy

import PySide2.QtWidgets as _QtWidgets

class AttributeDelegate(_QtWidgets.QStyledItemDelegate):
    def __init__(self, treeView):
        pass
    
    
    def createEditor(self, parent, option, index):
        pass
    
    
    def editorEvent(self, event, model, option, index):
        pass
    
    
    def paint(self, painter, option, index):
        pass
    
    
    def setEditorData(self, editor, index):
        pass
    
    
    def setModelData(self, editor, model, index):
        pass
    
    
    def sizeHint(self, option, index):
        pass
    
    
    def updateEditorGeometry(self, editor, option, index):
        pass
    
    
    staticMetaObject = None


class ColumnDelegate(_QtWidgets.QStyledItemDelegate):
    def __init__(self):
        pass
    
    
    def createEditor(self, parent, option, index):
        pass
    
    
    def paint(self, painter, option, index):
        pass
    
    
    BOTTOM_GAP_OFFSET = 2.0
    
    
    DISABLED_BACKGROUND_IMAGE = None
    
    
    DISABLED_HIGHLIGHT_IMAGE = None
    
    
    staticMetaObject = None


class FloatFieldDelegate(ColumnDelegate):
    def __init__(self):
        pass
    
    
    def createEditor(self, parent, option, index):
        pass
    
    
    def paint(self, painter, option, index):
        pass
    
    
    def setEditorData(self, editor, index):
        pass
    
    
    def setModelData(self, editor, model, index):
        pass
    
    
    staticMetaObject = None


class ColorPickerDelegate(ColumnDelegate):
    def __init__(self):
        pass
    
    
    def createEditor(self, parent, option, index):
        pass
    
    
    def editorEvent(self, event, model, option, index):
        pass
    
    
    def paint(self, painter, option, index):
        pass
    
    
    staticMetaObject = None


class NameDelegate(ColumnDelegate):
    def __del__(self):
        pass
    
    
    def __init__(self, treeView):
        pass
    
    
    def createEditor(self, parent, option, index):
        pass
    
    
    def paint(self, painter, option, index):
        pass
    
    
    def setEditorData(self, editor, index):
        pass
    
    
    def setModelData(self, editor, model, index):
        pass
    
    
    def sizeHint(self, option, index):
        pass
    
    
    def updateEditorGeometry(self, editor, option, index):
        pass
    
    
    ARROW_COLOR = None
    
    
    COLLAPSED_ARROW = ()
    
    
    EXPANDED_ARROW = ()
    
    
    LIGHT_ICON_OFFSET = 4.0
    
    
    LIGHT_ICON_SIZE = 20.0
    
    
    staticMetaObject = None


class IntFieldDelegate(ColumnDelegate):
    def __init__(self):
        pass
    
    
    def createEditor(self, parent, option, index):
        pass
    
    
    def paint(self, painter, option, index):
        pass
    
    
    def setEditorData(self, editor, index):
        pass
    
    
    def setModelData(self, editor, model, index):
        pass
    
    
    staticMetaObject = None


class CheckBoxDelegate(ColumnDelegate):
    def __init__(self):
        pass
    
    
    def createEditor(self, parent, option, index):
        pass
    
    
    def editorEvent(self, event, model, option, index):
        pass
    
    
    def paint(self, painter, option, index):
        pass
    
    
    staticMetaObject = None


class AngleFieldDelegate(FloatFieldDelegate):
    def __init__(self):
        pass
    
    
    staticMetaObject = None



