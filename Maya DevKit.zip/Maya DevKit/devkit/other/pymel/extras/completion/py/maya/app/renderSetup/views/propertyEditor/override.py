from maya.app.renderSetup.views.propertyEditor.layout import *

from maya.app.general.mayaMixin import MayaQWidgetBaseMixin
from PySide2.QtWidgets import QGroupBox
from functools import partial
from PySide2.QtWidgets import QHBoxLayout
from PySide2.QtCore import QSize
from PySide2.QtCore import Signal
from PySide2.QtWidgets import QWidget
from PySide2.QtWidgets import QVBoxLayout
from PySide2.QtWidgets import QLineEdit

class Override(MayaQWidgetBaseMixin, QGroupBox):
    """
    This class represents the property editor view of an override.
    """
    
    
    
    def __init__(self, item, parent):
        pass
    
    
    def paintEvent(self, event):
        pass
    
    
    attributeDropped = None
    
    
    staticMetaObject = None



def getCppPointer(*args, **kwargs):
    pass



kInvalidAttribute = []

kDragAttributeFromAE = []

kLayer = []

kIncompatibleAttribute = []


