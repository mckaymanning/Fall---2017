from maya.app.renderSetup.views.renderSetupPreferences import addRenderSetupPreferences

def initialize(mplugin):
    pass


def uninitialize(mplugin):
    pass



commands = []


