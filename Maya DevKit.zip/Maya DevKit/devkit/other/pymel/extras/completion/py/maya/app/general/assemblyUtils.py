"""
#       Description:
#               Assembly-related utility routines.
#
"""

def isReferenceInAssembly(refNodeName):
    """
    Determines if the specified reference node is contained within an assembly.
    """

    pass



