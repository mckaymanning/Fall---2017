from PySide2.QtWidgets import *
from PySide2.QtGui import *

from posixpath import expanduser

def addPolyRemeshNodeType(typeTransform, typeExtruder, typeTool, typeMesh):
    pass


def addUVNodeToType(typeMesh, typeExtruder):
    pass


def connectTypeAdjustDeformer(typeMesh, typeTransform, typeExtruder, typeTool):
    pass


def createTypeTool():
    pass


def connectShellDeformer(typeMesh, typeTransform, typeExtruder, typeTool):
    pass


def showTheTypeTool(typeTool, typeTransform):
    pass



