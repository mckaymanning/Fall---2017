def delete_MRenderLine(*args, **kwargs):
    pass


def MnSolver_setStartTime(*args, **kwargs):
    pass


def MnParticle_setFriction(*args, **kwargs):
    pass


def MnCloth_setAddCrossLinks(*args, **kwargs):
    pass


def MFnParticleSystem_create(*args, **kwargs):
    pass


def MnCloth_getBounce(*args, **kwargs):
    pass


def MDynSweptLine_vertex(*args, **kwargs):
    pass


def MFnAirField_inheritRotation(*args, **kwargs):
    pass


def MFnAirField_inheritVelocity(*args, **kwargs):
    pass


def MDynamicsUtil_swiginit(*args, **kwargs):
    pass


def MFnAirField_className(*args, **kwargs):
    pass


def MnCloth_setInverseMass(*args, **kwargs):
    pass


def MFnAirField_setSpeed(*args, **kwargs):
    pass


def MnRigid_setCollisionFlags(*args, **kwargs):
    pass


def MnCloth_setTangentialDrag(*args, **kwargs):
    pass


def MnRigid_getFriction(*args, **kwargs):
    pass


def MnRigid_setPositions(*args, **kwargs):
    pass


def MnRigid_swiginit(*args, **kwargs):
    pass


def MFnParticleSystem_getPerParticleAttribute(*args, **kwargs):
    pass


def MnCloth_setMaxSelfCollisionIterations(*args, **kwargs):
    pass


def new_MnSolver(*args, **kwargs):
    pass


def MDynamicsUtil_evalDynamics2dTexture(*args, **kwargs):
    pass


def delete_MFnFluid(*args, **kwargs):
    pass


def MnParticle_setRestDensity(*args, **kwargs):
    pass


def MFnParticleSystem_particleName(*args, **kwargs):
    pass


def MFnNObjectData_swiginit(*args, **kwargs):
    pass


def MnCloth_setBendAngleScale(*args, **kwargs):
    pass


def new_MFnDynSweptGeometryData(*args, **kwargs):
    pass


def MFnInstancer_className(*args, **kwargs):
    pass


def MFnDragField_setDirection(*args, **kwargs):
    pass


def delete_MFnNObjectData(*args, **kwargs):
    pass


def MFnVolumeAxisField_speedAlongAxis(*args, **kwargs):
    pass


def MFnParticleSystem_castsShadows(*args, **kwargs):
    pass


def MFnParticleSystem_betterIllum(*args, **kwargs):
    pass


def MFnVolumeAxisField_turbulenceOffset(*args, **kwargs):
    pass


def MFnField_maxDistance(*args, **kwargs):
    pass


def MHairSystem_className(*args, **kwargs):
    pass


def MFnTurbulenceField_setFrequency(*args, **kwargs):
    pass


def MnCloth_setBounce(*args, **kwargs):
    pass


def delete_MFnVolumeAxisField(*args, **kwargs):
    pass


def MnSolver_removeAllCollisions(*args, **kwargs):
    pass


def MFnParticleSystem_swiginit(*args, **kwargs):
    pass


def MnCloth_setTopology(*args, **kwargs):
    pass


def MRenderLine_getTwist(*args, **kwargs):
    pass


def MFnParticleSystem_surfaceShading(*args, **kwargs):
    pass


def MnRigid_getInverseMass(*args, **kwargs):
    pass


def MnRigid_swigregister(*args, **kwargs):
    pass


def MnParticle_setVelocities(*args, **kwargs):
    pass


def MDynSweptLine_className(*args, **kwargs):
    pass


def MnObject_swigregister(*args, **kwargs):
    pass


def MnParticle_setThickness(*args, **kwargs):
    pass


def delete_MnCloth(*args, **kwargs):
    pass


def MFnNIdData_swiginit(*args, **kwargs):
    pass


def MFnNObjectData_setObjectPtr(*args, **kwargs):
    pass


def new_MFnFluid(*args, **kwargs):
    pass


def MFnParticleSystem_isValid(*args, **kwargs):
    pass


def MFnFluid_fuel(*args, **kwargs):
    pass


def MHairSystem_registeringCallableScript(*args, **kwargs):
    pass


def MnCloth_setDamping(*args, **kwargs):
    pass


def MFnVolumeAxisField_speedAwayFromAxis(*args, **kwargs):
    pass


def MFnVortexField_axis(*args, **kwargs):
    pass


def MFnField_isFalloffCurveConstantOne(*args, **kwargs):
    pass


def MnRigid_createNRigid(*args, **kwargs):
    pass


def MFnVolumeAxisField_detailTurbulence(*args, **kwargs):
    pass


def MnParticle_swigregister(*args, **kwargs):
    pass


def MFnVolumeAxisField_setInvertAttenuation(*args, **kwargs):
    pass


def new_MRenderLine(*args, **kwargs):
    pass


def MFnPfxGeometry_getBoundingBox(*args, **kwargs):
    pass


def MFnParticleSystem_flatShaded(*args, **kwargs):
    pass


def MFnParticleSystem_swigregister(*args, **kwargs):
    pass


def MnSolver_createNSolver(*args, **kwargs):
    pass


def MFnParticleSystem_visibleInRefractions(*args, **kwargs):
    pass


def MnParticle_setIncompressibility(*args, **kwargs):
    pass


def MnCloth_swiginit(*args, **kwargs):
    pass


def MnParticle_setSelfCollide(*args, **kwargs):
    pass


def MFnFluid_className(*args, **kwargs):
    pass


def MFnFluid_getCoordinateMode(*args, **kwargs):
    pass


def MFnGravityField_className(*args, **kwargs):
    pass


def MnCloth_setInputMeshAttractDamping(*args, **kwargs):
    pass


def MFnField_setMaxDistance(*args, **kwargs):
    pass


def delete_MDynSweptLine(*args, **kwargs):
    pass


def MFnVolumeAxisField_className(*args, **kwargs):
    pass


def MHairSystem_swiginit(*args, **kwargs):
    pass


def MFnVolumeAxisField_directionalSpeed(*args, **kwargs):
    pass


def delete_MDynSweptTriangle(*args, **kwargs):
    pass


def MnRigid_setBounce(*args, **kwargs):
    pass


def MnCloth_setTrackVolume(*args, **kwargs):
    pass


def MFnGravityField_swigregister(*args, **kwargs):
    pass


def MFnUniformField_swiginit(*args, **kwargs):
    pass


def MnSolver_swigregister(*args, **kwargs):
    pass


def MFnFluid_expandToInclude(*args, **kwargs):
    pass


def MFnRadialField_radialType(*args, **kwargs):
    pass


def MnSolver_setGravity(*args, **kwargs):
    pass


def MRenderLine_getWidth(*args, **kwargs):
    pass


def MFnParticleSystem_isDeformedParticleShape(*args, **kwargs):
    pass


def MFnVolumeAxisField_swigregister(*args, **kwargs):
    pass


def MnParticle_setCollide(*args, **kwargs):
    pass


def MFnTurbulenceField_phase(*args, **kwargs):
    pass


def MFnTurbulenceField_className(*args, **kwargs):
    pass


def MFnVolumeAxisField_turbulence(*args, **kwargs):
    pass


def MnParticle_setSurfaceTension(*args, **kwargs):
    pass


def MFnFluid_toGridIndex(*args, **kwargs):
    pass


def MDynSweptTriangle_normalToPoint(*args, **kwargs):
    pass


def MFnUniformField_swigregister(*args, **kwargs):
    pass


def new_MFnField(*args, **kwargs):
    pass


def MDynSweptTriangle_vertex(*args, **kwargs):
    pass


def MDynSweptTriangle_className(*args, **kwargs):
    pass


def MnCloth_setSelfCollisionFlags(*args, **kwargs):
    pass


def MHairSystem_swigregister(*args, **kwargs):
    pass


def MnCloth_setVelocities(*args, **kwargs):
    pass


def MFnPfxGeometry_swigregister(*args, **kwargs):
    pass


def MFnVolumeAxisField_setDirection(*args, **kwargs):
    pass


def MnSolver_swiginit(*args, **kwargs):
    pass


def MFnDragField_swigregister(*args, **kwargs):
    pass


def new_MFnInstancer(*args, **kwargs):
    pass


def MFnRadialField_swiginit(*args, **kwargs):
    pass


def MnCloth_setFriction(*args, **kwargs):
    pass


def MFnAirField_spread(*args, **kwargs):
    pass


def delete_MFnPfxGeometry(*args, **kwargs):
    pass


def MDynSweptLine_length(*args, **kwargs):
    pass


def MFnFluid_getVelocity(*args, **kwargs):
    pass


def MFnParticleSystem_position1(*args, **kwargs):
    pass


def MFnFluid_create3D(*args, **kwargs):
    pass


def MFnParticleSystem_renderType(*args, **kwargs):
    pass


def MFnFluid_getFuelMode(*args, **kwargs):
    pass


def MFnAirField_direction(*args, **kwargs):
    pass


def MDynSweptTriangle_uvPoint(*args, **kwargs):
    pass


def delete_MFnAirField(*args, **kwargs):
    pass


def MFnField_magnitude(*args, **kwargs):
    pass


def MnCloth_setInputMeshAttractPositions(*args, **kwargs):
    pass


def new_MRenderLineArray(*args, **kwargs):
    pass


def MFnParticleSystem_hasRgb(*args, **kwargs):
    pass


def MFnParticleSystem_className(*args, **kwargs):
    pass


def MnSolver_setWindNoiseIntensity(*args, **kwargs):
    pass


def MnCloth_getInverseMass(*args, **kwargs):
    pass


def MnCloth_getPositions(*args, **kwargs):
    pass


def MFnDynSweptGeometryData_swiginit(*args, **kwargs):
    pass


def MFnDynSweptGeometryData_swigregister(*args, **kwargs):
    pass


def MFnFluid_getColors(*args, **kwargs):
    pass


def MFnParticleSystem_originalParticleShape(*args, **kwargs):
    pass


def MFnParticleSystem_emit(*args, **kwargs):
    pass


def MFnFluid_setFalloffMode(*args, **kwargs):
    pass


def MFnParticleSystem_count(*args, **kwargs):
    pass


def delete_MDynamicsUtil(*args, **kwargs):
    pass


def MFnDynSweptGeometryData_triangleCount(*args, **kwargs):
    pass


def delete_MFnVortexField(*args, **kwargs):
    pass


def MDynSweptTriangle_swigregister(*args, **kwargs):
    pass


def delete_MHairSystem(*args, **kwargs):
    pass


def MFnTurbulenceField_swiginit(*args, **kwargs):
    pass


def new_MFnGravityField(*args, **kwargs):
    pass


def MnCloth_setStartPressure(*args, **kwargs):
    pass


def MFnFluid_emitIntoArrays(*args, **kwargs):
    pass


def MRenderLine_getIncandescence(*args, **kwargs):
    pass


def MFnFluid_isResizeToEmitter(*args, **kwargs):
    pass


def MFnRadialField_className(*args, **kwargs):
    pass


def MnSolver_setAirDensity(*args, **kwargs):
    pass


def MnCloth_setCollisionFlags(*args, **kwargs):
    pass


def MnSolver_setSubsteps(*args, **kwargs):
    pass


def MFnParticleSystem_rgb(*args, **kwargs):
    pass


def MRenderLine_getColor(*args, **kwargs):
    pass


def MnParticle_setDisableGravity(*args, **kwargs):
    pass


def SWIG_PyInstanceMethod_New(*args, **kwargs):
    pass


def MnParticle_getInverseMass(*args, **kwargs):
    pass


def MFnFluid_velocityGridSizes(*args, **kwargs):
    pass


def MnCloth_setMaxIterations(*args, **kwargs):
    pass


def MnParticle_getFriction(*args, **kwargs):
    pass


def MnSolver_setDisabled(*args, **kwargs):
    pass


def MFnParticleSystem_evaluateDynamics(*args, **kwargs):
    pass


def MFnFluid_pressure(*args, **kwargs):
    pass


def MFnFluid_setSize(*args, **kwargs):
    pass


def MFnInstancer_instancesForParticle(*args, **kwargs):
    pass


def delete_MFnDragField(*args, **kwargs):
    pass


def MDynSweptTriangle_area(*args, **kwargs):
    pass


def MRenderLine_assign(*args, **kwargs):
    pass


def MFnAirField_enableSpread(*args, **kwargs):
    pass


def MnObject_swiginit(*args, **kwargs):
    pass


def MFnVolumeAxisField_swiginit(*args, **kwargs):
    pass


def MnCloth_setComputeRestAngles(*args, **kwargs):
    pass


def MnCloth_setBendRestAngleFromPositions(*args, **kwargs):
    pass


def MFnGravityField_swiginit(*args, **kwargs):
    pass


def MFnFluid_getForceAtPoint(*args, **kwargs):
    pass


def MFnParticleSystem_receiveShadows(*args, **kwargs):
    pass


def MFnRadialField_swigregister(*args, **kwargs):
    pass


def MFnGravityField_setDirection(*args, **kwargs):
    pass


def MnCloth_setPumpRate(*args, **kwargs):
    pass


def MnSolver_makeAllCollide(*args, **kwargs):
    pass


def MRenderLine_getFlatness(*args, **kwargs):
    pass


def MnCloth_setSelfCollideWidth(*args, **kwargs):
    pass


def MFnField_perVertex(*args, **kwargs):
    pass


def MFnVolumeAxisField_setTurbulenceFrequency(*args, **kwargs):
    pass


def MFnParticleSystem_setCount(*args, **kwargs):
    pass


def delete_MnObject(*args, **kwargs):
    pass


def MnCloth_getVelocities(*args, **kwargs):
    pass


def MFnFluid_getColorMode(*args, **kwargs):
    pass


def MFnNObjectData_create(*args, **kwargs):
    pass


def MFnDynSweptGeometryData_lineCount(*args, **kwargs):
    pass


def MFnInstancer_swigregister(*args, **kwargs):
    pass


def MnCloth_getThickness(*args, **kwargs):
    pass


def MFnAirField_setDirection(*args, **kwargs):
    pass


def MFnAirField_setInheritVelocity(*args, **kwargs):
    pass


def MFnNObjectData_swigregister(*args, **kwargs):
    pass


def MFnVolumeAxisField_setSpeedAlongAxis(*args, **kwargs):
    pass


def MFnAirField_setComponentOnly(*args, **kwargs):
    pass


def MFnVolumeAxisField_setSpeedAwayFromCenter(*args, **kwargs):
    pass


def MFnVolumeAxisField_setTurbulence(*args, **kwargs):
    pass


def MFnFluid_index(*args, **kwargs):
    pass


def MnCloth_setPressure(*args, **kwargs):
    pass


def MFnParticleSystem_age(*args, **kwargs):
    pass


def MRenderLine_getTransparency(*args, **kwargs):
    pass


def MFnPfxGeometry_getLineData(*args, **kwargs):
    pass


def MHairSystem_registerCollisionSolverCollide(*args, **kwargs):
    pass


def MFnUniformField_className(*args, **kwargs):
    pass


def MnSolver_removeNObject(*args, **kwargs):
    pass


def MRenderLineArray_length(*args, **kwargs):
    pass


def MFnParticleSystem_mass(*args, **kwargs):
    pass


def MnCloth_setSelfTrappedCheck(*args, **kwargs):
    pass


def MFnField_attenuation(*args, **kwargs):
    pass


def MFnNObjectData_isCached(*args, **kwargs):
    pass


def MnParticle_setMaxSelfCollisionIterations(*args, **kwargs):
    pass


def MFnFluid_falloff(*args, **kwargs):
    pass


def MFnNewtonField_swiginit(*args, **kwargs):
    pass


def MnParticle_setSelfCollisionSoftness(*args, **kwargs):
    pass


def MFnFluid_getCoordinates(*args, **kwargs):
    pass


def MFnNObjectData_getClothObjectPtr(*args, **kwargs):
    pass


def MFnFluid_temperature(*args, **kwargs):
    pass


def MFnNIdData_create(*args, **kwargs):
    pass


def MFnAirField_speed(*args, **kwargs):
    pass


def MFnParticleSystem_deformedParticleShape(*args, **kwargs):
    pass


def MDynSweptLine_swiginit(*args, **kwargs):
    pass


def MFnTurbulenceField_frequency(*args, **kwargs):
    pass


def MnRigid_setVelocities(*args, **kwargs):
    pass


def MnCloth_setComputeRestLength(*args, **kwargs):
    pass


def MFnDragField_direction(*args, **kwargs):
    pass


def MRenderLineArray_swigregister(*args, **kwargs):
    pass


def MFnFluid_updateGrid(*args, **kwargs):
    pass


def MnCloth_createNCloth(*args, **kwargs):
    pass


def MnRigid_getThickness(*args, **kwargs):
    pass


def delete_MFnTurbulenceField(*args, **kwargs):
    pass


def MnRigid_getBounce(*args, **kwargs):
    pass


def MFnVortexField_swigregister(*args, **kwargs):
    pass


def MFnPfxGeometry_swiginit(*args, **kwargs):
    pass


def MFnVolumeAxisField_setSpeedAroundAxis(*args, **kwargs):
    pass


def MFnParticleSystem_particleIds(*args, **kwargs):
    pass


def MnParticle_setPositions(*args, **kwargs):
    pass


def MFnFluid_setFuelMode(*args, **kwargs):
    pass


def MFnNObjectData_getParticleObjectPtr(*args, **kwargs):
    pass


def MnParticle_getBounce(*args, **kwargs):
    pass


def new_MFnParticleSystem(*args, **kwargs):
    pass


def MFnNIdData_swigregister(*args, **kwargs):
    pass


def MFnParticleSystem_primaryVisibility(*args, **kwargs):
    pass


def new_MFnDragField(*args, **kwargs):
    pass


def MnCloth_setRestitutionAngle(*args, **kwargs):
    pass


def MFnAirField_setInheritRotation(*args, **kwargs):
    pass


def MFnUniformField_direction(*args, **kwargs):
    pass


def new_MnCloth(*args, **kwargs):
    pass


def MnRigid_setFriction(*args, **kwargs):
    pass


def MnCloth_setPressureDamping(*args, **kwargs):
    pass


def MFnFluid_voxelCenterPosition(*args, **kwargs):
    pass


def MnCloth_setDisableGravity(*args, **kwargs):
    pass


def MFnParticleSystem_isPerParticleDoubleAttribute(*args, **kwargs):
    pass


def MnParticle_setTopology(*args, **kwargs):
    pass


def MFnFluid_getDensityMode(*args, **kwargs):
    pass


def MFnParticleSystem_isPerParticleIntAttribute(*args, **kwargs):
    pass


def new_MnRigid(*args, **kwargs):
    pass


def delete_MnSolver(*args, **kwargs):
    pass


def MFnParticleSystem_isPerParticleVectorAttribute(*args, **kwargs):
    pass


def MRenderLineArray_swiginit(*args, **kwargs):
    pass


def MFnDynSweptGeometryData_create(*args, **kwargs):
    pass


def new_MFnRadialField(*args, **kwargs):
    pass


def MFnNObjectData_getCollide(*args, **kwargs):
    pass


def MnCloth_setSelfCrossoverPush(*args, **kwargs):
    pass


def MnParticle_setLiquidSimulation(*args, **kwargs):
    pass


def MFnNewtonField_setMinDistance(*args, **kwargs):
    pass


def MDynamicsUtil_addNodeTypeToRunup(*args, **kwargs):
    pass


def MnParticle_createNParticle(*args, **kwargs):
    pass


def MFnFluid_getFalloffMode(*args, **kwargs):
    pass


def MnParticle_setDragAndLift(*args, **kwargs):
    pass


def MFnParticleSystem_radius0(*args, **kwargs):
    pass


def MFnField_falloffCurve(*args, **kwargs):
    pass


def MFnNObjectData_getRigidObjectPtr(*args, **kwargs):
    pass


def MFnFluid_isAutoResize(*args, **kwargs):
    pass


def MFnVolumeAxisField_direction(*args, **kwargs):
    pass


def new_MDynSweptTriangle(*args, **kwargs):
    pass


def MnCloth_setInputMeshAttractAndRigidStrength(*args, **kwargs):
    pass


def MFnVortexField_setAxis(*args, **kwargs):
    pass


def MnCloth_setShearResistance(*args, **kwargs):
    pass


def MFnNIdData_className(*args, **kwargs):
    pass


def MFnTurbulenceField_swigregister(*args, **kwargs):
    pass


def MnRigid_setTopology(*args, **kwargs):
    pass


def MnCloth_setSealHoles(*args, **kwargs):
    pass


def MFnParticleSystem_setPerParticleAttribute(*args, **kwargs):
    pass


def MFnVolumeAxisField_turbulenceFrequency(*args, **kwargs):
    pass


def MnSolver_addNObject(*args, **kwargs):
    pass


def MFnParticleSystem_tailSize(*args, **kwargs):
    pass


def MDynSweptLine_swigregister(*args, **kwargs):
    pass


def MRenderLine_getLine(*args, **kwargs):
    pass


def MRenderLineArray_className(*args, **kwargs):
    pass


def MnParticle_getVelocities(*args, **kwargs):
    pass


def MnParticle_setMaxIterations(*args, **kwargs):
    pass


def MDynamicsUtil_removeNodeTypeFromRunup(*args, **kwargs):
    pass


def MFnDragField_setUseDirection(*args, **kwargs):
    pass


def MFnNewtonField_className(*args, **kwargs):
    pass


def MnParticle_getPositions(*args, **kwargs):
    pass


def MFnFluid_getDimensions(*args, **kwargs):
    pass


def delete_MFnNIdData(*args, **kwargs):
    pass


def MnCloth_getNumVertices(*args, **kwargs):
    pass


def MFnFluid_create2D(*args, **kwargs):
    pass


def MFnNObjectData_setCached(*args, **kwargs):
    pass


def MFnNewtonField_swigregister(*args, **kwargs):
    pass


def MFnTurbulenceField_setPhase(*args, **kwargs):
    pass


def MFnAirField_setEnableSpread(*args, **kwargs):
    pass


def MFnVolumeAxisField_speedAroundAxis(*args, **kwargs):
    pass


def MFnNewtonField_minDistance(*args, **kwargs):
    pass


def MnRigid_getNumVertices(*args, **kwargs):
    pass


def MDynSweptTriangle_swiginit(*args, **kwargs):
    pass


def delete_MFnUniformField(*args, **kwargs):
    pass


def MnRigid_setThickness(*args, **kwargs):
    pass


def delete_MFnGravityField(*args, **kwargs):
    pass


def MFnPfxGeometry_className(*args, **kwargs):
    pass


def MFnParticleSystem_saveInitialState(*args, **kwargs):
    pass


def MnSolver_setGravityDir(*args, **kwargs):
    pass


def MFnFluid_swiginit(*args, **kwargs):
    pass


def new_MDynSweptLine(*args, **kwargs):
    pass


def MnCloth_setBendAngleDropoff(*args, **kwargs):
    pass


def MFnParticleSystem_hasLifespan(*args, **kwargs):
    pass


def MnRigid_getVelocities(*args, **kwargs):
    pass


def MnParticle_setDamping(*args, **kwargs):
    pass


def MnParticle_setSelfCollideWidth(*args, **kwargs):
    pass


def new_MnObject(*args, **kwargs):
    pass


def delete_MFnParticleSystem(*args, **kwargs):
    pass


def MnCloth_setRestitutionTension(*args, **kwargs):
    pass


def MFnDragField_useDirection(*args, **kwargs):
    pass


def MHairSystem_setRegisteringCallableScript(*args, **kwargs):
    pass


def new_MFnNewtonField(*args, **kwargs):
    pass


def MnCloth_setBendResistance(*args, **kwargs):
    pass


def MFnFluid_setDensityMode(*args, **kwargs):
    pass


def new_MFnNIdData(*args, **kwargs):
    pass


def MFnFluid_getVelocityMode(*args, **kwargs):
    pass


def MFnDynSweptGeometryData_className(*args, **kwargs):
    pass


def MnCloth_setDragAndLift(*args, **kwargs):
    pass


def MFnNObjectData_className(*args, **kwargs):
    pass


def MnRigid_getPositions(*args, **kwargs):
    pass


def MFnVolumeAxisField_setTurbulenceSpeed(*args, **kwargs):
    pass


def MDynamicsUtil_hasValidDynamics2dTexture(*args, **kwargs):
    pass


def MFnDragField_className(*args, **kwargs):
    pass


def delete_MRenderLineArray(*args, **kwargs):
    pass


def MFnFluid_getTemperatureMode(*args, **kwargs):
    pass


def MRenderLineArray_assign(*args, **kwargs):
    pass


def MDynSweptLine_normal(*args, **kwargs):
    pass


def MRenderLine_getParameter(*args, **kwargs):
    pass


def MnParticle_setBounce(*args, **kwargs):
    pass


def MnParticle_getNumVertices(*args, **kwargs):
    pass


def MFnFluid_setTemperatureMode(*args, **kwargs):
    pass


def MFnFluid_setColorMode(*args, **kwargs):
    pass


def MnParticle_swiginit(*args, **kwargs):
    pass


def MFnInstancer_particleCount(*args, **kwargs):
    pass


def MFnDynSweptGeometryData_sweptLine(*args, **kwargs):
    pass


def MFnParticleSystem_position0(*args, **kwargs):
    pass


def MRenderLineArray_renderLine(*args, **kwargs):
    pass


def MFnField_setAttenuation(*args, **kwargs):
    pass


def MFnVolumeAxisField_setSpeedAwayFromAxis(*args, **kwargs):
    pass


def MFnField_setPerVertex(*args, **kwargs):
    pass


def MFnVortexField_className(*args, **kwargs):
    pass


def MHairSystem_getCollisionObject(*args, **kwargs):
    pass


def delete_MnRigid(*args, **kwargs):
    pass


def MFnVolumeAxisField_setTurbulenceOffset(*args, **kwargs):
    pass


def MFnGravityField_direction(*args, **kwargs):
    pass


def MnCloth_setLinksRestLengthFromPositions(*args, **kwargs):
    pass


def MnParticle_setViscosity(*args, **kwargs):
    pass


def MFnParticleSystem_opacity(*args, **kwargs):
    pass


def new_MHairSystem(*args, **kwargs):
    pass


def MHairSystem_registerCollisionSolverPreFrame(*args, **kwargs):
    pass


def MnSolver_setWindSpeed(*args, **kwargs):
    pass


def MFnField_getForceAtPoint(*args, **kwargs):
    pass


def MFnParticleSystem_radius1(*args, **kwargs):
    pass


def MnSolver_solve(*args, **kwargs):
    pass


def MnParticle_setInverseMass(*args, **kwargs):
    pass


def MnCloth_setIncompressibility(*args, **kwargs):
    pass


def MFnParticleSystem_radius(*args, **kwargs):
    pass


def MnParticle_getThickness(*args, **kwargs):
    pass


def MFnDynSweptGeometryData_sweptTriangle(*args, **kwargs):
    pass


def new_MFnNObjectData(*args, **kwargs):
    pass


def MDynamicsUtil_swigregister(*args, **kwargs):
    pass


def delete_MFnNewtonField(*args, **kwargs):
    pass


def MFnFluid_setCoordinateMode(*args, **kwargs):
    pass


def new_MDynamicsUtil(*args, **kwargs):
    pass


def MFnField_className(*args, **kwargs):
    pass


def MDynSweptTriangle_normal(*args, **kwargs):
    pass


def MFnParticleSystem_acceleration(*args, **kwargs):
    pass


def MFnField_swigregister(*args, **kwargs):
    pass


def new_MFnVortexField(*args, **kwargs):
    pass


def MFnAirField_componentOnly(*args, **kwargs):
    pass


def MDynamicsUtil_inRunup(*args, **kwargs):
    pass


def MHairSystem_getFollicle(*args, **kwargs):
    pass


def MFnUniformField_setDirection(*args, **kwargs):
    pass


def MFnFluid_swigregister(*args, **kwargs):
    pass


def MFnParticleSystem_visibleInReflections(*args, **kwargs):
    pass


def MFnVolumeAxisField_setDirectionalSpeed(*args, **kwargs):
    pass


def MRenderLine_swigregister(*args, **kwargs):
    pass


def MFnParticleSystem_disableCloudAxis(*args, **kwargs):
    pass


def MFnParticleSystem_threshold(*args, **kwargs):
    pass


def MFnField_setMagnitude(*args, **kwargs):
    pass


def MnCloth_getFriction(*args, **kwargs):
    pass


def new_MFnVolumeAxisField(*args, **kwargs):
    pass


def new_MnParticle(*args, **kwargs):
    pass


def MFnFluid_gridSize(*args, **kwargs):
    pass


def delete_MFnDynSweptGeometryData(*args, **kwargs):
    pass


def MFnNIdData_getObjectPtr(*args, **kwargs):
    pass


def MFnAirField_swigregister(*args, **kwargs):
    pass


def MFnAirField_swiginit(*args, **kwargs):
    pass


def MnCloth_setThickness(*args, **kwargs):
    pass


def MHairSystem_unregisterCollisionSolverPreFrame(*args, **kwargs):
    pass


def MFnVolumeAxisField_turbulenceSpeed(*args, **kwargs):
    pass


def MFnField_setUseMaxDistance(*args, **kwargs):
    pass


def MnCloth_swigregister(*args, **kwargs):
    pass


def MDynamicsUtil_runupIfRequired(*args, **kwargs):
    pass


def MDynSweptLine_tangent(*args, **kwargs):
    pass


def new_MFnUniformField(*args, **kwargs):
    pass


def MFnFluid_getResolution(*args, **kwargs):
    pass


def MFnRadialField_setType(*args, **kwargs):
    pass


def MnCloth_setPositions(*args, **kwargs):
    pass


def delete_MFnInstancer(*args, **kwargs):
    pass


def new_MFnPfxGeometry(*args, **kwargs):
    pass


def MRenderLine_swiginit(*args, **kwargs):
    pass


def MFnParticleSystem_hasOpacity(*args, **kwargs):
    pass


def MnSolver_setWindDir(*args, **kwargs):
    pass


def MFnParticleSystem_lifespan(*args, **kwargs):
    pass


def MRenderLineArray_deleteArray(*args, **kwargs):
    pass


def MFnParticleSystem_hasEmission(*args, **kwargs):
    pass


def MFnField_useMaxDistance(*args, **kwargs):
    pass


def MnCloth_setAirTightness(*args, **kwargs):
    pass


def MnCloth_setStretchAndCompressionResistance(*args, **kwargs):
    pass


def MFnParticleSystem_velocity(*args, **kwargs):
    pass


def MnParticle_setLiquidRadiusScale(*args, **kwargs):
    pass


def MFnFluid_density(*args, **kwargs):
    pass


def MFnParticleSystem_position(*args, **kwargs):
    pass


def MFnDragField_swiginit(*args, **kwargs):
    pass


def delete_MnParticle(*args, **kwargs):
    pass


def MFnInstancer_swiginit(*args, **kwargs):
    pass


def MFnFluid_setVelocityMode(*args, **kwargs):
    pass


def MFnParticleSystem_emission(*args, **kwargs):
    pass


def MFnField_swiginit(*args, **kwargs):
    pass


def delete_MFnField(*args, **kwargs):
    pass


def MFnVortexField_swiginit(*args, **kwargs):
    pass


def MFnVolumeAxisField_invertAttenuation(*args, **kwargs):
    pass


def MFnAirField_setSpread(*args, **kwargs):
    pass


def new_MFnAirField(*args, **kwargs):
    pass


def MHairSystem_unregisterCollisionSolverCollide(*args, **kwargs):
    pass


def MFnVolumeAxisField_speedAwayFromCenter(*args, **kwargs):
    pass


def MFnInstancer_allInstances(*args, **kwargs):
    pass


def new_MFnTurbulenceField(*args, **kwargs):
    pass


def MRenderLine_className(*args, **kwargs):
    pass


def MnCloth_setSelfCollisionSoftness(*args, **kwargs):
    pass


def delete_MFnRadialField(*args, **kwargs):
    pass


def MnSolver_setMaxIterations(*args, **kwargs):
    pass



MFnParticleSystem_kStreak = 9

MFnParticleSystem_kSprites = 8

MFnFluid_kCenterGradient = 7

MFnFluid_kNegZGradient = 6

MFnFluid_kNegYGradient = 5

MFnFluid_kNegXGradient = 4

MFnFluid_kGradient = 3

MFnFluid_kDynamicColorGrid = 2

MFnFluid_kGrid = 1

MFnFluid_kConstant = 0

MFnFluid_kFixed = MFnFluid_kConstant
MFnFluid_kNoFalloffGrid = MFnFluid_kConstant
MFnFluid_kUseShadingColor = MFnFluid_kConstant
MFnFluid_kZero = MFnFluid_kConstant
MFnParticleSystem_kCloud = MFnFluid_kConstant

