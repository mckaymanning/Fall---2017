class _Object(object):
    __dict__ = None


class QTest(_Object):
    def addColumnInternal(*args, **kwargs):
        pass
    
    
    def asciiToKey(*args, **kwargs):
        pass
    
    
    def compare_ptr_helper(*args, **kwargs):
        pass
    
    
    def compare_string_helper(*args, **kwargs):
        pass
    
    
    def currentAppName(*args, **kwargs):
        pass
    
    
    def currentDataTag(*args, **kwargs):
        pass
    
    
    def currentTestFailed(*args, **kwargs):
        pass
    
    
    def currentTestFunction(*args, **kwargs):
        pass
    
    
    def ignoreMessage(*args, **kwargs):
        pass
    
    
    def keyClick(*args, **kwargs):
        pass
    
    
    def keyClicks(*args, **kwargs):
        pass
    
    
    def keyEvent(*args, **kwargs):
        pass
    
    
    def keyPress(*args, **kwargs):
        pass
    
    
    def keyRelease(*args, **kwargs):
        pass
    
    
    def keyToAscii(*args, **kwargs):
        pass
    
    
    def mouseClick(*args, **kwargs):
        pass
    
    
    def mouseDClick(*args, **kwargs):
        pass
    
    
    def mouseEvent(*args, **kwargs):
        pass
    
    
    def mouseMove(*args, **kwargs):
        pass
    
    
    def mousePress(*args, **kwargs):
        pass
    
    
    def mouseRelease(*args, **kwargs):
        pass
    
    
    def qElementData(*args, **kwargs):
        pass
    
    
    def qExpectFail(*args, **kwargs):
        pass
    
    
    def qFindTestData(*args, **kwargs):
        pass
    
    
    def qGlobalData(*args, **kwargs):
        pass
    
    
    def qSkip(*args, **kwargs):
        pass
    
    
    def qWaitForWindowActive(*args, **kwargs):
        pass
    
    
    def qWaitForWindowExposed(*args, **kwargs):
        pass
    
    
    def sendKeyEvent(*args, **kwargs):
        pass
    
    
    def setBenchmarkResult(*args, **kwargs):
        pass
    
    
    def setMainSourcePath(*args, **kwargs):
        pass
    
    
    def simulateEvent(*args, **kwargs):
        pass
    
    
    def testObject(*args, **kwargs):
        pass
    
    
    def toPrettyCString(*args, **kwargs):
        pass
    
    
    def touchEvent(*args, **kwargs):
        pass
    
    
    def waitForEvents(*args, **kwargs):
        pass
    
    
    Abort = None
    
    
    AlignmentFaults = None
    
    
    BitsPerSecond = None
    
    
    BranchInstructions = None
    
    
    BranchMisses = None
    
    
    BusCycles = None
    
    
    BytesAllocated = None
    
    
    BytesPerSecond = None
    
    
    CPUCycles = None
    
    
    CPUMigrations = None
    
    
    CPUTicks = None
    
    
    CacheMisses = None
    
    
    CachePrefetchMisses = None
    
    
    CachePrefetches = None
    
    
    CacheReadMisses = None
    
    
    CacheReads = None
    
    
    CacheReferences = None
    
    
    CacheWriteMisses = None
    
    
    CacheWrites = None
    
    
    Click = None
    
    
    ContextSwitches = None
    
    
    Continue = None
    
    
    EmulationFaults = None
    
    
    Events = None
    
    
    FramesPerSecond = None
    
    
    InstructionReads = None
    
    
    Instructions = None
    
    
    KeyAction = None
    
    
    MajorPageFaults = None
    
    
    MinorPageFaults = None
    
    
    MouseAction = None
    
    
    MouseClick = None
    
    
    MouseDClick = None
    
    
    MouseMove = None
    
    
    MousePress = None
    
    
    MouseRelease = None
    
    
    PageFaults = None
    
    
    Press = None
    
    
    QBenchmarkMetric = None
    
    
    QTouchEventSequence = None
    
    
    Release = None
    
    
    Shortcut = None
    
    
    StalledCycles = None
    
    
    TestFailMode = None
    
    
    WalltimeMilliseconds = None
    
    
    WalltimeNanoseconds = None



