from maya.app.renderSetup.views.propertyEditor.expressionLabels import *
from maya.app.renderSetup.views.renderSetupButton import *

from PySide2.QtWidgets import QPushButton
from PySide2.QtCore import QTimer
from PySide2.QtWidgets import QApplication
from PySide2.QtGui import QKeySequence
from PySide2.QtWidgets import QStyleOptionViewItem
from PySide2.QtWidgets import QFormLayout
from PySide2.QtWidgets import QStyledItemDelegate
from PySide2.QtWidgets import QAbstractItemView
from maya.app.renderSetup.views.propertyEditor.layout import Layout
from PySide2.QtGui import QTextDocument
from PySide2.QtWidgets import QWidget
from PySide2.QtGui import QAbstractTextDocumentLayout
from PySide2.QtWidgets import QSizePolicy
from PySide2.QtCore import QItemSelectionModel
from maya.app.general.mayaMixin import MayaQWidgetBaseMixin
from PySide2.QtWidgets import QShortcut
from PySide2.QtGui import QPen
from PySide2.QtWidgets import QLineEdit
from PySide2.QtWidgets import QVBoxLayout
from PySide2.QtWidgets import QTextEdit
from maya.app.renderSetup.views.renderSetupDelegate import RenderSetupDelegate
from PySide2.QtCore import QRect
from PySide2.QtGui import QPalette
from PySide2.QtWidgets import QGroupBox
from maya.app.renderSetup.views.propertyEditor.collectionStaticSelectionWidget import HTMLDelegate
from maya.app.renderSetup.views.propertyEditor.collectionFilterLineEdit import CollectionFilterLineEdit
from PySide2.QtWidgets import QHBoxLayout
from maya.app.renderSetup.views.propertyEditor.collectionStaticSelectionWidget import CollectionStaticSelectionWidget
from PySide2.QtWidgets import QComboBox
from PySide2.QtGui import QFont
from functools import partial
from PySide2.QtWidgets import QCheckBox
from PySide2.QtWidgets import QListWidget
from PySide2.QtWidgets import QAction

class Collection(MayaQWidgetBaseMixin, QGroupBox):
    """
    This class represents the property editor view of a collection.
    """
    
    
    
    def __init__(self, item, treeView, parent):
        pass
    
    
    def customFilterEntered(self):
        pass
    
    
    def deleteExcludeExpression(self):
        pass
    
    
    def deleteIncludeExpression(self):
        pass
    
    
    def excludeExpressionAdded(self):
        pass
    
    
    def includeExpressionAdded(self):
        pass
    
    
    def includeExpressionChanged(self, text):
        pass
    
    
    def includeExpressionEntered(self):
        pass
    
    
    def isAbsoluteMode(self):
        pass
    
    
    def populateFields(*args, **kwargs):
        pass
    
    
    def selectIncludeExpression(self):
        pass
    
    
    def selectStaticEntries(self):
        pass
    
    
    CREATE_EXPRESSION_STRING = []
    
    
    DRAG_DROP_FILTER_STRING = []
    
    
    EXPRESSION_BUTTON_WIDTH = 50.0
    
    
    INVERSE_STRING = []
    
    
    LIST_BOX_HEIGHT = 100.0
    
    
    RELATIVE_WARNING = []
    
    
    SELECT_STRING = []
    
    
    attributeDropped = None
    
    
    staticMetaObject = None



def getCppPointer(*args, **kwargs):
    pass



kStaticAddTooltipStr = []

kExpressionTooltipStr1 = []

kIncludeHierarchyTooltipStr = []

kInclude = []

kRemove = []

kInverse = []

kStaticRemoveTooltipStr = []

kCreateExpression = []

kExpressionSelectTooltipStr = []

kStaticSelectTooltipStr = []

kDragDropFilter = []

kLayer = []

kFiltersToolTip = []

kRelativeWarning = []

kExpressionTooltipStr4 = []

kAddOverrideTooltipStr = []

kIncludeHierarchy = []

kAddOverride = []

kCollectionFilters = []

kByTypeFilter = []

kAddToCollection = []

kExpressionTooltipStr3 = []

kSelectAll = []

kSelect = []

kExpressionTooltipStr = []

kAdd = []

kExpressionTooltipStr2 = []

kDragAttributesFromAE = []


