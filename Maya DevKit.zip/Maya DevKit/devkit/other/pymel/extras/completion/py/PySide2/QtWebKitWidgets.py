from PySide2.QtCore import QObject as _QObject
from PySide2.QtWidgets import QWidget as _QWidget

class _Object(object):
    __dict__ = None


class QWebSettings(_Object):
    def cssMediaType(*args, **kwargs):
        pass
    
    
    def defaultTextEncoding(*args, **kwargs):
        pass
    
    
    def fontFamily(*args, **kwargs):
        pass
    
    
    def fontSize(*args, **kwargs):
        pass
    
    
    def localStoragePath(*args, **kwargs):
        pass
    
    
    def resetAttribute(*args, **kwargs):
        pass
    
    
    def resetFontFamily(*args, **kwargs):
        pass
    
    
    def resetFontSize(*args, **kwargs):
        pass
    
    
    def setAttribute(*args, **kwargs):
        pass
    
    
    def setCSSMediaType(*args, **kwargs):
        pass
    
    
    def setDefaultTextEncoding(*args, **kwargs):
        pass
    
    
    def setFontFamily(*args, **kwargs):
        pass
    
    
    def setFontSize(*args, **kwargs):
        pass
    
    
    def setLocalStoragePath(*args, **kwargs):
        pass
    
    
    def setThirdPartyCookiePolicy(*args, **kwargs):
        pass
    
    
    def setUserStyleSheetUrl(*args, **kwargs):
        pass
    
    
    def testAttribute(*args, **kwargs):
        pass
    
    
    def thirdPartyCookiePolicy(*args, **kwargs):
        pass
    
    
    def userStyleSheetUrl(*args, **kwargs):
        pass
    
    
    def clearIconDatabase(*args, **kwargs):
        pass
    
    
    def clearMemoryCaches(*args, **kwargs):
        pass
    
    
    def enablePersistentStorage(*args, **kwargs):
        pass
    
    
    def globalSettings(*args, **kwargs):
        pass
    
    
    def iconDatabasePath(*args, **kwargs):
        pass
    
    
    def iconForUrl(*args, **kwargs):
        pass
    
    
    def maximumPagesInCache(*args, **kwargs):
        pass
    
    
    def offlineStorageDefaultQuota(*args, **kwargs):
        pass
    
    
    def offlineStoragePath(*args, **kwargs):
        pass
    
    
    def offlineWebApplicationCachePath(*args, **kwargs):
        pass
    
    
    def offlineWebApplicationCacheQuota(*args, **kwargs):
        pass
    
    
    def setIconDatabasePath(*args, **kwargs):
        pass
    
    
    def setMaximumPagesInCache(*args, **kwargs):
        pass
    
    
    def setObjectCacheCapacities(*args, **kwargs):
        pass
    
    
    def setOfflineStorageDefaultQuota(*args, **kwargs):
        pass
    
    
    def setOfflineStoragePath(*args, **kwargs):
        pass
    
    
    def setOfflineWebApplicationCachePath(*args, **kwargs):
        pass
    
    
    def setOfflineWebApplicationCacheQuota(*args, **kwargs):
        pass
    
    
    def setWebGraphic(*args, **kwargs):
        pass
    
    
    def webGraphic(*args, **kwargs):
        pass
    
    
    Accelerated2dCanvasEnabled = None
    
    
    AcceleratedCompositingEnabled = None
    
    
    AllowThirdPartyWithExistingCookies = None
    
    
    AlwaysAllowThirdPartyCookies = None
    
    
    AlwaysBlockThirdPartyCookies = None
    
    
    AutoLoadImages = None
    
    
    CSSGridLayoutEnabled = None
    
    
    CSSRegionsEnabled = None
    
    
    CaretBrowsingEnabled = None
    
    
    CursiveFont = None
    
    
    DefaultFixedFontSize = None
    
    
    DefaultFontSize = None
    
    
    DefaultFrameIconGraphic = None
    
    
    DeleteButtonGraphic = None
    
    
    DeveloperExtrasEnabled = None
    
    
    DnsPrefetchEnabled = None
    
    
    FantasyFont = None
    
    
    FixedFont = None
    
    
    FontFamily = None
    
    
    FontSize = None
    
    
    FrameFlatteningEnabled = None
    
    
    HyperlinkAuditingEnabled = None
    
    
    InputSpeechButtonGraphic = None
    
    
    JavaEnabled = None
    
    
    JavascriptCanAccessClipboard = None
    
    
    JavascriptCanCloseWindows = None
    
    
    JavascriptCanOpenWindows = None
    
    
    JavascriptEnabled = None
    
    
    LinksIncludedInFocusChain = None
    
    
    LocalContentCanAccessFileUrls = None
    
    
    LocalContentCanAccessRemoteUrls = None
    
    
    LocalStorageDatabaseEnabled = None
    
    
    LocalStorageEnabled = None
    
    
    MinimumFontSize = None
    
    
    MinimumLogicalFontSize = None
    
    
    MissingImageGraphic = None
    
    
    MissingPluginGraphic = None
    
    
    NotificationsEnabled = None
    
    
    OfflineStorageDatabaseEnabled = None
    
    
    OfflineWebApplicationCacheEnabled = None
    
    
    PluginsEnabled = None
    
    
    PrintElementBackgrounds = None
    
    
    PrivateBrowsingEnabled = None
    
    
    SansSerifFont = None
    
    
    ScrollAnimatorEnabled = None
    
    
    SearchCancelButtonGraphic = None
    
    
    SearchCancelButtonPressedGraphic = None
    
    
    SerifFont = None
    
    
    SiteSpecificQuirksEnabled = None
    
    
    SpatialNavigationEnabled = None
    
    
    StandardFont = None
    
    
    TextAreaSizeGripCornerGraphic = None
    
    
    ThirdPartyCookiePolicy = None
    
    
    TiledBackingStoreEnabled = None
    
    
    WebAttribute = None
    
    
    WebAudioEnabled = None
    
    
    WebGLEnabled = None
    
    
    WebGraphic = None
    
    
    XSSAuditingEnabled = None
    
    
    ZoomTextOnly = None


class QWebElement(_Object):
    def __copy__(*args, **kwargs):
        pass
    
    
    def __eq__(*args, **kwargs):
        """
        x.__eq__(y) <==> x==y
        """
    
        pass
    
    
    def __ge__(*args, **kwargs):
        """
        x.__ge__(y) <==> x>=y
        """
    
        pass
    
    
    def __gt__(*args, **kwargs):
        """
        x.__gt__(y) <==> x>y
        """
    
        pass
    
    
    def __init__(*args, **kwargs):
        """
        x.__init__(...) initializes x; see help(type(x)) for signature
        """
    
        pass
    
    
    def __le__(*args, **kwargs):
        """
        x.__le__(y) <==> x<=y
        """
    
        pass
    
    
    def __lt__(*args, **kwargs):
        """
        x.__lt__(y) <==> x<y
        """
    
        pass
    
    
    def __ne__(*args, **kwargs):
        """
        x.__ne__(y) <==> x!=y
        """
    
        pass
    
    
    def __nonzero__(*args, **kwargs):
        """
        x.__nonzero__() <==> x != 0
        """
    
        pass
    
    
    def addClass(*args, **kwargs):
        pass
    
    
    def appendInside(*args, **kwargs):
        pass
    
    
    def appendOutside(*args, **kwargs):
        pass
    
    
    def attribute(*args, **kwargs):
        pass
    
    
    def attributeNS(*args, **kwargs):
        pass
    
    
    def attributeNames(*args, **kwargs):
        pass
    
    
    def classes(*args, **kwargs):
        pass
    
    
    def clone(*args, **kwargs):
        pass
    
    
    def document(*args, **kwargs):
        pass
    
    
    def encloseContentsWith(*args, **kwargs):
        pass
    
    
    def encloseWith(*args, **kwargs):
        pass
    
    
    def evaluateJavaScript(*args, **kwargs):
        pass
    
    
    def findAll(*args, **kwargs):
        pass
    
    
    def findFirst(*args, **kwargs):
        pass
    
    
    def firstChild(*args, **kwargs):
        pass
    
    
    def geometry(*args, **kwargs):
        pass
    
    
    def hasAttribute(*args, **kwargs):
        pass
    
    
    def hasAttributeNS(*args, **kwargs):
        pass
    
    
    def hasAttributes(*args, **kwargs):
        pass
    
    
    def hasClass(*args, **kwargs):
        pass
    
    
    def hasFocus(*args, **kwargs):
        pass
    
    
    def isNull(*args, **kwargs):
        pass
    
    
    def lastChild(*args, **kwargs):
        pass
    
    
    def localName(*args, **kwargs):
        pass
    
    
    def namespaceUri(*args, **kwargs):
        pass
    
    
    def nextSibling(*args, **kwargs):
        pass
    
    
    def parent(*args, **kwargs):
        pass
    
    
    def prefix(*args, **kwargs):
        pass
    
    
    def prependInside(*args, **kwargs):
        pass
    
    
    def prependOutside(*args, **kwargs):
        pass
    
    
    def previousSibling(*args, **kwargs):
        pass
    
    
    def removeAllChildren(*args, **kwargs):
        pass
    
    
    def removeAttribute(*args, **kwargs):
        pass
    
    
    def removeAttributeNS(*args, **kwargs):
        pass
    
    
    def removeClass(*args, **kwargs):
        pass
    
    
    def removeFromDocument(*args, **kwargs):
        pass
    
    
    def render(*args, **kwargs):
        pass
    
    
    def replace(*args, **kwargs):
        pass
    
    
    def setAttribute(*args, **kwargs):
        pass
    
    
    def setAttributeNS(*args, **kwargs):
        pass
    
    
    def setFocus(*args, **kwargs):
        pass
    
    
    def setInnerXml(*args, **kwargs):
        pass
    
    
    def setOuterXml(*args, **kwargs):
        pass
    
    
    def setPlainText(*args, **kwargs):
        pass
    
    
    def setStyleProperty(*args, **kwargs):
        pass
    
    
    def styleProperty(*args, **kwargs):
        pass
    
    
    def tagName(*args, **kwargs):
        pass
    
    
    def takeFromDocument(*args, **kwargs):
        pass
    
    
    def toInnerXml(*args, **kwargs):
        pass
    
    
    def toOuterXml(*args, **kwargs):
        pass
    
    
    def toPlainText(*args, **kwargs):
        pass
    
    
    def toggleClass(*args, **kwargs):
        pass
    
    
    def webFrame(*args, **kwargs):
        pass
    
    
    CascadedStyle = None
    
    
    ComputedStyle = None
    
    
    InlineStyle = None
    
    
    StyleResolveStrategy = None
    
    
    __new__ = None


class QWebInspector(_QWidget):
    def __init__(*args, **kwargs):
        """
        x.__init__(...) initializes x; see help(type(x)) for signature
        """
    
        pass
    
    
    def closeEvent(*args, **kwargs):
        pass
    
    
    def event(*args, **kwargs):
        pass
    
    
    def hideEvent(*args, **kwargs):
        pass
    
    
    def page(*args, **kwargs):
        pass
    
    
    def resizeEvent(*args, **kwargs):
        pass
    
    
    def setPage(*args, **kwargs):
        pass
    
    
    def showEvent(*args, **kwargs):
        pass
    
    
    def sizeHint(*args, **kwargs):
        pass
    
    
    __new__ = None
    
    
    staticMetaObject = None


class QWebView(_QWidget):
    def __init__(*args, **kwargs):
        """
        x.__init__(...) initializes x; see help(type(x)) for signature
        """
    
        pass
    
    
    def back(*args, **kwargs):
        pass
    
    
    def changeEvent(*args, **kwargs):
        pass
    
    
    def contextMenuEvent(*args, **kwargs):
        pass
    
    
    def createWindow(*args, **kwargs):
        pass
    
    
    def dragEnterEvent(*args, **kwargs):
        pass
    
    
    def dragLeaveEvent(*args, **kwargs):
        pass
    
    
    def dragMoveEvent(*args, **kwargs):
        pass
    
    
    def dropEvent(*args, **kwargs):
        pass
    
    
    def event(*args, **kwargs):
        pass
    
    
    def findText(*args, **kwargs):
        pass
    
    
    def focusInEvent(*args, **kwargs):
        pass
    
    
    def focusNextPrevChild(*args, **kwargs):
        pass
    
    
    def focusOutEvent(*args, **kwargs):
        pass
    
    
    def forward(*args, **kwargs):
        pass
    
    
    def hasSelection(*args, **kwargs):
        pass
    
    
    def history(*args, **kwargs):
        pass
    
    
    def icon(*args, **kwargs):
        pass
    
    
    def inputMethodEvent(*args, **kwargs):
        pass
    
    
    def inputMethodQuery(*args, **kwargs):
        pass
    
    
    def isModified(*args, **kwargs):
        pass
    
    
    def keyPressEvent(*args, **kwargs):
        pass
    
    
    def keyReleaseEvent(*args, **kwargs):
        pass
    
    
    def load(*args, **kwargs):
        pass
    
    
    def mouseDoubleClickEvent(*args, **kwargs):
        pass
    
    
    def mouseMoveEvent(*args, **kwargs):
        pass
    
    
    def mousePressEvent(*args, **kwargs):
        pass
    
    
    def mouseReleaseEvent(*args, **kwargs):
        pass
    
    
    def page(*args, **kwargs):
        pass
    
    
    def pageAction(*args, **kwargs):
        pass
    
    
    def paintEvent(*args, **kwargs):
        pass
    
    
    def print_(*args, **kwargs):
        pass
    
    
    def reload(*args, **kwargs):
        pass
    
    
    def renderHints(*args, **kwargs):
        pass
    
    
    def resizeEvent(*args, **kwargs):
        pass
    
    
    def selectedHtml(*args, **kwargs):
        pass
    
    
    def selectedText(*args, **kwargs):
        pass
    
    
    def setContent(*args, **kwargs):
        pass
    
    
    def setHtml(*args, **kwargs):
        pass
    
    
    def setPage(*args, **kwargs):
        pass
    
    
    def setRenderHint(*args, **kwargs):
        pass
    
    
    def setRenderHints(*args, **kwargs):
        pass
    
    
    def setTextSizeMultiplier(*args, **kwargs):
        pass
    
    
    def setUrl(*args, **kwargs):
        pass
    
    
    def setZoomFactor(*args, **kwargs):
        pass
    
    
    def settings(*args, **kwargs):
        pass
    
    
    def sizeHint(*args, **kwargs):
        pass
    
    
    def stop(*args, **kwargs):
        pass
    
    
    def textSizeMultiplier(*args, **kwargs):
        pass
    
    
    def title(*args, **kwargs):
        pass
    
    
    def triggerPageAction(*args, **kwargs):
        pass
    
    
    def url(*args, **kwargs):
        pass
    
    
    def wheelEvent(*args, **kwargs):
        pass
    
    
    def zoomFactor(*args, **kwargs):
        pass
    
    
    __new__ = None
    
    
    iconChanged = None
    
    
    linkClicked = None
    
    
    loadFinished = None
    
    
    loadProgress = None
    
    
    loadStarted = None
    
    
    selectionChanged = None
    
    
    staticMetaObject = None
    
    
    statusBarMessage = None
    
    
    titleChanged = None
    
    
    urlChanged = None


class QWebPluginFactory(_QObject):
    def __init__(*args, **kwargs):
        """
        x.__init__(...) initializes x; see help(type(x)) for signature
        """
    
        pass
    
    
    def create(*args, **kwargs):
        pass
    
    
    def plugins(*args, **kwargs):
        pass
    
    
    def refreshPlugins(*args, **kwargs):
        pass
    
    
    def supportsExtension(*args, **kwargs):
        pass
    
    
    Extension = None
    
    
    MimeType = None
    
    
    Plugin = None
    
    
    __new__ = None
    
    
    staticMetaObject = None


class QWebElementCollection(_Object):
    def __add__(*args, **kwargs):
        """
        x.__add__(y) <==> x+y
        """
    
        pass
    
    
    def __copy__(*args, **kwargs):
        pass
    
    
    def __getitem__(*args, **kwargs):
        """
        x.__getitem__(y) <==> x[y]
        """
    
        pass
    
    
    def __iadd__(*args, **kwargs):
        """
        x.__iadd__(y) <==> x+=y
        """
    
        pass
    
    
    def __init__(*args, **kwargs):
        """
        x.__init__(...) initializes x; see help(type(x)) for signature
        """
    
        pass
    
    
    def __len__(*args, **kwargs):
        """
        x.__len__() <==> len(x)
        """
    
        pass
    
    
    def __radd__(*args, **kwargs):
        """
        x.__radd__(y) <==> y+x
        """
    
        pass
    
    
    def append(*args, **kwargs):
        pass
    
    
    def at(*args, **kwargs):
        pass
    
    
    def count(*args, **kwargs):
        pass
    
    
    def first(*args, **kwargs):
        pass
    
    
    def last(*args, **kwargs):
        pass
    
    
    def toList(*args, **kwargs):
        pass
    
    
    __new__ = None


class QWebSecurityOrigin(_Object):
    def __copy__(*args, **kwargs):
        pass
    
    
    def __init__(*args, **kwargs):
        """
        x.__init__(...) initializes x; see help(type(x)) for signature
        """
    
        pass
    
    
    def addAccessWhitelistEntry(*args, **kwargs):
        pass
    
    
    def databaseQuota(*args, **kwargs):
        pass
    
    
    def databaseUsage(*args, **kwargs):
        pass
    
    
    def databases(*args, **kwargs):
        pass
    
    
    def host(*args, **kwargs):
        pass
    
    
    def port(*args, **kwargs):
        pass
    
    
    def removeAccessWhitelistEntry(*args, **kwargs):
        pass
    
    
    def scheme(*args, **kwargs):
        pass
    
    
    def setApplicationCacheQuota(*args, **kwargs):
        pass
    
    
    def setDatabaseQuota(*args, **kwargs):
        pass
    
    
    def addLocalScheme(*args, **kwargs):
        pass
    
    
    def allOrigins(*args, **kwargs):
        pass
    
    
    def localSchemes(*args, **kwargs):
        pass
    
    
    def removeLocalScheme(*args, **kwargs):
        pass
    
    
    AllowSubdomains = None
    
    
    DisallowSubdomains = None
    
    
    SubdomainSetting = None
    
    
    __new__ = None


class QWebHistory(_Object):
    def __lshift__(*args, **kwargs):
        """
        x.__lshift__(y) <==> x<<y
        """
    
        pass
    
    
    def __rlshift__(*args, **kwargs):
        """
        x.__rlshift__(y) <==> y<<x
        """
    
        pass
    
    
    def __rrshift__(*args, **kwargs):
        """
        x.__rrshift__(y) <==> y>>x
        """
    
        pass
    
    
    def __rshift__(*args, **kwargs):
        """
        x.__rshift__(y) <==> x>>y
        """
    
        pass
    
    
    def back(*args, **kwargs):
        pass
    
    
    def backItem(*args, **kwargs):
        pass
    
    
    def backItems(*args, **kwargs):
        pass
    
    
    def canGoBack(*args, **kwargs):
        pass
    
    
    def canGoForward(*args, **kwargs):
        pass
    
    
    def clear(*args, **kwargs):
        pass
    
    
    def count(*args, **kwargs):
        pass
    
    
    def currentItem(*args, **kwargs):
        pass
    
    
    def currentItemIndex(*args, **kwargs):
        pass
    
    
    def forward(*args, **kwargs):
        pass
    
    
    def forwardItem(*args, **kwargs):
        pass
    
    
    def forwardItems(*args, **kwargs):
        pass
    
    
    def goToItem(*args, **kwargs):
        pass
    
    
    def itemAt(*args, **kwargs):
        pass
    
    
    def items(*args, **kwargs):
        pass
    
    
    def maximumItemCount(*args, **kwargs):
        pass
    
    
    def setMaximumItemCount(*args, **kwargs):
        pass


class QWebHistoryInterface(_QObject):
    def __init__(*args, **kwargs):
        """
        x.__init__(...) initializes x; see help(type(x)) for signature
        """
    
        pass
    
    
    def addHistoryEntry(*args, **kwargs):
        pass
    
    
    def historyContains(*args, **kwargs):
        pass
    
    
    def defaultInterface(*args, **kwargs):
        pass
    
    
    def setDefaultInterface(*args, **kwargs):
        pass
    
    
    __new__ = None
    
    
    staticMetaObject = None


from . import QtWidgets as _QtWidgets

class QGraphicsWebView(_QtWidgets.QGraphicsWidget):
    def __init__(*args, **kwargs):
        """
        x.__init__(...) initializes x; see help(type(x)) for signature
        """
    
        pass
    
    
    def back(*args, **kwargs):
        pass
    
    
    def contextMenuEvent(*args, **kwargs):
        pass
    
    
    def dragEnterEvent(*args, **kwargs):
        pass
    
    
    def dragLeaveEvent(*args, **kwargs):
        pass
    
    
    def dragMoveEvent(*args, **kwargs):
        pass
    
    
    def dropEvent(*args, **kwargs):
        pass
    
    
    def event(*args, **kwargs):
        pass
    
    
    def findText(*args, **kwargs):
        pass
    
    
    def focusInEvent(*args, **kwargs):
        pass
    
    
    def focusNextPrevChild(*args, **kwargs):
        pass
    
    
    def focusOutEvent(*args, **kwargs):
        pass
    
    
    def forward(*args, **kwargs):
        pass
    
    
    def history(*args, **kwargs):
        pass
    
    
    def hoverLeaveEvent(*args, **kwargs):
        pass
    
    
    def hoverMoveEvent(*args, **kwargs):
        pass
    
    
    def icon(*args, **kwargs):
        pass
    
    
    def inputMethodEvent(*args, **kwargs):
        pass
    
    
    def inputMethodQuery(*args, **kwargs):
        pass
    
    
    def isModified(*args, **kwargs):
        pass
    
    
    def isTiledBackingStoreFrozen(*args, **kwargs):
        pass
    
    
    def itemChange(*args, **kwargs):
        pass
    
    
    def keyPressEvent(*args, **kwargs):
        pass
    
    
    def keyReleaseEvent(*args, **kwargs):
        pass
    
    
    def load(*args, **kwargs):
        pass
    
    
    def mouseDoubleClickEvent(*args, **kwargs):
        pass
    
    
    def mouseMoveEvent(*args, **kwargs):
        pass
    
    
    def mousePressEvent(*args, **kwargs):
        pass
    
    
    def mouseReleaseEvent(*args, **kwargs):
        pass
    
    
    def page(*args, **kwargs):
        pass
    
    
    def pageAction(*args, **kwargs):
        pass
    
    
    def paint(*args, **kwargs):
        pass
    
    
    def reload(*args, **kwargs):
        pass
    
    
    def renderHints(*args, **kwargs):
        pass
    
    
    def resizesToContents(*args, **kwargs):
        pass
    
    
    def sceneEvent(*args, **kwargs):
        pass
    
    
    def setContent(*args, **kwargs):
        pass
    
    
    def setGeometry(*args, **kwargs):
        pass
    
    
    def setHtml(*args, **kwargs):
        pass
    
    
    def setPage(*args, **kwargs):
        pass
    
    
    def setRenderHint(*args, **kwargs):
        pass
    
    
    def setRenderHints(*args, **kwargs):
        pass
    
    
    def setResizesToContents(*args, **kwargs):
        pass
    
    
    def setTiledBackingStoreFrozen(*args, **kwargs):
        pass
    
    
    def setUrl(*args, **kwargs):
        pass
    
    
    def setZoomFactor(*args, **kwargs):
        pass
    
    
    def settings(*args, **kwargs):
        pass
    
    
    def sizeHint(*args, **kwargs):
        pass
    
    
    def stop(*args, **kwargs):
        pass
    
    
    def title(*args, **kwargs):
        pass
    
    
    def triggerPageAction(*args, **kwargs):
        pass
    
    
    def updateGeometry(*args, **kwargs):
        pass
    
    
    def url(*args, **kwargs):
        pass
    
    
    def wheelEvent(*args, **kwargs):
        pass
    
    
    def zoomFactor(*args, **kwargs):
        pass
    
    
    __new__ = None
    
    
    iconChanged = None
    
    
    linkClicked = None
    
    
    loadFinished = None
    
    
    loadProgress = None
    
    
    loadStarted = None
    
    
    staticMetaObject = None
    
    
    statusBarMessage = None
    
    
    titleChanged = None
    
    
    urlChanged = None


class QWebFrame(_QObject):
    def addToJavaScriptWindowObject(*args, **kwargs):
        pass
    
    
    def baseUrl(*args, **kwargs):
        pass
    
    
    def childFrames(*args, **kwargs):
        pass
    
    
    def contentsSize(*args, **kwargs):
        pass
    
    
    def documentElement(*args, **kwargs):
        pass
    
    
    def evaluateJavaScript(*args, **kwargs):
        pass
    
    
    def event(*args, **kwargs):
        pass
    
    
    def findAllElements(*args, **kwargs):
        pass
    
    
    def findFirstElement(*args, **kwargs):
        pass
    
    
    def frameName(*args, **kwargs):
        pass
    
    
    def geometry(*args, **kwargs):
        pass
    
    
    def hasFocus(*args, **kwargs):
        pass
    
    
    def hitTestContent(*args, **kwargs):
        pass
    
    
    def icon(*args, **kwargs):
        pass
    
    
    def load(*args, **kwargs):
        pass
    
    
    def metaData(*args, **kwargs):
        pass
    
    
    def page(*args, **kwargs):
        pass
    
    
    def parentFrame(*args, **kwargs):
        pass
    
    
    def pos(*args, **kwargs):
        pass
    
    
    def print_(*args, **kwargs):
        pass
    
    
    def render(*args, **kwargs):
        pass
    
    
    def requestedUrl(*args, **kwargs):
        pass
    
    
    def scroll(*args, **kwargs):
        pass
    
    
    def scrollBarGeometry(*args, **kwargs):
        pass
    
    
    def scrollBarMaximum(*args, **kwargs):
        pass
    
    
    def scrollBarMinimum(*args, **kwargs):
        pass
    
    
    def scrollBarPolicy(*args, **kwargs):
        pass
    
    
    def scrollBarValue(*args, **kwargs):
        pass
    
    
    def scrollPosition(*args, **kwargs):
        pass
    
    
    def scrollToAnchor(*args, **kwargs):
        pass
    
    
    def securityOrigin(*args, **kwargs):
        pass
    
    
    def setContent(*args, **kwargs):
        pass
    
    
    def setFocus(*args, **kwargs):
        pass
    
    
    def setHtml(*args, **kwargs):
        pass
    
    
    def setScrollBarPolicy(*args, **kwargs):
        pass
    
    
    def setScrollBarValue(*args, **kwargs):
        pass
    
    
    def setScrollPosition(*args, **kwargs):
        pass
    
    
    def setTextSizeMultiplier(*args, **kwargs):
        pass
    
    
    def setUrl(*args, **kwargs):
        pass
    
    
    def setZoomFactor(*args, **kwargs):
        pass
    
    
    def textSizeMultiplier(*args, **kwargs):
        pass
    
    
    def title(*args, **kwargs):
        pass
    
    
    def toHtml(*args, **kwargs):
        pass
    
    
    def toPlainText(*args, **kwargs):
        pass
    
    
    def url(*args, **kwargs):
        pass
    
    
    def zoomFactor(*args, **kwargs):
        pass
    
    
    AllLayers = None
    
    
    AutoOwnership = None
    
    
    ContentsLayer = None
    
    
    PanIconLayer = None
    
    
    QtOwnership = None
    
    
    RenderLayer = None
    
    
    RenderLayers = None
    
    
    ScriptOwnership = None
    
    
    ScrollBarLayer = None
    
    
    ValueOwnership = None
    
    
    contentsSizeChanged = None
    
    
    iconChanged = None
    
    
    initialLayoutCompleted = None
    
    
    javaScriptWindowObjectCleared = None
    
    
    loadFinished = None
    
    
    loadStarted = None
    
    
    pageChanged = None
    
    
    provisionalLoad = None
    
    
    staticMetaObject = None
    
    
    titleChanged = None
    
    
    urlChanged = None


class QWebPage(_QObject):
    def __init__(*args, **kwargs):
        """
        x.__init__(...) initializes x; see help(type(x)) for signature
        """
    
        pass
    
    
    def acceptNavigationRequest(*args, **kwargs):
        pass
    
    
    def action(*args, **kwargs):
        pass
    
    
    def bytesReceived(*args, **kwargs):
        pass
    
    
    def chooseFile(*args, **kwargs):
        pass
    
    
    def createPlugin(*args, **kwargs):
        pass
    
    
    def createStandardContextMenu(*args, **kwargs):
        pass
    
    
    def createWindow(*args, **kwargs):
        pass
    
    
    def currentFrame(*args, **kwargs):
        pass
    
    
    def event(*args, **kwargs):
        pass
    
    
    def extension(*args, **kwargs):
        pass
    
    
    def findText(*args, **kwargs):
        pass
    
    
    def focusNextPrevChild(*args, **kwargs):
        pass
    
    
    def forwardUnsupportedContent(*args, **kwargs):
        pass
    
    
    def frameAt(*args, **kwargs):
        pass
    
    
    def hasSelection(*args, **kwargs):
        pass
    
    
    def history(*args, **kwargs):
        pass
    
    
    def inputMethodQuery(*args, **kwargs):
        pass
    
    
    def isContentEditable(*args, **kwargs):
        pass
    
    
    def isModified(*args, **kwargs):
        pass
    
    
    def javaScriptAlert(*args, **kwargs):
        pass
    
    
    def javaScriptConfirm(*args, **kwargs):
        pass
    
    
    def javaScriptConsoleMessage(*args, **kwargs):
        pass
    
    
    def javaScriptPrompt(*args, **kwargs):
        pass
    
    
    def linkDelegationPolicy(*args, **kwargs):
        pass
    
    
    def mainFrame(*args, **kwargs):
        pass
    
    
    def networkAccessManager(*args, **kwargs):
        pass
    
    
    def palette(*args, **kwargs):
        pass
    
    
    def pluginFactory(*args, **kwargs):
        pass
    
    
    def preferredContentsSize(*args, **kwargs):
        pass
    
    
    def selectedHtml(*args, **kwargs):
        pass
    
    
    def selectedText(*args, **kwargs):
        pass
    
    
    def setActualVisibleContentRect(*args, **kwargs):
        pass
    
    
    def setContentEditable(*args, **kwargs):
        pass
    
    
    def setFeaturePermission(*args, **kwargs):
        pass
    
    
    def setForwardUnsupportedContent(*args, **kwargs):
        pass
    
    
    def setLinkDelegationPolicy(*args, **kwargs):
        pass
    
    
    def setNetworkAccessManager(*args, **kwargs):
        pass
    
    
    def setPalette(*args, **kwargs):
        pass
    
    
    def setPluginFactory(*args, **kwargs):
        pass
    
    
    def setPreferredContentsSize(*args, **kwargs):
        pass
    
    
    def setView(*args, **kwargs):
        pass
    
    
    def setViewportSize(*args, **kwargs):
        pass
    
    
    def setVisibilityState(*args, **kwargs):
        pass
    
    
    def settings(*args, **kwargs):
        pass
    
    
    def shouldInterruptJavaScript(*args, **kwargs):
        pass
    
    
    def supportedContentTypes(*args, **kwargs):
        pass
    
    
    def supportsContentType(*args, **kwargs):
        pass
    
    
    def supportsExtension(*args, **kwargs):
        pass
    
    
    def swallowContextMenuEvent(*args, **kwargs):
        pass
    
    
    def totalBytes(*args, **kwargs):
        pass
    
    
    def triggerAction(*args, **kwargs):
        pass
    
    
    def undoStack(*args, **kwargs):
        pass
    
    
    def updatePositionDependentActions(*args, **kwargs):
        pass
    
    
    def userAgentForUrl(*args, **kwargs):
        pass
    
    
    def view(*args, **kwargs):
        pass
    
    
    def viewportAttributesForSize(*args, **kwargs):
        pass
    
    
    def viewportSize(*args, **kwargs):
        pass
    
    
    def visibilityState(*args, **kwargs):
        pass
    
    
    AlignCenter = None
    
    
    AlignJustified = None
    
    
    AlignLeft = None
    
    
    AlignRight = None
    
    
    Back = None
    
    
    ChooseMultipleFilesExtension = None
    
    
    ChooseMultipleFilesExtensionOption = None
    
    
    ChooseMultipleFilesExtensionReturn = None
    
    
    Copy = None
    
    
    CopyImageToClipboard = None
    
    
    CopyImageUrlToClipboard = None
    
    
    CopyLinkToClipboard = None
    
    
    CopyMediaUrlToClipboard = None
    
    
    Cut = None
    
    
    DelegateAllLinks = None
    
    
    DelegateExternalLinks = None
    
    
    DeleteEndOfWord = None
    
    
    DeleteStartOfWord = None
    
    
    DontDelegateLinks = None
    
    
    DownloadImageToDisk = None
    
    
    DownloadLinkToDisk = None
    
    
    DownloadMediaToDisk = None
    
    
    ErrorDomain = None
    
    
    ErrorPageExtension = None
    
    
    ErrorPageExtensionOption = None
    
    
    ErrorPageExtensionReturn = None
    
    
    Extension = None
    
    
    ExtensionOption = None
    
    
    ExtensionReturn = None
    
    
    Feature = None
    
    
    FindAtWordBeginningsOnly = None
    
    
    FindBackward = None
    
    
    FindBeginsInSelection = None
    
    
    FindCaseSensitively = None
    
    
    FindFlag = None
    
    
    FindFlags = None
    
    
    FindWrapsAroundDocument = None
    
    
    Forward = None
    
    
    Geolocation = None
    
    
    HighlightAllOccurrences = None
    
    
    Http = None
    
    
    Indent = None
    
    
    InsertLineSeparator = None
    
    
    InsertOrderedList = None
    
    
    InsertParagraphSeparator = None
    
    
    InsertUnorderedList = None
    
    
    InspectElement = None
    
    
    LinkDelegationPolicy = None
    
    
    MoveToEndOfBlock = None
    
    
    MoveToEndOfDocument = None
    
    
    MoveToEndOfLine = None
    
    
    MoveToNextChar = None
    
    
    MoveToNextLine = None
    
    
    MoveToNextWord = None
    
    
    MoveToPreviousChar = None
    
    
    MoveToPreviousLine = None
    
    
    MoveToPreviousWord = None
    
    
    MoveToStartOfBlock = None
    
    
    MoveToStartOfDocument = None
    
    
    MoveToStartOfLine = None
    
    
    NavigationType = None
    
    
    NavigationTypeBackOrForward = None
    
    
    NavigationTypeFormResubmitted = None
    
    
    NavigationTypeFormSubmitted = None
    
    
    NavigationTypeLinkClicked = None
    
    
    NavigationTypeOther = None
    
    
    NavigationTypeReload = None
    
    
    NoWebAction = None
    
    
    Notifications = None
    
    
    OpenFrameInNewWindow = None
    
    
    OpenImageInNewWindow = None
    
    
    OpenLink = None
    
    
    OpenLinkInNewWindow = None
    
    
    OpenLinkInThisWindow = None
    
    
    Outdent = None
    
    
    Paste = None
    
    
    PasteAndMatchStyle = None
    
    
    PermissionDeniedByUser = None
    
    
    PermissionGrantedByUser = None
    
    
    PermissionPolicy = None
    
    
    PermissionUnknown = None
    
    
    QtNetwork = None
    
    
    Redo = None
    
    
    Reload = None
    
    
    ReloadAndBypassCache = None
    
    
    RemoveFormat = None
    
    
    SelectAll = None
    
    
    SelectEndOfBlock = None
    
    
    SelectEndOfDocument = None
    
    
    SelectEndOfLine = None
    
    
    SelectNextChar = None
    
    
    SelectNextLine = None
    
    
    SelectNextWord = None
    
    
    SelectPreviousChar = None
    
    
    SelectPreviousLine = None
    
    
    SelectPreviousWord = None
    
    
    SelectStartOfBlock = None
    
    
    SelectStartOfDocument = None
    
    
    SelectStartOfLine = None
    
    
    SetTextDirectionDefault = None
    
    
    SetTextDirectionLeftToRight = None
    
    
    SetTextDirectionRightToLeft = None
    
    
    Stop = None
    
    
    StopScheduledPageRefresh = None
    
    
    ToggleBold = None
    
    
    ToggleItalic = None
    
    
    ToggleMediaControls = None
    
    
    ToggleMediaLoop = None
    
    
    ToggleMediaMute = None
    
    
    ToggleMediaPlayPause = None
    
    
    ToggleStrikethrough = None
    
    
    ToggleSubscript = None
    
    
    ToggleSuperscript = None
    
    
    ToggleUnderline = None
    
    
    ToggleVideoFullscreen = None
    
    
    TreatMedialCapitalAsWordBeginning = None
    
    
    Undo = None
    
    
    ViewportAttributes = None
    
    
    VisibilityState = None
    
    
    VisibilityStateHidden = None
    
    
    VisibilityStatePrerender = None
    
    
    VisibilityStateUnloaded = None
    
    
    VisibilityStateVisible = None
    
    
    WebAction = None
    
    
    WebActionCount = None
    
    
    WebBrowserWindow = None
    
    
    WebKit = None
    
    
    WebModalDialog = None
    
    
    WebWindowType = None
    
    
    __new__ = None
    
    
    applicationCacheQuotaExceeded = None
    
    
    contentsChanged = None
    
    
    databaseQuotaExceeded = None
    
    
    downloadRequested = None
    
    
    featurePermissionRequestCanceled = None
    
    
    featurePermissionRequested = None
    
    
    frameCreated = None
    
    
    geometryChangeRequested = None
    
    
    linkClicked = None
    
    
    linkHovered = None
    
    
    loadFinished = None
    
    
    loadProgress = None
    
    
    loadStarted = None
    
    
    menuBarVisibilityChangeRequested = None
    
    
    microFocusChanged = None
    
    
    printRequested = None
    
    
    repaintRequested = None
    
    
    restoreFrameStateRequested = None
    
    
    saveFrameStateRequested = None
    
    
    scrollRequested = None
    
    
    selectionChanged = None
    
    
    staticMetaObject = None
    
    
    statusBarMessage = None
    
    
    statusBarVisibilityChangeRequested = None
    
    
    toolBarVisibilityChangeRequested = None
    
    
    unsupportedContent = None
    
    
    viewportChangeRequested = None
    
    
    windowCloseRequested = None


class QWebHistoryItem(_Object):
    def __copy__(*args, **kwargs):
        pass
    
    
    def __init__(*args, **kwargs):
        """
        x.__init__(...) initializes x; see help(type(x)) for signature
        """
    
        pass
    
    
    def icon(*args, **kwargs):
        pass
    
    
    def isValid(*args, **kwargs):
        pass
    
    
    def lastVisited(*args, **kwargs):
        pass
    
    
    def originalUrl(*args, **kwargs):
        pass
    
    
    def setUserData(*args, **kwargs):
        pass
    
    
    def title(*args, **kwargs):
        pass
    
    
    def url(*args, **kwargs):
        pass
    
    
    def userData(*args, **kwargs):
        pass
    
    
    __new__ = None


class QWebHitTestResult(_Object):
    def __copy__(*args, **kwargs):
        pass
    
    
    def __init__(*args, **kwargs):
        """
        x.__init__(...) initializes x; see help(type(x)) for signature
        """
    
        pass
    
    
    def __nonzero__(*args, **kwargs):
        """
        x.__nonzero__() <==> x != 0
        """
    
        pass
    
    
    def alternateText(*args, **kwargs):
        pass
    
    
    def boundingRect(*args, **kwargs):
        pass
    
    
    def element(*args, **kwargs):
        pass
    
    
    def enclosingBlockElement(*args, **kwargs):
        pass
    
    
    def frame(*args, **kwargs):
        pass
    
    
    def imageUrl(*args, **kwargs):
        pass
    
    
    def isContentEditable(*args, **kwargs):
        pass
    
    
    def isContentSelected(*args, **kwargs):
        pass
    
    
    def isNull(*args, **kwargs):
        pass
    
    
    def linkElement(*args, **kwargs):
        pass
    
    
    def linkTargetFrame(*args, **kwargs):
        pass
    
    
    def linkText(*args, **kwargs):
        pass
    
    
    def linkTitle(*args, **kwargs):
        pass
    
    
    def linkTitleString(*args, **kwargs):
        pass
    
    
    def linkUrl(*args, **kwargs):
        pass
    
    
    def mediaUrl(*args, **kwargs):
        pass
    
    
    def pixmap(*args, **kwargs):
        pass
    
    
    def pos(*args, **kwargs):
        pass
    
    
    def title(*args, **kwargs):
        pass
    
    
    __new__ = None


class QWebDatabase(_Object):
    def __copy__(*args, **kwargs):
        pass
    
    
    def __init__(*args, **kwargs):
        """
        x.__init__(...) initializes x; see help(type(x)) for signature
        """
    
        pass
    
    
    def displayName(*args, **kwargs):
        pass
    
    
    def expectedSize(*args, **kwargs):
        pass
    
    
    def fileName(*args, **kwargs):
        pass
    
    
    def name(*args, **kwargs):
        pass
    
    
    def origin(*args, **kwargs):
        pass
    
    
    def size(*args, **kwargs):
        pass
    
    
    def removeAllDatabases(*args, **kwargs):
        pass
    
    
    def removeDatabase(*args, **kwargs):
        pass
    
    
    __new__ = None



