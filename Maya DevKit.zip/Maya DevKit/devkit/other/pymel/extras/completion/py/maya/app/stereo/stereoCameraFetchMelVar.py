"""
# Description:
#
"""

def getVar(type, varName):
    pass


def setVar(type, varName, value):
    pass



