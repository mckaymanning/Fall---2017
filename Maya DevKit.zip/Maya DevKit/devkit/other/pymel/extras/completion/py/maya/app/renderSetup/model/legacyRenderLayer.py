def isRenderable(legacyRenderLayerName):
    pass


def filterNodes(nodeNames):
    pass


def create(parentName):
    pass


def delete(legacyRenderLayerName):
    pass


def rename(oldLegacyRenderLayerName, newParentName):
    pass


def makeVisible(legacyRenderLayerName):
    pass


def appendNodes(legacyRenderLayerName, nodeNames):
    pass


def isVisible(legacyRenderLayerName):
    pass


def setRenderable(legacyRenderLayerName, value):
    pass


def removeNodes(legacyRenderLayerName):
    pass



