from PySide2.QtCore import QObject as _QObject
from PySide2.QtWidgets import QItemDelegate as _QItemDelegate
from PySide2.QtCore import QAbstractTableModel as _QAbstractTableModel

class _Object(object):
    __dict__ = None


class QSqlRecord(_Object):
    def __copy__(*args, **kwargs):
        pass
    
    
    def __eq__(*args, **kwargs):
        """
        x.__eq__(y) <==> x==y
        """
    
        pass
    
    
    def __ge__(*args, **kwargs):
        """
        x.__ge__(y) <==> x>=y
        """
    
        pass
    
    
    def __gt__(*args, **kwargs):
        """
        x.__gt__(y) <==> x>y
        """
    
        pass
    
    
    def __init__(*args, **kwargs):
        """
        x.__init__(...) initializes x; see help(type(x)) for signature
        """
    
        pass
    
    
    def __le__(*args, **kwargs):
        """
        x.__le__(y) <==> x<=y
        """
    
        pass
    
    
    def __lt__(*args, **kwargs):
        """
        x.__lt__(y) <==> x<y
        """
    
        pass
    
    
    def __ne__(*args, **kwargs):
        """
        x.__ne__(y) <==> x!=y
        """
    
        pass
    
    
    def __repr__(*args, **kwargs):
        """
        x.__repr__() <==> repr(x)
        """
    
        pass
    
    
    def append(*args, **kwargs):
        pass
    
    
    def clear(*args, **kwargs):
        pass
    
    
    def clearValues(*args, **kwargs):
        pass
    
    
    def contains(*args, **kwargs):
        pass
    
    
    def count(*args, **kwargs):
        pass
    
    
    def field(*args, **kwargs):
        pass
    
    
    def fieldName(*args, **kwargs):
        pass
    
    
    def indexOf(*args, **kwargs):
        pass
    
    
    def insert(*args, **kwargs):
        pass
    
    
    def isEmpty(*args, **kwargs):
        pass
    
    
    def isGenerated(*args, **kwargs):
        pass
    
    
    def isNull(*args, **kwargs):
        pass
    
    
    def keyValues(*args, **kwargs):
        pass
    
    
    def remove(*args, **kwargs):
        pass
    
    
    def replace(*args, **kwargs):
        pass
    
    
    def setGenerated(*args, **kwargs):
        pass
    
    
    def setNull(*args, **kwargs):
        pass
    
    
    def setValue(*args, **kwargs):
        pass
    
    
    def value(*args, **kwargs):
        pass
    
    
    __new__ = None


class QSqlQuery(_Object):
    def __copy__(*args, **kwargs):
        pass
    
    
    def __init__(*args, **kwargs):
        """
        x.__init__(...) initializes x; see help(type(x)) for signature
        """
    
        pass
    
    
    def addBindValue(*args, **kwargs):
        pass
    
    
    def at(*args, **kwargs):
        pass
    
    
    def bindValue(*args, **kwargs):
        pass
    
    
    def boundValue(*args, **kwargs):
        pass
    
    
    def boundValues(*args, **kwargs):
        pass
    
    
    def clear(*args, **kwargs):
        pass
    
    
    def driver(*args, **kwargs):
        pass
    
    
    def execBatch(*args, **kwargs):
        pass
    
    
    def exec_(*args, **kwargs):
        pass
    
    
    def executedQuery(*args, **kwargs):
        pass
    
    
    def finish(*args, **kwargs):
        pass
    
    
    def first(*args, **kwargs):
        pass
    
    
    def isActive(*args, **kwargs):
        pass
    
    
    def isForwardOnly(*args, **kwargs):
        pass
    
    
    def isNull(*args, **kwargs):
        pass
    
    
    def isSelect(*args, **kwargs):
        pass
    
    
    def isValid(*args, **kwargs):
        pass
    
    
    def last(*args, **kwargs):
        pass
    
    
    def lastError(*args, **kwargs):
        pass
    
    
    def lastInsertId(*args, **kwargs):
        pass
    
    
    def lastQuery(*args, **kwargs):
        pass
    
    
    def next(*args, **kwargs):
        pass
    
    
    def nextResult(*args, **kwargs):
        pass
    
    
    def numRowsAffected(*args, **kwargs):
        pass
    
    
    def numericalPrecisionPolicy(*args, **kwargs):
        pass
    
    
    def prepare(*args, **kwargs):
        pass
    
    
    def previous(*args, **kwargs):
        pass
    
    
    def record(*args, **kwargs):
        pass
    
    
    def result(*args, **kwargs):
        pass
    
    
    def seek(*args, **kwargs):
        pass
    
    
    def setForwardOnly(*args, **kwargs):
        pass
    
    
    def setNumericalPrecisionPolicy(*args, **kwargs):
        pass
    
    
    def size(*args, **kwargs):
        pass
    
    
    def value(*args, **kwargs):
        pass
    
    
    BatchExecutionMode = None
    
    
    ValuesAsColumns = None
    
    
    ValuesAsRows = None
    
    
    __new__ = None


class QSqlRelation(_Object):
    def __copy__(*args, **kwargs):
        pass
    
    
    def __init__(*args, **kwargs):
        """
        x.__init__(...) initializes x; see help(type(x)) for signature
        """
    
        pass
    
    
    def displayColumn(*args, **kwargs):
        pass
    
    
    def indexColumn(*args, **kwargs):
        pass
    
    
    def isValid(*args, **kwargs):
        pass
    
    
    def tableName(*args, **kwargs):
        pass
    
    
    __new__ = None


class QSqlDriverCreatorBase(_Object):
    def __init__(*args, **kwargs):
        """
        x.__init__(...) initializes x; see help(type(x)) for signature
        """
    
        pass
    
    
    def createObject(*args, **kwargs):
        pass
    
    
    __new__ = None


class QSqlDriver(_QObject):
    def __init__(*args, **kwargs):
        """
        x.__init__(...) initializes x; see help(type(x)) for signature
        """
    
        pass
    
    
    def beginTransaction(*args, **kwargs):
        pass
    
    
    def cancelQuery(*args, **kwargs):
        pass
    
    
    def close(*args, **kwargs):
        pass
    
    
    def commitTransaction(*args, **kwargs):
        pass
    
    
    def createResult(*args, **kwargs):
        pass
    
    
    def dbmsType(*args, **kwargs):
        pass
    
    
    def escapeIdentifier(*args, **kwargs):
        pass
    
    
    def formatValue(*args, **kwargs):
        pass
    
    
    def hasFeature(*args, **kwargs):
        pass
    
    
    def isIdentifierEscaped(*args, **kwargs):
        pass
    
    
    def isOpen(*args, **kwargs):
        pass
    
    
    def isOpenError(*args, **kwargs):
        pass
    
    
    def lastError(*args, **kwargs):
        pass
    
    
    def numericalPrecisionPolicy(*args, **kwargs):
        pass
    
    
    def open(*args, **kwargs):
        pass
    
    
    def primaryIndex(*args, **kwargs):
        pass
    
    
    def record(*args, **kwargs):
        pass
    
    
    def rollbackTransaction(*args, **kwargs):
        pass
    
    
    def setLastError(*args, **kwargs):
        pass
    
    
    def setNumericalPrecisionPolicy(*args, **kwargs):
        pass
    
    
    def setOpen(*args, **kwargs):
        pass
    
    
    def setOpenError(*args, **kwargs):
        pass
    
    
    def sqlStatement(*args, **kwargs):
        pass
    
    
    def stripDelimiters(*args, **kwargs):
        pass
    
    
    def subscribeToNotification(*args, **kwargs):
        pass
    
    
    def subscribedToNotifications(*args, **kwargs):
        pass
    
    
    def tables(*args, **kwargs):
        pass
    
    
    def unsubscribeFromNotification(*args, **kwargs):
        pass
    
    
    BLOB = None
    
    
    BatchOperations = None
    
    
    CancelQuery = None
    
    
    DB2 = None
    
    
    DbmsType = None
    
    
    DeleteStatement = None
    
    
    DriverFeature = None
    
    
    EventNotifications = None
    
    
    FieldName = None
    
    
    FinishQuery = None
    
    
    IdentifierType = None
    
    
    InsertStatement = None
    
    
    Interbase = None
    
    
    LastInsertId = None
    
    
    LowPrecisionNumbers = None
    
    
    MSSqlServer = None
    
    
    MultipleResultSets = None
    
    
    MySqlServer = None
    
    
    NamedPlaceholders = None
    
    
    NotificationSource = None
    
    
    Oracle = None
    
    
    OtherSource = None
    
    
    PositionalPlaceholders = None
    
    
    PostgreSQL = None
    
    
    PreparedQueries = None
    
    
    QuerySize = None
    
    
    SQLite = None
    
    
    SelectStatement = None
    
    
    SelfSource = None
    
    
    SimpleLocking = None
    
    
    StatementType = None
    
    
    Sybase = None
    
    
    TableName = None
    
    
    Transactions = None
    
    
    Unicode = None
    
    
    UnknownDbms = None
    
    
    UnknownSource = None
    
    
    UpdateStatement = None
    
    
    WhereStatement = None
    
    
    __new__ = None
    
    
    notification = None
    
    
    staticMetaObject = None


class QSqlRelationalDelegate(_QItemDelegate):
    def __init__(*args, **kwargs):
        """
        x.__init__(...) initializes x; see help(type(x)) for signature
        """
    
        pass
    
    
    def createEditor(*args, **kwargs):
        pass
    
    
    def setModelData(*args, **kwargs):
        pass
    
    
    __new__ = None
    
    
    staticMetaObject = None


class QSqlResult(_Object):
    def __init__(*args, **kwargs):
        """
        x.__init__(...) initializes x; see help(type(x)) for signature
        """
    
        pass
    
    
    def addBindValue(*args, **kwargs):
        pass
    
    
    def at(*args, **kwargs):
        pass
    
    
    def bindValue(*args, **kwargs):
        pass
    
    
    def bindValueType(*args, **kwargs):
        pass
    
    
    def bindingSyntax(*args, **kwargs):
        pass
    
    
    def boundValue(*args, **kwargs):
        pass
    
    
    def boundValueCount(*args, **kwargs):
        pass
    
    
    def boundValueName(*args, **kwargs):
        pass
    
    
    def boundValues(*args, **kwargs):
        pass
    
    
    def clear(*args, **kwargs):
        pass
    
    
    def data(*args, **kwargs):
        pass
    
    
    def detachFromResultSet(*args, **kwargs):
        pass
    
    
    def driver(*args, **kwargs):
        pass
    
    
    def execBatch(*args, **kwargs):
        pass
    
    
    def exec_(*args, **kwargs):
        pass
    
    
    def executedQuery(*args, **kwargs):
        pass
    
    
    def fetch(*args, **kwargs):
        pass
    
    
    def fetchFirst(*args, **kwargs):
        pass
    
    
    def fetchLast(*args, **kwargs):
        pass
    
    
    def fetchNext(*args, **kwargs):
        pass
    
    
    def fetchPrevious(*args, **kwargs):
        pass
    
    
    def handle(*args, **kwargs):
        pass
    
    
    def hasOutValues(*args, **kwargs):
        pass
    
    
    def isActive(*args, **kwargs):
        pass
    
    
    def isForwardOnly(*args, **kwargs):
        pass
    
    
    def isNull(*args, **kwargs):
        pass
    
    
    def isSelect(*args, **kwargs):
        pass
    
    
    def isValid(*args, **kwargs):
        pass
    
    
    def lastError(*args, **kwargs):
        pass
    
    
    def lastInsertId(*args, **kwargs):
        pass
    
    
    def lastQuery(*args, **kwargs):
        pass
    
    
    def nextResult(*args, **kwargs):
        pass
    
    
    def numRowsAffected(*args, **kwargs):
        pass
    
    
    def numericalPrecisionPolicy(*args, **kwargs):
        pass
    
    
    def prepare(*args, **kwargs):
        pass
    
    
    def record(*args, **kwargs):
        pass
    
    
    def reset(*args, **kwargs):
        pass
    
    
    def resetBindCount(*args, **kwargs):
        pass
    
    
    def savePrepare(*args, **kwargs):
        pass
    
    
    def setActive(*args, **kwargs):
        pass
    
    
    def setAt(*args, **kwargs):
        pass
    
    
    def setForwardOnly(*args, **kwargs):
        pass
    
    
    def setLastError(*args, **kwargs):
        pass
    
    
    def setNumericalPrecisionPolicy(*args, **kwargs):
        pass
    
    
    def setQuery(*args, **kwargs):
        pass
    
    
    def setSelect(*args, **kwargs):
        pass
    
    
    def size(*args, **kwargs):
        pass
    
    
    BindingSyntax = None
    
    
    NamedBinding = None
    
    
    PositionalBinding = None
    
    
    VirtualHookOperation = None
    
    
    __new__ = None


class QSql(_Object):
    AfterLastRow = None
    
    
    AllTables = None
    
    
    BeforeFirstRow = None
    
    
    Binary = None
    
    
    HighPrecision = None
    
    
    In = None
    
    
    InOut = None
    
    
    Location = None
    
    
    LowPrecisionDouble = None
    
    
    LowPrecisionInt32 = None
    
    
    LowPrecisionInt64 = None
    
    
    NumericalPrecisionPolicy = None
    
    
    Out = None
    
    
    ParamType = None
    
    
    ParamTypeFlag = None
    
    
    SystemTables = None
    
    
    TableType = None
    
    
    Tables = None
    
    
    Views = None


class QSqlError(_Object):
    def __copy__(*args, **kwargs):
        pass
    
    
    def __eq__(*args, **kwargs):
        """
        x.__eq__(y) <==> x==y
        """
    
        pass
    
    
    def __ge__(*args, **kwargs):
        """
        x.__ge__(y) <==> x>=y
        """
    
        pass
    
    
    def __gt__(*args, **kwargs):
        """
        x.__gt__(y) <==> x>y
        """
    
        pass
    
    
    def __init__(*args, **kwargs):
        """
        x.__init__(...) initializes x; see help(type(x)) for signature
        """
    
        pass
    
    
    def __le__(*args, **kwargs):
        """
        x.__le__(y) <==> x<=y
        """
    
        pass
    
    
    def __lt__(*args, **kwargs):
        """
        x.__lt__(y) <==> x<y
        """
    
        pass
    
    
    def __ne__(*args, **kwargs):
        """
        x.__ne__(y) <==> x!=y
        """
    
        pass
    
    
    def __repr__(*args, **kwargs):
        """
        x.__repr__() <==> repr(x)
        """
    
        pass
    
    
    def databaseText(*args, **kwargs):
        pass
    
    
    def driverText(*args, **kwargs):
        pass
    
    
    def isValid(*args, **kwargs):
        pass
    
    
    def nativeErrorCode(*args, **kwargs):
        pass
    
    
    def number(*args, **kwargs):
        pass
    
    
    def setDatabaseText(*args, **kwargs):
        pass
    
    
    def setDriverText(*args, **kwargs):
        pass
    
    
    def setNumber(*args, **kwargs):
        pass
    
    
    def setType(*args, **kwargs):
        pass
    
    
    def text(*args, **kwargs):
        pass
    
    
    def type(*args, **kwargs):
        pass
    
    
    ConnectionError = None
    
    
    ErrorType = None
    
    
    NoError = None
    
    
    StatementError = None
    
    
    TransactionError = None
    
    
    UnknownError = None
    
    
    __new__ = None


class QSqlDatabase(_Object):
    def __copy__(*args, **kwargs):
        pass
    
    
    def __init__(*args, **kwargs):
        """
        x.__init__(...) initializes x; see help(type(x)) for signature
        """
    
        pass
    
    
    def __repr__(*args, **kwargs):
        """
        x.__repr__() <==> repr(x)
        """
    
        pass
    
    
    def close(*args, **kwargs):
        pass
    
    
    def commit(*args, **kwargs):
        pass
    
    
    def connectOptions(*args, **kwargs):
        pass
    
    
    def connectionName(*args, **kwargs):
        pass
    
    
    def databaseName(*args, **kwargs):
        pass
    
    
    def driver(*args, **kwargs):
        pass
    
    
    def driverName(*args, **kwargs):
        pass
    
    
    def exec_(*args, **kwargs):
        pass
    
    
    def hostName(*args, **kwargs):
        pass
    
    
    def isOpen(*args, **kwargs):
        pass
    
    
    def isOpenError(*args, **kwargs):
        pass
    
    
    def isValid(*args, **kwargs):
        pass
    
    
    def lastError(*args, **kwargs):
        pass
    
    
    def numericalPrecisionPolicy(*args, **kwargs):
        pass
    
    
    def open(*args, **kwargs):
        pass
    
    
    def password(*args, **kwargs):
        pass
    
    
    def port(*args, **kwargs):
        pass
    
    
    def primaryIndex(*args, **kwargs):
        pass
    
    
    def record(*args, **kwargs):
        pass
    
    
    def rollback(*args, **kwargs):
        pass
    
    
    def setConnectOptions(*args, **kwargs):
        pass
    
    
    def setDatabaseName(*args, **kwargs):
        pass
    
    
    def setHostName(*args, **kwargs):
        pass
    
    
    def setNumericalPrecisionPolicy(*args, **kwargs):
        pass
    
    
    def setPassword(*args, **kwargs):
        pass
    
    
    def setPort(*args, **kwargs):
        pass
    
    
    def setUserName(*args, **kwargs):
        pass
    
    
    def tables(*args, **kwargs):
        pass
    
    
    def transaction(*args, **kwargs):
        pass
    
    
    def userName(*args, **kwargs):
        pass
    
    
    def addDatabase(*args, **kwargs):
        pass
    
    
    def cloneDatabase(*args, **kwargs):
        pass
    
    
    def connectionNames(*args, **kwargs):
        pass
    
    
    def contains(*args, **kwargs):
        pass
    
    
    def database(*args, **kwargs):
        pass
    
    
    def drivers(*args, **kwargs):
        pass
    
    
    def isDriverAvailable(*args, **kwargs):
        pass
    
    
    def registerSqlDriver(*args, **kwargs):
        pass
    
    
    def removeDatabase(*args, **kwargs):
        pass
    
    
    __new__ = None
    
    
    defaultConnection = 'qt_sql_default_connection'


class QSqlField(_Object):
    def __copy__(*args, **kwargs):
        pass
    
    
    def __eq__(*args, **kwargs):
        """
        x.__eq__(y) <==> x==y
        """
    
        pass
    
    
    def __ge__(*args, **kwargs):
        """
        x.__ge__(y) <==> x>=y
        """
    
        pass
    
    
    def __gt__(*args, **kwargs):
        """
        x.__gt__(y) <==> x>y
        """
    
        pass
    
    
    def __init__(*args, **kwargs):
        """
        x.__init__(...) initializes x; see help(type(x)) for signature
        """
    
        pass
    
    
    def __le__(*args, **kwargs):
        """
        x.__le__(y) <==> x<=y
        """
    
        pass
    
    
    def __lt__(*args, **kwargs):
        """
        x.__lt__(y) <==> x<y
        """
    
        pass
    
    
    def __ne__(*args, **kwargs):
        """
        x.__ne__(y) <==> x!=y
        """
    
        pass
    
    
    def __nonzero__(*args, **kwargs):
        """
        x.__nonzero__() <==> x != 0
        """
    
        pass
    
    
    def __repr__(*args, **kwargs):
        """
        x.__repr__() <==> repr(x)
        """
    
        pass
    
    
    def clear(*args, **kwargs):
        pass
    
    
    def defaultValue(*args, **kwargs):
        pass
    
    
    def isAutoValue(*args, **kwargs):
        pass
    
    
    def isGenerated(*args, **kwargs):
        pass
    
    
    def isNull(*args, **kwargs):
        pass
    
    
    def isReadOnly(*args, **kwargs):
        pass
    
    
    def isValid(*args, **kwargs):
        pass
    
    
    def length(*args, **kwargs):
        pass
    
    
    def name(*args, **kwargs):
        pass
    
    
    def precision(*args, **kwargs):
        pass
    
    
    def requiredStatus(*args, **kwargs):
        pass
    
    
    def setAutoValue(*args, **kwargs):
        pass
    
    
    def setDefaultValue(*args, **kwargs):
        pass
    
    
    def setGenerated(*args, **kwargs):
        pass
    
    
    def setLength(*args, **kwargs):
        pass
    
    
    def setName(*args, **kwargs):
        pass
    
    
    def setPrecision(*args, **kwargs):
        pass
    
    
    def setReadOnly(*args, **kwargs):
        pass
    
    
    def setRequired(*args, **kwargs):
        pass
    
    
    def setRequiredStatus(*args, **kwargs):
        pass
    
    
    def setSqlType(*args, **kwargs):
        pass
    
    
    def setType(*args, **kwargs):
        pass
    
    
    def setValue(*args, **kwargs):
        pass
    
    
    def type(*args, **kwargs):
        pass
    
    
    def typeID(*args, **kwargs):
        pass
    
    
    def value(*args, **kwargs):
        pass
    
    
    Optional = None
    
    
    Required = None
    
    
    RequiredStatus = None
    
    
    Unknown = None
    
    
    __new__ = None


class QSqlQueryModel(_QAbstractTableModel):
    def __init__(*args, **kwargs):
        """
        x.__init__(...) initializes x; see help(type(x)) for signature
        """
    
        pass
    
    
    def beginInsertColumns(*args, **kwargs):
        pass
    
    
    def beginInsertRows(*args, **kwargs):
        pass
    
    
    def beginRemoveColumns(*args, **kwargs):
        pass
    
    
    def beginRemoveRows(*args, **kwargs):
        pass
    
    
    def beginResetModel(*args, **kwargs):
        pass
    
    
    def canFetchMore(*args, **kwargs):
        pass
    
    
    def clear(*args, **kwargs):
        pass
    
    
    def columnCount(*args, **kwargs):
        pass
    
    
    def data(*args, **kwargs):
        pass
    
    
    def endInsertColumns(*args, **kwargs):
        pass
    
    
    def endInsertRows(*args, **kwargs):
        pass
    
    
    def endRemoveColumns(*args, **kwargs):
        pass
    
    
    def endRemoveRows(*args, **kwargs):
        pass
    
    
    def endResetModel(*args, **kwargs):
        pass
    
    
    def fetchMore(*args, **kwargs):
        pass
    
    
    def headerData(*args, **kwargs):
        pass
    
    
    def indexInQuery(*args, **kwargs):
        pass
    
    
    def insertColumns(*args, **kwargs):
        pass
    
    
    def lastError(*args, **kwargs):
        pass
    
    
    def query(*args, **kwargs):
        pass
    
    
    def queryChange(*args, **kwargs):
        pass
    
    
    def record(*args, **kwargs):
        pass
    
    
    def removeColumns(*args, **kwargs):
        pass
    
    
    def rowCount(*args, **kwargs):
        pass
    
    
    def setHeaderData(*args, **kwargs):
        pass
    
    
    def setLastError(*args, **kwargs):
        pass
    
    
    def setQuery(*args, **kwargs):
        pass
    
    
    __new__ = None
    
    
    staticMetaObject = None


class QSqlIndex(QSqlRecord):
    def __copy__(*args, **kwargs):
        pass
    
    
    def __init__(*args, **kwargs):
        """
        x.__init__(...) initializes x; see help(type(x)) for signature
        """
    
        pass
    
    
    def append(*args, **kwargs):
        pass
    
    
    def cursorName(*args, **kwargs):
        pass
    
    
    def isDescending(*args, **kwargs):
        pass
    
    
    def name(*args, **kwargs):
        pass
    
    
    def setCursorName(*args, **kwargs):
        pass
    
    
    def setDescending(*args, **kwargs):
        pass
    
    
    def setName(*args, **kwargs):
        pass
    
    
    __new__ = None


class QSqlTableModel(QSqlQueryModel):
    def __init__(*args, **kwargs):
        """
        x.__init__(...) initializes x; see help(type(x)) for signature
        """
    
        pass
    
    
    def clear(*args, **kwargs):
        pass
    
    
    def data(*args, **kwargs):
        pass
    
    
    def database(*args, **kwargs):
        pass
    
    
    def deleteRowFromTable(*args, **kwargs):
        pass
    
    
    def editStrategy(*args, **kwargs):
        pass
    
    
    def fieldIndex(*args, **kwargs):
        pass
    
    
    def filter(*args, **kwargs):
        pass
    
    
    def flags(*args, **kwargs):
        pass
    
    
    def headerData(*args, **kwargs):
        pass
    
    
    def indexInQuery(*args, **kwargs):
        pass
    
    
    def insertRecord(*args, **kwargs):
        pass
    
    
    def insertRowIntoTable(*args, **kwargs):
        pass
    
    
    def insertRows(*args, **kwargs):
        pass
    
    
    def isDirty(*args, **kwargs):
        pass
    
    
    def orderByClause(*args, **kwargs):
        pass
    
    
    def primaryKey(*args, **kwargs):
        pass
    
    
    def primaryValues(*args, **kwargs):
        pass
    
    
    def record(*args, **kwargs):
        pass
    
    
    def removeColumns(*args, **kwargs):
        pass
    
    
    def removeRows(*args, **kwargs):
        pass
    
    
    def revert(*args, **kwargs):
        pass
    
    
    def revertAll(*args, **kwargs):
        pass
    
    
    def revertRow(*args, **kwargs):
        pass
    
    
    def rowCount(*args, **kwargs):
        pass
    
    
    def select(*args, **kwargs):
        pass
    
    
    def selectRow(*args, **kwargs):
        pass
    
    
    def selectStatement(*args, **kwargs):
        pass
    
    
    def setData(*args, **kwargs):
        pass
    
    
    def setEditStrategy(*args, **kwargs):
        pass
    
    
    def setFilter(*args, **kwargs):
        pass
    
    
    def setPrimaryKey(*args, **kwargs):
        pass
    
    
    def setQuery(*args, **kwargs):
        pass
    
    
    def setRecord(*args, **kwargs):
        pass
    
    
    def setSort(*args, **kwargs):
        pass
    
    
    def setTable(*args, **kwargs):
        pass
    
    
    def sort(*args, **kwargs):
        pass
    
    
    def submit(*args, **kwargs):
        pass
    
    
    def submitAll(*args, **kwargs):
        pass
    
    
    def tableName(*args, **kwargs):
        pass
    
    
    def updateRowInTable(*args, **kwargs):
        pass
    
    
    EditStrategy = None
    
    
    OnFieldChange = None
    
    
    OnManualSubmit = None
    
    
    OnRowChange = None
    
    
    __new__ = None
    
    
    beforeDelete = None
    
    
    beforeInsert = None
    
    
    beforeUpdate = None
    
    
    primeInsert = None
    
    
    staticMetaObject = None


class QSqlRelationalTableModel(QSqlTableModel):
    def __init__(*args, **kwargs):
        """
        x.__init__(...) initializes x; see help(type(x)) for signature
        """
    
        pass
    
    
    def clear(*args, **kwargs):
        pass
    
    
    def data(*args, **kwargs):
        pass
    
    
    def insertRowIntoTable(*args, **kwargs):
        pass
    
    
    def orderByClause(*args, **kwargs):
        pass
    
    
    def relation(*args, **kwargs):
        pass
    
    
    def relationModel(*args, **kwargs):
        pass
    
    
    def removeColumns(*args, **kwargs):
        pass
    
    
    def revertRow(*args, **kwargs):
        pass
    
    
    def select(*args, **kwargs):
        pass
    
    
    def selectStatement(*args, **kwargs):
        pass
    
    
    def setData(*args, **kwargs):
        pass
    
    
    def setJoinMode(*args, **kwargs):
        pass
    
    
    def setRelation(*args, **kwargs):
        pass
    
    
    def setTable(*args, **kwargs):
        pass
    
    
    def updateRowInTable(*args, **kwargs):
        pass
    
    
    InnerJoin = None
    
    
    JoinMode = None
    
    
    LeftJoin = None
    
    
    __new__ = None
    
    
    staticMetaObject = None



