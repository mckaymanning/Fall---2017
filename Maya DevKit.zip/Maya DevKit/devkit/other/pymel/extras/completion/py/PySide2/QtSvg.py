from PySide2.QtCore import QObject as _QObject
from PySide2.QtGui import QPaintDevice as _QPaintDevice
from PySide2.QtWidgets import QWidget as _QWidget
from PySide2.QtWidgets import QGraphicsObject as _QGraphicsObject

class QGraphicsSvgItem(_QGraphicsObject):
    def __init__(*args, **kwargs):
        """
        x.__init__(...) initializes x; see help(type(x)) for signature
        """
    
        pass
    
    
    def boundingRect(*args, **kwargs):
        pass
    
    
    def elementId(*args, **kwargs):
        pass
    
    
    def isCachingEnabled(*args, **kwargs):
        pass
    
    
    def maximumCacheSize(*args, **kwargs):
        pass
    
    
    def paint(*args, **kwargs):
        pass
    
    
    def renderer(*args, **kwargs):
        pass
    
    
    def setCachingEnabled(*args, **kwargs):
        pass
    
    
    def setElementId(*args, **kwargs):
        pass
    
    
    def setMaximumCacheSize(*args, **kwargs):
        pass
    
    
    def setSharedRenderer(*args, **kwargs):
        pass
    
    
    def type(*args, **kwargs):
        pass
    
    
    __new__ = None
    
    
    staticMetaObject = None


class QSvgGenerator(_QPaintDevice):
    def __init__(*args, **kwargs):
        """
        x.__init__(...) initializes x; see help(type(x)) for signature
        """
    
        pass
    
    
    def description(*args, **kwargs):
        pass
    
    
    def fileName(*args, **kwargs):
        pass
    
    
    def metric(*args, **kwargs):
        pass
    
    
    def outputDevice(*args, **kwargs):
        pass
    
    
    def paintEngine(*args, **kwargs):
        pass
    
    
    def resolution(*args, **kwargs):
        pass
    
    
    def setDescription(*args, **kwargs):
        pass
    
    
    def setFileName(*args, **kwargs):
        pass
    
    
    def setOutputDevice(*args, **kwargs):
        pass
    
    
    def setResolution(*args, **kwargs):
        pass
    
    
    def setSize(*args, **kwargs):
        pass
    
    
    def setTitle(*args, **kwargs):
        pass
    
    
    def setViewBox(*args, **kwargs):
        pass
    
    
    def size(*args, **kwargs):
        pass
    
    
    def title(*args, **kwargs):
        pass
    
    
    def viewBox(*args, **kwargs):
        pass
    
    
    def viewBoxF(*args, **kwargs):
        pass
    
    
    __new__ = None


class QSvgRenderer(_QObject):
    def __init__(*args, **kwargs):
        """
        x.__init__(...) initializes x; see help(type(x)) for signature
        """
    
        pass
    
    
    def animated(*args, **kwargs):
        pass
    
    
    def animationDuration(*args, **kwargs):
        pass
    
    
    def boundsOnElement(*args, **kwargs):
        pass
    
    
    def currentFrame(*args, **kwargs):
        pass
    
    
    def defaultSize(*args, **kwargs):
        pass
    
    
    def elementExists(*args, **kwargs):
        pass
    
    
    def framesPerSecond(*args, **kwargs):
        pass
    
    
    def isValid(*args, **kwargs):
        pass
    
    
    def load(*args, **kwargs):
        pass
    
    
    def matrixForElement(*args, **kwargs):
        pass
    
    
    def render(*args, **kwargs):
        pass
    
    
    def setCurrentFrame(*args, **kwargs):
        pass
    
    
    def setFramesPerSecond(*args, **kwargs):
        pass
    
    
    def setViewBox(*args, **kwargs):
        pass
    
    
    def viewBox(*args, **kwargs):
        pass
    
    
    def viewBoxF(*args, **kwargs):
        pass
    
    
    __new__ = None
    
    
    repaintNeeded = None
    
    
    staticMetaObject = None


class QSvgWidget(_QWidget):
    def __init__(*args, **kwargs):
        """
        x.__init__(...) initializes x; see help(type(x)) for signature
        """
    
        pass
    
    
    def load(*args, **kwargs):
        pass
    
    
    def paintEvent(*args, **kwargs):
        pass
    
    
    def renderer(*args, **kwargs):
        pass
    
    
    def sizeHint(*args, **kwargs):
        pass
    
    
    __new__ = None
    
    
    staticMetaObject = None



